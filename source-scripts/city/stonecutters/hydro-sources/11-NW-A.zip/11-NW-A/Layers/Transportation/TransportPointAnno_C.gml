<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821024.46768 830024.77859</gml:lowerCorner>
<gml:upperCorner>823986.99793 833710.88809</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id50ea96e1-f5b1-49e5-a2c1-116cdf2426a0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-26.5650366999524</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000088</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831115.83056963</fme:EASTING>
<fme:NORTHING>822802.55547432</fme:NORTHING>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018266</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822798.04957 831132.53368</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id3d1c6bfc-9423-4cb1-b9a1-bd23fade89f8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>蝴蝶谷道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000029</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832769.95205906</fme:EASTING>
<fme:NORTHING>822344.67141546</fme:NORTHING>
<fme:ST_CODE>10101</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015919</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822331.23861 832786.55539</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idc81cd5f3-e10d-4648-b2e7-4748973c942b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>光昌街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.1005799334211</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000073</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833663.72788209</fme:EASTING>
<fme:NORTHING>822232.95843325</fme:NORTHING>
<fme:ST_CODE>11118</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016049</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822221.09230 833671.07162</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id2d853f7e-3494-4b6d-b62b-65c6c71fbda0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>興華街西</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>41.1859290722071</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000296</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832780.71026661</fme:EASTING>
<fme:NORTHING>821104.4115224</fme:NORTHING>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015744</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821118.98571 832793.01362</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idd2678348-c8fa-4a16-bd46-b7ebbc22f9b6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永德路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000306</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833591.5755777</fme:EASTING>
<fme:NORTHING>822434.02100129</fme:NORTHING>
<fme:ST_CODE>39310</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015409</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822442.94062 833603.98816</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idc9bc939e-82b1-4892-816d-574af1acc5a7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗祖路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.8699184175314</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000575</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831537.10777928</fme:EASTING>
<fme:NORTHING>823938.46384576</fme:NORTHING>
<fme:ST_CODE>11151</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000199</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823928.53291 831550.34903</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idd2bd75b2-a705-4bc5-8bba-7824d5b89c98">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>呈祥道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000518</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832229.0841647</fme:EASTING>
<fme:NORTHING>822472.0830833</fme:NORTHING>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015922</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822475.01784 832247.23696</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id538214f0-ad70-491e-aafe-c6a42dccc314">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華員徑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-88.7078539371397</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000602</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832093.17051502</fme:EASTING>
<fme:NORTHING>823388.35429774</fme:NORTHING>
<fme:ST_CODE>12599</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016827</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823374.39487 832096.35250</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id417d837b-a9ef-480d-9db2-ec62bf597f0e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>聯接街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-33.5304978158247</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000646</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831190.66046571</fme:EASTING>
<fme:NORTHING>823624.73925989</fme:NORTHING>
<fme:ST_CODE>10901</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002940</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823619.48886 831198.58380</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idcd6f9fe3-668d-49fe-810f-c9c6e26c49a9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青葵公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-34.0459319690059</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000750</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831299.23348458</fme:EASTING>
<fme:NORTHING>822667.90953452</fme:NORTHING>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016740</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822656.37899 831323.46642</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="iddc8450d1-48f4-4f6d-98a3-9c7e33797b06">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>百老匯街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-25.0306978639242</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000921</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832321.13248147</fme:EASTING>
<fme:NORTHING>821898.15814683</fme:NORTHING>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015959</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821892.86108 832339.25088</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id839adc48-8ef0-4e02-aa9b-71947fe78eda">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-3.78253058700072</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000925</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832480.795</fme:EASTING>
<fme:NORTHING>821968.231</fme:NORTHING>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006289</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821968.43352 832480.97617</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id4ad443b4-44db-43d0-a255-b2209f757c02">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景山路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.2348391386127</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001073</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831140.805</fme:EASTING>
<fme:NORTHING>823507.521</fme:NORTHING>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210029388</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823507.32653 831140.56319</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7baae76b-80cb-4a6f-a004-51f21e3f2a64">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵泰路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-26.9474714693139</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001039</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830812.15079592</fme:EASTING>
<fme:NORTHING>823590.8956087</fme:NORTHING>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016998</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823586.99989 830826.13907</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7f3333a8-5486-4a50-a321-1d86b09ccc0b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔灣道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>64.9164100835488</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001118</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832214.21896131</fme:EASTING>
<fme:NORTHING>822001.96211353</fme:NORTHING>
<fme:ST_CODE>11163</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015925</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822016.05372 832217.65017</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id1fdbcc51-0597-4360-b685-1e798fad9547">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西九龍公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-22.479429281747</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001147</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832265.30447276</fme:EASTING>
<fme:NORTHING>821606.47329253</fme:NORTHING>
<fme:ST_CODE>13885</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015834</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821583.27736 832321.36132</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id86b3ce0c-caec-4bd5-b143-c9ff8170de10">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝嶺路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002039</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831569.83924375</fme:EASTING>
<fme:NORTHING>823324.96607244</fme:NORTHING>
<fme:ST_CODE>11150</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016745</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823314.57733 831587.56645</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id852c1b93-6e42-4fc7-ae7a-875953860253">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>發祥街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.7781115307654</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002368</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833703.902</fme:EASTING>
<fme:NORTHING>821451.822</fme:NORTHING>
<fme:ST_CODE>10475</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210025903</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821451.82203 833703.90199</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id99fc24f1-7b1d-4882-b937-6e46a3a694c6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>敬祖路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001761</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831357.08596913</fme:EASTING>
<fme:NORTHING>822993.20562957</fme:NORTHING>
<fme:ST_CODE>11021</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016418</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822995.75729 831372.39690</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9442c5bb-32eb-45f3-a421-8f988c75e6cf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>百老匯街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-10.3986860416884</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002098</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832644.86948529</fme:EASTING>
<fme:NORTHING>821816.19795786</fme:NORTHING>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014904</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821815.64957 832663.73837</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id278c8c70-3158-4567-9d43-04e064db8c7e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青葵公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002398</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830261.14235194</fme:EASTING>
<fme:NORTHING>823655.02061324</fme:NORTHING>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002663</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823668.95854 830285.50254</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idc14392e9-5df1-4442-9ea3-3e9f619f9a46">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔發街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.5881196523128</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001447</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833609.79046354</fme:EASTING>
<fme:NORTHING>821482.20761369</fme:NORTHING>
<fme:ST_CODE>11152</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016106</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821475.44041 833617.97406</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ida151bb60-f15a-421e-81ac-d921ec85ca02">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荃灣路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.18608820634</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002421</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830813.24889737</fme:EASTING>
<fme:NORTHING>823993.10356523</fme:NORTHING>
<fme:ST_CODE>12469</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003032</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823985.08189 830825.25921</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id78cfa415-8776-4387-baa5-cdc815906344">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青山公路　–　葵涌段</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-85.2941866157024</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001801</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832308.33654906</fme:EASTING>
<fme:NORTHING>823011.50153029</fme:NORTHING>
<fme:ST_CODE>10132</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006403</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822956.07523 832316.35037</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id535abd90-2294-49e0-8066-0f5e9503bb82">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>呈祥道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>16.6869888488548</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001483</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833213.37364769</fme:EASTING>
<fme:NORTHING>822335.09558562</fme:NORTHING>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018471</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822343.22693 833228.52034</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id852d046f-bd92-4f00-8d5d-ae72de0ace09">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長源路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>53.9995469179849</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001824</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832903.46732787</fme:EASTING>
<fme:NORTHING>823165.94140551</fme:NORTHING>
<fme:ST_CODE>10223</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016452</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823167.64088 832909.91883</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id8f72d112-d93e-4c2c-96c4-5da19951e834">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-10.7843038635446</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001195</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832435.73135084</fme:EASTING>
<fme:NORTHING>822004.16666031</fme:NORTHING>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015311</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822004.37311 832453.03032</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ida72647d2-825e-4d72-88eb-85584788034d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長荔街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.9902960887794</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002165</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833287.56</fme:EASTING>
<fme:NORTHING>821976.43</fme:NORTHING>
<fme:ST_CODE>10196</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017680</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821976.24023 833287.63290</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id6741dbdb-95ea-47bf-9f77-33a5654f9df7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔崗街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-74.4847886945105</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001200</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831485.189</fme:EASTING>
<fme:NORTHING>823187.93</fme:NORTHING>
<fme:ST_CODE>11157</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016741</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823188.19581 831485.33686</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9d6068a8-0f82-4318-a956-a2684012534a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景山路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-26.5650634341067</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001851</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831295.03317527</fme:EASTING>
<fme:NORTHING>822844.02379979</fme:NORTHING>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018141</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822838.31448 831312.86124</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id45cca0b7-b452-4485-9658-5de56e78cb4d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青沙公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>37.5930851089499</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001875</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832444.4654737</fme:EASTING>
<fme:NORTHING>821007.90420041</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016034</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821027.20729 832462.95929</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id60583033-733d-43d4-a0b1-c973a6cfa0e3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華瑤路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-19.945999319981</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002210</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831480.551</fme:EASTING>
<fme:NORTHING>823658.224</fme:NORTHING>
<fme:ST_CODE>12598</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003278</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823658.22378 831480.55108</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9916c92b-5b8c-44d0-850e-320cc85b5e05">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵泰路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.2551100708883</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001907</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830436.14224892</fme:EASTING>
<fme:NORTHING>823574.9202866</fme:NORTHING>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003034</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823579.14274 830449.73648</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id35142d26-f2c4-4a2a-8b9d-2f85fb5dfa52">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>蘭秀道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.9999943276577</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002218</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832471.057</fme:EASTING>
<fme:NORTHING>822153.668</fme:NORTHING>
<fme:ST_CODE>11503</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014909</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822153.79269 832471.29486</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idcb14355f-6af1-4e02-b1d3-2423ba6111e4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海麗街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001266</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833146.13999225</fme:EASTING>
<fme:NORTHING>821360.04500047</fme:NORTHING>
<fme:ST_CODE>14190</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016171</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821347.61476 833159.94717</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9f42c72a-a46b-43dd-bc5b-2ff310a3291f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵景路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001269</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830490.90822391</fme:EASTING>
<fme:NORTHING>823727.77678141</fme:NORTHING>
<fme:ST_CODE>13016</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000228</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823730.24339 830506.08594</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idd320c50a-29d6-44c5-8a3e-c1e5008c1743">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>新葵街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001920</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831636.57877276</fme:EASTING>
<fme:NORTHING>823966.8928025</fme:NORTHING>
<fme:ST_CODE>11895</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016371</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823982.61026 831635.06376</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id47f3964c-d2f0-45da-a2a4-89b526a7b6c3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵喜街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>28.6790312703254</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001601</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830086.42812797</fme:EASTING>
<fme:NORTHING>823961.10025973</fme:NORTHING>
<fme:ST_CODE>11086</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002935</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823970.42943 830097.51018</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idd329e8db-3863-4e21-9346-93fc6a9b2b76">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>瓊林街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>18.8724481770396</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001971</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833165.26245947</fme:EASTING>
<fme:NORTHING>822221.22205927</fme:NORTHING>
<fme:ST_CODE>11026</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015770</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822228.56733 833177.88839</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ide46799a2-e72c-44ec-a0d8-b3e8bedc3643">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>金山路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002308</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833667.59616847</fme:EASTING>
<fme:NORTHING>823957.20435151</fme:NORTHING>
<fme:ST_CODE>10612</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018091</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823954.55421 833681.29112</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id24d92b87-e35e-43fe-8854-f02899dd2124">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>美荔道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.3443646717652</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001355</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832500.68111955</fme:EASTING>
<fme:NORTHING>822245.92083563</fme:NORTHING>
<fme:ST_CODE>11413</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016178</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822233.64513 832508.37217</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ide1f1725e-4813-4bee-8717-b3a711b85b08">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>發祥街西</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.300945864426</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001682</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833583.155</fme:EASTING>
<fme:NORTHING>821305.699</fme:NORTHING>
<fme:ST_CODE>13895</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016105</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821305.69923 833583.15464</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ide2ed060c-1a4f-4804-b23d-6d75dd19f931">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔寶路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002017</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832643.12486388</fme:EASTING>
<fme:NORTHING>821129.84905062</fme:NORTHING>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015742</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821141.40972 832662.79659</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7a008fb9-3569-440e-8e39-59de70950238">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵豐街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.6510742268995</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002324</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830924.604</fme:EASTING>
<fme:NORTHING>823971.199</fme:NORTHING>
<fme:ST_CODE>11084</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003188</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823971.19886 830924.60443</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id8efc1085-d865-48c4-ac15-b40ad6ec54e9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔峰街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.0366226198608</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001689</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831423.728</fme:EASTING>
<fme:NORTHING>823270.106</fme:NORTHING>
<fme:ST_CODE>11154</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003102</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823270.22432 831423.92855</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idbbd3ab84-410d-40c8-9e25-807b9c3dcc1b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>尖山隧道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.412965443457</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001729</fme:FEATURE_ID>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:EASTING>833384.6316841</fme:EASTING>
<fme:NORTHING>823119.01916123</fme:NORTHING>
<fme:ST_CODE>39535</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017494</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823128.45439 833400.84030</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7781b9c6-7802-4009-837b-88c4e5a919b7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長義街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1794679385454</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001732</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833255.8435285</fme:EASTING>
<fme:NORTHING>821867.97318257</fme:NORTHING>
<fme:ST_CODE>10220</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014972</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821875.54217 833268.12893</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id6bd99530-4c1e-4160-992a-ce4ab0bf13dd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵裕街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.8789654591582</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003367</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830033.70905437</fme:EASTING>
<fme:NORTHING>823725.44828192</fme:NORTHING>
<fme:ST_CODE>11108</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003451</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823739.69477 830035.99633</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb615bf6f-2db5-4ec2-9c39-59bf13502af2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>月輪街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-10.9456552322108</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003696</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832831.06947034</fme:EASTING>
<fme:NORTHING>821864.54185292</fme:NORTHING>
<fme:ST_CODE>12932</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015670</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821864.74279 832845.12640</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id048454da-a1dd-4e4f-97d2-69e10dfba572">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永康街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.4884387867223</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003054</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833178.015</fme:EASTING>
<fme:NORTHING>822160.358</fme:NORTHING>
<fme:ST_CODE>12724</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015137</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822160.64017 833178.17276</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idef45477a-9762-4980-adc1-88381aebb547">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>景荔徑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.62475452293433</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003055</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832204.7424225</fme:EASTING>
<fme:NORTHING>822490.81393064</fme:NORTHING>
<fme:ST_CODE>14087</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016479</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822494.56478 832218.61359</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id01d1a4dc-5ca5-468d-9034-a22aa833c07c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大窩交匯處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003717</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831775.52230129</fme:EASTING>
<fme:NORTHING>823603.83183631</fme:NORTHING>
<fme:ST_CODE>13581</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016829</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823606.69822 831800.72808</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id467aa06c-424c-4fca-b21f-dbb5882b2a76">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>深旺道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.7858146302166</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003726</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833238.633</fme:EASTING>
<fme:NORTHING>821505.468</fme:NORTHING>
<fme:ST_CODE>13892</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016167</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821505.53748 833238.87978</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ida93cdc40-e770-46c9-bb5f-7a28d7848644">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>美青路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>26.2113816926911</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003743</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832143.35159828</fme:EASTING>
<fme:NORTHING>821418.39176975</fme:NORTHING>
<fme:ST_CODE>13897</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018029</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821427.13971 832154.63119</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb9488a12-52bf-4a77-9b59-9f3ac06cd8c8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>通州街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-44.114481119848</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003130</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833596.691</fme:EASTING>
<fme:NORTHING>821587.617</fme:NORTHING>
<fme:ST_CODE>12509</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014974</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821587.73320 833596.87800</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id863628da-23ad-4160-8824-629dde767c73">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>瑪嘉烈醫院路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-50.8478058591985</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003775</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831749.73482431</fme:EASTING>
<fme:NORTHING>822438.55280052</fme:NORTHING>
<fme:ST_CODE>11790</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016654</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822417.91916 831770.23087</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb0fb65e9-821c-4a97-8345-699fed7e0043">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>榮祖街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.836376761551276</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003776</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831360.75000419</fme:EASTING>
<fme:NORTHING>823025.92808213</fme:NORTHING>
<fme:ST_CODE>12714</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018146</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823028.58650 831375.01640</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9484047e-e3ee-431b-adc1-12d627fac305">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵德街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.1315034904597</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003460</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830702.82445287</fme:EASTING>
<fme:NORTHING>823680.57064445</fme:NORTHING>
<fme:ST_CODE>11099</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002702</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823693.82481 830708.41465</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id85cca89d-1ef1-4edc-ba0a-02e656706e92">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003465</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833535.1599351</fme:EASTING>
<fme:NORTHING>821890.06210972</fme:NORTHING>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015141</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821890.87732 833559.22771</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id62b277db-6a6b-4b3b-a1b8-3a802aa2453f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長沙灣道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003468</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833081.23787537</fme:EASTING>
<fme:NORTHING>821942.21089133</fme:NORTHING>
<fme:ST_CODE>10206</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015403</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821950.30232 833103.80476</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id5852f172-1f44-409f-be45-c4e1f7402169">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青沙公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.3764177536855</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002477</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832864.5417393</fme:EASTING>
<fme:NORTHING>822289.67173995</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016012</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822267.31747 832879.20179</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id67a78847-307d-4a09-be34-6a6fd126f88a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永明街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2825451446308</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002818</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833504.86813098</fme:EASTING>
<fme:NORTHING>822323.37253113</fme:NORTHING>
<fme:ST_CODE>12736</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015666</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822330.89176 833516.94548</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idcab2e6b7-dcb6-4b9a-aec4-198ccd18d255">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西九龍走廊</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.5908909217828</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003178</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833624.77790935</fme:EASTING>
<fme:NORTHING>821573.96190297</fme:NORTHING>
<fme:ST_CODE>14283</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015944</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821555.73317 833653.11652</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idded21587-626f-435e-9b76-de2e60db0ecf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>念祖街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-53.7707676630106</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003496</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831329.241</fme:EASTING>
<fme:NORTHING>823262.506</fme:NORTHING>
<fme:ST_CODE>11232</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002775</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823262.40446 831329.58002</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id72875d86-2643-416b-aeeb-af73c03f0365">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵福路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003536</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831187.30232799</fme:EASTING>
<fme:NORTHING>823987.69346905</fme:NORTHING>
<fme:ST_CODE>11083</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003187</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823984.52838 831202.36579</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idebd83b58-1648-4af9-84e3-575c59d1082b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長茂街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.8026545692381</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002883</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833144.74324385</fme:EASTING>
<fme:NORTHING>821873.08083935</fme:NORTHING>
<fme:ST_CODE>10201</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015142</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821860.71090 833152.34803</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idc1326340-173c-45ef-b511-ab03bc4d1c31">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長坑路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>10.6116004874875</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003223</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832535.12364407</fme:EASTING>
<fme:NORTHING>823051.9777615</fme:NORTHING>
<fme:ST_CODE>10190</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016830</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823057.39375 832548.46589</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id11ea74bc-d092-4398-87b4-9cdfbca122d8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨櫃碼頭南路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.6101342960012</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003236</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831465.0146462</fme:EASTING>
<fme:NORTHING>822441.13598033</fme:NORTHING>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016653</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822390.81144 831480.77563</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id78b84db9-27a3-4535-96f2-5114b4305ce3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>深盛路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>4.63546800774518</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002588</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833220.60613273</fme:EASTING>
<fme:NORTHING>821621.96238175</fme:NORTHING>
<fme:ST_CODE>13953</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015138</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821625.96409 833234.49249</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9409a633-a1ad-4d93-9e5c-e3c27b39093e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨櫃碼頭路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>66.4713737912571</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002926</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830843.506</fme:EASTING>
<fme:NORTHING>823755.38</fme:NORTHING>
<fme:ST_CODE>10331</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003457</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823756.05960 830843.80188</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7335ef04-8afa-4a55-a77e-1f54dbc0a433">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>連翔道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002936</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833380.51703316</fme:EASTING>
<fme:NORTHING>821112.41710411</fme:NORTHING>
<fme:ST_CODE>13922</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014897</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821103.54920 833397.61129</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id8e27e76c-fb15-49db-953c-b538ed785272">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>吉利徑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.7751353824872</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003577</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832375.3571159</fme:EASTING>
<fme:NORTHING>821950.62390352</fme:NORTHING>
<fme:ST_CODE>10607</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014910</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821947.44970 832389.07461</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id1e90d4b8-26cb-47a1-a516-b4d336a61cce">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗瑤街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>4.29325389664181</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002944</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831408.29777502</fme:EASTING>
<fme:NORTHING>823868.3305621</fme:NORTHING>
<fme:ST_CODE>11169</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000217</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823945.68837 831453.90672</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb4d54c94-8bd5-4c19-9366-07fa751b7ba9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003303</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831137.98521195</fme:EASTING>
<fme:NORTHING>823777.51467916</fme:NORTHING>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003157</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823793.37813 831147.05176</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idff5d32cc-0ad1-419c-90ed-26ea20e3176b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗祖路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>57.3390728282734</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003313</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831190.8513889</fme:EASTING>
<fme:NORTHING>823573.18986213</fme:NORTHING>
<fme:ST_CODE>11151</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002936</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823584.35890 831198.01104</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id42dc0ff5-14e7-4ed2-a66a-d93f20c5dc07">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>郝德傑道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003317</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833299.26567121</fme:EASTING>
<fme:NORTHING>822791.37370846</fme:NORTHING>
<fme:ST_CODE>10106</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015675</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822784.08279 833322.06507</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id236c2351-7144-423b-a879-b817484575d3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨櫃碼頭南路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003323</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830900.8421477</fme:EASTING>
<fme:NORTHING>823325.26609242</fme:NORTHING>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000225</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823355.67730 830903.57568</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="iddd86f1d1-fcc9-4b38-862f-ad7af67b4fc2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永順街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.4581700132774</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003338</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830058.243</fme:EASTING>
<fme:NORTHING>823987.253</fme:NORTHING>
<fme:ST_CODE>12741</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006530</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823986.99793 830058.54163</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb9fcc07e-8908-4ab3-82da-0e2cf8e33adf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>達美路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>16.3895322197878</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003339</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831761.76</fme:EASTING>
<fme:NORTHING>821748.483</fme:NORTHING>
<fme:ST_CODE>14337</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014942</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821748.77367 831761.99176</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id3679fcd4-7b0d-4bb7-a2bb-2a74d7dc3375">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>甘泉街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003342</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832993.854</fme:EASTING>
<fme:NORTHING>821963.953</fme:NORTHING>
<fme:ST_CODE>11057</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016052</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821963.71697 832993.98436</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9c4b3287-2d87-42cc-b92d-a1f4909e1146">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青山道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1562386244123</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003028</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833287.36608165</fme:EASTING>
<fme:NORTHING>822131.27678751</fme:NORTHING>
<fme:ST_CODE>10128</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015140</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822138.60375 833299.00875</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9b7a1787-bfd1-4e2f-b870-6f7b9e1d3ec4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景山路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003030</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832213.36656241</fme:EASTING>
<fme:NORTHING>822733.66286755</fme:NORTHING>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016451</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822715.87450 832237.54008</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9defa24f-7e3f-49a8-9f20-61cf6d4f7634">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵青路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>48.3664585910023</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003041</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830258.69161775</fme:EASTING>
<fme:NORTHING>823492.32700163</fme:NORTHING>
<fme:ST_CODE>11101</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000218</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823507.23295 830267.33926</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id458152fb-3c21-4fa1-9256-329e537efeba">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大埔道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004653</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833588.20148486</fme:EASTING>
<fme:NORTHING>822818.32527905</fme:NORTHING>
<fme:ST_CODE>12254</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016179</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822801.35801 833603.10962</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id339c6c92-39c7-4690-a628-156e51e5577d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長沙灣道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004994</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832659.31051622</fme:EASTING>
<fme:NORTHING>821989.74674205</fme:NORTHING>
<fme:ST_CODE>10206</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017078</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821984.65370 832678.96446</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id1dbb69ec-1c95-498d-a6dc-8e37e18e8ad7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大埔公路　–　琵琶山段</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004006</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833607.50426404</fme:EASTING>
<fme:NORTHING>822924.07769978</fme:NORTHING>
<fme:ST_CODE>12257</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006474</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822980.97943 833620.11444</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id583b7183-f985-4f3e-b353-3e59d40a2619">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵順街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-23.8681638259047</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004008</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830820.56645946</fme:EASTING>
<fme:NORTHING>823874.82797165</fme:NORTHING>
<fme:ST_CODE>11096</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000229</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823866.98837 830832.93863</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id59f50732-2d05-4731-985d-ad7b57ae407c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長裕街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.8396564997385</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004356</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833517.21888089</fme:EASTING>
<fme:NORTHING>821963.12176127</fme:NORTHING>
<fme:ST_CODE>10222</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015139</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821970.88043 833529.54401</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ida664caf0-c8ff-4b42-91da-0f081a4f37ca">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長順街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3119884984469</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005008</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833241.21282553</fme:EASTING>
<fme:NORTHING>821924.78224938</fme:NORTHING>
<fme:ST_CODE>10212</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015217</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821932.44699 833253.66266</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb9562c60-6308-4281-8ad3-827bfdfe5613">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華景山路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005011</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831860.88785401</fme:EASTING>
<fme:NORTHING>823548.95603759</fme:NORTHING>
<fme:ST_CODE>12593</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018257</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823527.70080 831872.48593</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id2c4650f8-26f1-4e9b-95d7-fb6396fbbab5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>寶輪街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>79.7174689327201</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004031</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832762.20052797</fme:EASTING>
<fme:NORTHING>821830.88963954</fme:NORTHING>
<fme:ST_CODE>11746</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016109</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821845.34683 832761.91013</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb0864f85-aa60-467f-aee2-d26193067ddb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌醫院路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004033</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831808.232</fme:EASTING>
<fme:NORTHING>822508.413</fme:NORTHING>
<fme:ST_CODE>11078</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016577</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822507.68921 831808.55296</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id437a367c-ce4f-4a57-950c-ed162f715c35">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>興華街西</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004696</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833447.21552663</fme:EASTING>
<fme:NORTHING>821520.01958786</fme:NORTHING>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016107</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821538.02482 833455.66841</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id32e5cb37-83a3-48cc-b768-dc46352aabb5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>興華街西</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>37.8027819560017</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004697</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832389.91721403</fme:EASTING>
<fme:NORTHING>821006.68018559</fme:NORTHING>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016276</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821024.46768 832412.84641</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id06d9adf1-9dd5-41b4-a0b7-1004692e11e1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>福華街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.1307300312898</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004055</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833674.78039912</fme:EASTING>
<fme:NORTHING>822328.71267411</fme:NORTHING>
<fme:ST_CODE>10560</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016181</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822316.58522 833682.47161</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id4a29a2e8-4b17-4cf5-b379-dbb3d354c335">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>深旺道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004716</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832828.76180987</fme:EASTING>
<fme:NORTHING>821801.64681587</fme:NORTHING>
<fme:ST_CODE>13892</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015775</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821799.20022 832843.43626</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7977b9dc-a0c2-42cd-9f2c-277b890b9a1a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華景山路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-18.2593781443682</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004734</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832169.95973844</fme:EASTING>
<fme:NORTHING>823662.68360862</fme:NORTHING>
<fme:ST_CODE>12593</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018267</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823659.65649 832188.28317</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id52cbee14-fdc1-4c6d-955f-4cc700c72b37">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝嶺路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-21.6659669434817</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004442</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831590.13532275</fme:EASTING>
<fme:NORTHING>822917.89237976</fme:NORTHING>
<fme:ST_CODE>11150</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016832</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822911.01273 831607.45307</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id8cf26794-a3ee-4d12-b4b3-5748fa47e47f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵和街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>66.9006191518653</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004764</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830672.413</fme:EASTING>
<fme:NORTHING>823748.098</fme:NORTHING>
<fme:ST_CODE>13051</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003189</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823748.28432 830672.49261</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id480ebb59-499e-47fc-ba9d-e3f664047818">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>呈祥道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004464</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831967.14802353</fme:EASTING>
<fme:NORTHING>822161.42727801</fme:NORTHING>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016014</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822171.89873 831978.41010</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ida8cf8a89-6a02-4d9f-887b-ad82b288cfc8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>恒柏道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-25.7960501172708</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004474</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832433.6140577</fme:EASTING>
<fme:NORTHING>822249.93355961</fme:NORTHING>
<fme:ST_CODE>10861</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016016</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822246.41951 832447.47133</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7661a832-e03e-4338-abd0-fd4d2392002f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大南西街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.3818330791114</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004812</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833404.52763981</fme:EASTING>
<fme:NORTHING>822151.20955525</fme:NORTHING>
<fme:ST_CODE>12240</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015211</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822134.48077 833413.53350</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id32ccada2-59d6-45c6-97a2-5bbd7f620579">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華荔徑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-74.1569035218797</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003847</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832058.0192829</fme:EASTING>
<fme:NORTHING>822669.31273981</fme:NORTHING>
<fme:ST_CODE>12582</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016478</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822656.62172 832064.60036</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ide776b606-36c2-41e4-b16c-304a760bd899">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華泰路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-55.4166666446512</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004190</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831691.696</fme:EASTING>
<fme:NORTHING>823317.389</fme:NORTHING>
<fme:ST_CODE>12586</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018265</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823317.48444 831691.88939</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id6f5e3ed9-3db2-47f4-a3a5-192937802a2c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>英華街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.8499251013945</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004858</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833710.673</fme:EASTING>
<fme:NORTHING>821341.19</fme:NORTHING>
<fme:ST_CODE>14140</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016104</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821341.28867 833710.88809</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id33cbc8b6-50a1-4afe-b794-3dcf3249147f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>汝州西街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.5130026568787</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003880</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833486.18104816</fme:EASTING>
<fme:NORTHING>822317.59602506</fme:NORTHING>
<fme:ST_CODE>12889</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016187</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822301.07595 833495.41330</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb5df3529-a2e4-41e4-9da4-22f63d3be4a9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔灣道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004220</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832297.10159145</fme:EASTING>
<fme:NORTHING>822442.49418003</fme:NORTHING>
<fme:ST_CODE>11163</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016011</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822430.19447 832306.94986</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id899b5717-c18a-4044-86a2-ee8301c79ced">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青山道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-63.4171452678147</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004895</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832615.38099524</fme:EASTING>
<fme:NORTHING>822146.18662885</fme:NORTHING>
<fme:ST_CODE>10128</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014907</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822135.43724 832623.96508</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id957545fc-c361-4f74-bee9-74c9011b46d1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長坑路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.7273928753336</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003909</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832732.37856617</fme:EASTING>
<fme:NORTHING>822660.57936152</fme:NORTHING>
<fme:ST_CODE>10190</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016417</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822674.42617 832734.63928</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id0fade832-06c4-4e36-aab2-af9d893bb7ad">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>通州西街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.0025834438344</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004261</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833077.78725299</fme:EASTING>
<fme:NORTHING>822183.08973086</fme:NORTHING>
<fme:ST_CODE>12510</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014975</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822166.37948 833086.91872</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id2fa45068-7cbd-45ed-8684-bdc330728a31">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長沙灣徑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.9896377138743</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004263</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833573.9066676</fme:EASTING>
<fme:NORTHING>822083.54260581</fme:NORTHING>
<fme:ST_CODE>10205</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015207</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822076.19124 833580.13646</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ideea35b95-9460-4b1d-9711-e3c7924af27f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨櫃碼頭南路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.0720873256186</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004591</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832110.94837672</fme:EASTING>
<fme:NORTHING>821220.14534802</fme:NORTHING>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018147</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821193.38222 832122.61970</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idfef764d7-6dbb-431f-9db9-9ac858a92736">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>興華街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.0502311196003</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004339</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833617.38670084</fme:EASTING>
<fme:NORTHING>821740.00018805</fme:NORTHING>
<fme:ST_CODE>10731</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015214</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821752.60119 833624.20234</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idcfa93d94-3ae3-4a05-89ce-98c730417d29">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>達洋路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005076</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831747.70005191</fme:EASTING>
<fme:NORTHING>822070.62270439</fme:NORTHING>
<fme:ST_CODE>13954</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016018</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822075.40296 831762.31648</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id2d6a0605-6e64-4535-9de2-93e6ce02c77d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵康街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-22.7396604722717</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005086</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830768.025</fme:EASTING>
<fme:NORTHING>823713.246</fme:NORTHING>
<fme:ST_CODE>11089</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003452</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823713.09785 830768.37850</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id220bd9e4-5532-4134-96ad-1d9af0d1d3bb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔康街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.0721341969701</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005189</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833616.74412051</fme:EASTING>
<fme:NORTHING>821506.26219279</fme:NORTHING>
<fme:ST_CODE>11155</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014895</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821519.01798 833623.68231</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idc3d31c93-f2e2-403e-9e83-4e502056d1fa">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>醫局西街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.0873898795225</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005257</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833220.821</fme:EASTING>
<fme:NORTHING>822208.01</fme:NORTHING>
<fme:ST_CODE>12845</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014969</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822207.89663 833221.09301</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id970d23a3-f9ec-4de3-afb4-23e84c65c4d0">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>港鐵（荃灣綫）</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001000005839</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005509</fme:FEATURE_ID>
<fme:FEATURECODE>MTN</fme:FEATURECODE>
<fme:EASTING>830901.62111202</fme:EASTING>
<fme:NORTHING>823700.8726326</fme:NORTHING>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210020231</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823724.42299 830909.78467</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9b59ee37-8ca4-4e24-a1a2-61f606ad4127">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌交匯處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005289</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831569.97438646</fme:EASTING>
<fme:NORTHING>822446.07043163</fme:NORTHING>
<fme:ST_CODE>14066</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016825</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822448.93681 831593.63307</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id5faa593f-58e3-4e29-9c00-7cf612774bd0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵泰路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005303</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830011.63583804</fme:EASTING>
<fme:NORTHING>823530.94604152</fme:NORTHING>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002774</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823538.83747 830024.77859</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id0594e5f4-b07a-46ab-afff-624b1438a247">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>港鐵（機場快綫及東涌綫）</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001000005839</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.8878045609799</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005537</fme:FEATURE_ID>
<fme:FEATURECODE>MTN</fme:FEATURECODE>
<fme:EASTING>830244.27065115</fme:EASTING>
<fme:NORTHING>823916.50826751</fme:NORTHING>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210020326</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823885.60709 830300.45034</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id156f85a7-e7d0-46a4-9538-8f5d6e4504c4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌交匯處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008566</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831678.049</fme:EASTING>
<fme:NORTHING>822229.884</fme:NORTHING>
<fme:ST_CODE>14066</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006266</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822229.69158 831678.41950</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id6788c4bb-8b9b-406a-897d-59409a4791b3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>連翔道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-33.3170589384887</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008726</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:ST_CODE>13922</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014897</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821109.04615 833529.24837</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idfc197343-5a1b-45ea-a120-40890cafcac9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>丹荔街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.1671921003028</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210009368</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833679.477</fme:EASTING>
<fme:NORTHING>821690.282</fme:NORTHING>
<fme:ST_CODE>14448</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017241</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821690.60206 833679.46511</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id0065d379-0ecb-4d77-8178-fb8898bc0937">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔盈街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-35.5872992654338</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010432</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833269.25</fme:EASTING>
<fme:NORTHING>821029.554</fme:NORTHING>
<fme:ST_CODE>14468</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210028030</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821029.55044 833269.62134</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idcddbc528-28f1-48c3-9aa3-e7ab421fc4bf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長順街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.9158462761647</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012126</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833019.308</fme:EASTING>
<fme:NORTHING>821876.365</fme:NORTHING>
<fme:ST_CODE>10212</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015294</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821876.07196 833019.63584</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idf31f638f-548c-4d7c-a175-32f1cf96875f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-85.8197005029404</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012746</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833124.848</fme:EASTING>
<fme:NORTHING>821715.498</fme:NORTHING>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017446</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821715.34639 833125.07377</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id6b242b3f-ac73-418f-bbb7-6f7f2c5054b3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔寶路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-23.1569234819305</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012747</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832578.308</fme:EASTING>
<fme:NORTHING>821425.567</fme:NORTHING>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210028637</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821425.72654 832578.47706</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7fd4a398-2800-49d4-8cf2-4671bf8027f1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔寶路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>18.5577544015147</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012748</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832777.911</fme:EASTING>
<fme:NORTHING>821472.093</fme:NORTHING>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015743</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821472.32533 832777.93039</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id0974cdbc-b60c-491b-a40e-a4d5a3d466c7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔寶路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>2.67543188637302</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012749</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832932.938</fme:EASTING>
<fme:NORTHING>821239.922</fme:NORTHING>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310029707</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240229</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821240.13938 832933.02096</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id023c1121-59a2-477a-ab90-97d61ae1ae0e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海達街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>51.7556296980001</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310014086</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833611.84</fme:EASTING>
<fme:NORTHING>821166.048</fme:NORTHING>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210016209</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821166.18008 833611.67233</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
