<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821011.07600 830012.19725 0.00000</gml:lowerCorner>
<gml:upperCorner>823992.36700 833741.86400 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPoint gml:id="id1e404864-5716-46d4-94e6-dbc379522cd6">
<fme:FEATURE_ID>1210016276</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832396.144</fme:EASTING>
<fme:NORTHING>821011.076</fme:NORTHING>
<fme:ENGLISHNAME>HING WAH STREET WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>興華街西</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821011.07600 832396.14400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ide5b63c33-1e2e-4ad1-b30f-3da744082686">
<fme:FEATURE_ID>1210015744</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832706.608</fme:EASTING>
<fme:NORTHING>821047.079</fme:NORTHING>
<fme:ENGLISHNAME>HING WAH STREET WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>興華街西</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821047.07900 832706.60800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id35f52843-c178-4136-a342-31c81ed608e9">
<fme:FEATURE_ID>1210028030</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833233.881</fme:EASTING>
<fme:NORTHING>821050.9</fme:NORTHING>
<fme:ENGLISHNAME>LAI YING STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>荔盈街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14468</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821050.89980 833233.88063 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4a279b41-b188-4283-a3d6-8a7bd47bdeb8">
<fme:FEATURE_ID>1210007723</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833735.2</fme:EASTING>
<fme:NORTHING>821070.704</fme:NORTHING>
<fme:ENGLISHNAME>TONKIN STREET WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>東京街西</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13894</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821070.70418 833735.19954 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7d7d7464-dfb6-401b-9dc5-3590ccd49b2c">
<fme:FEATURE_ID>1210014897</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833395.663</fme:EASTING>
<fme:NORTHING>821102.573</fme:NORTHING>
<fme:ENGLISHNAME>LIN CHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>連翔道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13922</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821102.57289 833395.66331 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idffbeecd2-8522-4205-bb45-eabf1dac359b">
<fme:FEATURE_ID>1210015742</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832627.896</fme:EASTING>
<fme:NORTHING>821124.105</fme:NORTHING>
<fme:ENGLISHNAME>LAI PO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔寶路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821124.10500 832627.89600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id20d2683f-6b19-424b-bd4a-08fc92e413ad">
<fme:FEATURE_ID>1210015745</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832590.914</fme:EASTING>
<fme:NORTHING>821133.708</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821133.70800 832590.91400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id56a3daf2-d47f-4668-ab5e-a00fc9eda87c">
<fme:FEATURE_ID>1210016209</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833594</fme:EASTING>
<fme:NORTHING>821144</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>海達街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>45186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821144.00000 833594.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4961d771-370f-4fb6-b24a-20fc1adb09c3">
<fme:FEATURE_ID>1210018148</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832582.394</fme:EASTING>
<fme:NORTHING>821165.177</fme:NORTHING>
<fme:ENGLISHNAME>LAI PO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔寶路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821165.17700 832582.39400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id610b4cd2-9f84-45d0-b439-6a42bb671a3e">
<fme:FEATURE_ID>1210015830</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832912.175</fme:EASTING>
<fme:NORTHING>821195.443</fme:NORTHING>
<fme:ENGLISHNAME>HING WAH STREET WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>興華街西</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821195.44300 832912.17500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id270b6333-234f-4832-bdf6-68deb4fda2f9">
<fme:FEATURE_ID>1210018147</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832121.482</fme:EASTING>
<fme:NORTHING>821215.378</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821215.37800 832121.48200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id2360fb04-71a9-4694-a1b3-d4281cf8fbfe">
<fme:FEATURE_ID>1310029707</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833021.65</fme:EASTING>
<fme:NORTHING>821234.889</fme:NORTHING>
<fme:ENGLISHNAME>LAI PO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔寶路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821234.88945 833021.65003 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6af27c5c-af10-418e-a2d4-034c6a6706c4">
<fme:FEATURE_ID>1210014896</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833175.642</fme:EASTING>
<fme:NORTHING>821241.453</fme:NORTHING>
<fme:ENGLISHNAME>WEST KOWLOON HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>西九龍公路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13885</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821241.45261 833175.64161 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ida783c3c7-8c49-40a5-a20f-a3e74190dbf6">
<fme:FEATURE_ID>1210016173</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833126.075</fme:EASTING>
<fme:NORTHING>821280.038</fme:NORTHING>
<fme:ENGLISHNAME>LIN CHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>連翔道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13922</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821280.03800 833126.07500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idaeebde62-37e0-4fa5-bcfa-2423be38e359">
<fme:FEATURE_ID>1210016105</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833600.105</fme:EASTING>
<fme:NORTHING>821325.547</fme:NORTHING>
<fme:ENGLISHNAME>FAT TSEUNG STREET WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>發祥街西</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13895</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821325.54700 833600.10500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf54fe50f-c06a-4f68-baa8-8bdb664471ca">
<fme:FEATURE_ID>1210016171</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833157.955</fme:EASTING>
<fme:NORTHING>821349.435</fme:NORTHING>
<fme:ENGLISHNAME>HOI LAI STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>海麗街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14190</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821349.43500 833157.95500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6494b77a-1391-4300-b45b-158126cdb844">
<fme:FEATURE_ID>1210016168</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833428.54</fme:EASTING>
<fme:NORTHING>821361.311</fme:NORTHING>
<fme:ENGLISHNAME>SHAM MONG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>深旺道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13892</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821361.31100 833428.54000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id06a56500-cc59-4ba7-985e-80b86af2fee9">
<fme:FEATURE_ID>1210016104</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833674.991</fme:EASTING>
<fme:NORTHING>821371.182</fme:NORTHING>
<fme:ENGLISHNAME>YING WA STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>英華街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14140</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821371.18200 833674.99100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idcfc1c248-27fa-4428-babf-23d8c8d9697a">
<fme:FEATURE_ID>1210028637</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832593.973</fme:EASTING>
<fme:NORTHING>821419.58</fme:NORTHING>
<fme:ENGLISHNAME>LAI PO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔寶路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821419.58002 832593.97342 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id10dffd02-96d2-422a-b898-e8c7a4b4bc47">
<fme:FEATURE_ID>1210018029</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832176.191</fme:EASTING>
<fme:NORTHING>821444.069</fme:NORTHING>
<fme:ENGLISHNAME>MEI CHING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>美青路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13897</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821444.06900 832176.19100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id97ff8ad0-7928-4de1-a2bf-01bbf17d60f0">
<fme:FEATURE_ID>1210025903</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833701.989</fme:EASTING>
<fme:NORTHING>821452.202</fme:NORTHING>
<fme:ENGLISHNAME>FAT TSEUNG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>發祥街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10475</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821452.20200 833701.98900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id76711806-1e34-48ad-b676-bfa20d8a385a">
<fme:FEATURE_ID>1210014895</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833581.251</fme:EASTING>
<fme:NORTHING>821468.033</fme:NORTHING>
<fme:ENGLISHNAME>LAI HONG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>荔康街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11155</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821468.03300 833581.25100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf8cda6c0-d5df-4494-8473-f1950f29a4a1">
<fme:FEATURE_ID>1210015743</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832788.691</fme:EASTING>
<fme:NORTHING>821473.319</fme:NORTHING>
<fme:ENGLISHNAME>LAI PO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔寶路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821473.31900 832788.69100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ide3b1028a-f7f0-4bf5-aa76-15421f624ab4">
<fme:FEATURE_ID>1210016106</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833619.512</fme:EASTING>
<fme:NORTHING>821474.756</fme:NORTHING>
<fme:ENGLISHNAME>LAI FAT STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>荔發街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11152</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821474.75600 833619.51200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id50d3f5d8-7388-413c-bb64-7150d363dfa3">
<fme:FEATURE_ID>1210015834</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832550.944</fme:EASTING>
<fme:NORTHING>821498.033</fme:NORTHING>
<fme:ENGLISHNAME>WEST KOWLOON HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>西九龍公路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13885</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821498.03300 832550.94400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id07ec1124-0b96-4b60-aaf6-bf48b3df8c2e">
<fme:FEATURE_ID>1210015832</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832954.306</fme:EASTING>
<fme:NORTHING>821511.655</fme:NORTHING>
<fme:ENGLISHNAME>LAI PO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔寶路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821511.65500 832954.30600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7bf9ff97-a4db-4482-8b85-efd3fc6d1288">
<fme:FEATURE_ID>1210016107</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833467.524</fme:EASTING>
<fme:NORTHING>821566.86</fme:NORTHING>
<fme:ENGLISHNAME>HING WAH STREET WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>興華街西</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821566.86000 833467.52400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6ea21829-1eaf-41b8-8f2c-b00016e26223">
<fme:FEATURE_ID>1210015944</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833642.801</fme:EASTING>
<fme:NORTHING>821572.846</fme:NORTHING>
<fme:ENGLISHNAME>WEST KOWLOON CORRIDOR</fme:ENGLISHNAME>
<fme:CHINESENAME>西九龍走廊</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14283</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821572.84600 833642.80100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf803ebc6-5412-4717-8a92-d35626369bcc">
<fme:FEATURE_ID>1210016214</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833723.773</fme:EASTING>
<fme:NORTHING>821580.087</fme:NORTHING>
<fme:ENGLISHNAME>TAN LAI STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>丹荔街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821580.08653 833723.77306 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb47dbed3-75de-467c-9a56-9b0e0567555e">
<fme:FEATURE_ID>1210016061</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833641.918</fme:EASTING>
<fme:NORTHING>821586.495</fme:NORTHING>
<fme:ENGLISHNAME>TAN LAI STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>丹荔街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821586.49513 833641.91768 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7e397fdb-3522-4439-a73c-e5ec83ae8b2f">
<fme:FEATURE_ID>1210027449</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832391.322</fme:EASTING>
<fme:NORTHING>821591.689</fme:NORTHING>
<fme:ENGLISHNAME>LIN CHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>連翔道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13922</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821591.68874 832391.32208 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id36d25ead-d97b-454b-92d3-b3345caaf4d2">
<fme:FEATURE_ID>1210014974</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833579.642</fme:EASTING>
<fme:NORTHING>821607.659</fme:NORTHING>
<fme:ENGLISHNAME>TUNG CHAU STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>通州街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12509</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821607.65900 833579.64200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="iddb673833-4174-4383-bc9b-de04852abc9f">
<fme:FEATURE_ID>1210015138</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833264.493</fme:EASTING>
<fme:NORTHING>821627.323</fme:NORTHING>
<fme:ENGLISHNAME>SHAM SHING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>深盛路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13953</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821627.32300 833264.49300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id62f3980c-46bf-4e3a-b44d-261a8c817c11">
<fme:FEATURE_ID>1210017241</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833655.874</fme:EASTING>
<fme:NORTHING>821662.341</fme:NORTHING>
<fme:ENGLISHNAME>TAN LAI STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>丹荔街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821662.34119 833655.87397 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idc982a225-26bc-4cbf-b44f-e25243bcc267">
<fme:FEATURE_ID>1210017446</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833122.83</fme:EASTING>
<fme:NORTHING>821721.791</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI KOK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821721.79100 833122.83000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="iddb78f9d6-9df3-4de8-a1cb-a0901388c38c">
<fme:FEATURE_ID>1210016109</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832742.589</fme:EASTING>
<fme:NORTHING>821736.036</fme:NORTHING>
<fme:ENGLISHNAME>PO LUN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>寶輪街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11746</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821736.03600 832742.58900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id9e050593-ceab-4642-85e7-fcb08823969c">
<fme:FEATURE_ID>1210015214</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833621.8</fme:EASTING>
<fme:NORTHING>821749.197</fme:NORTHING>
<fme:ENGLISHNAME>HING WAH STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>興華街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10731</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821749.19700 833621.80000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd5523e80-7259-450b-a8e8-d4b0d033e661">
<fme:FEATURE_ID>1210014942</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831774.698</fme:EASTING>
<fme:NORTHING>821752.48</fme:NORTHING>
<fme:ENGLISHNAME>TAT MEI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>達美路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14337</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821752.48000 831774.69800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6f777634-f798-4840-bf2c-4fc8122c2fbc">
<fme:FEATURE_ID>1210016746</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831687.197</fme:EASTING>
<fme:NORTHING>821755.78</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821755.78000 831687.19700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id75a3e067-b7a7-46c4-ac37-205aa59449ba">
<fme:FEATURE_ID>1210017560</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833531.253</fme:EASTING>
<fme:NORTHING>821779.181</fme:NORTHING>
<fme:ENGLISHNAME>WEST KOWLOON CORRIDOR</fme:ENGLISHNAME>
<fme:CHINESENAME>西九龍走廊</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14283</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821779.18100 833531.25300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id13627239-1dae-4d46-820a-ec852835ee63">
<fme:FEATURE_ID>1210015775</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832790.38</fme:EASTING>
<fme:NORTHING>821811.162</fme:NORTHING>
<fme:ENGLISHNAME>SHAM MONG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>深旺道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13892</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821811.16200 832790.38000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6a3728a8-05c6-46a6-91e9-c64638d05491">
<fme:FEATURE_ID>1210014904</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832614.474</fme:EASTING>
<fme:NORTHING>821824.883</fme:NORTHING>
<fme:ENGLISHNAME>BROADWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>百老匯街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821824.88300 832614.47400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id40508b2b-8f2a-4a8d-b14a-e93f286f5af6">
<fme:FEATURE_ID>1210015142</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833153.115</fme:EASTING>
<fme:NORTHING>821852.553</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG MOU STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長茂街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10201</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821852.55300 833153.11500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id310eb23f-1f60-4058-bad8-81d6dca196bf">
<fme:FEATURE_ID>1210014972</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833230.981</fme:EASTING>
<fme:NORTHING>821860.177</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG YEE STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長義街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10220</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821860.17700 833230.98100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id15cab8d5-c137-4dc3-a015-d4275b19cbe2">
<fme:FEATURE_ID>1210016177</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832704.243</fme:EASTING>
<fme:NORTHING>821866.763</fme:NORTHING>
<fme:ENGLISHNAME>BROADWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>百老匯街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821866.76300 832704.24300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id045f706b-0677-41bc-a4b4-461ee21c6020">
<fme:FEATURE_ID>1210015141</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833375.566</fme:EASTING>
<fme:NORTHING>821870.567</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI KOK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821870.56700 833375.56600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb5cfcba3-5556-4705-bfaa-46e786c7657a">
<fme:FEATURE_ID>1210015670</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832807.736</fme:EASTING>
<fme:NORTHING>821871.269</fme:NORTHING>
<fme:ENGLISHNAME>YUET LUN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>月輪街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12932</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821871.26900 832807.73600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id9c0aa0f8-73ea-42f8-b363-68a853c05d51">
<fme:FEATURE_ID>1210015959</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832382.729</fme:EASTING>
<fme:NORTHING>821873.884</fme:NORTHING>
<fme:ENGLISHNAME>BROADWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>百老匯街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821873.88400 832382.72900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd02f80d1-d82b-4f6b-8f07-51795191a78b">
<fme:FEATURE_ID>1210016116</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832536.257</fme:EASTING>
<fme:NORTHING>821885.029</fme:NORTHING>
<fme:ENGLISHNAME>BROADWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>百老匯街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821885.02900 832536.25700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id68f52cac-38c5-49ce-b1fe-1e258ca10df2">
<fme:FEATURE_ID>1210027404</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832897.85</fme:EASTING>
<fme:NORTHING>821890.15</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI KOK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821890.14963 832897.84998 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb32cf6a7-ff7e-46bd-8f87-5f78181282b8">
<fme:FEATURE_ID>1210015294</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833012.523</fme:EASTING>
<fme:NORTHING>821893.698</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHUN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長順街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10212</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821893.69800 833012.52300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id65f6f3d6-dfbc-4696-a50e-000e1a2c110e">
<fme:FEATURE_ID>1210014910</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832312.69</fme:EASTING>
<fme:NORTHING>821913.886</fme:NORTHING>
<fme:ENGLISHNAME>GLEE PATH</fme:ENGLISHNAME>
<fme:CHINESENAME>吉利徑</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10607</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821913.88600 832312.69000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7318d801-8f18-4de6-b0b9-4df2dbef40d2">
<fme:FEATURE_ID>1210015217</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833211.457</fme:EASTING>
<fme:NORTHING>821915.266</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHUN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長順街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10212</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821915.26600 833211.45700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8d7ab64c-d24f-4132-a7ed-947dcdc68bfb">
<fme:FEATURE_ID>1210015403</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833028.884</fme:EASTING>
<fme:NORTHING>821919.911</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHA WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10206</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821919.91100 833028.88400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf6e1d97b-eaf1-4806-842d-ad073e0cc0e8">
<fme:FEATURE_ID>1210015207</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833583.592</fme:EASTING>
<fme:NORTHING>821928.055</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHA WAN PATH</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣徑</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10205</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821928.05500 833583.59200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id61e02179-e422-4624-85b5-229a64d9cd23">
<fme:FEATURE_ID>1210016052</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832992.213</fme:EASTING>
<fme:NORTHING>821961.58</fme:NORTHING>
<fme:ENGLISHNAME>KOM TSUN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>甘泉街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11057</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821961.58000 832992.21300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ide8835f5f-c0b9-4e93-8cc7-46290366848a">
<fme:FEATURE_ID>1210006289</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832492.595</fme:EASTING>
<fme:NORTHING>821966.284</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI KOK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821966.28400 832492.59500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id2a82d51b-ffa5-4b48-af98-3d3b518dea70">
<fme:FEATURE_ID>1210016188</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832685.825</fme:EASTING>
<fme:NORTHING>821967.811</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821967.81100 832685.82500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4d37ece4-965c-4f1e-9048-65c14922a881">
<fme:FEATURE_ID>1210017680</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833284.604</fme:EASTING>
<fme:NORTHING>821979.599</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG LAI STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長荔街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10196</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821979.59900 833284.60400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idcb24512e-d628-42d2-a13e-cf89a7b2c969">
<fme:FEATURE_ID>1210015925</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832205.595</fme:EASTING>
<fme:NORTHING>821990.173</fme:NORTHING>
<fme:ENGLISHNAME>LAI WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔灣道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11163</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821990.17300 832205.59500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7ed4fc78-5d6b-4a58-b39e-a8456b34a70c">
<fme:FEATURE_ID>1210015139</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833506.972</fme:EASTING>
<fme:NORTHING>822025.208</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG YUE STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長裕街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10222</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822025.20800 833506.97200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="iddeb8aa05-b693-44ea-8fd1-8495e6356647">
<fme:FEATURE_ID>1210015131</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833310.323</fme:EASTING>
<fme:NORTHING>822032.652</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHA WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10206</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822032.65200 833310.32300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf06c852c-2149-4b6a-82e1-b646594af2f9">
<fme:FEATURE_ID>1210015311</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832388.792</fme:EASTING>
<fme:NORTHING>822034.671</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822034.67100 832388.79200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ida6878c04-b448-4063-9069-edc52d1f50b2">
<fme:FEATURE_ID>1210015211</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833450.909</fme:EASTING>
<fme:NORTHING>822035.851</fme:NORTHING>
<fme:ENGLISHNAME>TAI NAN WEST STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>大南西街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12240</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822035.85100 833450.90900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id99d461a3-4227-44a0-975b-db488c67c53b">
<fme:FEATURE_ID>1210017078</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832510.108</fme:EASTING>
<fme:NORTHING>822044.021</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHA WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10206</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822044.02100 832510.10800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id04f1ceb3-77f9-4b4e-90a8-9b7018168db1">
<fme:FEATURE_ID>1210015923</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831884.219</fme:EASTING>
<fme:NORTHING>822074.015</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG INTERCHANGE</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌交匯處</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14066</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822074.01463 831884.21924 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0f88e377-c2bd-4769-974b-7c3a00f04ada">
<fme:FEATURE_ID>1210016018</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831777.534</fme:EASTING>
<fme:NORTHING>822075.796</fme:NORTHING>
<fme:ENGLISHNAME>TAT YEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>達洋路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13954</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822075.79600 831777.53400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="iddc3a800d-7f6d-4998-b60f-0b968d9e09e5">
<fme:FEATURE_ID>1210015140</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833160.109</fme:EASTING>
<fme:NORTHING>822086.416</fme:NORTHING>
<fme:ENGLISHNAME>CASTLE PEAK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青山道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10128</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822086.41600 833160.10900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7470fae8-ba80-417f-9a54-c500119f992c">
<fme:FEATURE_ID>1210016045</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832261.761</fme:EASTING>
<fme:NORTHING>822105.137</fme:NORTHING>
<fme:ENGLISHNAME>LAI WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔灣道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11163</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822105.13700 832261.76100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id938e31f1-fbfb-4163-a807-ea0fb79dcac6">
<fme:FEATURE_ID>1210014907</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832632.164</fme:EASTING>
<fme:NORTHING>822114.826</fme:NORTHING>
<fme:ENGLISHNAME>CASTLE PEAK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青山道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10128</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822114.82600 832632.16400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id61534895-84de-4ca4-a07d-afd8eae73d2f">
<fme:FEATURE_ID>1210014975</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833103.563</fme:EASTING>
<fme:NORTHING>822119.918</fme:NORTHING>
<fme:ENGLISHNAME>TUNG CHAU WEST STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>通州西街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12510</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822119.91800 833103.56300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id441b2127-bb3c-4375-b21f-b99ec4803ff4">
<fme:FEATURE_ID>1210016014</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831999.894</fme:EASTING>
<fme:NORTHING>822133.96</fme:NORTHING>
<fme:ENGLISHNAME>CHING CHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>呈祥道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822133.96000 831999.89400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8a8c9eee-dc4f-4232-ac1a-6f855dab2653">
<fme:FEATURE_ID>1210015137</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833114.911</fme:EASTING>
<fme:NORTHING>822135.023</fme:NORTHING>
<fme:ENGLISHNAME>WING HONG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>永康街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12724</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822135.02300 833114.91100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idda362938-2512-4610-8d22-7da55440f002">
<fme:FEATURE_ID>1210014909</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832412.958</fme:EASTING>
<fme:NORTHING>822180.36</fme:NORTHING>
<fme:ENGLISHNAME>NASSAU STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>蘭秀道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11503</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822180.36000 832412.95800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id5225baf2-ecbe-4975-a7f3-13a155ef7729">
<fme:FEATURE_ID>1210016178</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832526.778</fme:EASTING>
<fme:NORTHING>822185.347</fme:NORTHING>
<fme:ENGLISHNAME>MEI LAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>美荔道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11413</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822185.34700 832526.77800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ided021fe9-b2d9-4aeb-9677-3a646f90b16c">
<fme:FEATURE_ID>1210014969</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833227.636</fme:EASTING>
<fme:NORTHING>822189.706</fme:NORTHING>
<fme:ENGLISHNAME>YEE KUK WEST STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>醫局西街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12845</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822189.70600 833227.63600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idcf7ae216-bc57-4692-8cba-b4a3cf22e756">
<fme:FEATURE_ID>1210016117</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833550.733</fme:EASTING>
<fme:NORTHING>822231.943</fme:NORTHING>
<fme:ENGLISHNAME>CASTLE PEAK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青山道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10128</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822231.94300 833550.73300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idab9773e3-77bb-44d8-b528-10ec93fb92df">
<fme:FEATURE_ID>1210016181</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833741.363</fme:EASTING>
<fme:NORTHING>822245.591</fme:NORTHING>
<fme:ENGLISHNAME>FUK WA STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>福華街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10560</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822245.59101 833741.36321 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id3a512642-c44f-430f-939f-453d6cf3e5a8">
<fme:FEATURE_ID>1210006266</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831639.005</fme:EASTING>
<fme:NORTHING>822251.094</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG INTERCHANGE</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌交匯處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14066</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822251.09400 831639.00500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id9b3d2d04-8f5e-4976-8aa8-a5b66b23d337">
<fme:FEATURE_ID>1210016016</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832428.818</fme:EASTING>
<fme:NORTHING>822252.699</fme:NORTHING>
<fme:ENGLISHNAME>HUMBERT STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>恒柏道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10861</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822252.69900 832428.81800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id93656c93-afab-4a96-b595-3154e9cd5c9b">
<fme:FEATURE_ID>1210016049</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833659.002</fme:EASTING>
<fme:NORTHING>822253.208</fme:NORTHING>
<fme:ENGLISHNAME>KWONG CHEUNG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>光昌街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11118</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822253.20800 833659.00200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb221f5ec-bf19-44c0-b621-93f85ca9db01">
<fme:FEATURE_ID>1210015770</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833249.398</fme:EASTING>
<fme:NORTHING>822254.589</fme:NORTHING>
<fme:ENGLISHNAME>KING LAM STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>瓊林街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11026</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822254.58900 833249.39800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf93befbd-85b6-4c28-b51e-86541bf4d9ed">
<fme:FEATURE_ID>1210015564</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>UCL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832892.594</fme:EASTING>
<fme:NORTHING>822259.399</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>高架道路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822259.39943 832892.59438 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id43f795e8-32b4-4dc5-9d69-3f5741a5fd8d">
<fme:FEATURE_ID>1210015667</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833741.864</fme:EASTING>
<fme:NORTHING>822285.907</fme:NORTHING>
<fme:ENGLISHNAME>KIM SHIN LANE</fme:ENGLISHNAME>
<fme:CHINESENAME>兼善里</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10993</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822285.90700 833741.86400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id78c68c18-69d3-48c2-86a5-8f2341a59797">
<fme:FEATURE_ID>1210016187</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833497.812</fme:EASTING>
<fme:NORTHING>822297.53</fme:NORTHING>
<fme:ENGLISHNAME>YU CHAU WEST STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>汝州西街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12889</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822297.53000 833497.81200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idc9285c73-a482-4ca9-954b-da5c9c31de44">
<fme:FEATURE_ID>1210016012</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832867.132</fme:EASTING>
<fme:NORTHING>822314.261</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822314.26095 832867.13245 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id38bd9796-e384-45e7-b7fb-0364d314244a">
<fme:FEATURE_ID>1210015666</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833515.547</fme:EASTING>
<fme:NORTHING>822327.64</fme:NORTHING>
<fme:ENGLISHNAME>WING MING STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>永明街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12736</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822327.64000 833515.54700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id3ab85a69-f7b1-4aa7-9ad2-5d71fd47736f">
<fme:FEATURE_ID>1210015919</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832785.723</fme:EASTING>
<fme:NORTHING>822331.861</fme:NORTHING>
<fme:ENGLISHNAME>BUTTERFLY VALLEY ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>蝴蝶谷道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10101</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822331.86100 832785.72300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4b7ac262-1884-48ae-8f44-501035978d1c">
<fme:FEATURE_ID>1210015920</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832434.948</fme:EASTING>
<fme:NORTHING>822359.387</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822359.38700 832434.94800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ide7a045ff-c645-45b1-a21a-27f89824d865">
<fme:FEATURE_ID>1210018471</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833287.84</fme:EASTING>
<fme:NORTHING>822361.961</fme:NORTHING>
<fme:ENGLISHNAME>CHING CHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>呈祥道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822361.96100 833287.84000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="iddbe23979-ac54-4554-b156-6691c1f93786">
<fme:FEATURE_ID>1210006670</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831552.385</fme:EASTING>
<fme:NORTHING>822365.049</fme:NORTHING>
<fme:ENGLISHNAME>TSING KWAI HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青葵公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822365.04900 831552.38500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf8795982-4061-4414-8ec8-4bb03006d80d">
<fme:FEATURE_ID>1210018260</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831796.543</fme:EASTING>
<fme:NORTHING>822387.346</fme:NORTHING>
<fme:ENGLISHNAME>PRINCESS MARGARET HOSPITAL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>瑪嘉烈醫院路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11790</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822387.34600 831796.54300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf164e0d2-8ea1-46c9-84d8-eb603dade520">
<fme:FEATURE_ID>1210015922</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832114.149</fme:EASTING>
<fme:NORTHING>822408.903</fme:NORTHING>
<fme:ENGLISHNAME>CHING CHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>呈祥道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822408.90300 832114.14900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id171894d9-a666-4ae6-827c-27ffaed3d68f">
<fme:FEATURE_ID>1210016419</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832380.828</fme:EASTING>
<fme:NORTHING>822425.089</fme:NORTHING>
<fme:ENGLISHNAME>CHING CHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>呈祥道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822425.08900 832380.82800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8d57d1a2-5de7-4721-b833-ca3fdaf72cce">
<fme:FEATURE_ID>1210016825</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831563.849</fme:EASTING>
<fme:NORTHING>822426.753</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG INTERCHANGE</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌交匯處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14066</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822426.75300 831563.84900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8ac352b7-f20f-4a28-8429-141f6867a95c">
<fme:FEATURE_ID>1210016011</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832303.901</fme:EASTING>
<fme:NORTHING>822434.045</fme:NORTHING>
<fme:ENGLISHNAME>LAI WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔灣道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11163</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822434.04500 832303.90100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id048fcdf1-a626-4097-a4cf-f23ba449e9bc">
<fme:FEATURE_ID>1210015409</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833591.388</fme:EASTING>
<fme:NORTHING>822438.071</fme:NORTHING>
<fme:ENGLISHNAME>WING TAK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>永德路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39310</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822438.07100 833591.38800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id2940b54f-4f4d-4e3f-a0a9-210e9d6180ad">
<fme:FEATURE_ID>1210016654</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831786.747</fme:EASTING>
<fme:NORTHING>822440.589</fme:NORTHING>
<fme:ENGLISHNAME>PRINCESS MARGARET HOSPITAL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>瑪嘉烈醫院路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11790</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822440.58900 831786.74700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id52ce3214-64d3-4c27-ba56-cb4bdfd94548">
<fme:FEATURE_ID>1210016653</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831470.896</fme:EASTING>
<fme:NORTHING>822442.97</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822442.97000 831470.89600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb307c020-5995-46dd-905b-16bff68b0ab9">
<fme:FEATURE_ID>1210016189</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833665.797</fme:EASTING>
<fme:NORTHING>822469.25</fme:NORTHING>
<fme:ENGLISHNAME>WING TAK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>永德路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39310</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822469.25000 833665.79700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb8c7d6e0-bc4c-4f75-bf21-9808a3a9193e">
<fme:FEATURE_ID>1210016479</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832259.145</fme:EASTING>
<fme:NORTHING>822496.549</fme:NORTHING>
<fme:ENGLISHNAME>KING LAI PATH</fme:ENGLISHNAME>
<fme:CHINESENAME>景荔徑</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14087</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822496.54900 832259.14500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id143271f8-2853-4b37-a655-4228d106cae9">
<fme:FEATURE_ID>1210016417</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832726.777</fme:EASTING>
<fme:NORTHING>822581.689</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG HANG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長坑路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10190</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822581.68900 832726.77700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ida267daa3-4bc2-48df-b3e9-b8232d788676">
<fme:FEATURE_ID>1210016577</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831747.882</fme:EASTING>
<fme:NORTHING>822593.585</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG HOSPITAL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌醫院路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11078</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822593.58500 831747.88200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id790703a0-7c69-4565-9bdb-04c9d8fd66c8">
<fme:FEATURE_ID>1210016451</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832271.418</fme:EASTING>
<fme:NORTHING>822631.291</fme:NORTHING>
<fme:ENGLISHNAME>LAI KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822631.29100 832271.41800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idcac8a6f0-4e5b-4a42-94e3-6faa4a3a0382">
<fme:FEATURE_ID>1210016478</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832065.83</fme:EASTING>
<fme:NORTHING>822647.055</fme:NORTHING>
<fme:ENGLISHNAME>WA LAI PATH</fme:ENGLISHNAME>
<fme:CHINESENAME>華荔徑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12582</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822647.05500 832065.83000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0c7daadf-5ea7-45da-b039-eb07ec34f928">
<fme:FEATURE_ID>1210018258</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832856.024</fme:EASTING>
<fme:NORTHING>822648.732</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822648.73200 832856.02400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id445082a9-ae1d-487c-a06e-756a8f9b3960">
<fme:FEATURE_ID>1210016740</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831344.641</fme:EASTING>
<fme:NORTHING>822656.3</fme:NORTHING>
<fme:ENGLISHNAME>TSING KWAI HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青葵公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822656.30000 831344.64100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id148d07b7-1bd1-47d1-840e-909af02a8a24">
<fme:FEATURE_ID>1210018263</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832065.213</fme:EASTING>
<fme:NORTHING>822724.267</fme:NORTHING>
<fme:ENGLISHNAME>LAI KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822724.26700 832065.21300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id11bbb23f-3dcc-4ef7-b596-92d7a7475c1c">
<fme:FEATURE_ID>1210018268</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831567.505</fme:EASTING>
<fme:NORTHING>822744.194</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG HOSPITAL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌醫院路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11078</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822744.19400 831567.50500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id707651c3-eb58-45ee-bf96-a44d8a207875">
<fme:FEATURE_ID>1210016422</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831187.582</fme:EASTING>
<fme:NORTHING>822774.054</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822774.05400 831187.58200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id781c67c3-b5d1-495b-a5ac-bc69baf26ee7">
<fme:FEATURE_ID>1210016481</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831426.689</fme:EASTING>
<fme:NORTHING>822783.395</fme:NORTHING>
<fme:ENGLISHNAME>LAI KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822783.39500 831426.68900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id37581521-3d5e-47eb-b8d4-e97b74043e1f">
<fme:FEATURE_ID>1210015675</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833282.395</fme:EASTING>
<fme:NORTHING>822789.784</fme:NORTHING>
<fme:ENGLISHNAME>CALDECOTT ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>郝德傑道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10106</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822789.78400 833282.39500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id2551edd1-eda5-44f8-8f0b-033a07019c14">
<fme:FEATURE_ID>1210016179</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833590.902</fme:EASTING>
<fme:NORTHING>822824.364</fme:NORTHING>
<fme:ENGLISHNAME>TAI PO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>大埔道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12254</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822824.36370 833590.90195 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id28877e87-a734-4a68-bdf0-af832ebe2060">
<fme:FEATURE_ID>1210018266</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831060.576</fme:EASTING>
<fme:NORTHING>822844.467</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822844.46700 831060.57600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id9dd2eb0c-2acb-4a10-b423-baa2a7b285b8">
<fme:FEATURE_ID>1210002937</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830952.254</fme:EASTING>
<fme:NORTHING>822862.193</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822862.19300 830952.25400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idfae05fa9-c987-470c-a5e2-a0df0a1eeb74">
<fme:FEATURE_ID>1210016418</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831382.409</fme:EASTING>
<fme:NORTHING>822864.927</fme:NORTHING>
<fme:ENGLISHNAME>KING CHO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>敬祖路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11021</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822864.92700 831382.40900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="iddc291951-2562-41f6-8c34-2912aeb8dd33">
<fme:FEATURE_ID>1210016554</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833056.629</fme:EASTING>
<fme:NORTHING>822870.808</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822870.80800 833056.62900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idfc7dc424-e779-43ee-9075-ff5244c07d00">
<fme:FEATURE_ID>1210018141</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831208.433</fme:EASTING>
<fme:NORTHING>822889.676</fme:NORTHING>
<fme:ENGLISHNAME>LAI KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822889.67600 831208.43300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4f0b3491-1cd6-4db6-a548-1e0554f747c9">
<fme:FEATURE_ID>1210016832</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831587.614</fme:EASTING>
<fme:NORTHING>822917.505</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI LING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝嶺路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11150</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822917.50500 831587.61400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id5925a93a-3d3b-45ec-8671-3f037bb21116">
<fme:FEATURE_ID>1210018030</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831188.958</fme:EASTING>
<fme:NORTHING>822996.67</fme:NORTHING>
<fme:ENGLISHNAME>KING CHO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>敬祖路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11021</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822996.67000 831188.95800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id5a484e2c-5739-4df3-80e6-cde3b02f1a9c">
<fme:FEATURE_ID>1210018146</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831408.413</fme:EASTING>
<fme:NORTHING>823031.343</fme:NORTHING>
<fme:ENGLISHNAME>WING CHO STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>榮祖街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12714</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823031.34300 831408.41300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0bd6c71f-6a32-478d-9a21-de925379647a">
<fme:FEATURE_ID>1210006403</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832311.85</fme:EASTING>
<fme:NORTHING>823034.746</fme:NORTHING>
<fme:ENGLISHNAME>CASTLE PEAK ROAD - KWAI CHUNG</fme:ENGLISHNAME>
<fme:CHINESENAME>青山公路　－　葵涌段</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10132</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823034.74600 832311.85000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7a07f3e1-7a40-4a79-8f0f-9236885c8595">
<fme:FEATURE_ID>1210016830</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832563.015</fme:EASTING>
<fme:NORTHING>823037.842</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG HANG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長坑路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10190</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823037.84200 832563.01500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0eabd090-b40d-4324-a12d-db3e0acce977">
<fme:FEATURE_ID>1210016741</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831524.492</fme:EASTING>
<fme:NORTHING>823073.135</fme:NORTHING>
<fme:ENGLISHNAME>LAI KONG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>荔崗街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11157</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823073.13500 831524.49200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id76eb5f8c-d965-40e8-8251-b61c0e41309f">
<fme:FEATURE_ID>1210006474</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833625.116</fme:EASTING>
<fme:NORTHING>823115.941</fme:NORTHING>
<fme:ENGLISHNAME>TAI PO ROAD - PIPER'S HILL</fme:ENGLISHNAME>
<fme:CHINESENAME>大埔公路　－　琵琶山段</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12257</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823115.94100 833625.11600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idc03b05b9-fb55-4859-87a6-bd7bced2ca01">
<fme:FEATURE_ID>1210017494</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833536.592</fme:EASTING>
<fme:NORTHING>823152.541</fme:NORTHING>
<fme:ENGLISHNAME>EAGLE'S NEST TUNNEL</fme:ENGLISHNAME>
<fme:CHINESENAME>尖山隧道</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39535</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823152.54100 833536.59200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id70f9cfea-9e71-4922-bda2-7e10ee19c641">
<fme:FEATURE_ID>1210018255</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831710.339</fme:EASTING>
<fme:NORTHING>823153.694</fme:NORTHING>
<fme:ENGLISHNAME>WA TAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>華泰路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12586</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823153.69400 831710.33900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb9ef597f-c297-40a1-9d52-aa277d290718">
<fme:FEATURE_ID>1210016452</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832913.757</fme:EASTING>
<fme:NORTHING>823164.854</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG YUEN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長源路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10223</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823164.85400 832913.75700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id5f2442c8-1111-4a8d-b1f1-763bf6e06aae">
<fme:FEATURE_ID>1210003104</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830785.983</fme:EASTING>
<fme:NORTHING>823170.554</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10331</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823170.55400 830785.98300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id780c911e-8cdf-4ed7-a259-24c5b69caeaf">
<fme:FEATURE_ID>1210002775</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831356.618</fme:EASTING>
<fme:NORTHING>823220.82</fme:NORTHING>
<fme:ENGLISHNAME>LIM CHO STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>念祖街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11232</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823220.82000 831356.61800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4ba617f1-3a59-4094-9d2a-93640e59123c">
<fme:FEATURE_ID>1210016745</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831616.064</fme:EASTING>
<fme:NORTHING>823265.914</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI LING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝嶺路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11150</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823265.91400 831616.06400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6e085be6-0d7e-4a59-a293-8ffc638f0346">
<fme:FEATURE_ID>1210003102</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831393.668</fme:EASTING>
<fme:NORTHING>823291.908</fme:NORTHING>
<fme:ENGLISHNAME>LAI FUNG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>荔峰街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11154</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823291.90800 831393.66800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id79ee0091-554b-48d7-8665-76695013cd6b">
<fme:FEATURE_ID>1210003179</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830021.868</fme:EASTING>
<fme:NORTHING>823312.879</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TSING BRIDGE</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青橋</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39486</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823312.87900 830021.86800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id196cb35d-d285-49e1-85c1-6b71bf229dac">
<fme:FEATURE_ID>1210017408</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833085.695</fme:EASTING>
<fme:NORTHING>823321.819</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG YUEN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長源路</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10223</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823321.81891 833085.69518 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4aa63840-0358-4d14-a615-c46e8870a918">
<fme:FEATURE_ID>1210000225</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830902.622</fme:EASTING>
<fme:NORTHING>823345.261</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823345.26100 830902.62200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8ed19740-bc9b-4fec-b2dd-1d9b74a6a347">
<fme:FEATURE_ID>1210016450</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831894.086</fme:EASTING>
<fme:NORTHING>823345.796</fme:NORTHING>
<fme:ENGLISHNAME>CASTLE PEAK ROAD - KWAI CHUNG</fme:ENGLISHNAME>
<fme:CHINESENAME>青山公路　－　葵涌段</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10132</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823345.79600 831894.08600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6c66d22a-c292-4f2e-9a13-84e05b1c112f">
<fme:FEATURE_ID>1210000243</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830012.197</fme:EASTING>
<fme:NORTHING>823368.24</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI BRIDGE</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣大橋</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39485</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823368.24042 830012.19725 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id1d691bcd-aae7-482d-925b-1cbc9f861457">
<fme:FEATURE_ID>1210016827</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832093.081</fme:EASTING>
<fme:NORTHING>823392.385</fme:NORTHING>
<fme:ENGLISHNAME>WAH YUEN DRIVE</fme:ENGLISHNAME>
<fme:CHINESENAME>華員徑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12599</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823392.38500 832093.08100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7c6f345c-c45d-48f7-ae8a-59736d4209bf">
<fme:FEATURE_ID>1210018265</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831674.296</fme:EASTING>
<fme:NORTHING>823406.922</fme:NORTHING>
<fme:ENGLISHNAME>WA TAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>華泰路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12586</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823406.92200 831674.29600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id90f094ca-a321-4afc-998f-8b6bbc6598e6">
<fme:FEATURE_ID>1210029388</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831130.573</fme:EASTING>
<fme:NORTHING>823424.772</fme:NORTHING>
<fme:ENGLISHNAME>LAI KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823424.77248 831130.57251 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb97c85b6-7785-4502-b830-2e8960f457cc">
<fme:FEATURE_ID>1210005744</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830998.149</fme:EASTING>
<fme:NORTHING>823450.488</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260716</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823450.48822 830998.14926 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf01d77a4-0362-44a9-a0a1-36ca9d4166a1">
<fme:FEATURE_ID>1210016824</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832037.885</fme:EASTING>
<fme:NORTHING>823456.685</fme:NORTHING>
<fme:ENGLISHNAME>WAH YUEN DRIVE</fme:ENGLISHNAME>
<fme:CHINESENAME>華員徑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12599</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823456.68500 832037.88500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id157ce54b-e57b-444a-856e-2d1d9a5ea90b">
<fme:FEATURE_ID>1210003453</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831502.829</fme:EASTING>
<fme:NORTHING>823458.68</fme:NORTHING>
<fme:ENGLISHNAME>LAI KONG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>荔崗街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11157</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823458.68036 831502.82870 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7b03efde-0273-4a1b-92e3-54e31965ff72">
<fme:FEATURE_ID>1210018257</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831875.98</fme:EASTING>
<fme:NORTHING>823522.768</fme:NORTHING>
<fme:ENGLISHNAME>WAH KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>華景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12593</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823522.76800 831875.98000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idc580e16d-196b-4ba8-85e8-7acb04bca219">
<fme:FEATURE_ID>1210016487</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831718.438</fme:EASTING>
<fme:NORTHING>823555.419</fme:NORTHING>
<fme:ENGLISHNAME>TAI WO INTERCHANGE</fme:ENGLISHNAME>
<fme:CHINESENAME>大窩交匯處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13581</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823555.41900 831718.43800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8af4f5e0-311e-42b6-a14d-01b9a5f75a83">
<fme:FEATURE_ID>1210003034</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830391.341</fme:EASTING>
<fme:NORTHING>823560.915</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵泰路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823560.91500 830391.34100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id037a8f10-e21b-4519-9967-96415d702ae2">
<fme:FEATURE_ID>1210016353</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832333.812</fme:EASTING>
<fme:NORTHING>823568.407</fme:NORTHING>
<fme:ENGLISHNAME>WAH KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>華景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12593</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823568.40700 832333.81200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id26555f32-822c-46ec-8040-fa52d89381df">
<fme:FEATURE_ID>1210000230</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830149.996</fme:EASTING>
<fme:NORTHING>823571.018</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵泰路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823571.01800 830149.99600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idcaeff62e-2b0f-4893-b98f-15af0ec7a3fa">
<fme:FEATURE_ID>1210016998</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830786.984</fme:EASTING>
<fme:NORTHING>823604.024</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵泰路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823604.02400 830786.98400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id1a225dc9-331c-45c2-9514-300772225179">
<fme:FEATURE_ID>1210003451</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830029.752</fme:EASTING>
<fme:NORTHING>823606.444</fme:NORTHING>
<fme:ENGLISHNAME>KWAI YUE STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>葵裕街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11108</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823606.44400 830029.75200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4d9ffb8a-b817-4b2b-b89a-12bf775baddf">
<fme:FEATURE_ID>1210002940</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831198.906</fme:EASTING>
<fme:NORTHING>823622.901</fme:NORTHING>
<fme:ENGLISHNAME>JOINT STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>聯接街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10901</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823622.90100 831198.90600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id5157614b-200a-4526-b3e2-b75e661f8998">
<fme:FEATURE_ID>1210000218</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830245.549</fme:EASTING>
<fme:NORTHING>823627.83</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TSING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11101</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823627.83000 830245.54900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd41e91ff-6181-41fc-989e-279d545d539c">
<fme:FEATURE_ID>1210003329</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831556.667</fme:EASTING>
<fme:NORTHING>823628.997</fme:NORTHING>
<fme:ENGLISHNAME>WAH YIU ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>華瑤路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12598</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823628.99700 831556.66700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id621ceb8b-ed53-4349-8d7d-12c9c9baa775">
<fme:FEATURE_ID>1210016829</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831798.092</fme:EASTING>
<fme:NORTHING>823639.364</fme:NORTHING>
<fme:ENGLISHNAME>TAI WO INTERCHANGE</fme:ENGLISHNAME>
<fme:CHINESENAME>大窩交匯處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13581</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823639.36400 831798.09200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf173d3c9-feb4-4d76-8730-b1e8c51a8dba">
<fme:FEATURE_ID>1210003105</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831210.835</fme:EASTING>
<fme:NORTHING>823699.736</fme:NORTHING>
<fme:ENGLISHNAME>LAI KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823699.73631 831210.83489 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf003dca7-3aad-47f8-8c1b-e0429a31110a">
<fme:FEATURE_ID>1210003278</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831419.15</fme:EASTING>
<fme:NORTHING>823716.707</fme:NORTHING>
<fme:ENGLISHNAME>WAH YIU ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>華瑤路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12598</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823716.70700 831419.15000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id9f03a09d-2f75-44f0-ae51-e3a308d1fbe2">
<fme:FEATURE_ID>1210002936</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831296.858</fme:EASTING>
<fme:NORTHING>823716.938</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>麗祖路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11151</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823716.93822 831296.85755 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idcab3743f-a573-4d96-9dcc-815eb0bbfa21">
<fme:FEATURE_ID>1210002663</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830360.018</fme:EASTING>
<fme:NORTHING>823718.766</fme:NORTHING>
<fme:ENGLISHNAME>TSING KWAI HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青葵公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823718.76600 830360.01800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0cc75832-f314-4eda-b367-62aed82fc735">
<fme:FEATURE_ID>1210003457</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830828.593</fme:EASTING>
<fme:NORTHING>823718.983</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10331</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823718.98300 830828.59300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id45de9aeb-efbd-4a9a-94d6-b5d9972ed5dc">
<fme:FEATURE_ID>1210003452</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830743.139</fme:EASTING>
<fme:NORTHING>823721.616</fme:NORTHING>
<fme:ENGLISHNAME>KWAI HONG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>葵康街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11089</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823721.61600 830743.13900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idff9c4cff-2e58-48cb-8aa9-caf60dfcca0a">
<fme:FEATURE_ID>1210000228</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830508.637</fme:EASTING>
<fme:NORTHING>823733.33</fme:NORTHING>
<fme:ENGLISHNAME>KWAI KING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵景路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13016</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823733.33000 830508.63700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd7f5f841-55b6-4a75-9315-21cc892d5daa">
<fme:FEATURE_ID>1210018267</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832087.252</fme:EASTING>
<fme:NORTHING>823740.404</fme:NORTHING>
<fme:ENGLISHNAME>WAH KING HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>華景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12593</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823740.40400 832087.25200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id82ae3ed1-f910-4be8-a535-cbc1feafe433">
<fme:FEATURE_ID>1210003157</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831117.563</fme:EASTING>
<fme:NORTHING>823753.182</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823753.18200 831117.56300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idcfb4533b-644f-46fb-9f24-959a0ddb9b88">
<fme:FEATURE_ID>1210002702</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830739.476</fme:EASTING>
<fme:NORTHING>823768.06</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TAK STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>葵德街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11099</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823768.06000 830739.47600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd0602ade-3646-46dc-926b-d9b9e4049b3c">
<fme:FEATURE_ID>1210020231</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830927.548</fme:EASTING>
<fme:NORTHING>823768.447</fme:NORTHING>
<fme:ENGLISHNAME>MTR (TSUEN WAN LINE)</fme:ENGLISHNAME>
<fme:CHINESENAME>港鐵（荃灣綫）</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823768.44700 830927.54800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id90f40ee5-67bf-4d88-8db4-0e9a15030f1f">
<fme:FEATURE_ID>1210029387</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831002.691</fme:EASTING>
<fme:NORTHING>823770.185</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823770.18462 831002.69080 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id667b07fe-fe91-4396-a147-301ed45dea0d">
<fme:FEATURE_ID>1210016454</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831745.706</fme:EASTING>
<fme:NORTHING>823783.298</fme:NORTHING>
<fme:ENGLISHNAME>CASTLE PEAK ROAD - KWAI CHUNG</fme:ENGLISHNAME>
<fme:CHINESENAME>青山公路　－　葵涌段</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10132</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823783.29800 831745.70600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id1c836673-5c59-4320-bd14-9466e0ae14a7">
<fme:FEATURE_ID>1210000227</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831165.618</fme:EASTING>
<fme:NORTHING>823821.652</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823821.65200 831165.61800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id45671739-92e8-4b81-b956-35a1f2174e2d">
<fme:FEATURE_ID>1210003035</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831530.689</fme:EASTING>
<fme:NORTHING>823825.75</fme:NORTHING>
<fme:ENGLISHNAME>LAI YIU STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>麗瑤街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11169</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823825.75004 831530.68942 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf4e8f981-6770-4efe-9a11-9af9ac4a3616">
<fme:FEATURE_ID>1210003189</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830709.904</fme:EASTING>
<fme:NORTHING>823826.921</fme:NORTHING>
<fme:ENGLISHNAME>KWAI WO STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>葵和街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823826.92100 830709.90400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7956efff-2c14-4f7c-bcdf-55e644ad8461">
<fme:FEATURE_ID>1210000222</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830551.058</fme:EASTING>
<fme:NORTHING>823849.298</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TSING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11101</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823849.29800 830551.05800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0c42dfc5-929a-4c8e-b263-e5e93a21415f">
<fme:FEATURE_ID>1210002683</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830058.448</fme:EASTING>
<fme:NORTHING>823875.118</fme:NORTHING>
<fme:ENGLISHNAME>KWAI YUE STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>葵裕街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11108</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823875.11800 830058.44800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id9535b696-4899-436a-b480-0d3cc3de8355">
<fme:FEATURE_ID>1210000217</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831407.836</fme:EASTING>
<fme:NORTHING>823875.451</fme:NORTHING>
<fme:ENGLISHNAME>LAI YIU STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>麗瑤街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11169</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823875.45100 831407.83600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7c2d1c43-016b-4a30-83aa-91325069b2d0">
<fme:FEATURE_ID>1210000229</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830808.715</fme:EASTING>
<fme:NORTHING>823877.161</fme:NORTHING>
<fme:ENGLISHNAME>KWAI SHUN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>葵順街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11096</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823877.16100 830808.71500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id255a076f-0ff2-4c48-aeb1-73e2f53709ab">
<fme:FEATURE_ID>1210016370</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831614.373</fme:EASTING>
<fme:NORTHING>823881.711</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>麗祖路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11151</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823881.71100 831614.37300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idffd1a70e-ba0a-4102-85ee-2a30f3edb23b">
<fme:FEATURE_ID>1210000199</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831545.446</fme:EASTING>
<fme:NORTHING>823931.381</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>麗祖路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11151</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823931.38100 831545.44600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idde4fdf4e-14f8-4a82-a8ea-f537b736c6ce">
<fme:FEATURE_ID>1210002755</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831253.994</fme:EASTING>
<fme:NORTHING>823946.424</fme:NORTHING>
<fme:ENGLISHNAME>KWAI FUK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵福路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11083</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823946.42400 831253.99400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id222d664b-cc72-478d-99a5-9c17992c9a0b">
<fme:FEATURE_ID>1210018091</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833652.899</fme:EASTING>
<fme:NORTHING>823950.202</fme:NORTHING>
<fme:ENGLISHNAME>GOLDEN HILL ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>金山路</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10612</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823950.20200 833652.89900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id9885da2d-289b-499c-b099-22f01fa4b9e0">
<fme:FEATURE_ID>1210016371</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831635.072</fme:EASTING>
<fme:NORTHING>823965.61</fme:NORTHING>
<fme:ENGLISHNAME>SAN KWAI STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>新葵街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11895</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823965.61000 831635.07200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id752a1ec0-5a94-48fa-8bbd-0a9254067911">
<fme:FEATURE_ID>1210002935</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830110.826</fme:EASTING>
<fme:NORTHING>823975.416</fme:NORTHING>
<fme:ENGLISHNAME>KWAI HEI STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>葵喜街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11086</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823975.41600 830110.82600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf2e8e7bb-9caf-463f-9c03-e5e10911f699">
<fme:FEATURE_ID>1210003032</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830827.024</fme:EASTING>
<fme:NORTHING>823979.996</fme:NORTHING>
<fme:ENGLISHNAME>TSUEN WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>荃灣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12469</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823979.99600 830827.02400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6e542fb3-2ee2-4a87-a2a5-12cab2e5c00e">
<fme:FEATURE_ID>1210003188</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830905.609</fme:EASTING>
<fme:NORTHING>823989.828</fme:NORTHING>
<fme:ENGLISHNAME>KWAI FUNG CRESCENT</fme:ENGLISHNAME>
<fme:CHINESENAME>葵豐街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11084</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823989.82800 830905.60900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id348babe9-d20c-443d-9bf7-a136c973994d">
<fme:FEATURE_ID>1210003187</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831184.477</fme:EASTING>
<fme:NORTHING>823992.367</fme:NORTHING>
<fme:ENGLISHNAME>KWAI FUK ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵福路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11083</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823992.36700 831184.47700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
</gml:FeatureCollection>
