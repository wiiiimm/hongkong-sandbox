<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme RoadLineAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>823041.32985 833225.01677</gml:lowerCorner>
<gml:upperCorner>823041.32985 833225.01677</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:RoadLineAnno_C gml:id="id5cd24c9b-a161-4fe6-9c38-8bc0e08aba76">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>隧道口</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>40.476777329158</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310000064</fme:FEATURE_ID>
<fme:FEATURECODE>TPO</fme:FEATURECODE>
<fme:EASTING>833225.017</fme:EASTING>
<fme:NORTHING>823041.33</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231227</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823041.32985 833225.01677</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:RoadLineAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
