<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821138.07030 830050.57840</gml:lowerCorner>
<gml:upperCorner>823941.80752 833726.67485</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc0cf9234-8983-4d0c-88a0-7e5e3757df28">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI KING HILL ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000076</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832024.0889264</fme:EASTING>
<fme:NORTHING>822624.30132396</fme:NORTHING>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018263</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822576.74125 832039.93570</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idd1203ef2-af91-4b30-aaff-0ed3828efe83">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CALDECOTT ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000082</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833363.4623671</fme:EASTING>
<fme:NORTHING>822771.89616501</fme:NORTHING>
<fme:ST_CODE>10106</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015675</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822796.92529 833400.73621</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id6b5ced45-7609-475c-b5d0-091c3f8ef84a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHING CHEUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.2551124254511</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000085</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833307.19402678</fme:EASTING>
<fme:NORTHING>822363.62214595</fme:NORTHING>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018471</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822387.30545 833371.07350</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc7fcdb0c-e968-40c1-9820-27a1d635a24a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KING LAM STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4200019466202</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000156</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833223.57544913</fme:EASTING>
<fme:NORTHING>822241.4718329</fme:NORTHING>
<fme:ST_CODE>11026</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015770</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822260.76923 833266.64585</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id0846bd2c-d659-4730-a70d-f45cdd5410c3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WA TAI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000190</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831744.412</fme:EASTING>
<fme:NORTHING>823103.242</fme:NORTHING>
<fme:ST_CODE>12586</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018255</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823108.31989 831741.95241</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id7bfbfe79-d1d3-42a9-afb9-e6061bb3e2e4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WEST KOWLOON CORRIDOR</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000277</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833512.395678</fme:EASTING>
<fme:NORTHING>821795.98658256</fme:NORTHING>
<fme:ST_CODE>14283</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017560</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821705.49800 833552.12949</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id865ff34d-b3c5-46a7-a020-09f25c13802d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WA LAI PATH</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000286</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832069.88356733</fme:EASTING>
<fme:NORTHING>822624.3981116</fme:NORTHING>
<fme:ST_CODE>12582</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016478</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822595.25069 832081.29976</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id9ca135e2-e961-4d5b-b6b1-f808700d91ec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SHAM MONG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-29.7034926653061</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000356</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833472.022</fme:EASTING>
<fme:NORTHING>821328.265</fme:NORTHING>
<fme:ST_CODE>13892</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016168</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821328.26530 833472.02160</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id3875158d-6baf-41d7-9951-61b331419d69">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI HONG STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000360</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833448.88985041</fme:EASTING>
<fme:NORTHING>821471.37595125</fme:NORTHING>
<fme:ST_CODE>11155</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014895</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821450.86577 833490.43422</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idd43e313d-3cb0-4b40-a767-c2e3736720e6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CONTAINER PORT ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.4248186743835</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000369</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830766.3507465</fme:EASTING>
<fme:NORTHING>823224.80530709</fme:NORTHING>
<fme:ST_CODE>10331</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003104</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823166.73244 830787.95210</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id32b899b2-99a7-47aa-a429-60bb34351000">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>FAT TSEUNG ST WEST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.640004760481</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000406</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833636.474</fme:EASTING>
<fme:NORTHING>821368.851</fme:NORTHING>
<fme:ST_CODE>13895</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016105</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821368.85092 833636.47406</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="iddb5e04ee-ce53-4c56-93ca-8744275e15dc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI CHUNG
INTERCHANGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000516</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831562.45055768</fme:EASTING>
<fme:NORTHING>822424.07777728</fme:NORTHING>
<fme:ST_CODE>14066</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016825</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822431.74313 831598.44327</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idfc7d99ba-48e6-481d-9f9a-f8589ee898cc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WAH KING HILL ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-49.9183869772086</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000558</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831895.6833166</fme:EASTING>
<fme:NORTHING>823492.16752109</fme:NORTHING>
<fme:ST_CODE>12593</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018257</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823451.27574 831934.09107</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ida06747a2-b1e4-47ab-ae24-d18625974222">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TUNG CHAU WEST STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.9299998231376</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000620</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833100.66260188</fme:EASTING>
<fme:NORTHING>822122.04876459</fme:NORTHING>
<fme:ST_CODE>12510</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014975</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822057.88258 833127.36121</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idd5b00c2e-0d4a-4621-811e-c86f279bf0a2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CASTLE PEAK ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000665</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832640.90674387</fme:EASTING>
<fme:NORTHING>822096.72509107</fme:NORTHING>
<fme:ST_CODE>10128</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014907</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822053.39026 832667.58260</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id9b93fc4f-6964-4a10-a197-912a8df51502">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI YUE STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.8762303944937</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000706</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830043.07146279</fme:EASTING>
<fme:NORTHING>823781.07568082</fme:NORTHING>
<fme:ST_CODE>11108</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002683</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823827.81887 830050.57840</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id8ec671f0-224f-4d1b-be91-438c4b183b13">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG YEE STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3305695636271</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000724</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833363.57543937</fme:EASTING>
<fme:NORTHING>821906.63380915</fme:NORTHING>
<fme:ST_CODE>10220</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014972</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821928.91618 833414.91363</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id7166b0cd-af3a-4520-9147-9a3af2ec0574">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG YUEN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000730</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833092.81025868</fme:EASTING>
<fme:NORTHING>823328.21666374</fme:NORTHING>
<fme:ST_CODE>10223</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017408</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823310.75748 833147.73475</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id4665e411-a023-43bc-83ce-d4bc10d80b96">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TAT YEUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000802</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831824.58219813</fme:EASTING>
<fme:NORTHING>822064.88186777</fme:NORTHING>
<fme:ST_CODE>13954</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016018</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822048.77622 831862.08782</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id436f0dc9-caba-4757-9cdc-37159b9c402c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>GOLDEN HILL RD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000777</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833707.45871687</fme:EASTING>
<fme:NORTHING>823944.42399007</fme:NORTHING>
<fme:ST_CODE>10612</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018091</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823901.80537 833722.74255</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id0b4dc313-e7fb-4b3b-b633-5da01c2055b4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TAI PO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001421</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833633.85679457</fme:EASTING>
<fme:NORTHING>822775.80814952</fme:NORTHING>
<fme:ST_CODE>12254</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016179</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822743.28662 833679.75579</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc86152b0-8fd0-4b39-ac70-a9673293800e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LIN CHEUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-22.6024007035049</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000978</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833111.81919578</fme:EASTING>
<fme:NORTHING>821283.57814154</fme:NORTHING>
<fme:ST_CODE>13922</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016173</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821267.73558 833157.82940</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idf116c258-5ddb-4c4f-97f2-bb0dfb19e076">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>BROADWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>65.1144425326028</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000980</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832539.55222716</fme:EASTING>
<fme:NORTHING>821884.35707458</fme:NORTHING>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016116</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821907.88087 832546.58964</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idefce9436-1b5c-4a72-8f31-69c589c4958c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI WAN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>65.3152036635426</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001008</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832277.71388596</fme:EASTING>
<fme:NORTHING>822150.11854014</fme:NORTHING>
<fme:ST_CODE>11163</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016045</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822182.29073 832292.50110</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id66ef3bb3-8c98-4771-8119-d4f07b43742f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>MEI LAI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.416535764949</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001230</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832515.35781199</fme:EASTING>
<fme:NORTHING>822206.45852988</fme:NORTHING>
<fme:ST_CODE>11413</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016178</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822173.94130 832530.83555</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id0bb963cb-273f-4e07-b971-3135232abee4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI FUNG STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001464</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831408.794</fme:EASTING>
<fme:NORTHING>823371.541</fme:NORTHING>
<fme:ST_CODE>11154</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003102</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823371.53313 831408.96343</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ida1a4d07e-2899-44bc-9616-345b90997e44">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TAI PO ROAD - PIPER'S HILL</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001020</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833616.52761187</fme:EASTING>
<fme:NORTHING>823083.37024</fme:NORTHING>
<fme:ST_CODE>12257</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006474</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823173.03762 833652.74763</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id75e32aaa-ff69-44a7-8e55-d1606cb03438">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KING CHO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001027</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831155.73309298</fme:EASTING>
<fme:NORTHING>823010.31264393</fme:NORTHING>
<fme:ST_CODE>11021</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018030</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822996.41865 831195.38774</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id562b54af-6826-453b-a1f7-361c519cbbaf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI CHUNG HOSPITAL ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000808</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831602.18601624</fme:EASTING>
<fme:NORTHING>822719.98948588</fme:NORTHING>
<fme:ST_CODE>11078</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018268</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822681.35123 831652.18663</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id32691468-b132-4128-9c63-26d12790e81a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI TSING ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>48.1288126957397</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000823</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830511.13437999</fme:EASTING>
<fme:NORTHING>823799.85518385</fme:NORTHING>
<fme:ST_CODE>11101</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000222</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823844.38670 830546.12262</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id99dfb897-e398-4f97-bf98-5fcf7fc7cdc8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI CHO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>52.7870049346365</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000837</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831248.97040402</fme:EASTING>
<fme:NORTHING>823651.91800973</fme:NORTHING>
<fme:ST_CODE>11151</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002936</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823677.31087 831268.25371</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idfd1bf384-ccf5-4e32-9799-6c88f0095b2b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI CHO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.2122417651473</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001558</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831581.92040875</fme:EASTING>
<fme:NORTHING>823905.1154926</fme:NORTHING>
<fme:ST_CODE>11151</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016370</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823881.94330 831613.56701</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="iddba2b1fa-8bbe-4699-a004-da79ea7e1347">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WING TAK RD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1878752854306</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000870</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833651.27680381</fme:EASTING>
<fme:NORTHING>822459.24528249</fme:NORTHING>
<fme:ST_CODE>39310</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016189</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822474.13627 833682.91593</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id1ea6c2b0-9aa2-4bd9-a295-4f593f9aa415">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>EAGLE'S NEST TUNNEL</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>12.2787719946026</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000875</fme:FEATURE_ID>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:EASTING>833530.44815764</fme:EASTING>
<fme:NORTHING>823165.75913424</fme:NORTHING>
<fme:ST_CODE>39535</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017494</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823181.32474 833587.58877</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id38ff3e6f-6139-4315-a0cf-1b66ef6cd395">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG SHA WAN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-9.91652511572316</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001119</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832789.099</fme:EASTING>
<fme:NORTHING>821958.422</fme:NORTHING>
<fme:ST_CODE>10206</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017078</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821958.42246 832789.09876</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id482a142b-ec63-44f0-b487-36bb0d889c94">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG SHUN STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3354103801482</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000902</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833333.37113856</fme:EASTING>
<fme:NORTHING>821957.91098614</fme:NORTHING>
<fme:ST_CODE>10212</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015217</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821981.63662 833388.58997</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id61e0c24b-681f-4cda-b008-fd08fda68d07">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WAH YIU ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-20.1883577620614</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001138</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831544.147</fme:EASTING>
<fme:NORTHING>823633.701</fme:NORTHING>
<fme:ST_CODE>12598</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003329</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823633.70146 831544.14721</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idb2b5136b-ddb6-4176-9f07-e880dd316bd1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI CHUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-22.8700607968342</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001378</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831186.08166949</fme:EASTING>
<fme:NORTHING>822771.34391794</fme:NORTHING>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016422</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822751.46761 831242.64482</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idff85875a-65d3-4c7a-974e-04ee19d2b35a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>FUK WA ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.4499873808399</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000927</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833726.67485278</fme:EASTING>
<fme:NORTHING>822257.81864699</fme:NORTHING>
<fme:ST_CODE>10560</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016181</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822257.81865 833726.67485</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id7cb9d639-76a0-40c2-ae73-01e8e0e585b4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG LAI ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.7448674577323</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001151</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833314.779</fme:EASTING>
<fme:NORTHING>821897.906</fme:NORTHING>
<fme:ST_CODE>10196</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210017680</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821897.90646 833314.77874</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id8fb06575-ca35-49cd-8442-7a36da5bf20e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TAT MEI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-30.9707159309492</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000931</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831893.636</fme:EASTING>
<fme:NORTHING>821725.056</fme:NORTHING>
<fme:ST_CODE>14337</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014942</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821725.05585 831893.63647</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc264a9c8-ee8d-46aa-960f-144b537f65d6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI WO STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.2192686145405</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000952</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830716.721</fme:EASTING>
<fme:NORTHING>823848.466</fme:NORTHING>
<fme:ST_CODE>13051</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003189</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823848.46573 830716.72097</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id23f59fec-80a4-4553-85b7-1723d9522bef">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI PO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>41.871187767899</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000963</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832555.4165823</fme:EASTING>
<fme:NORTHING>821139.24608156</fme:NORTHING>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018148</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821164.23292 832578.71221</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc1e1b47a-1c50-46d2-82d6-6b7c4b5b208c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TAI WO
INTERCHANGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.298412819994883</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001868</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831765.51261595</fme:EASTING>
<fme:NORTHING>823581.15358636</fme:NORTHING>
<fme:ST_CODE>13581</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016487</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823588.62299 831800.68993</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idb677782d-7499-4415-a9d5-e4d36722068b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>MEI CHING ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002092</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832184.98387271</fme:EASTING>
<fme:NORTHING>821437.76292672</fme:NORTHING>
<fme:ST_CODE>13897</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018029</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821459.92123 832221.81545</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id5e9a85c6-b93c-4568-b008-b76e5b552df9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HOI LAI STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.5275567777037</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002565</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833239.09457305</fme:EASTING>
<fme:NORTHING>821374.15197969</fme:NORTHING>
<fme:ST_CODE>14190</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016171</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821404.95479 833264.46158</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ida38a7be4-3927-49a3-8189-db58ffe3bf8a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CONTAINER PORT ROAD SOUTH</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.8523753623234</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002127</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831674.10636233</fme:EASTING>
<fme:NORTHING>821770.53840543</fme:NORTHING>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016746</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821693.22287 831701.16185</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id6d19c9b9-6b02-4d59-b422-0caca88f5227">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WAH YUEN DRIVE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002363</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832035.83143467</fme:EASTING>
<fme:NORTHING>823456.10642021</fme:NORTHING>
<fme:ST_CODE>12599</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016824</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823432.47808 832067.41865</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id107b6043-51ab-4594-872d-10c817cfcc5d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WAH KING HILL ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-53.6700009312541</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002584</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832326.21</fme:EASTING>
<fme:NORTHING>823573.1</fme:NORTHING>
<fme:ST_CODE>12593</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016353</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823529.78278 832361.85986</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idcfa20418-dfdb-4dc6-a1c9-724171eed353">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI CHI KOK ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.245427821381</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001921</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833628.07334372</fme:EASTING>
<fme:NORTHING>821852.25223932</fme:NORTHING>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015292</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821818.11648 833675.65976</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id9b7a1d22-f30c-4e5e-943b-2312a354d2ba">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI FUK ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001925</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831234.55381447</fme:EASTING>
<fme:NORTHING>823962.28610837</fme:NORTHING>
<fme:ST_CODE>11083</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002755</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823941.80752 831256.83990</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id46cb9ee7-75dc-4cad-86bd-925e67b7e3f6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CASTLE PEAK ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.5500008051604</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002149</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833425.95624196</fme:EASTING>
<fme:NORTHING>822182.4319193</fme:NORTHING>
<fme:ST_CODE>10128</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016117</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822203.51399 833473.48283</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id8f985b99-6769-4857-9679-a60be496c004">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI TAI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.3966056543497</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002174</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830491.84049454</fme:EASTING>
<fme:NORTHING>823588.48235749</fme:NORTHING>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003034</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823603.17200 830528.49854</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idd91e6fdf-65b1-4271-b603-22e4beef844a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI WAN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-57.2848826427594</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002399</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832319.02736078</fme:EASTING>
<fme:NORTHING>822408.68155182</fme:NORTHING>
<fme:ST_CODE>11163</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016011</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822378.22116 832342.22793</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id8c8a95cf-afaa-4482-91cb-04f86930c5c3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>BUTTERFLY VALLEY RD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001957</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832809.42764035</fme:EASTING>
<fme:NORTHING>822310.56768148</fme:NORTHING>
<fme:ST_CODE>10101</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015919</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822265.60634 832842.66503</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id1f0605c8-e100-4e19-8141-2972bde4b48a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CONTAINER PORT ROAD SOUTH</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002454</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830926.003105</fme:EASTING>
<fme:NORTHING>822888.26478754</fme:NORTHING>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002937</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822827.88914 830984.85557</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id78b49a2c-4806-4e2b-8d74-0c3d0a23d814">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HING WAH STREET WEST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001785</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832949.3006207</fme:EASTING>
<fme:NORTHING>821190.89447059</fme:NORTHING>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015830</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821162.91468 833002.67344</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id8089e90c-b091-4eb3-a9f7-41a37b758706">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SHAM SHING ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002008</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833361.17115188</fme:EASTING>
<fme:NORTHING>821630.95054577</fme:NORTHING>
<fme:ST_CODE>13953</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015138</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821636.69333 833409.63976</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ideb821f45-daa9-4965-8085-8fccf18c8b64">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSUEN WAN RD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.2928202330433</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002465</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830847.050517</fme:EASTING>
<fme:NORTHING>823962.30705041</fme:NORTHING>
<fme:ST_CODE>12469</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003032</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823928.08841 830880.92118</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id9b09bb05-bb39-4808-88a4-19a1f30ccd51">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI FAT ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.7691909437439</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002466</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833626.98387425</fme:EASTING>
<fme:NORTHING>821468.04368754</fme:NORTHING>
<fme:ST_CODE>11152</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016106</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821447.74208 833651.37729</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ided2bb791-9e3e-4ce1-9a57-b44fabaab1e9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LIN CHEUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.3976844037009</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002481</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832430.142</fme:EASTING>
<fme:NORTHING>821496.31</fme:NORTHING>
<fme:ST_CODE>13922</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210027449</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821496.30977 832430.14244</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id91c277f1-a7e6-44fa-bb21-4e4271d68a89">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING SHA HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>38.0996692059265</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002018</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832546.67983923</fme:EASTING>
<fme:NORTHING>821088.47844244</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015745</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821138.07030 832602.99012</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idbd724352-37d8-44ab-8af7-f3b1f93f3479">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>BROADWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.9099741081654</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002023</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832385.41632199</fme:EASTING>
<fme:NORTHING>821868.8127506</fme:NORTHING>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015959</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821860.98152 832408.54505</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc466121e-537c-4946-8368-94a7c1555949">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LIM CHO STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-48.5106856959354</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002486</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831441.14</fme:EASTING>
<fme:NORTHING>823100.165</fme:NORTHING>
<fme:ST_CODE>11232</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002775</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823100.16507 831441.14033</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id3a51fbb3-c181-4ac8-b8ee-625dff06dbae">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING KWAI HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.6136251749969</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002049</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831538.63896403</fme:EASTING>
<fme:NORTHING>822366.49922077</fme:NORTHING>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006670</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822296.63051 831575.01264</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc53df07c-ff3c-42d4-be98-162a766771f2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG YUE ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002272</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833490.43375651</fme:EASTING>
<fme:NORTHING>822016.21239666</fme:NORTHING>
<fme:ST_CODE>10222</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015139</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822032.14422 833524.03225</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idbc24c82f-f5b6-4724-bb44-75a96388f381">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WING MING ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002279</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833595.88827362</fme:EASTING>
<fme:NORTHING>822355.543581</fme:NORTHING>
<fme:ST_CODE>12736</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015666</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822373.93913 833626.41314</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id25789536-f1e4-45d8-be89-2a970b5c66d6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI TAI RD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.095240180201</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002513</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830149.87024179</fme:EASTING>
<fme:NORTHING>823567.68443446</fme:NORTHING>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000230</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823581.62688 830179.08059</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id27877614-a99e-4ab4-830c-ae2738030f5c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG SHA WAN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.5560482674173</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002516</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833218.31392142</fme:EASTING>
<fme:NORTHING>821992.18947553</fme:NORTHING>
<fme:ST_CODE>10206</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015131</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822019.32781 833290.68280</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id47fdc215-888c-4ff8-bed7-e49e41a93985">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PO LUN STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>79.5852330723635</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002067</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832741.70100683</fme:EASTING>
<fme:NORTHING>821713.95026954</fme:NORTHING>
<fme:ST_CODE>11746</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016109</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821755.47866 832746.22522</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id4c811ef8-3516-4a44-a1a5-4f0c8f0b1c72">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI CHI LING ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003175</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831612.78455448</fme:EASTING>
<fme:NORTHING>823271.7133035</fme:NORTHING>
<fme:ST_CODE>11150</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016745</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823224.22888 831622.51602</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idb9158af5-6289-4a6f-b2c6-12d917adf345">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HING WAH ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.1900042050886</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002780</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833701.48132991</fme:EASTING>
<fme:NORTHING>821839.45197312</fme:NORTHING>
<fme:ST_CODE>10731</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015064</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821868.35515 833721.59084</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ide2ed5547-df7e-4e1e-9a10-81c72d2e6425">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI YIU STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003429</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831483.34641533</fme:EASTING>
<fme:NORTHING>823840.02078878</fme:NORTHING>
<fme:ST_CODE>11169</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003035</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823830.17406 831520.99492</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idae7b7d8f-9898-4b1e-b732-542cc821f4da">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WING CHO ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003009</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831408.72583138</fme:EASTING>
<fme:NORTHING>823027.63220441</fme:NORTHING>
<fme:ST_CODE>12714</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018146</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823003.85926 831434.28147</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idce28e83c-ec52-41eb-a7a4-fb4f22241fc3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG SHA WAN PATH</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>78.822085663384</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003022</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833578.23756447</fme:EASTING>
<fme:NORTHING>821899.75016811</fme:NORTHING>
<fme:ST_CODE>10205</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015207</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821961.33342 833590.40671</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc221da82-ce00-4271-9def-19bd6b07a3d4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>GLEE PATH</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-25.5372606449086</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002816</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832410.24083337</fme:EASTING>
<fme:NORTHING>821935.1055333</fme:NORTHING>
<fme:ST_CODE>10607</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014910</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821925.71283 832436.99256</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id624c337a-e330-45f4-9ced-c8cada797852">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING SHA HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003273</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832857.68567006</fme:EASTING>
<fme:NORTHING>822619.95882546</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018258</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822692.66842 832895.55049</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id574dd0a4-7d11-4601-9c1c-c26ea106e3e0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>BROADWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>79.6241527333586</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003285</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832702.84029682</fme:EASTING>
<fme:NORTHING>821842.66330602</fme:NORTHING>
<fme:ST_CODE>10092</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016177</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821870.72017 832704.86912</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id6b842b61-e1ea-46d8-9028-76bf2926f57e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KING LAI PATH</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003076</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832117.95017427</fme:EASTING>
<fme:NORTHING>822457.9398065</fme:NORTHING>
<fme:ST_CODE>14087</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016479</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822480.97947 832148.42393</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id14998099-ad0c-4ed5-b6fe-d91caf54a360">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CASTLE PEAK ROAD - KWAI CHUNG</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002656</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831861.82162416</fme:EASTING>
<fme:NORTHING>823377.53961943</fme:NORTHING>
<fme:ST_CODE>10132</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016450</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823297.02016 831957.06559</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idd6f2021d-03d2-422d-a44b-178578ba51b6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI TAK STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.0584391046361</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003313</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830742.2584092</fme:EASTING>
<fme:NORTHING>823773.75760655</fme:NORTHING>
<fme:ST_CODE>11099</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002702</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823816.60166 830760.39308</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id4736de83-8926-40e0-9db9-17a26ec1dea2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI KONG STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.2422461232091</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003352</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831493.74049051</fme:EASTING>
<fme:NORTHING>823370.63715332</fme:NORTHING>
<fme:ST_CODE>11157</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003453</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823417.47445 831497.03545</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id798fdf7f-7f8d-42d3-a569-dea26aa0c7a1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI KING HILL ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.0216847616269</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002732</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831197.62917874</fme:EASTING>
<fme:NORTHING>823668.55624817</fme:NORTHING>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003105</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823722.58767 831220.54002</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ideb33c19d-8187-4cfb-beee-24fb22e7b2c5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI KING HILL ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-25.8753710013769</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003626</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831370.79287044</fme:EASTING>
<fme:NORTHING>822806.51585799</fme:NORTHING>
<fme:ST_CODE>11156</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016481</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822786.34984 831419.37463</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idf742c1bd-1917-4a2c-b5e1-1a764f00c671">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PRINCESS MARGARET HOSPITAL ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003637</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831863.108</fme:EASTING>
<fme:NORTHING>822408.693</fme:NORTHING>
<fme:ST_CODE>11790</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018260</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822408.77026 831863.18033</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id85e38245-499c-48b4-bbe8-0c3e816e8226">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WING HONG STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2199975404828</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003650</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833293.498</fme:EASTING>
<fme:NORTHING>822202.877</fme:NORTHING>
<fme:ST_CODE>12724</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015137</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822202.87692 833293.49755</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id7efaca92-58c0-4c66-880d-c5355cd72d48">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG HANG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003670</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832772.13107058</fme:EASTING>
<fme:NORTHING>822732.16347011</fme:NORTHING>
<fme:ST_CODE>10190</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016417</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822760.54247 832788.50828</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id6ebf148e-cab7-4e26-9b13-c07e66b79522">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WEST KOWLOON HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-22.7460902790867</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003680</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833045.73079854</fme:EASTING>
<fme:NORTHING>821281.08625396</fme:NORTHING>
<fme:ST_CODE>13885</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014896</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821248.18777 833135.27068</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id2f6412b6-46fc-479f-9977-56cad455d736">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHING CHEUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.1884110660366</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003475</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832361.54632953</fme:EASTING>
<fme:NORTHING>822427.48982287</fme:NORTHING>
<fme:ST_CODE>10247</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016419</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822390.28348 832418.61798</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idbeb587e4-d3c5-4b43-abc7-379f50b341ec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI CHUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-10.6639196918893</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003491</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832542.87778009</fme:EASTING>
<fme:NORTHING>821983.81347623</fme:NORTHING>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016188</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821976.34562 832602.36467</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ide8809423-4954-470d-a892-75516465e96e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>NASSAU ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.5074020714806</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003716</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832377.89600883</fme:EASTING>
<fme:NORTHING>822192.85382446</fme:NORTHING>
<fme:ST_CODE>11503</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014909</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822183.57101 832405.62922</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id0acaeef1-1a0b-409a-bd9d-28a8455de339">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>MTR (TSUEN WAN LINE)</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000372529</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003872</fme:FEATURE_ID>
<fme:FEATURECODE>MTN</fme:FEATURECODE>
<fme:EASTING>830980.62874536</fme:EASTING>
<fme:NORTHING>823852.34335824</fme:NORTHING>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210020231</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823911.92576 831018.70553</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idb28207ba-d27f-43db-8506-f6e1402400d5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI CHUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>48.3913433142282</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003529</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831169.29375006</fme:EASTING>
<fme:NORTHING>823813.14623484</fme:NORTHING>
<fme:ST_CODE>11079</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000227</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823860.32591 831206.28747</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id29a9476e-4906-4064-b245-28501840687f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TAI NAN WEST STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.2300015087788</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003597</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833442.75393054</fme:EASTING>
<fme:NORTHING>822049.65191835</fme:NORTHING>
<fme:ST_CODE>12240</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015211</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821994.68593 833465.75943</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id43a8ab46-a051-41a0-8221-7848b40ee453">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI CHUNG INTERCHANGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006196</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831918.314</fme:EASTING>
<fme:NORTHING>822075.136</fme:NORTHING>
<fme:ST_CODE>14066</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015923</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822072.98781 831918.08445</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id15f278b0-a251-4cbf-8a4a-892e4c0783d8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TAN LAI STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.9575496527776</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007015</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833655.943</fme:EASTING>
<fme:NORTHING>821577.167</fme:NORTHING>
<fme:ST_CODE>14448</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016061</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821577.16660 833655.94268</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id24c23ec0-ece9-4bc9-b594-ac9aca56fc25">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI CHI KOK ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-20.0048555568541</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210009115</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832878.68</fme:EASTING>
<fme:NORTHING>821895.116</fme:NORTHING>
<fme:ST_CODE>11149</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210027404</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821895.11618 832878.68047</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ide8bb156c-29c4-482a-acfc-33e7d9ab0d4e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI PO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210009535</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832953.795</fme:EASTING>
<fme:NORTHING>821527.447</fme:NORTHING>
<fme:ST_CODE>13951</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015832</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821527.48160 832953.87076</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
