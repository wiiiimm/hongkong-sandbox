<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BoulderLine.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>822754.07401 831823.71001 0.00000</gml:lowerCorner>
<gml:upperCorner>823026.00845 832871.68230 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BoulderLine gml:id="iddd4d6079-4cbd-4d8e-bc9a-08db1c336164">
<fme:FEATURE_ID>1000858114</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884067</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823016.82206 831845.02125 0.00000 823017.43062 831844.45652 0.00000 823018.27720 831845.48770 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idab8275b6-8a3c-47cd-b501-27ff836ac9c8">
<fme:FEATURE_ID>1000858366</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882208</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822757.74718 832871.57144 0.00000 822756.76540 832871.23924 0.00000 822756.12378 832871.68230 0.00000 822754.07401 832871.52679 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9adfd0da-e68f-4231-8b44-a1474bfef862">
<fme:FEATURE_ID>1000858219</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882236</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822884.69214 831903.22622 0.00000 822883.78662 831903.03900 0.00000 822883.18509 831903.09266 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idbb215dbe-1eeb-41ba-8ed3-4fd7ba3d675a">
<fme:FEATURE_ID>1000858268</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884064</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822843.44034 831897.00222 0.00000 822842.18010 831897.26974 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id444b40c1-2ba6-4e7f-83fc-28723cc40c1a">
<fme:FEATURE_ID>1000858273</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884064</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822845.64595 831897.35870 0.00000 822844.00133 831898.31161 0.00000 822841.84442 831898.99363 0.00000 822841.00194 831899.77327 0.00000 822840.24017 831900.13890 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc3df79db-0788-4411-8537-a5690d86cf24">
<fme:FEATURE_ID>1000858209</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882236</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822892.56976 831908.33474 0.00000 822891.45572 831908.57854 0.00000 822889.93419 831908.64558 0.00000 822888.06166 831908.30813 0.00000 822887.41845 831907.91633 0.00000 822886.25151 831906.26004 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8ce3ab82-4c56-4d11-ad15-19825501bd56">
<fme:FEATURE_ID>1000858267</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884064</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822842.18010 831897.26974 0.00000 822843.80393 831898.28552 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id34aede66-5b79-4659-b292-f0d6845707ac">
<fme:FEATURE_ID>1000858108</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882255</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823025.16197 831840.63696 0.00000 823024.41381 831841.71846 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2dfb0cb5-d659-4df3-8ced-4f2f51527596">
<fme:FEATURE_ID>1000858361</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882208</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822759.62800 832868.32408 0.00000 822759.08096 832869.62331 0.00000 822758.60360 832870.03775 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id31fd5ca4-176e-4fb9-8a34-342a2712327a">
<fme:FEATURE_ID>1000858110</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882255</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823024.50271 831839.46453 0.00000 823022.81601 831840.36021 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide0dea98b-b7ac-43aa-bf17-adf2f52874aa">
<fme:FEATURE_ID>1000858116</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884067</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823018.79276 831845.29880 0.00000 823018.15576 831845.73018 0.00000 823017.41196 831845.81231 0.00000 823015.89439 831845.59886 0.00000 823014.57042 831844.97906 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="iddf5c8704-76e0-4d8f-aa35-4afd62253651">
<fme:FEATURE_ID>1000858115</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882254</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823014.95282 831826.76046 0.00000 823014.89660 831827.89346 0.00000 823015.87257 831831.18382 0.00000 823015.93572 831831.94372 0.00000 823016.61567 831832.85390 0.00000 823018.62725 831833.93650 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id42576f06-db6f-447a-8f60-4132865a180c">
<fme:FEATURE_ID>1000858112</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882254</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823018.89865 831829.33453 0.00000 823019.04214 831830.60195 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idaa49f3fb-f013-47da-b890-3163d233f6d8">
<fme:FEATURE_ID>1000858111</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882255</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823026.00845 831841.62118 0.00000 823024.07287 831838.81061 0.00000 823023.35533 831838.60835 0.00000 823021.68655 831838.67228 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id49bae8a8-0e93-4f7d-82d9-e9f7349da303">
<fme:FEATURE_ID>1000858120</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882254</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823015.66494 831830.65606 0.00000 823013.08840 831831.50617 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8a18c410-2697-4c67-99b5-19dabf2b9b4c">
<fme:FEATURE_ID>1000858210</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882236</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822887.41706 831909.88034 0.00000 822886.49634 831909.20537 0.00000 822885.77822 831908.38514 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ida9f5b76b-a19c-4cfb-b3e5-638cef09252b">
<fme:FEATURE_ID>1000858118</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882254</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823014.24256 831823.71001 0.00000 823013.72156 831824.27982 0.00000 823013.40673 831824.95348 0.00000 823013.16925 831827.60777 0.00000 823013.26381 831828.40739 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1785f41b-0769-4107-82fb-4af9503ef170">
<fme:FEATURE_ID>1000858119</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882254</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823013.08840 831831.50617 0.00000 823013.15542 831832.44793 0.00000 823014.92006 831833.24005 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6a6f618e-ec28-4e27-b7fb-d35866e1de8d">
<fme:FEATURE_ID>1000858279</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884064</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822842.18010 831897.26974 0.00000 822839.67895 831897.14721 0.00000 822837.77387 831897.34099 0.00000 822837.41278 831897.31097 0.00000 822836.86581 831896.93589 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idee3d297a-04b6-40bb-9c9b-8466dffdcb3d">
<fme:FEATURE_ID>1000858121</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882254</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823013.26381 831828.40739 0.00000 823013.29621 831829.11925 0.00000 823013.00772 831830.61714 0.00000 823013.08840 831831.50617 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id067175e5-f419-465c-9f86-a6f0be853250">
<fme:FEATURE_ID>1000858274</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884064</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822845.20008 831895.11254 0.00000 822843.74600 831894.71514 0.00000 822840.23019 831895.56445 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5bf3c983-b5af-4f8d-a1a9-58fc808e51f9">
<fme:FEATURE_ID>1000858117</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882254</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823015.00332 831828.40371 0.00000 823013.26381 831828.40739 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id76ab6655-55e0-42e4-bf22-7c2dd57117df">
<fme:FEATURE_ID>1000858275</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884064</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822839.95317 831897.21024 0.00000 822841.40078 831899.25365 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4eb736be-9dcc-439b-955b-8afe91f2687e">
<fme:FEATURE_ID>1000858113</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882254</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823019.64783 831828.72255 0.00000 823017.96184 831829.94690 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9af33c74-5771-4e76-8ae7-70e2edbfab82">
<fme:FEATURE_ID>1000858217</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882236</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822889.36974 831907.67333 0.00000 822887.50736 831907.27452 0.00000 822886.03710 831906.06893 0.00000 822884.35763 831905.09473 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
</gml:FeatureCollection>
