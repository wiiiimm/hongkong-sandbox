<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingPolyAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821175.88125 830073.88517</gml:lowerCorner>
<gml:upperCorner>823693.49018 833711.52719</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="id3d5dd737-105c-4550-a38d-64ba1549cf85">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pump House</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000753796</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833638.11340512</fme:EASTING>
<fme:NORTHING>822567.67230897</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822567.67231 833653.20573</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="idfc95bb92-a920-414d-b805-3116c045e098">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Workshop</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.1476203735557</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000753799</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>830741.09675318</fme:EASTING>
<fme:NORTHING>823092.84548868</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823102.88363 830763.94852</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="id2df7c746-3a09-481e-a390-c5c124445e84">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Godown</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.3160363468755</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000753795</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>830677.16325586</fme:EASTING>
<fme:NORTHING>823452.55973851</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823471.17674 830676.58984</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="idebfcd4ee-a7e5-425a-8e28-06c97b1e4ea3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stand</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>49.812666303697</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000753822</fme:FEATURE_ID>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:EASTING>833652.489</fme:EASTING>
<fme:NORTHING>822019.703</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822019.70338 833652.48914</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="id64ae9ff0-0fe3-42b1-9c84-8f4605f1cae2">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stand</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.633649329024</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000753823</fme:FEATURE_ID>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:EASTING>832171.44833918</fme:EASTING>
<fme:NORTHING>822263.83997712</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822277.10201 832173.59918</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="idb6651e00-b256-4507-acb6-ef64d22a2949">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stand</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>81.1131208823032</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000702</fme:FEATURE_ID>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:EASTING>832171.44833918</fme:EASTING>
<fme:NORTHING>822263.83997712</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823693.49018 830073.88517</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="id9e47aca8-28a3-457f-9b31-29e1481fe119">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Office</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-73.141599823599</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001208</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832025.28015679</fme:EASTING>
<fme:NORTHING>821281.92767205</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821281.92767 832025.28016</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="ide128f06a-3d45-44e9-adb8-ee78db6e948f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Office</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-73.1416045213284</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000257</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832058.353</fme:EASTING>
<fme:NORTHING>821175.881</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821175.88125 832058.35304</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="id291d2fe3-2132-45c9-b553-e1d00ffcef54">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Works in progress</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310016075</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>832200.461</fme:EASTING>
<fme:NORTHING>821279.127</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821279.12680 832200.46054</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="idb3d4ea33-655e-4a00-9dc5-c5c636b500a2">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Works in progress</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310016076</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>833572.638</fme:EASTING>
<fme:NORTHING>821380.914</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821380.91400 833572.63780</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="ide546e634-ed82-4e5a-a89f-8ab659d3b223">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Works in progress</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>51.1701821524328</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310017015</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>833711.527</fme:EASTING>
<fme:NORTHING>821605.976</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20241125</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821605.97571 833711.52719</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_E gml:id="ide4d5e43b-c9a7-4d2a-a4b9-faebbb655f63">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Works in progress</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000922</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>830754.659</fme:EASTING>
<fme:NORTHING>822901.87</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822901.87008 830754.65853</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
