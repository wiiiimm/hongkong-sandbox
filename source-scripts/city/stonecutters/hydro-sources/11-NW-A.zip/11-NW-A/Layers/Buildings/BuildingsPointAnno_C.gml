<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingsPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821006.18030 830687.64929</gml:lowerCorner>
<gml:upperCorner>823980.39781 833738.44741</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ida61774a2-96c8-47ac-9850-371980498079">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>製衣中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2414575912021</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000333</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833476.335</fme:EASTING>
<fme:NORTHING>822238.054</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021890</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822238.25446 833476.26131</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idd44915f9-3212-4fd7-a673-e2f5965bf8fb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>信德</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.184802081763059</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000337</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832809.47214442</fme:EASTING>
<fme:NORTHING>821106.48878505</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000826</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821109.38471 832818.62645</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id63c5e4a5-47e2-417a-8e67-082b6a3c9377">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>昌隆</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3546175904333</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000319</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833332.253</fme:EASTING>
<fme:NORTHING>821928.547</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022559</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821928.50170 833331.51699</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idbb0a006d-b2d5-4c79-b555-6042310ef1d2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>時信</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0889876413137</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000925</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833109.247</fme:EASTING>
<fme:NORTHING>821999.569</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021910</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821999.69196 833108.96216</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id59114c98-0cd7-4f1c-ac7a-343f4902f633">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>奇華</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.2089936126643</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000932</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833260.569</fme:EASTING>
<fme:NORTHING>822155.647</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023229</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822155.84648 833260.49188</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id178fe849-2fb3-42fb-91d5-6d1295a7d994">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>合興</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-32.0053843829011</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000939</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832846.45658338</fme:EASTING>
<fme:NORTHING>821122.22690594</fme:NORTHING>
<fme:LINKFEATURE_ID>1210002114</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821119.08688 832857.91799</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id18185337-4620-422e-86cf-4da4b7bc0cc4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌
海關大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.6039724119542</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000942</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831809.2194128</fme:EASTING>
<fme:NORTHING>821508.78266969</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000897</fme:LINKFEATURE_ID>
<fme:ST_CODE>74580</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821491.51457 831822.37138</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id272a7486-aca7-4916-84de-ca8ec3912153">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>誠信</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.9651129434394</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000896</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833078.04979017</fme:EASTING>
<fme:NORTHING>822026.33781545</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023098</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822033.88173 833090.42105</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id25afcd78-0159-4637-ba79-504f20f23f8a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>新昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.9831234925163</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000899</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833435.219</fme:EASTING>
<fme:NORTHING>821966.095</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021908</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821966.29622 833435.14638</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8a50ba22-6fa3-4c48-b3db-880e26bba6f3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>電訊盈科</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-4.57460148399698</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000905</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832821.67877281</fme:EASTING>
<fme:NORTHING>821842.62127313</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022187</fme:LINKFEATURE_ID>
<fme:ST_CODE>70423</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821843.96088 832840.87513</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id9089d3dc-1cc4-48c2-b846-70862003e837">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>源盛</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.089</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000910</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833211.682</fme:EASTING>
<fme:NORTHING>822152.693</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023228</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822152.88653 833211.58819</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1b6c4719-e35d-4b91-a552-712880d65a67">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>羅氏商業</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.9951506011165</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000914</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833483.635</fme:EASTING>
<fme:NORTHING>822125.455</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021898</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822125.65603 833483.56179</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ida06c331d-5620-4770-9fcc-280b9b61e44e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永新</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.6501070380453</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000918</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833193.488</fme:EASTING>
<fme:NORTHING>821818.048</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022565</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821818.24826 833193.41250</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id0aec529a-8a3f-4177-bc58-1d83cea1c5b1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華豐園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001333</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832035.03276139</fme:EASTING>
<fme:NORTHING>822626.30056901</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000877</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822629.16695 832048.63265</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id65870d01-e853-4c5b-b492-545544ced619">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>東方
石油</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.42281427026261</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001302</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833144.072</fme:EASTING>
<fme:NORTHING>821682.144</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023112</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821682.69229 833144.03910</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id34b5dd9d-fbb9-4d71-8abb-68cfa8a5382a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>匯華</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0889950712635</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001310</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833195.421</fme:EASTING>
<fme:NORTHING>822197.963</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007479</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822198.16328 833195.34754</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide6283d79-c592-4f97-827a-bfb1162adead">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>聯興</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.6069350903122</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001313</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833371.28356943</fme:EASTING>
<fme:NORTHING>822338.16145537</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023075</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822330.56274 833377.16651</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id4c331d35-0403-4288-b118-632b6aee3728">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>合興</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1817972453042</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001319</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833012.731</fme:EASTING>
<fme:NORTHING>822075.155</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022416</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822075.35571 833012.65684</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb26231ed-f4ac-4bfa-8ee5-07b2c07e6440">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>嘉名</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0890044139331</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001320</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833144.645</fme:EASTING>
<fme:NORTHING>822122.227</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021612</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822122.18336 833143.90440</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id61b531c2-16f8-4249-a3fd-d98a9fd67e97">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>潮流
工貿
</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0889154016699</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001909</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833195.125</fme:EASTING>
<fme:NORTHING>822120.536</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022031</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822121.68126 833194.70633</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc7bd71da-834b-4d64-a40e-32c8789e8352">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>萬利</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.5560551145394</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001913</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833311.576</fme:EASTING>
<fme:NORTHING>822059.218</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022840</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822059.41841 833311.50079</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id996ad7ad-c3e7-4201-8f98-3771c8fba314">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>公源</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.224996885924</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001914</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833489.307</fme:EASTING>
<fme:NORTHING>822189.215</fme:NORTHING>
<fme:LINKFEATURE_ID>1210036673</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822189.39519 833489.17908</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ideb80443e-e8e3-4447-bbfe-56e86dbc9da2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>恩福</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4142960695938</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001921</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833469.121</fme:EASTING>
<fme:NORTHING>822050.992</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022837</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822051.19197 833469.04630</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id9dee8d95-d5cb-4fb0-bae8-827bd42ba599">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>擎天</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.3864009265716</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001927</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833390.17467897</fme:EASTING>
<fme:NORTHING>822345.87464707</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022948</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822337.07379 833393.48509</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id083c0282-9c92-411d-9eec-b4c69eb39795">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>通源</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0890015107373</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003249</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833013.034</fme:EASTING>
<fme:NORTHING>822003.585</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021627</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822003.83068 833013.08494</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id19ed5aa5-b33a-4f3a-97b7-c10f38843dc2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>鴻昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.7583269632737</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003264</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833645.929</fme:EASTING>
<fme:NORTHING>822201.976</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022952</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822202.17555 833645.85372</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id0568611e-7b50-446d-ac6e-19a2e474428e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>定豐</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2250081505349</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003268</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833511.892</fme:EASTING>
<fme:NORTHING>822001.212</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021629</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822001.34836 833511.64430</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id507601a3-4b53-47d1-ac79-7aa170102cfb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>宏德</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.184824098770255</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003270</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832770.79274928</fme:EASTING>
<fme:NORTHING>821071.62069265</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000941</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821074.51640 832779.88092</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8b5079c6-599a-4f77-b319-af9e110f1e5f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>翠竹苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.333117096232462</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002868</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833648.06293816</fme:EASTING>
<fme:NORTHING>822702.37986768</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023206</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822705.16457 833662.12023</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide20cf254-6caa-48cd-a78f-9b11f9ea4ff2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>兆威</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0890035866229</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002877</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833147.816</fme:EASTING>
<fme:NORTHING>822165.52</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007478</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822165.72114 833147.74215</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide2fa28f0-1201-4a0e-b3f2-f56ed96bcd33">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>83.0250726533971</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002889</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831003.05402366</fme:EASTING>
<fme:NORTHING>823026.83928272</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007659</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823048.59426 831002.76680</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8c10c833-4781-4474-a5ef-ca0db6d88345">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>集運中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.1263318519893</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002895</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830755.52315924</fme:EASTING>
<fme:NORTHING>823654.00582997</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000812</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823673.22551 830757.81444</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id56a73344-3c9a-4e9e-8a58-918b0bb2ca5d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>珠江集團
船廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-34.7348369135768</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002951</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832724.42464973</fme:EASTING>
<fme:NORTHING>821017.8557641</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003484</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821011.73949 832746.49876</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide2e7f1d7-ac16-4cc1-9bc4-9ee8a9402fc6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-26.0477147502968</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002272</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831472.96610488</fme:EASTING>
<fme:NORTHING>822765.5490792</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000836</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822761.96064 831486.83554</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id65108f60-5647-4077-9a93-8ca30274af37">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>時來</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.5964265363981</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002277</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833067.30221393</fme:EASTING>
<fme:NORTHING>822032.99974782</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023375</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822025.59223 833073.11582</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5b4991c4-1d6c-41f9-81d2-3c4a45d6a1e5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永興</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.6331650114986</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002278</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833054.49320263</fme:EASTING>
<fme:NORTHING>822027.52961069</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023371</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822020.01915 833060.33890</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc62526fb-57d4-460a-90b2-cb241928baf0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>陸佰</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.068256098469</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002281</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833241.364</fme:EASTING>
<fme:NORTHING>822228.688</fme:NORTHING>
<fme:LINKFEATURE_ID>1210004424</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822228.77401 833240.97563</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id655a49d3-2ba3-4d02-9088-db4a783efeac">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>嘉圖</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2249920555329</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002285</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833510.864</fme:EASTING>
<fme:NORTHING>821937.992</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022428</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821938.19213 833510.79062</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id0f7f32ad-53b2-4d8d-a9a3-4c3ed7feba79">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>嘉里貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.0831078503397</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002301</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830722.08448714</fme:EASTING>
<fme:NORTHING>823668.78389178</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000802</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823687.21125 830726.76290</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idd3d9e103-e338-48d3-88b5-79c5b14c96d9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>懷愛</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3915003817562</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002302</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833694.404</fme:EASTING>
<fme:NORTHING>822456.775</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021334</fme:LINKFEATURE_ID>
<fme:ST_CODE>75057</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822456.97536 833694.33002</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id74526a0a-e8e8-435e-9f2d-e66c17546396">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>百欣</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3950017848396</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004836</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833738.629</fme:EASTING>
<fme:NORTHING>822343.263</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023079</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822343.42355 833738.44741</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id10da6b20-77ba-401e-8731-5e04e5918b88">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海關
驗貨場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.2462129161491</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004846</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831797.05566062</fme:EASTING>
<fme:NORTHING>821558.84114678</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000944</fme:LINKFEATURE_ID>
<fme:ST_CODE>74580</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821548.30499 831808.42104</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id17e7005e-5900-48d8-939c-dba34a94fc24">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>卓匯</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2250181505845</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004895</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833513.541</fme:EASTING>
<fme:NORTHING>822190.661</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003356</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822190.68312 833512.98310</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idec078813-2bdf-4612-b009-cc16f2478e53">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>時穎</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3615896477466</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003275</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833248.834</fme:EASTING>
<fme:NORTHING>822208.466</fme:NORTHING>
<fme:LINKFEATURE_ID>1210004425</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822208.65861 833248.73880</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idd7b673be-8018-4fdf-a60d-d5dd0bb0e47a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>百美</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3948838868996</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003276</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833711.755</fme:EASTING>
<fme:NORTHING>822324.513</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022817</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822324.71297 833711.68009</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id84fbd22e-d4f8-45bc-b961-ca6582cde4cc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>中太</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.1816406752156</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003278</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833066.62770482</fme:EASTING>
<fme:NORTHING>822095.53732375</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022298</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822088.60489 833072.33023</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1692a5ba-d363-48bc-88bd-b901d5a50600">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>半島</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3915003817562</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003279</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833578.344</fme:EASTING>
<fme:NORTHING>822262.686</fme:NORTHING>
<fme:LINKFEATURE_ID>1210004450</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822262.88670 833578.26978</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1d578a65-1f98-443b-ae36-7e1eecde29c5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>好運</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2162672608381</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003304</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833452.703</fme:EASTING>
<fme:NORTHING>821923.49</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022696</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821923.69095 833452.62870</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id96e1b56e-60b3-4ecb-a408-35f2d22f5a3f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長江</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.2900047153129</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003305</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833393.781</fme:EASTING>
<fme:NORTHING>821954.482</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022307</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821954.68412 833393.71056</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id6ae33ef9-d7bc-40a4-9cc0-ff4bccabc30e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>巴士廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>41.47854412366</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003368</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832672.57615262</fme:EASTING>
<fme:NORTHING>821090.8354888</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001082</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821101.98489 832680.86011</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id56db38c7-ac9a-44db-b1d0-1426de0f5b92">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>鍾意恒勝
中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.9391896210419</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004230</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830945.653</fme:EASTING>
<fme:NORTHING>823980.016</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005842</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823980.39781 830946.04724</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id4f00b61f-4292-4586-a767-36ed8c1b4fc3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角道
８２２號</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>22.3407814869604</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003828</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833293.878</fme:EASTING>
<fme:NORTHING>821861.815</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021641</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821862.32289 833293.66982</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idbe9a1acf-b0ca-4349-96f9-bbd153459cc4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>勵豐</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.0750989923955</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003830</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833238.31</fme:EASTING>
<fme:NORTHING>821847.415</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021929</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821847.57637 833238.12392</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idaa6faafa-ca91-46dd-ae16-fc0da89399c6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>盈業大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.5304948861137</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003835</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830898.319</fme:EASTING>
<fme:NORTHING>823972.755</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034763</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823972.68174 830898.69030</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id610acd7f-2bfc-4383-8c91-5eb0c3197528">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>國際</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.9423934521994</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003836</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833036.91715431</fme:EASTING>
<fme:NORTHING>822009.04726935</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021624</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822014.75745 833044.25100</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id501c706b-9e8f-4095-9811-70feb6ecebb1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港紗廠
第一、二期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.427</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004247</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833358.729</fme:EASTING>
<fme:NORTHING>822128.973</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021616</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822129.48756 833358.53778</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id803d5c8d-744d-4578-bb64-22a8cdf11451">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西港
都會</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0349751823174</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003844</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833020.664</fme:EASTING>
<fme:NORTHING>822124.304</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021899</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822124.82013 833020.47575</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id606716cb-d347-4eec-91b4-7414f7023fb0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>時運
</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.6538205551007</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003845</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833056.951</fme:EASTING>
<fme:NORTHING>822077.47</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022300</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822078.27865 833056.58694</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id3108fa77-22dd-4f74-bdb1-96acf4068159">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>經達</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.8079621574733</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003846</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833575.698</fme:EASTING>
<fme:NORTHING>822045.999</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005067</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822046.06952 833575.90010</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8a58ce3f-bf75-42bc-be32-5d7621899f26">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永盛</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.0622316756123</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003852</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833442.706</fme:EASTING>
<fme:NORTHING>822217.48</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022685</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822217.64060 833442.51576</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb2af0fd2-9e84-4749-8d52-93477fa41126">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港國際
貨櫃碼頭有限公司</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003859</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831292.499</fme:EASTING>
<fme:NORTHING>822488.839</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007543</fme:LINKFEATURE_ID>
<fme:ST_CODE>70635</fme:ST_CODE>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822489.38780 831292.80707</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb68fedbe-03f5-4fd0-bf11-69abc3302cc9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2743778415752</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004270</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833604.82077619</fme:EASTING>
<fme:NORTHING>822215.9199562</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022408</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822231.75052 833629.26165</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb59aee75-aa35-423e-bfcb-5fa4a6ba063e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>天安</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.29</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004272</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833556.015</fme:EASTING>
<fme:NORTHING>822068.865</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022414</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822069.06638 833555.94472</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1d61e88b-43ba-4a77-8001-73a3c8614a7a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永明</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2250146101425</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004275</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833492.159</fme:EASTING>
<fme:NORTHING>821989.939</fme:NORTHING>
<fme:LINKFEATURE_ID>1210171436</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821990.13995 833492.08506</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id44951bf2-4332-4600-8dc4-3227581eed19">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>星匯居</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.0174205219212965</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003906</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833645.92471266</fme:EASTING>
<fme:NORTHING>821511.41419618</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006905</fme:LINKFEATURE_ID>
<fme:ST_CODE>71177</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821554.77691 833733.84584</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id09a64864-48e1-4984-8cd0-2e375f5182be">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華盛</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.2505088312618</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004808</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833153.7879809</fme:EASTING>
<fme:NORTHING>821921.52663754</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022700</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821935.95040 833172.28761</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id88b6a9ef-0857-4e95-a3b7-e7afb9151d5f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>楊耀松
第六</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0690025563568</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004816</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833172.887</fme:EASTING>
<fme:NORTHING>821874.597</fme:NORTHING>
<fme:LINKFEATURE_ID>1210029282</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821875.11217 833172.69911</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id85142822-4069-44d8-b8d7-2263eca47ac9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>時釆</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0890113251</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004824</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833090.702</fme:EASTING>
<fme:NORTHING>822084.204</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022552</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822084.33811 833090.44606</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8b13d41b-ddd1-429d-bb17-77c122479b98">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>新光</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3094248116831</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005742</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833083.518</fme:EASTING>
<fme:NORTHING>822103.589</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022029</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822103.80791 833083.49382</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id16d32f1c-97f4-41a2-bc41-bed82614ca6a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永義</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.7540668888814</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005744</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833366.28</fme:EASTING>
<fme:NORTHING>822203.262</fme:NORTHING>
<fme:LINKFEATURE_ID>1210004452</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822203.46134 833366.20420</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ided3c5f09-4159-4e06-8cda-e73647e71ba8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>曉峰豪園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>10.0079798020393</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005750</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832252.89808716</fme:EASTING>
<fme:NORTHING>822732.8536761</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000702</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822735.99806 832270.71622</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc0023166-0fd3-41cb-b777-013acef70f0d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>時豐
中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0245352721306</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005757</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833130.30887648</fme:EASTING>
<fme:NORTHING>821931.33283668</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022427</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821926.89062 833142.77831</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id992b2fcc-f578-4b51-98d1-127860c41741">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>宏昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.1643129202381</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005758</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833694.464</fme:EASTING>
<fme:NORTHING>821662.685</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022574</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821662.25002 833693.82218</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id924243da-06ec-4772-9495-95ae2b0244af">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海水泵房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-71.9728346545394</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005767</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831606.608</fme:EASTING>
<fme:NORTHING>822055.434</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000978</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822055.34877 831606.85995</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf9da2524-4607-46a3-9780-be0f04003396">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>水務署
九龍西區
大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.8617108119639</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005773</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833607.777</fme:EASTING>
<fme:NORTHING>821542.727</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006906</fme:LINKFEATURE_ID>
<fme:ST_CODE>71173</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821543.28507 833607.09075</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id04cf6bf2-eb57-4781-89d9-41dae3e03995">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>環薈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.8849906229331</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005809</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833418.554</fme:EASTING>
<fme:NORTHING>822276.107</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007047</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822276.35404 833418.61016</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5bda4410-0598-4bf5-8bce-e93dcba32a60">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>興迅</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0890092509616</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005810</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833025.261</fme:EASTING>
<fme:NORTHING>821969.84</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005054</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821970.04952 833025.21226</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id77b3266f-bcd2-4ec0-984f-649fb1ff4c9c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>偉基</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.9773837653232</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005161</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833607.168</fme:EASTING>
<fme:NORTHING>822289.223</fme:NORTHING>
<fme:LINKFEATURE_ID>1210004446</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822289.41661 833607.07550</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idbd20da7e-1dd2-4b33-9582-ca3df6026ad3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>百福</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3619989721169</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005162</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833338.973</fme:EASTING>
<fme:NORTHING>822256.481</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021891</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822256.60311 833338.68769</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide35d2eb8-7b7a-4003-b15b-0234a19edfdb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>應通</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2250005139893</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005179</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833537.976</fme:EASTING>
<fme:NORTHING>821938.498</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022172</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821938.69803 833537.90245</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id81304a54-cd69-4ba7-941c-69b8bf0bb565">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>亞洲貨櫃物流中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007060</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830900.87995279</fme:EASTING>
<fme:NORTHING>822628.38082238</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000797</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822631.24720 830945.47692</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id9ec7a001-937f-41d5-b8ee-abbf2030bf71">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>利豐</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4270406079746</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007061</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833221.06</fme:EASTING>
<fme:NORTHING>822028.781</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023101</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822028.89227 833220.74587</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id284ae393-df20-4b40-8c76-8e9313a03114">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>恒昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1199992536883</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007064</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833502.655</fme:EASTING>
<fme:NORTHING>822371.694</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022538</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822371.89501 833502.58103</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id250089d4-473a-4e07-bf8e-adfe089646c6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>實用
貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.083107849522</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007068</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830688.189</fme:EASTING>
<fme:NORTHING>823719.162</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000901</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823719.29458 830687.64929</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1c7f99d6-24c1-42d8-817a-bf7ec2e5b28a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>中國
宏興</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2250024479872</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007074</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833534.37</fme:EASTING>
<fme:NORTHING>822006.797</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021360</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822007.31241 833534.18046</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id3a373041-26c4-4cfa-943b-7587cfb6fb54">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>龍翔工業大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.208562728548</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007102</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833213.754409</fme:EASTING>
<fme:NORTHING>822289.38971244</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023215</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822303.32156 833243.88534</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id97bd3456-f430-41df-bbc1-225f93f6103a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵芳輔助
設施大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>48.5035246160944</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007105</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831150.82488485</fme:EASTING>
<fme:NORTHING>823877.03377692</fme:NORTHING>
<fme:LINKFEATURE_ID>1210030903</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823897.60587 831159.50736</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idad635c2e-027b-481e-9c19-92aa6a352027">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>億利工業中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.9459947454507</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006697</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833221.5105648</fme:EASTING>
<fme:NORTHING>821949.57562179</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003447</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821961.85271 833246.93827</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ida84001ae-bc21-4ae8-956c-acf6693f335b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華創中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.0504394908628</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006698</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833183.33311117</fme:EASTING>
<fme:NORTHING>821943.92381765</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022309</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821953.26016 833199.61112</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8580b27a-2da4-4f88-b5c0-f95c79eef4c6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>安泰</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0889874762173</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006702</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833115.387</fme:EASTING>
<fme:NORTHING>822168.599</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007480</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822168.79958 833115.31334</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf5606162-2eac-4106-9c0c-491e14a360cd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>順昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.6469880478317</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007107</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833428.22564793</fme:EASTING>
<fme:NORTHING>822231.90899222</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022539</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822237.67006 833435.38557</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc587ee11-084c-4ef4-943c-8ebe6b82369b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景
通風樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-60.7621565433082</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007110</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831301.97809522</fme:EASTING>
<fme:NORTHING>822805.74066377</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000675</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822795.46684 831315.99414</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id9b72a11d-1268-4b6e-9da9-ca60b44530df">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>志興昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.4769957038407</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007111</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833514.798</fme:EASTING>
<fme:NORTHING>822064.781</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022835</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822064.85233 833514.99929</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id34b27651-81d2-4b2d-ad26-96b3579ed70c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>栢裕</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.2899992265906</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007112</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833493.101</fme:EASTING>
<fme:NORTHING>822054.373</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007671</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822054.57500 833493.02994</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id9a774898-8c36-45be-983b-60be3aa352aa">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>億京</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007113</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833568.249</fme:EASTING>
<fme:NORTHING>821938.402</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022174</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821938.61572 833568.05011</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id415fc282-1efb-43b4-bd66-44c2513d56ad">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港紗廠
第六期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3930140026979</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006713</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833560.613</fme:EASTING>
<fme:NORTHING>822208.293</fme:NORTHING>
<fme:LINKFEATURE_ID>1210019322</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822208.80703 833560.42171</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id80ecc07c-01c6-4c9a-9abe-0977fb2171f5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港紗廠
第五期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0409607698582</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006716</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833574.78</fme:EASTING>
<fme:NORTHING>822164.398</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022955</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822164.91343 833574.59219</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5d9f6f1f-bfdc-4187-8120-518922e25348">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西頓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.290070036601</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006720</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833361.842</fme:EASTING>
<fme:NORTHING>821949.912</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022178</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821949.84976 833361.66265</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1cf4e680-62a1-46b7-b766-654a8a4fb793">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4288301493444</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006722</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833522.785</fme:EASTING>
<fme:NORTHING>822138.902</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021487</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822139.10220 833522.71027</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id63bf36ab-691e-46e0-a1dc-1e7da63fd719">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>新世界
第一渡輪</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>58.6547827713893</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006732</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833089.42948675</fme:EASTING>
<fme:NORTHING>821026.19989338</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028448</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821046.55353 833092.91463</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id46d5d10a-b560-479e-bc29-cfe6952a7e83">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>福至</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.8056703003583</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006734</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833289.35515517</fme:EASTING>
<fme:NORTHING>822180.19893871</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023085</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822172.75783 833295.14625</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idd35d4558-e2e4-487d-8662-f6f2bcaa2884">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>安老院</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006737</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831632.73301662</fme:EASTING>
<fme:NORTHING>822939.57126277</fme:NORTHING>
<fme:LINKFEATURE_ID>1210038581</fme:LINKFEATURE_ID>
<fme:ST_CODE>71007</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822942.43764 831646.40787</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide9e877a4-b303-4fb8-ac88-65ed2051b2fb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長城</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3549904467795</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007632</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833286.018</fme:EASTING>
<fme:NORTHING>821916.845</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003470</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821917.02847 833285.89801</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id90d087a6-7e58-4218-8729-42a2e83f3aef">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>時代</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.4358694794492</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007642</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833045.922</fme:EASTING>
<fme:NORTHING>821966.048</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034793</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821966.13494 833046.11763</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id263f2014-4e00-42fb-a8c0-480cd2fc778b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>榮吉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2410054785767</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007649</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833413.313</fme:EASTING>
<fme:NORTHING>822214.883</fme:NORTHING>
<fme:LINKFEATURE_ID>1210004451</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822214.96178 833412.90861</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id6ce00be8-725d-4165-8849-d8511fd008ec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>福源</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0890067585218</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006797</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833168.136</fme:EASTING>
<fme:NORTHING>822187.651</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007477</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822187.86367 833168.09613</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id795d26a2-7c76-44cb-82be-407dee6f165b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>再發</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2250127706234</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007654</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833471.228</fme:EASTING>
<fme:NORTHING>822172.784</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023225</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822172.98478 833471.15457</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf8d50ae7-dda2-4a81-a804-c5c2c7a583f5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永康</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.3368533094265</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007656</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833301.46888254</fme:EASTING>
<fme:NORTHING>822184.67160653</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023083</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822190.66127 833308.92449</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idef4a9c5a-6a04-463e-8143-69dacd6198ef">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>浪淘</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.2092306867331</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007667</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833312.59762621</fme:EASTING>
<fme:NORTHING>822156.93882011</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021349</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822162.85601 833319.92267</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf4145c74-e1a2-4174-b99c-99def118b86a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>益大</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.6409933939867</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007670</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833331.774</fme:EASTING>
<fme:NORTHING>822184.041</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022827</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822184.24110 833331.69899</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc6c08a05-e23a-4b4d-985d-00f48deefd48">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>煤氣
調壓站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.4625702672438</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007685</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832923.66</fme:EASTING>
<fme:NORTHING>822040.319</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023095</fme:LINKFEATURE_ID>
<fme:ST_CODE>77459</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822040.28581 832923.54507</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id358103ab-6911-49bf-9501-54b5b1be2385">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>瑪嘉烈醫院
荔景大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011254</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831554.286</fme:EASTING>
<fme:NORTHING>823130.698</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000932</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823131.25880 831554.28552</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8ab960c6-4a49-4194-9133-781218798922">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>護理學校及宿舍</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-66.4086869292884</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011274</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831675.145</fme:EASTING>
<fme:NORTHING>822460.808</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005774</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822460.11760 831675.67923</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf5ae0674-7f99-43a3-ab5b-3ef529a2639c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>懷明</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0332456770686</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011823</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833719.905</fme:EASTING>
<fme:NORTHING>822387.476</fme:NORTHING>
<fme:LINKFEATURE_ID>1210171063</fme:LINKFEATURE_ID>
<fme:ST_CODE>75057</fme:ST_CODE>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822394.22667 833716.34682</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id7311bb14-5d7c-4764-a3e1-1392d571c695">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>職員
宿舍</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>34.405916460989</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014143</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832756.292</fme:EASTING>
<fme:NORTHING>822010.755</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021489</fme:LINKFEATURE_ID>
<fme:ST_CODE>79249</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822011.26224 832756.04051</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idaae8ea36-e006-4323-a27b-56836868eead">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>億京
二期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014144</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833582.428</fme:EASTING>
<fme:NORTHING>822010.134</fme:NORTHING>
<fme:LINKFEATURE_ID>1210175383</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822010.69403 833582.42847</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id978ca6dc-9824-4c67-af4d-c0b7470a8b3e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>美心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3549982375439</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014145</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833205.55</fme:EASTING>
<fme:NORTHING>821888.732</fme:NORTHING>
<fme:LINKFEATURE_ID>1210177257</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821888.89541 833205.37688</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id412d6a2e-81c9-4e07-ac1a-5720c2a26da5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>榮瑤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017342</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831609.114</fme:EASTING>
<fme:NORTHING>823932.113</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000732</fme:LINKFEATURE_ID>
<fme:ST_CODE>75169</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823932.32674 831609.05274</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id17217851-10dd-48bc-878b-925927bc281a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>富瑤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017343</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831462.817</fme:EASTING>
<fme:NORTHING>823901.329</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000879</fme:LINKFEATURE_ID>
<fme:ST_CODE>75169</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823901.54268 831462.45972</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idabc9dae0-308d-4895-af24-6f569d9b1e23">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貴瑤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017344</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831626.999</fme:EASTING>
<fme:NORTHING>823817.479</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000918</fme:LINKFEATURE_ID>
<fme:ST_CODE>75169</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823817.69277 831626.84420</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8778ea4a-cbc7-4b33-8823-363c72092044">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>樂瑤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017345</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831515.59</fme:EASTING>
<fme:NORTHING>823773.209</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000664</fme:LINKFEATURE_ID>
<fme:ST_CODE>75169</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823773.42237 831515.64250</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id983251f6-6deb-4ca7-962f-d150acedee02">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華瑤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017346</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831595.335</fme:EASTING>
<fme:NORTHING>823671.768</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007052</fme:LINKFEATURE_ID>
<fme:ST_CODE>75169</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823671.98157 831595.16296</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idcf2f452d-4ab5-4a2e-847f-f4542c19b60e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>日景</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017347</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831109.533</fme:EASTING>
<fme:NORTHING>823427.841</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000902</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823428.05458 831108.31610</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id4cbf6b2a-8e94-48ac-bb1c-fb30fa727bf7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>明景</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017348</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831059.692</fme:EASTING>
<fme:NORTHING>823435.757</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000785</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823435.97046 831059.33957</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id773115b9-a363-4f04-af54-bfb43d69936d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>和景</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017349</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831120.088</fme:EASTING>
<fme:NORTHING>823586.159</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001047</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823586.37258 831119.81433</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ida190f3c9-26d4-42ad-8bf1-01562b9727fc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>風景</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017350</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831077.576</fme:EASTING>
<fme:NORTHING>823559.479</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000925</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823559.69305 831077.53233</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc81aef43-3ae8-46c5-bbb5-814dd44f1ea9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華智</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017351</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832057.151</fme:EASTING>
<fme:NORTHING>823394.014</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001058</fme:LINKFEATURE_ID>
<fme:ST_CODE>75165</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823394.22739 832056.65314</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id13e1129b-0087-444c-92d9-432c76556974">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華義</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017352</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831934.108</fme:EASTING>
<fme:NORTHING>823404.899</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000904</fme:LINKFEATURE_ID>
<fme:ST_CODE>75165</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823405.11275 831933.89641</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id23ea1044-00d1-40d1-b305-2a4efec96a26">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華信</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017353</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832100.887</fme:EASTING>
<fme:NORTHING>823445.525</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000787</fme:LINKFEATURE_ID>
<fme:ST_CODE>75165</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823445.73844 832100.64029</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id97fc140b-54ab-4fcf-ace0-de6cc51f1c03">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華仁</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017354</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831877.737</fme:EASTING>
<fme:NORTHING>823457.382</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001060</fme:LINKFEATURE_ID>
<fme:ST_CODE>75165</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823457.59570 831877.38913</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5ebf20a9-2a4b-46e1-8d8a-c4f8b6946924">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華禮</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017355</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832000.975</fme:EASTING>
<fme:NORTHING>823340.753</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000923</fme:LINKFEATURE_ID>
<fme:ST_CODE>75165</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823340.96692 832000.83414</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide4ce041d-99c9-4a11-8681-890c7a9a9094">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>賢光</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-9.19756735385273</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017356</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831093.954</fme:EASTING>
<fme:NORTHING>823347.808</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001049</fme:LINKFEATURE_ID>
<fme:ST_CODE>75239</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823348.02442 831093.95294</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="iddf56a540-d811-489d-becb-2f638c3a9851">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗霞</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017357</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831155.071</fme:EASTING>
<fme:NORTHING>823240.905</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001070</fme:LINKFEATURE_ID>
<fme:ST_CODE>75552</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823241.11835 831154.95201</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id0e0d6aa4-4a30-43d7-ac40-5f4111af7d1e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗華</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017358</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831155.63</fme:EASTING>
<fme:NORTHING>823198.162</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000688</fme:LINKFEATURE_ID>
<fme:ST_CODE>75552</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823198.37523 831155.50192</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id6064bd59-0d5f-49d1-8460-d4d8d4dbc4ee">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗虹</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017359</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831152.277</fme:EASTING>
<fme:NORTHING>823285.324</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007118</fme:LINKFEATURE_ID>
<fme:ST_CODE>75552</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823285.53767 831152.28182</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id008cbc24-9a3c-4f34-9d10-0d4facf1b922">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗雲</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017360</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831158.144</fme:EASTING>
<fme:NORTHING>823156.257</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001071</fme:LINKFEATURE_ID>
<fme:ST_CODE>75552</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823156.47022 831158.04268</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf09df58c-16a1-48f3-b74f-bf21e05799f3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>賢德</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-9.62826614978097</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017361</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831089.032</fme:EASTING>
<fme:NORTHING>823316.126</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001818</fme:LINKFEATURE_ID>
<fme:ST_CODE>75239</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823316.33532 831089.07611</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id075aff8a-3f93-446d-a4fd-6bc3a5868d1b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>啓謙</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017362</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831202.697</fme:EASTING>
<fme:NORTHING>823088.051</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007658</fme:LINKFEATURE_ID>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823088.26429 831202.84651</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id96e684ea-792d-4cdc-8610-7ed7441215bb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>啓敬</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017363</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831298.878</fme:EASTING>
<fme:NORTHING>823083.82</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007657</fme:LINKFEATURE_ID>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823084.03397 831298.97539</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id7a77267f-d0ec-4e01-9728-3a46326cac7a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>啓勉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017364</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831283.859</fme:EASTING>
<fme:NORTHING>823241.463</fme:NORTHING>
<fme:LINKFEATURE_ID>1210004307</fme:LINKFEATURE_ID>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823241.67708 831284.05759</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8dbe838f-ad9a-4ece-ab05-bddb35378c0a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>啓恆</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017365</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831249.067</fme:EASTING>
<fme:NORTHING>823141.609</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007221</fme:LINKFEATURE_ID>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823141.82244 831249.19939</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idabe48c50-63c7-4a2e-a142-485e735b5436">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>仰景</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>83.7289159446737</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017366</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831038.935</fme:EASTING>
<fme:NORTHING>823138.715</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001072</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823138.50603 831038.69668</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idbc7f9272-d491-4d02-b7bd-62afc8f50ad4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>安景</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-7.73361129490253</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017367</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831041.922</fme:EASTING>
<fme:NORTHING>823093.257</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000820</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823093.52201 831041.55710</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id2a4100fc-6915-4502-be82-8ea55bda6031">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>樂景</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.5234423935095</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017368</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831054.512</fme:EASTING>
<fme:NORTHING>823030.733</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001057</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823030.85031 831054.69697</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id285bdaec-b5e8-400e-8f1c-7fb64b2de7e5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>啓光</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-90</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017369</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831435.173</fme:EASTING>
<fme:NORTHING>822957.806</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007660</fme:LINKFEATURE_ID>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822957.67331 831435.38650</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc5af5d14-6611-401c-b1f1-d263db158beb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>啓真</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017370</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831443.378</fme:EASTING>
<fme:NORTHING>822833.309</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007661</fme:LINKFEATURE_ID>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822833.52225 831443.39521</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id2b5db748-7380-4ec0-a73f-caa63b38fde6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>啓廉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017371</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831383.872</fme:EASTING>
<fme:NORTHING>823014.059</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007224</fme:LINKFEATURE_ID>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823014.27254 831384.02238</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id839cb2ff-439c-4cfe-b2b5-8ecb4f5c92f9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>賞荔</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017382</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832221.707</fme:EASTING>
<fme:NORTHING>822577.187</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000795</fme:LINKFEATURE_ID>
<fme:ST_CODE>77063</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822577.40086 832221.49086</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id357df7bc-b428-40b1-a385-4e3bea0da2ed">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔林</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017383</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832149.706</fme:EASTING>
<fme:NORTHING>822700.617</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000942</fme:LINKFEATURE_ID>
<fme:ST_CODE>76863</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822700.83042 832149.71959</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5d7246ea-a51f-4577-9b3e-c4408f7129a8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>喜荔</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017384</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832213.857</fme:EASTING>
<fme:NORTHING>822629.97</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000708</fme:LINKFEATURE_ID>
<fme:ST_CODE>77063</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822630.18323 832213.70290</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id9f9c08f1-9bc3-4ecd-851a-3358ba3d97f5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔影</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017385</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832105.856</fme:EASTING>
<fme:NORTHING>822632.406</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000561</fme:LINKFEATURE_ID>
<fme:ST_CODE>76863</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822632.61934 832105.77701</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf5753a9c-2c53-4e00-9023-bf9522382b7a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔采</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017386</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832090.698</fme:EASTING>
<fme:NORTHING>822683.023</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001080</fme:LINKFEATURE_ID>
<fme:ST_CODE>76863</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822683.23628 832090.64104</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id04d0fcdc-affd-475d-b6e3-40ea92d61445">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗泰</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017387</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831888.865</fme:EASTING>
<fme:NORTHING>822223.042</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000837</fme:LINKFEATURE_ID>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822223.25576 831888.86068</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id39a1190e-cdcd-4784-bbd3-1d6eb216ef0f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗秀</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017388</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831947.671</fme:EASTING>
<fme:NORTHING>822188.406</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000569</fme:LINKFEATURE_ID>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822188.62012 831947.69296</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id2a9eef61-3c28-4b34-89d4-e5e8966eee03">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗裕</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017389</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831961.874</fme:EASTING>
<fme:NORTHING>822237.245</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000817</fme:LINKFEATURE_ID>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822237.45887 831962.01955</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id681ce7ab-3e23-4149-8a25-a8e464ab4107">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗寧</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017390</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831904.563</fme:EASTING>
<fme:NORTHING>822177.941</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000977</fme:LINKFEATURE_ID>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822178.15467 831904.31190</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idddc2f7fa-8cb0-4fd9-a77d-66286bec3354">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗康</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017391</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831863.2</fme:EASTING>
<fme:NORTHING>822186.911</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000979</fme:LINKFEATURE_ID>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822187.12506 831863.25274</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idca37438d-f9da-47f9-beb0-35c69f36e472">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗恒</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017392</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831998.752</fme:EASTING>
<fme:NORTHING>822242.727</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000674</fme:LINKFEATURE_ID>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822242.94076 831998.77430</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc7d0129f-9479-4e49-981a-cd606b262bc2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗建</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017393</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831923.999</fme:EASTING>
<fme:NORTHING>822232.76</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000558</fme:LINKFEATURE_ID>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822232.97368 831924.01672</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8cc85f62-8b33-4bbc-aa34-6d3e78d49ecf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海晴</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>28.8799968894743</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017407</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833077.49</fme:EASTING>
<fme:NORTHING>821538.095</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006907</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821538.20282 833077.24430</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id162f1c24-90d0-4a74-bb49-17ad69ba372d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海和</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.3649992520051</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017408</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833188.816</fme:EASTING>
<fme:NORTHING>821435.812</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006923</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821436.10018 833188.80645</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idbae88b50-fe8f-4a0f-8926-6445dc185560">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海健</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.3650091446956</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017409</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833155.134</fme:EASTING>
<fme:NORTHING>821462.736</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006922</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821462.90983 833155.25918</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id91e3c5a7-697a-44c6-8376-3905951210d9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海雅</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-4.73002737964974</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017410</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833107.087</fme:EASTING>
<fme:NORTHING>821432.224</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028182</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821432.43781 833107.09120</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb73d42ba-a520-4c05-9842-486bff399f9e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海暉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>28.8795388873868</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017411</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833014.32</fme:EASTING>
<fme:NORTHING>821551.57</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003485</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821551.67227 833014.06239</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id30949817-4ea6-4d78-a12c-287dcf9435f8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海禧</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.3650116041976</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017412</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833117.623</fme:EASTING>
<fme:NORTHING>821492.586</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027053</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821492.75415 833117.75447</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id6d813513-93f8-4dd1-aa1e-869f5bb08ef7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海慧</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-4.72999648114597</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017413</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833146.045</fme:EASTING>
<fme:NORTHING>821400.86</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028539</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821401.07407 833146.05427</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id2a924161-514e-4918-b985-9f74ef0fac17">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海信</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-4.73001469018501</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017414</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833067.598</fme:EASTING>
<fme:NORTHING>821463.37</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027302</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821463.59091 833067.52302</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5770f636-8031-4988-822e-b0bf60cb8447">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海明</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>30.6054290262995</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017415</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833056.001</fme:EASTING>
<fme:NORTHING>821575.675</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006904</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821575.72008 833055.65656</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id9e0fceb1-ccde-415c-abee-d4e3b28cb562">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海賢</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-4.72959111057464</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017416</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833029.635</fme:EASTING>
<fme:NORTHING>821494.543</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027055</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821494.76151 833029.58712</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="iddda0653a-0396-4bfc-987d-b3041e060fa7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海智</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-4.73001332437386</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017417</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833185.231</fme:EASTING>
<fme:NORTHING>821369.496</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027173</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821369.73776 833184.90615</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id851e1b9f-05ed-4faa-8afe-f3af9640a900">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海瑞</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.3649935550686</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017418</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833225.305</fme:EASTING>
<fme:NORTHING>821406.509</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028431</fme:LINKFEATURE_ID>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821406.68915 833225.42310</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1d25b358-c4a9-465c-a172-30fbdfe9b98a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>百生利</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.2428458233249</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017424</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833279.584</fme:EASTING>
<fme:NORTHING>822165.311</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179241</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822165.71636 833279.65843</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ida8ec55bf-3041-44ff-bb89-0f1bc30600bd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>義德</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.6178768335465</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017425</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833627.27</fme:EASTING>
<fme:NORTHING>822299.127</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179242</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822299.33420 833627.21447</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide4e009b4-3a26-4683-a9db-623c05655498">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>泰昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.119608970211</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017426</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833542.59</fme:EASTING>
<fme:NORTHING>822363.626</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179243</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822363.60023 833541.89912</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id85e77880-5dd3-4cf1-aae5-e4175ac33d6b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>中大貨倉大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3147016782868</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017427</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833429.071</fme:EASTING>
<fme:NORTHING>822350.115</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179244</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822350.27417 833428.88466</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id0c1a0856-5b47-4b4c-a969-4d2e508c8d66">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永康街９號</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.894688761352</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017428</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833058.812</fme:EASTING>
<fme:NORTHING>822144.959</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023358</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822144.77133 833057.72177</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf0282730-61c7-4d6a-8f03-03f9f8c3b953">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>通利</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0889833971749</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017702</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833122.918</fme:EASTING>
<fme:NORTHING>822015.491</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021490</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822015.67826 833122.80724</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id0286edc9-0303-4c4e-add0-80960cd79bd7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>安泰</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2506514684565</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017703</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833131.002</fme:EASTING>
<fme:NORTHING>821993.753</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022038</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821993.83320 833130.60146</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc2683e85-119c-471b-aafd-0c6df3f88d7c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九龍廣場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2248638353461</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017706</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833437.346</fme:EASTING>
<fme:NORTHING>822166.205</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021352</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822166.56360 833437.70271</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8a2e9ca8-761f-4b42-b1eb-651a6048c88d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華匯</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.9036028589617</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017707</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833436.014</fme:EASTING>
<fme:NORTHING>822127.887</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021759</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822128.37043 833436.06477</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id63b8459d-bc85-4672-acbb-88a9a59daabc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永康</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.8851573129476</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017708</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833467.497</fme:EASTING>
<fme:NORTHING>822312.354</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179249</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822312.53586 833467.37076</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id71181dac-e99e-4931-aabc-c33f1a54c110">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>日間復元中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>23.5637977057785</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210022725</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831876.51</fme:EASTING>
<fme:NORTHING>822554.721</fme:NORTHING>
<fme:LINKFEATURE_ID>1210191907</fme:LINKFEATURE_ID>
<fme:ST_CODE>75038</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822554.36142 831875.15086</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idfc8c8961-6c9c-4f04-8688-66ee53bbedd7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>盈輝</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210023185</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833292.962</fme:EASTING>
<fme:NORTHING>821075.348</fme:NORTHING>
<fme:LINKFEATURE_ID>1210192880</fme:LINKFEATURE_ID>
<fme:ST_CODE>82683</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821075.56209 833293.04541</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id4cbcb4b6-2197-490f-816f-f3f9acb51e39">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>盈昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210023186</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833328.372</fme:EASTING>
<fme:NORTHING>821033.722</fme:NORTHING>
<fme:LINKFEATURE_ID>1210192881</fme:LINKFEATURE_ID>
<fme:ST_CODE>82683</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821033.93565 833327.79410</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1cc597d7-d54e-4599-b4b8-fb63a39ac490">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>金百盛</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.0631269594886</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210023425</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833275.703</fme:EASTING>
<fme:NORTHING>822224.936</fme:NORTHING>
<fme:LINKFEATURE_ID>1210193045</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822225.16024 833275.84568</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id610b1ce5-7b04-4194-afc1-c03b35f16f1e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>創匯</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4722901325174</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210023426</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833450.288</fme:EASTING>
<fme:NORTHING>822280.105</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005066</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822280.16916 833449.84956</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id05c251d0-6dae-4cd4-af9e-e4621163eaf1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>中國
船舶</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-41.1990680446558</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210023505</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833738.076</fme:EASTING>
<fme:NORTHING>822197.393</fme:NORTHING>
<fme:LINKFEATURE_ID>1210191242</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822197.87283 833738.37835</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id59626560-54b5-42e8-8bd1-6a719688861b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>凱莎</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210024630</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833472.324</fme:EASTING>
<fme:NORTHING>821005.967</fme:NORTHING>
<fme:LINKFEATURE_ID>1210196920</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821006.18030 833472.31564</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf5e185e0-1ae7-4c78-ab27-bc5d85f35062">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>松齡舍</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210025348</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831196.688</fme:EASTING>
<fme:NORTHING>823036.193</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000819</fme:LINKFEATURE_ID>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823036.40676 831196.86862</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="iddd2e7b05-d9e9-4a93-8b36-7cdddb8b61ad">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>和黃物流中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210025368</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830930.591</fme:EASTING>
<fme:NORTHING>822420.736</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001079</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822420.94942 830930.52034</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id4c81f503-8aef-436e-b1d9-9a9152a4f6b5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華潤國際物流中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210025408</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831816.619</fme:EASTING>
<fme:NORTHING>821701.444</fme:NORTHING>
<fme:LINKFEATURE_ID>1210185566</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821701.65767 831816.53921</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1f41e4c7-f85e-4872-a4d2-46e818c417db">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>通風樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-38.1817781278712</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210025428</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833504.553</fme:EASTING>
<fme:NORTHING>821268.267</fme:NORTHING>
<fme:LINKFEATURE_ID>1210194244</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821268.19526 833504.98969</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id99786812-8d5a-437a-900d-c4959661a2bf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海榮</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310026468</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833467.101</fme:EASTING>
<fme:NORTHING>821229.125</fme:NORTHING>
<fme:LINKFEATURE_ID>1310201027</fme:LINKFEATURE_ID>
<fme:ST_CODE>83092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821229.33855 833467.01752</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id2510b7a1-51c8-47a2-8a6f-4c5d5c3d05c0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海華</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310026469</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833520.675</fme:EASTING>
<fme:NORTHING>821191.815</fme:NORTHING>
<fme:LINKFEATURE_ID>1310201039</fme:LINKFEATURE_ID>
<fme:ST_CODE>83092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821192.02873 833520.48097</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id39386df1-3717-4e66-8b6e-29e07dfc5f28">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海昌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310026470</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833578.548</fme:EASTING>
<fme:NORTHING>821162.647</fme:NORTHING>
<fme:LINKFEATURE_ID>1310201042</fme:LINKFEATURE_ID>
<fme:ST_CODE>83092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821162.86087 833577.92168</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idcd6df6ca-d8d4-42f8-960f-74776925271f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>深水埗
康樂文化大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310026472</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833408.8</fme:EASTING>
<fme:NORTHING>821273.384</fme:NORTHING>
<fme:LINKFEATURE_ID>1310200993</fme:LINKFEATURE_ID>
<fme:ST_CODE>83092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821273.94401 833408.79985</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="iddd305efd-06bf-4e57-972e-926b3f1b235c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>服務設施大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>54.3308798324158</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310026508</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833375.845</fme:EASTING>
<fme:NORTHING>821313.756</fme:NORTHING>
<fme:LINKFEATURE_ID>1310200994</fme:LINKFEATURE_ID>
<fme:ST_CODE>83092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821314.58280 833376.17571</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id6f5e391e-c08c-45e3-9d22-965649c7a1c0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>恒景</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.061436599065</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310027028</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831019.375</fme:EASTING>
<fme:NORTHING>822969.985</fme:NORTHING>
<fme:LINKFEATURE_ID>1310203089</fme:LINKFEATURE_ID>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822970.17924 831019.52703</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="iddc29046f-c372-488e-b4e4-b11b5eacafd3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海盛</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028348</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833629.192</fme:EASTING>
<fme:NORTHING>821121.167</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207893</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821121.38109 833629.19246</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id495c0fcc-209a-446e-8f01-3a202edc6e48">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>南商金融
創新中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.3735118148184</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028588</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833067.425</fme:EASTING>
<fme:NORTHING>821826.588</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206829</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231114</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821827.09819 833067.65674</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id4a900ac9-b742-4406-850d-471d479dba0d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>東方</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.8849906229331</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028628</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833386.487</fme:EASTING>
<fme:NORTHING>822274.36</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822274.45479 833386.11961</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id58f80d44-7f99-474f-910a-b7464290a8db">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>喜瑤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028810</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831440.048</fme:EASTING>
<fme:NORTHING>823967.002</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231217</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823967.21551 831439.92043</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8678b9f3-eeca-4557-b1f4-f8ee807aa9f9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵德工業中心第一座</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.1025344334398</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029408</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830719.841</fme:EASTING>
<fme:NORTHING>823784.395</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001036</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823784.47813 830719.64397</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idfee8a3a8-ec3f-46da-8fbd-c92b97d9fbd1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵德工業中心第二座</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.2821077962474</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029409</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830757.518</fme:EASTING>
<fme:NORTHING>823876.259</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000999</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823876.34103 830757.32044</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id23d52603-ae16-4b1d-a762-8f940d41d977">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>匡智張玉瓊
晨輝學校</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-26.503996197715</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029428</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831380.765</fme:EASTING>
<fme:NORTHING>822781.253</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001043</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822781.75463 831381.01523</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idba35b46b-5685-499f-9875-12e57324c213">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港工業中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>18.7239692959591</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029448</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833214.049</fme:EASTING>
<fme:NORTHING>822070.606</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022691</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822070.80857 833213.98080</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ida66518bc-3fd4-4f54-a2c1-1d2141a5cdec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>寶源
亞洲</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1248033948814</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000840</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833066.007</fme:EASTING>
<fme:NORTHING>821975.469</fme:NORTHING>
<fme:LINKFEATURE_ID>1420001442</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821975.96214 833065.72359</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc89ac3d5-079a-4456-b6af-4c2a490d9045">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>維特
健靈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.6477732759434</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000841</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833093.62</fme:EASTING>
<fme:NORTHING>821986.323</fme:NORTHING>
<fme:LINKFEATURE_ID>1420001440</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821986.81970 833093.34779</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id34a73a80-3054-4bd1-92e5-12eae1bca261">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>順庭居</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.8409205617732</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000860</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833045.183</fme:EASTING>
<fme:NORTHING>821882.61</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206828</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821882.91480 833045.38315</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id906ab98a-ec48-4052-8c87-c1a36779099b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>冷氣機房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.2940361444099</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002080</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831783.417</fme:EASTING>
<fme:NORTHING>822530.839</fme:NORTHING>
<fme:LINKFEATURE_ID>1210181891</fme:LINKFEATURE_ID>
<fme:ST_CODE>75038</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822530.56334 831783.77863</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1b4c5d1d-60df-4c05-8c37-cdc639db79ae">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>兒童及青少年
服務座</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>37.0807993657814</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002064</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831690.798</fme:EASTING>
<fme:NORTHING>822692.682</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822693.12900 831690.46038</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id3a6ee840-27a1-4c43-be21-aa8d80a0bfbd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>江博士</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.919994028782</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002920</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833537.907</fme:EASTING>
<fme:NORTHING>822261.866</fme:NORTHING>
<fme:LINKFEATURE_ID>1420003488</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822262.02997 833537.71950</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id7dc28b75-d19a-44a2-b7ab-fc6929538118">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>濾水廠
員工宿舍</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002940</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833449.169</fme:EASTING>
<fme:NORTHING>823209.404</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007122</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823209.96471 833449.22581</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id21573462-1894-46ee-8abb-e573ae3faa01">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渠務大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.5076900728732</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002700</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833707.699</fme:EASTING>
<fme:NORTHING>821380.187</fme:NORTHING>
<fme:LINKFEATURE_ID>1420003310</fme:LINKFEATURE_ID>
<fme:ST_CODE>77908</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260310</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821380.21694 833707.99852</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
