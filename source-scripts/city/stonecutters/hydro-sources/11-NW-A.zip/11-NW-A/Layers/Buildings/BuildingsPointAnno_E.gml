<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingsPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821024.27539 830740.92617</gml:lowerCorner>
<gml:upperCorner>824021.16977 833763.00759</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="iddb0f11de-aa0b-494f-90c3-7348ec2e71aa">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Bamboo Villa</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000090</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833662.709785</fme:EASTING>
<fme:NORTHING>822693.145795</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023206</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822693.14579 833662.70978</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idfad65980-cf55-4d27-8263-e69cfffe8957">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CEO</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.8850062495972</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000135</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833423.019</fme:EASTING>
<fme:NORTHING>822265.669</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007047</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822265.66933 833423.01907</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id243829a3-d2c4-49ff-914e-29fcce4d331c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Bus Depot</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>41.919059514481</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000250</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832690.530185</fme:EASTING>
<fme:NORTHING>821089.57633</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001082</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821089.57633 832690.53019</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id1992ea9b-cc1d-4cbf-96b3-dd1afc2d15ff">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Profit Indus Bldg</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.6378112373041</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000251</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830892.885</fme:EASTING>
<fme:NORTHING>823963.458</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034763</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823963.45822 830892.88452</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0cef832d-7e97-45e1-b2ae-d78172dc81cf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Kerry
Warehouse</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.1138698286624</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000259</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830740.914265</fme:EASTING>
<fme:NORTHING>823680.70173</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000802</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823680.69671 830740.92617</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id164ac8fb-1469-4059-8ee3-b4d8bcfd16f9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pacific Century Cyber Works</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-4.30164407714516</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000431</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832844.35857</fme:EASTING>
<fme:NORTHING>821830.995945</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022187</fme:LINKFEATURE_ID>
<fme:ST_CODE>70423</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821830.99595 832844.35857</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idf7504a9e-6c0f-4dd6-9e6b-9ec6607bfc44">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pumping
Station</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000523</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831785.17283</fme:EASTING>
<fme:NORTHING>823293.409855</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001817</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823293.39694 831785.17283</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id29d5e47d-fe4f-41f2-9bfd-fc61336219ab">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>ATL Logistics Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000677</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830943.17242</fme:EASTING>
<fme:NORTHING>822617.347135</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000797</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822617.34714 830943.17242</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide0d1fe97-d7ad-4beb-bc51-9ff4385bf48d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Customs
House</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.3973776191262</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000744</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831802.55687294</fme:EASTING>
<fme:NORTHING>821484.81049528</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000897</fme:LINKFEATURE_ID>
<fme:ST_CODE>74580</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821484.80659 831802.54456</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida158b37c-446f-40f4-9dba-2eec0dedeb92">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cargo
Consolidation
Complex</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.6198775815211</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000910</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830775.226155</fme:EASTING>
<fme:NORTHING>823666.00058</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000812</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823665.99074 830775.25005</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id6cb4ac4d-b6d8-4fc8-93d2-7320ab7d04b9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Excel
Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2250081848916</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000951</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833518.331</fme:EASTING>
<fme:NORTHING>822178.427</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003356</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822178.39030 833518.34448</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idea9f79f0-c66c-473e-a5ac-21ec98b3b04c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cargo Exam
Compound</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-71.7481134135476</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001062</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831790.16407</fme:EASTING>
<fme:NORTHING>821542.84961</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000944</fme:LINKFEATURE_ID>
<fme:ST_CODE>74580</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821542.84556 831790.15180</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idc9fb8bd4-d26c-4e46-9cf8-059d2a14ff77">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Dragon
Industrial Building</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4767511877384</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001063</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833247.89235332</fme:EASTING>
<fme:NORTHING>822287.75337381</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023215</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822287.74127 833247.89687</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id09105bc3-4ee3-474f-b367-4ee953f8ecec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hop Hing</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.8451672985887</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001068</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832853.74581829</fme:EASTING>
<fme:NORTHING>821109.88194004</fme:NORTHING>
<fme:LINKFEATURE_ID>1210002114</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821109.88194 832853.74582</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id1cdf6864-d150-48f5-9779-e8a849d22e74">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TheSparkle</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.534120835458097</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>0</fme:FlipAngle>
<fme:FEATURE_ID>1210001255</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833727.39435</fme:EASTING>
<fme:NORTHING>821536.407015</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006905</fme:LINKFEATURE_ID>
<fme:ST_CODE>71177</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821536.41994 833727.39447</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id5283024a-c32e-4b50-b6b7-d681df8b01b7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>21</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001936</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832271.747</fme:EASTING>
<fme:NORTHING>823951.45</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000593</fme:LINKFEATURE_ID>
<fme:ST_CODE>75167</fme:ST_CODE>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823951.45027 832271.74676</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id69cfc842-2983-4a71-b2b1-70ccc7b7ef07">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001993</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832310.523</fme:EASTING>
<fme:NORTHING>823548.538</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000763</fme:LINKFEATURE_ID>
<fme:ST_CODE>75783</fme:ST_CODE>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823548.53778 832310.52258</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id90c36316-5bfe-410c-8b84-46a7b47c3637">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>11</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002022</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832025.685</fme:EASTING>
<fme:NORTHING>823906.859</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000996</fme:LINKFEATURE_ID>
<fme:ST_CODE>75167</fme:ST_CODE>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823906.85923 832025.68521</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idb1e4a64c-3fee-488a-b286-24f29ee24afc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002069</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832048.783</fme:EASTING>
<fme:NORTHING>823652.873</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001666</fme:LINKFEATURE_ID>
<fme:ST_CODE>75167</fme:ST_CODE>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823652.87323 832048.78340</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id53ea3a10-95a8-4355-aa7c-a699d357955a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002279</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832190.782</fme:EASTING>
<fme:NORTHING>823575.023</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001062</fme:LINKFEATURE_ID>
<fme:ST_CODE>75783</fme:ST_CODE>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823575.02259 832190.78218</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id460d0f6d-88c5-421b-930d-bd1c3b129ff0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Wai Ming</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0940062884674</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210016789</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833722.924</fme:EASTING>
<fme:NORTHING>822376.956</fme:NORTHING>
<fme:LINKFEATURE_ID>1210171063</fme:LINKFEATURE_ID>
<fme:ST_CODE>75057</fme:ST_CODE>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822383.57093 833719.61657</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida1ccdb0f-fb85-4147-b3d2-de93e4e4c770">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Global 
Gateway 
Tower</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4677658041949</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210020566</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833312.621</fme:EASTING>
<fme:NORTHING>822235.311</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179138</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822235.23813 833312.64784</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id63cde41e-5ff5-4319-8dae-e90e676e9f7a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210020986</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832716.018</fme:EASTING>
<fme:NORTHING>822206.979</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179494</fme:LINKFEATURE_ID>
<fme:ST_CODE>80264</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822206.97881 832716.01825</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id5cc2b2b6-9a81-409b-b3c5-f575d994a92f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210020987</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832702.179</fme:EASTING>
<fme:NORTHING>822196.089</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179495</fme:LINKFEATURE_ID>
<fme:ST_CODE>80264</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822196.08862 832702.17863</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id2dcc2d87-1605-4011-a17b-137a86e1597c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>C</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210020988</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832686.087</fme:EASTING>
<fme:NORTHING>822189.963</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179496</fme:LINKFEATURE_ID>
<fme:ST_CODE>80264</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822189.96289 832686.08665</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id830a41c8-b762-4937-a427-558078260fad">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210020989</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID>1210179497</fme:LINKFEATURE_ID>
<fme:ST_CODE>80264</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822184.97154 832672.24702</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idb242ece9-59dd-42f1-9d22-060ad71953ec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>E</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210020990</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832651.585</fme:EASTING>
<fme:NORTHING>822179.3</fme:NORTHING>
<fme:LINKFEATURE_ID>1210179498</fme:LINKFEATURE_ID>
<fme:ST_CODE>80264</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822179.29956 832651.58460</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id8d3999d3-6e53-40eb-82e5-1f5358bbcf33">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hop Hing</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.181995448062</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021026</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833016.017</fme:EASTING>
<fme:NORTHING>822065.751</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022416</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822065.75077 833016.01717</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id48b8d1c7-f261-4033-89f9-eaa564a17928">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Ka Ming</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0889916003118</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021027</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833148.107</fme:EASTING>
<fme:NORTHING>822113.29</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021612</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822113.28961 833148.10696</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id57bc62c9-0ce2-4e51-a847-b597264f836c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>16.8662543895977</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021028</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833152.713</fme:EASTING>
<fme:NORTHING>822059.969</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022691</fme:LINKFEATURE_ID>
<fme:ST_CODE>76113</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822059.96874 833152.71252</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idbd4b1540-86bd-4db0-a8c0-b263b7030587">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2902805822491</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021029</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833209.256</fme:EASTING>
<fme:NORTHING>822080.806</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022417</fme:LINKFEATURE_ID>
<fme:ST_CODE>76113</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822080.80602 833209.25622</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id2562cdac-2221-4cf6-b9d6-5f36b2a2456a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>C</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2900050817972</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021030</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833270.436</fme:EASTING>
<fme:NORTHING>822104.224</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022294</fme:LINKFEATURE_ID>
<fme:ST_CODE>76113</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822104.22447 833270.43637</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida853f16c-5562-475e-bebe-56a427668682">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LiFung</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4269997948015</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021031</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833249.676</fme:EASTING>
<fme:NORTHING>822038.57</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023101</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822038.56997 833249.67632</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id8153f185-981b-4de5-8527-c9d83ce74675">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hong Kong
Spinners
Phase I And II</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4270011964575</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021032</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833368.009</fme:EASTING>
<fme:NORTHING>822106.006</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021616</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822105.93353 833368.03603</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idcf2a6514-4eb3-45c0-9829-7464a56139a4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai Cheong</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0349679304455</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021033</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID>1210022408</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822221.39251 833633.43238</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id263c9d8c-c9e6-427a-b097-07ba9239dcdf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hung
Cheong</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.9831007557125</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021034</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID>1210022952</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822188.11332 833651.30742</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idc320135b-6b39-4e5f-a09b-2eb74a3b247d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hang
Cheong</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1200079038189</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021036</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833507.121</fme:EASTING>
<fme:NORTHING>822358.753</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022538</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822358.71675 833507.13413</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id45cef38b-0c96-41c3-a57e-6443059fa0b5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Ka To</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2250143908889</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021037</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833514.55</fme:EASTING>
<fme:NORTHING>821927.875</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022428</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821927.87501 833514.55020</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida011ebd3-5b5d-42aa-bed4-348ad11a4986">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Goodluck</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2159980651085</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021038</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833455.64</fme:EASTING>
<fme:NORTHING>821913.852</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022696</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821913.85209 833455.63968</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idd6f840db-84a6-4034-ade9-b831a72ba03a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>W668</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.0000032195994</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210024426</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833223.443</fme:EASTING>
<fme:NORTHING>822130.075</fme:NORTHING>
<fme:LINKFEATURE_ID>1210188266</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822130.07475 833223.44349</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idbe426b99-176a-4208-961d-116003b80c34">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>L</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026034</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831822.28</fme:EASTING>
<fme:NORTHING>822695.376</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001067</fme:LINKFEATURE_ID>
<fme:ST_CODE>75038</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822695.37550 831822.27966</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id89182e2c-4288-4432-b3fe-6a0801558ff7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>M</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026035</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831766.907</fme:EASTING>
<fme:NORTHING>822694.112</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000976</fme:LINKFEATURE_ID>
<fme:ST_CODE>75038</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822694.11227 831766.90719</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id32fcf75d-5236-498a-a3ef-ae6673ad4f8a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>J</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026038</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831951.641</fme:EASTING>
<fme:NORTHING>822527.111</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000840</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822527.11142 831951.64087</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id867a9c2e-ea21-41e9-bde2-e9813a4db19c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>M</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026039</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831844.47</fme:EASTING>
<fme:NORTHING>822491.488</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005769</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822491.48795 831844.47037</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0262b8b4-a72c-4a9d-bf6a-611af9b9f371">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>N</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026040</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831831.14</fme:EASTING>
<fme:NORTHING>822524.495</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005767</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822524.49474 831831.13976</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idaeaab7d0-1d55-4939-9ba4-1c4e3149486a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>L</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026041</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831855.457</fme:EASTING>
<fme:NORTHING>822467.527</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005773</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822467.52692 831855.45735</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id64a57006-788a-4091-8c92-7e3d018181a0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>K</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026042</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831906.247</fme:EASTING>
<fme:NORTHING>822488.738</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000896</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822493.97633 831901.14046</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id555d927c-3bc1-4819-a3bf-143fd39fc74d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>P</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026043</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831856.35</fme:EASTING>
<fme:NORTHING>822427.326</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000612</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822427.32623 831856.35015</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idb851bb64-1faa-4d51-a760-ea6092983ef6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>G</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026044</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831906.439</fme:EASTING>
<fme:NORTHING>822426.945</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000638</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822426.94527 831906.43901</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id14098603-9ef1-4ab7-9a53-48223e5c62b2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>S</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>44.6609801862966</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026045</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831961.089</fme:EASTING>
<fme:NORTHING>822443.67</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005772</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822448.77697 831958.99346</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida2607226-eeb8-4206-a396-a1c137384997">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>E</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026046</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831995.94</fme:EASTING>
<fme:NORTHING>822411.344</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005776</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822411.34361 831995.94050</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idd213bdb6-0aeb-459f-847b-0109a0b67277">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>F</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026047</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831972.63</fme:EASTING>
<fme:NORTHING>822386.573</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005777</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822386.57263 831972.63026</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id4500f1d2-6ba0-4528-af8a-a6ae4f2acb46">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A-D</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026048</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831923.501</fme:EASTING>
<fme:NORTHING>822321.513</fme:NORTHING>
<fme:LINKFEATURE_ID>1210005778</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822321.51325 831923.50104</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idde1b5429-2e36-4e4b-9d27-967d20644e6e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>H</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026049</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831855.957</fme:EASTING>
<fme:NORTHING>822362.229</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000963</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822362.22875 831855.95735</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idfd59a03e-6fe4-4ee5-864c-c22f8d1ac531">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>I</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026050</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831865.482</fme:EASTING>
<fme:NORTHING>822329.533</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000692</fme:LINKFEATURE_ID>
<fme:ST_CODE>75039</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822329.53297 831865.48180</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idc95ec46a-d253-4b61-a0e1-5b77265f091e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Day Recovery
 Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>23.7748699978236</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026093</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831881.429</fme:EASTING>
<fme:NORTHING>822540.775</fme:NORTHING>
<fme:LINKFEATURE_ID>1210191907</fme:LINKFEATURE_ID>
<fme:ST_CODE>75038</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822540.73934 831881.44445</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idfef74fe7-79bf-48dd-9ce4-08d9a11a470f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hutchison Logistics Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.502581954001813</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210027994</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830934.756</fme:EASTING>
<fme:NORTHING>822400.342</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001079</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822400.34180 830934.75587</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0032d4f5-fa7a-45b0-93fa-40e4c47c84c9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>China Resources Int'l Logistics Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210028014</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831825.504</fme:EASTING>
<fme:NORTHING>821686.057</fme:NORTHING>
<fme:LINKFEATURE_ID>1210185566</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821686.05676 831825.50369</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide9611cdc-e62a-4058-9420-9a2b2cc5b52d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Magnet
Place
Tower 1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.8283330632935</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028758</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830989.539</fme:EASTING>
<fme:NORTHING>824021.224</fme:NORTHING>
<fme:LINKFEATURE_ID>1210195771</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>824021.16977 830989.48372</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id4db9a6f1-9d9f-4730-8d0b-f1fbda8cbb61">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030160</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833239.379</fme:EASTING>
<fme:NORTHING>821024.275</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206939</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821024.27539 833239.37908</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id6bd1aa08-a053-48bc-bcfa-37398ea2f430">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hong Kong Industrial Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.7738365739097</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030957</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833217.758</fme:EASTING>
<fme:NORTHING>822059.316</fme:NORTHING>
<fme:LINKFEATURE_ID>1210022691</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822059.31620 833217.75777</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id1f11ab85-b326-426a-b7ad-5f3941d1cb2e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Mariners'
Club</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030937</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>830867.347</fme:EASTING>
<fme:NORTHING>822974.51</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000564</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822974.47166 830867.34710</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id59ee0145-94ea-4e3d-ae6b-fb255a98b617">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PeakCastle</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.7077547904113</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310031257</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833763.008</fme:EASTING>
<fme:NORTHING>822343.345</fme:NORTHING>
<fme:LINKFEATURE_ID>1310203309</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822343.34513 833763.00759</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idd3ffc946-a249-46a0-a989-b656d38b8d05">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310031517</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833111.416</fme:EASTING>
<fme:NORTHING>822262.801</fme:NORTHING>
<fme:LINKFEATURE_ID>1310209465</fme:LINKFEATURE_ID>
<fme:ST_CODE>83425</fme:ST_CODE>
<fme:LASTUPDATEDATE>20241016</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822262.80150 833111.41585</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id7ec5ed23-e187-466e-bcb1-5e89b45f8859">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310031518</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833176.768</fme:EASTING>
<fme:NORTHING>822260.685</fme:NORTHING>
<fme:LINKFEATURE_ID>1310209467</fme:LINKFEATURE_ID>
<fme:ST_CODE>83425</fme:ST_CODE>
<fme:LASTUPDATEDATE>20241016</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822260.68482 833176.76806</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id15ac747c-bff4-4568-a90d-3bb2d6268382">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>One
Two
One</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.5134012499609</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000200</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833472.162</fme:EASTING>
<fme:NORTHING>822363.048</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20250213</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822362.97486 833472.18781</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id90903368-e648-40bf-9c04-f8a436344ce6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B/C</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420001724</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831861.549</fme:EASTING>
<fme:NORTHING>822626.569</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822626.56872 831861.54859</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id9d1a4cf1-6ffb-48f9-be00-28469af986c1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D/E</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420001725</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831736.136</fme:EASTING>
<fme:NORTHING>822650.54</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822650.54001 831736.13585</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
