<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingPolyAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821180.18957 830130.71844</gml:lowerCorner>
<gml:upperCorner>823892.05265 833730.48891</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idb9e155bc-9017-4152-b8a9-c9433f5a417d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>12.1913299121744</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749076</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>831654.8943175</fme:EASTING>
<fme:NORTHING>823528.45759624</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823531.40651 831668.54355</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id0febe9cf-3f73-432c-a5d0-ee1277f88a92">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749077</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>831764.75060075</fme:EASTING>
<fme:NORTHING>823306.37303499</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823309.23941 831778.78706</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idafeb1257-3c5c-4061-bfae-b546c80374e4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.8312178492128</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749075</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832965.615</fme:EASTING>
<fme:NORTHING>822187.494</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822187.71832 832965.60479</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id2fd76151-6481-4c9c-b5d8-d7208f0146e9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.5268710983505</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749082</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>830666.46412436</fme:EASTING>
<fme:NORTHING>823466.40430238</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823475.79292 830664.80474</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idaa0d0a84-2827-4377-91c4-34805bbda025">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749081</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833381.05768541</fme:EASTING>
<fme:NORTHING>822990.05150007</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822992.91788 833395.09415</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id73bd0303-1660-4a52-a673-ffc78f2db280">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.7703889103568</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749078</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833714.09831318</fme:EASTING>
<fme:NORTHING>821401.23028098</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821394.23487 833726.60041</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id0625e962-f6f4-4d61-864a-eaa0fc17b213">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.42299857755513</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749083</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833143.818</fme:EASTING>
<fme:NORTHING>821714.316</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821714.52364 833143.71717</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id62f39ba8-d814-476d-b88c-3a4e39b033af">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-38.3513538539087</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749074</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833427.00941832</fme:EASTING>
<fme:NORTHING>822725.05889187</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822718.60561 833439.78526</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id6a5490c3-5be9-41d6-a98e-25f3ddcd9a7f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749064</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>831959.86790738</fme:EASTING>
<fme:NORTHING>822362.04976303</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822364.91614 831973.89114</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id3f0cdf49-a98c-4b6f-b84e-dbef17d156a8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749069</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833043.37526537</fme:EASTING>
<fme:NORTHING>821752.66100371</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821755.52738 833057.39850</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ide58edb94-c422-4332-8c05-9600973aeff8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749067</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>831769.61457298</fme:EASTING>
<fme:NORTHING>822861.82717467</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822864.69355 831783.63780</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id342b1d33-ac47-48a5-a4cb-5a66f62338c9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749063</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>830981.80130676</fme:EASTING>
<fme:NORTHING>823146.82476551</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823149.69115 830995.82454</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id56eaa08e-414e-412d-ad3f-2970b7ed1679">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749072</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833637.66456442</fme:EASTING>
<fme:NORTHING>822580.57881852</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822580.57882 833637.66456</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id21e33eb6-c5b7-481d-9341-2e5429e5938a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749058</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832530.60138589</fme:EASTING>
<fme:NORTHING>823025.22658612</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823028.09297 832544.62462</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id6daeefe6-2c31-4373-96cb-3446dd09feb7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749071</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832504.22976687</fme:EASTING>
<fme:NORTHING>821941.30099678</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821944.16738 832518.25300</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id625259ff-6621-4c3b-abf7-777bb2c1cccd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749070</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832895.08874584</fme:EASTING>
<fme:NORTHING>821214.58601028</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821217.45239 832909.11198</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idb99193ca-5ac7-45cd-be73-ecbfdf7562dd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749062</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>830130.648</fme:EASTING>
<fme:NORTHING>823891.839</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823892.05265 830130.71844</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ida8f75626-6e43-4af7-b7b1-55308cda6d3f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-6.2034558747841</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749061</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833066.17360364</fme:EASTING>
<fme:NORTHING>822532.78081757</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822534.11508 833080.42445</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ida3e687e3-3a0b-4995-b513-22f1ba178cef">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749054</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>831097.01568419</fme:EASTING>
<fme:NORTHING>823518.45979757</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823521.32618 831111.03891</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id0f3e927b-754e-4c26-aa7d-902001369033">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749055</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832437.74995361</fme:EASTING>
<fme:NORTHING>821741.45947717</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821744.32586 832451.77318</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id12aef320-1e07-4ff6-96e6-63a8b39470b8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.6651994155042</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749048</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>830743.21009651</fme:EASTING>
<fme:NORTHING>823067.0159422</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823072.47437 830750.90371</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id6861b6f3-3772-45f1-9a37-b868094fa44b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749056</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>831700.01333759</fme:EASTING>
<fme:NORTHING>823375.04333611</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823377.90972 831714.03657</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id40cfe5c4-414d-43ff-9d57-d559bac601cc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749051</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832941.57199662</fme:EASTING>
<fme:NORTHING>823330.25599396</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823333.12237 832955.59523</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idb975f36c-4f11-4687-b57d-45ca7b939013">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749052</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832609.71518989</fme:EASTING>
<fme:NORTHING>823193.15285392</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823196.01923 832623.73842</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idf666c539-8c68-4569-9b4b-935459b806b3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749057</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832490.37428302</fme:EASTING>
<fme:NORTHING>821697.90249363</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821700.76887 832504.39751</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id5c252590-c127-45f3-bad5-160c06d3aaf5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749053</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>830224.57484446</fme:EASTING>
<fme:NORTHING>823705.71891387</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823705.71891 830238.59807</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id902be2cf-8f9a-4570-8a55-4970d1da9e5c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>污水
泵房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.000007963176</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749236</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>833730.143</fme:EASTING>
<fme:NORTHING>821441.107</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821441.53355 833730.48891</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id990dd71e-a424-4a7f-8330-369a1fcea234">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>看台</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.1721608250966</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749239</fme:FEATURE_ID>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:EASTING>833683.528</fme:EASTING>
<fme:NORTHING>822057.728</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822057.72791 833683.52777</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id7ccea119-2d0e-4414-bcc7-1416ffdd1c3b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>看台</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.0942311838197</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749240</fme:FEATURE_ID>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:EASTING>832159.2842936</fme:EASTING>
<fme:NORTHING>822236.12799227</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822245.13627 832159.97885</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ida91fc367-350c-495a-a3c7-57c30faccea2">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>看台</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>33.2065608083304</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000749241</fme:FEATURE_ID>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:EASTING>832140.22545281</fme:EASTING>
<fme:NORTHING>822378.56647158</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822384.84052 832149.81080</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idcb589f56-af1f-426e-b1a3-04ff2bcf9961">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>看台</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.4575837050677</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001043</fme:FEATURE_ID>
<fme:FEATURECODE>CSN</fme:FEATURECODE>
<fme:EASTING>830224.57484446</fme:EASTING>
<fme:NORTHING>823705.71891387</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823679.93729 830147.23549</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ideb01adf4-9797-4a2a-9850-11a450bd2682">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>辦事處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.6501066117851</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000935</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>830746.67730946</fme:EASTING>
<fme:NORTHING>823011.94846512</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823019.24856 830760.12079</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id87b1c2f6-05b2-4e7e-8f85-e162328837f3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>辦事處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-71.5650447923438</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004847</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832027.95905002</fme:EASTING>
<fme:NORTHING>821298.2110247</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821285.83059 832035.10730</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idb7b10316-8951-495c-ac00-73f089f613b6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>辦事處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-71.5650511788618</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001931</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>832061.80520444</fme:EASTING>
<fme:NORTHING>821192.56999938</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821180.18957 832068.95345</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id88589a7f-5dfe-4193-8cc5-fb088f7a3121">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工務區域
試驗所</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000909</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>831046.95539684</fme:EASTING>
<fme:NORTHING>823769.76495099</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823777.83316 831061.51402</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id1a247f15-3231-414e-8406-915704e09d6e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>看台</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>65.2129996933584</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210023127</fme:FEATURE_ID>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:EASTING>832013.076</fme:EASTING>
<fme:NORTHING>821840.29</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821839.82306 832012.62470</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ide5a0a434-9294-4434-a527-0f7fa9978419">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-67.0051069675769</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310027769</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>831920.94</fme:EASTING>
<fme:NORTHING>822640.921</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822641.00459 831921.13683</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idb8985e0b-f970-49a8-8294-4e3b5e2887f4">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028235</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>831507.182</fme:EASTING>
<fme:NORTHING>823259.827</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231114</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823260.04028 831506.62201</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idc3be5996-c041-4b22-a143-6509d8228723">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-69.5820041296256</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028289</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>833621.83</fme:EASTING>
<fme:NORTHING>822183.752</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822184.35090 833621.83516</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id671dfa2c-b422-4739-9032-09d0178c12b4">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.9698799759163</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028290</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>833364.152</fme:EASTING>
<fme:NORTHING>822182.156</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822182.16547 833363.55254</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id78d8a029-7f75-4aca-bcb3-1c3b751e8c2d">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030031</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>832199.945</fme:EASTING>
<fme:NORTHING>821295.391</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821295.60443 832199.94489</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id4cd93c5e-4c20-46f6-a7fc-4aeca9714878">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030032</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>833573.119</fme:EASTING>
<fme:NORTHING>821394.532</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821394.74579 833572.55860</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idad727984-cdad-495d-a501-80d645c9009e">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>49.2004235757413</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310031651</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>833697.322</fme:EASTING>
<fme:NORTHING>821616.539</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20241125</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821616.25459 833696.79445</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id3fa44f7b-d2b4-4502-a36b-2081f525cb94">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002901</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>830752.546</fme:EASTING>
<fme:NORTHING>822918.425</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822918.63875 830751.98641</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id31cef8d4-0b38-45b5-879f-56d475289902">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002902</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>831523.957</fme:EASTING>
<fme:NORTHING>823416.91</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823417.12408 831523.39725</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
