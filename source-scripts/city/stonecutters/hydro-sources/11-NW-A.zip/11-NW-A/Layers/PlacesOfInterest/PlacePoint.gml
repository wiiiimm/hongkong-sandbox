<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821005.00000 830717.99868 0.00000</gml:lowerCorner>
<gml:upperCorner>823945.00300 833673.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePoint gml:id="id7b0bf57d-3096-4f0a-bbed-e4965b164585">
<fme:FEATURE_ID>1310015452</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833217</fme:EASTING>
<fme:NORTHING>821005</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Grand Victoria</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20231128</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821005.00000 833217.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id7b3ba49c-e40c-4832-ad16-2a282702bf32">
<fme:FEATURE_ID>1001283505</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832866</fme:EASTING>
<fme:NORTHING>821054</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Shipyards</fme:ENGLISHNAME>
<fme:CHINESENAME>船廠</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821053.99880 832865.99972 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id89d77217-deba-4364-97a2-0d2143523691">
<fme:FEATURE_ID>1210009947</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833310</fme:EASTING>
<fme:NORTHING>821054</fme:NORTHING>
<fme:ST_CODE>82683</fme:ST_CODE>
<fme:ENGLISHNAME>Hoi Ying Estate</fme:ENGLISHNAME>
<fme:CHINESENAME>海盈邨</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821054.00000 833310.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id09382e19-68b1-4823-a020-bc2431ac0b50">
<fme:FEATURE_ID>1210005258</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832970</fme:EASTING>
<fme:NORTHING>821115</fme:NORTHING>
<fme:ST_CODE>80211</fme:ST_CODE>
<fme:ENGLISHNAME>Lai Chi Kok Drainage Tunnel - Outfall</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角雨水排放道－排水口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821114.99832 832969.99886 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf89c082c-bdef-48d8-b1e3-77a416389a85">
<fme:FEATURE_ID>1310015166</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833031</fme:EASTING>
<fme:NORTHING>821193</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>CITYBUS WEST KOWLOON DEPOT</fme:ENGLISHNAME>
<fme:CHINESENAME>城巴西九龍車廠</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20240531</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821193.00000 833031.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf9f26408-18a4-4933-a345-b95352edc895">
<fme:FEATURE_ID>1210009885</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833496.1</fme:EASTING>
<fme:NORTHING>821221.23</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Hoi Tat Estate</fme:ENGLISHNAME>
<fme:CHINESENAME>海達邨</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230922</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821221.22602 833496.09787 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc79fb887-3c12-43ca-8b18-4aeda99787e3">
<fme:FEATURE_ID>1210010560</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833637.95</fme:EASTING>
<fme:NORTHING>821298.41</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Hoi Tak Court</fme:ENGLISHNAME>
<fme:CHINESENAME>凱德苑</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821298.40981 833637.95370 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idd61a7cab-4f43-44ba-9a62-c838658ac156">
<fme:FEATURE_ID>1001281561</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833124</fme:EASTING>
<fme:NORTHING>821464</fme:NORTHING>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:ENGLISHNAME>Hoi Lai Estate</fme:ENGLISHNAME>
<fme:CHINESENAME>海麗邨</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821463.99998 833124.00188 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id9d34db6b-34ec-4e69-80b0-4be45863689e">
<fme:FEATURE_ID>1001281530</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833346</fme:EASTING>
<fme:NORTHING>821505</fme:NORTHING>
<fme:ST_CODE>79335</fme:ST_CODE>
<fme:ENGLISHNAME>Aqua Marine</fme:ENGLISHNAME>
<fme:CHINESENAME>碧海藍天</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821505.00330 833345.99949 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idbf7e263c-789f-4a81-923a-7d023a059a81">
<fme:FEATURE_ID>1310014596</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833673</fme:EASTING>
<fme:NORTHING>821507</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Kerry Hung Kai Warehouse (Cheung Sha Wan)</fme:ENGLISHNAME>
<fme:CHINESENAME>嘉里鴻基貨倉（長沙灣）</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821507.00000 833673.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idcaf654ae-681c-4ae1-8962-cf9a1609f880">
<fme:FEATURE_ID>1210004483</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833170</fme:EASTING>
<fme:NORTHING>821685</fme:NORTHING>
<fme:ST_CODE>80006</fme:ST_CODE>
<fme:ENGLISHNAME>One West Kowloon</fme:ENGLISHNAME>
<fme:CHINESENAME>一號．西九龍</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821684.99986 833170.00415 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0db4c604-ec35-4f19-94f7-8dec695eabdf">
<fme:FEATURE_ID>1001283838</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831972</fme:EASTING>
<fme:NORTHING>821707</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>West Kowloon Emergency Response Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>西九龍緊急支援中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821706.99476 831972.00254 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idbfaeecdb-b934-4c13-9a67-26e51b7f0283">
<fme:FEATURE_ID>1310014626</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833018</fme:EASTING>
<fme:NORTHING>821712</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Water Boat Dock Sewage Pumping Station</fme:ENGLISHNAME>
<fme:CHINESENAME>水船街污水泵房</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821712.00000 833018.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id2aecde5b-b4f5-4a4f-97ad-9ef24dcd9bc5">
<fme:FEATURE_ID>1001281270</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833380</fme:EASTING>
<fme:NORTHING>821737</fme:NORTHING>
<fme:ST_CODE>79184</fme:ST_CODE>
<fme:ENGLISHNAME>Liberte</fme:ENGLISHNAME>
<fme:CHINESENAME>昇悅居</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821736.99910 833379.99512 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf61bdcd4-3d9e-4381-8851-bb071abe5a75">
<fme:FEATURE_ID>1001278598</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833010</fme:EASTING>
<fme:NORTHING>821740</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Lai Chi Kok</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821740.00067 833010.00312 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idcedc95aa-ba53-44ef-9892-49adb9772282">
<fme:FEATURE_ID>1001281266</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833256</fme:EASTING>
<fme:NORTHING>821749</fme:NORTHING>
<fme:ST_CODE>79185</fme:ST_CODE>
<fme:ENGLISHNAME>Banyan Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>泓景臺</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821749.00131 833255.99706 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id3d4de173-48eb-4af4-a706-c8f3f39a4ad4">
<fme:FEATURE_ID>1001281493</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833449</fme:EASTING>
<fme:NORTHING>821763</fme:NORTHING>
<fme:ST_CODE>79334</fme:ST_CODE>
<fme:ENGLISHNAME>The Pacifica</fme:ENGLISHNAME>
<fme:CHINESENAME>宇晴軒</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821762.99800 833449.00259 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idd68cfd0b-344d-4e55-afe3-865fc95e3659">
<fme:FEATURE_ID>1001282655</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832607</fme:EASTING>
<fme:NORTHING>821770</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage 8</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨第八期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821769.99823 832607.00444 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf383acd2-738e-4451-b1fe-81ed766298c4">
<fme:FEATURE_ID>1210006651</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831756</fme:EASTING>
<fme:NORTHING>821774</fme:NORTHING>
<fme:ST_CODE>82366</fme:ST_CODE>
<fme:ENGLISHNAME>Hong Kong Institute of Construction Tat Mei Road Training Ground</fme:ENGLISHNAME>
<fme:CHINESENAME>香港建造學院達美路訓練場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821773.99660 831756.00042 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idfac21ff8-2ccf-4401-a7aa-ba7a3bfd625c">
<fme:FEATURE_ID>1001281593</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832719</fme:EASTING>
<fme:NORTHING>821778</fme:NORTHING>
<fme:ST_CODE>79749</fme:ST_CODE>
<fme:ENGLISHNAME>Manhattan Hill</fme:ENGLISHNAME>
<fme:CHINESENAME>曼克頓山</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821778.00369 832719.00242 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idb3d2dbc5-0419-4509-9968-0566d89c45c7">
<fme:FEATURE_ID>1310015111</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831000</fme:EASTING>
<fme:NORTHING>821800</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Kwai Tsing Container Terminals</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821800.00000 831000.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id9255dbe4-cab4-4b1f-8169-205da2259a39">
<fme:FEATURE_ID>1001282654</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832618</fme:EASTING>
<fme:NORTHING>821874</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage 4</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨第四期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821873.99668 832617.99662 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc9506c59-c55c-47bf-9493-b44715410192">
<fme:FEATURE_ID>1001282653</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832471</fme:EASTING>
<fme:NORTHING>821901</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage 3</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨第三期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821901.00292 832470.99606 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id3d008b3e-7ef7-43e1-8352-1d1c090d24d8">
<fme:FEATURE_ID>1001282652</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832358</fme:EASTING>
<fme:NORTHING>821946</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage 2</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨第二期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821946.00341 832357.99872 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0d57b0fc-c582-40e9-9e11-1d5965eff318">
<fme:FEATURE_ID>1001282651</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832261</fme:EASTING>
<fme:NORTHING>821971</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage 1</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨第一期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821971.00069 832261.00358 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf23bb9c7-ddac-46bf-a6fd-8327d0f229f1">
<fme:FEATURE_ID>1001279438</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832482</fme:EASTING>
<fme:NORTHING>821984</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821984.00417 832482.00100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf8f5def6-32d0-44a9-8466-9ab16e1ce895">
<fme:FEATURE_ID>1001282650</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832307</fme:EASTING>
<fme:NORTHING>822061</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage 7</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨第七期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822061.00253 832306.99822 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idaed7de08-af2a-45a6-82b5-f7b493d6c300">
<fme:FEATURE_ID>1001282649</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832490</fme:EASTING>
<fme:NORTHING>822111</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage 6</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨第六期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822111.00193 832489.99790 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idea376fe8-3986-4a57-af10-8a65663e7c00">
<fme:FEATURE_ID>1210007906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832698</fme:EASTING>
<fme:NORTHING>822129</fme:NORTHING>
<fme:ST_CODE>75080</fme:ST_CODE>
<fme:ENGLISHNAME>Jao Tsung-I Academy</fme:ENGLISHNAME>
<fme:CHINESENAME>饒宗頤文化館</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822128.99602 832697.99675 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0e62b6b0-2ab3-4e75-83b5-675a9ba270e1">
<fme:FEATURE_ID>1210006652</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832699</fme:EASTING>
<fme:NORTHING>822182</fme:NORTHING>
<fme:ST_CODE>80264</fme:ST_CODE>
<fme:ENGLISHNAME>Heritage Lodge</fme:ENGLISHNAME>
<fme:CHINESENAME>翠雅山房</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822181.99614 832698.99953 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idd11513c6-f7ae-4d5a-9f48-a457d97bd966">
<fme:FEATURE_ID>1001278600</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831938</fme:EASTING>
<fme:NORTHING>822229</fme:NORTHING>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:ENGLISHNAME>Ching Lai Court</fme:ENGLISHNAME>
<fme:CHINESENAME>清麗苑</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822229.00310 831938.00009 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ida7dd1b49-c2f2-4233-9222-1feecb4164e0">
<fme:FEATURE_ID>1310016854</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833143.59</fme:EASTING>
<fme:NORTHING>822258.18</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Portas</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20241218</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822258.18100 833143.58600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0259bcb0-64b8-4692-bd30-81c4d6fea932">
<fme:FEATURE_ID>1001280181</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831810</fme:EASTING>
<fme:NORTHING>822284</fme:NORTHING>
<fme:ST_CODE>77886</fme:ST_CODE>
<fme:ENGLISHNAME>Lai King Terrace</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景臺</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822283.99912 831809.99850 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id14033064-bc4f-440b-b8af-8d0faaea5005">
<fme:FEATURE_ID>1001282648</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832384</fme:EASTING>
<fme:NORTHING>822286</fme:NORTHING>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage 5</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨第五期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822286.00349 832384.00272 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id578f9609-0e7a-43a6-b027-30ec460d00b5">
<fme:FEATURE_ID>1001281078</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832221</fme:EASTING>
<fme:NORTHING>822521</fme:NORTHING>
<fme:ST_CODE>76864</fme:ST_CODE>
<fme:ENGLISHNAME>Nob Hill</fme:ENGLISHNAME>
<fme:CHINESENAME>盈暉臺</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822521.00025 832220.99767 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id21fc1c77-bd73-4f35-938b-334ebf8ad732">
<fme:FEATURE_ID>1210010959</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831640</fme:EASTING>
<fme:NORTHING>822552</fme:NORTHING>
<fme:ST_CODE>78847</fme:ST_CODE>
<fme:ENGLISHNAME>Fire Services Department New Territories Workshop (Kwai Chung)</fme:ENGLISHNAME>
<fme:CHINESENAME>消防處新界工程部（葵涌）</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822552.00000 831640.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id96b9d0b7-4724-45ec-88bb-abcfe946f91a">
<fme:FEATURE_ID>1001281286</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832061</fme:EASTING>
<fme:NORTHING>822565</fme:NORTHING>
<fme:ST_CODE>76862</fme:ST_CODE>
<fme:ENGLISHNAME>Lai Chi Kok Bay Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>荔灣花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822565.00281 832061.00409 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idb81c440c-641d-4c23-8282-058e41ce17c4">
<fme:FEATURE_ID>1210002437</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833517.21</fme:EASTING>
<fme:NORTHING>822574.98</fme:NORTHING>
<fme:ST_CODE>71531</fme:ST_CODE>
<fme:ENGLISHNAME>Piper's Hill Salt Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>琵琶山海水配水庫</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822574.98296 833517.21357 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id6b5ecc8d-c567-4c5d-812c-ca642f486ff0">
<fme:FEATURE_ID>1210002402</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833039.14</fme:EASTING>
<fme:NORTHING>822601.09</fme:NORTHING>
<fme:ST_CODE>70422</fme:ST_CODE>
<fme:ENGLISHNAME>Butterfly Valley Fresh Water Primary Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>蝴蝶谷食水主配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822601.09346 833039.13760 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ide012f997-d11d-4881-823e-27d5e71c8f9c">
<fme:FEATURE_ID>1001280965</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832214</fme:EASTING>
<fme:NORTHING>822613</fme:NORTHING>
<fme:ST_CODE>77063</fme:ST_CODE>
<fme:ENGLISHNAME>Wah Lai Estate</fme:ENGLISHNAME>
<fme:CHINESENAME>華荔邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822612.99554 832214.00117 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id18219802-4c76-4779-8107-43569f1c9585">
<fme:FEATURE_ID>1001280986</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832124</fme:EASTING>
<fme:NORTHING>822662</fme:NORTHING>
<fme:ST_CODE>76863</fme:ST_CODE>
<fme:ENGLISHNAME>Lai Yan Court</fme:ENGLISHNAME>
<fme:CHINESENAME>荔欣苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822662.00152 832123.99574 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id99a0b772-307c-4707-981d-8136198e5766">
<fme:FEATURE_ID>1001280188</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832207</fme:EASTING>
<fme:NORTHING>822685</fme:NORTHING>
<fme:ST_CODE>76839</fme:ST_CODE>
<fme:ENGLISHNAME>Happy Villa</fme:ENGLISHNAME>
<fme:CHINESENAME>樂園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822685.00436 832207.00127 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id96577814-3eb0-4437-b860-b0c69dea1ca6">
<fme:FEATURE_ID>1001282090</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832867</fme:EASTING>
<fme:NORTHING>822726</fme:NORTHING>
<fme:ST_CODE>68173</fme:ST_CODE>
<fme:ENGLISHNAME>Butterfly Valley</fme:ENGLISHNAME>
<fme:CHINESENAME>蝴蝶谷</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822726.00101 832867.00196 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idcb536f36-2084-44fb-9cf0-25e03c8044a9">
<fme:FEATURE_ID>1210002408</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833479.62</fme:EASTING>
<fme:NORTHING>822731.83</fme:NORTHING>
<fme:ST_CODE>71531</fme:ST_CODE>
<fme:ENGLISHNAME>Piper's Hill Salt Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>琵琶山海水配水庫</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822731.83008 833479.61520 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id96d57a5a-f76c-427e-8b6f-edd64231bec8">
<fme:FEATURE_ID>1001278596</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832571</fme:EASTING>
<fme:NORTHING>822743</fme:NORTHING>
<fme:ST_CODE>75079</fme:ST_CODE>
<fme:ENGLISHNAME>Tai Ching Cheung</fme:ENGLISHNAME>
<fme:CHINESENAME>大蒸場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822743.00042 832571.00026 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ida0b4f133-dc51-42a5-a046-a8bc8a450dfe">
<fme:FEATURE_ID>1001278599</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832325</fme:EASTING>
<fme:NORTHING>822746</fme:NORTHING>
<fme:ST_CODE>75054</fme:ST_CODE>
<fme:ENGLISHNAME>Chung Shan Terrace</fme:ENGLISHNAME>
<fme:CHINESENAME>鐘山臺</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20251118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822746.00088 832324.99555 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id1ff9eca8-a75a-4e5e-bcdd-d79cd703d915">
<fme:FEATURE_ID>1210007886</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831534.45</fme:EASTING>
<fme:NORTHING>822773.96</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Covered Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>有蓋配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822773.95830 831534.45236 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc18a0e46-ede6-4deb-8868-649213e4bedd">
<fme:FEATURE_ID>1210002441</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833433.17</fme:EASTING>
<fme:NORTHING>822780.68</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Piper's Hill High Level Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>琵琶山上食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822780.67999 833433.17299 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id51c3d454-c714-4031-a3b9-09bff3970a2b">
<fme:FEATURE_ID>1001281515</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833522</fme:EASTING>
<fme:NORTHING>822806</fme:NORTHING>
<fme:ST_CODE>79451</fme:ST_CODE>
<fme:ENGLISHNAME>The Caldecott</fme:ENGLISHNAME>
<fme:CHINESENAME>嘉珀山</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822805.99631 833521.99744 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id7b94fe23-ba45-456c-8aee-cadb523d866a">
<fme:FEATURE_ID>1210003909</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832290</fme:EASTING>
<fme:NORTHING>822820</fme:NORTHING>
<fme:ST_CODE>75054</fme:ST_CODE>
<fme:ENGLISHNAME>Chung Shan Lodge</fme:ENGLISHNAME>
<fme:CHINESENAME>鐘山小築</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822819.99872 832290.00273 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idde1c05b7-c6c7-4c9f-8f8c-8a1b2b182d9b">
<fme:FEATURE_ID>1001283812</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830931</fme:EASTING>
<fme:NORTHING>822848</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>DSD Container Port Road Maintenance Depot</fme:ENGLISHNAME>
<fme:CHINESENAME>渠務署貨櫃碼頭路渠務保養廠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822848.00000 830931.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc98fd454-5bc2-456b-932e-d266296c6de6">
<fme:FEATURE_ID>1001281526</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833483</fme:EASTING>
<fme:NORTHING>822863</fme:NORTHING>
<fme:ST_CODE>79452</fme:ST_CODE>
<fme:ENGLISHNAME>Caldecott Hill</fme:ENGLISHNAME>
<fme:CHINESENAME>郝德傑山</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822863.00232 833482.99556 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id65d65439-d291-406a-a84e-557d332067f2">
<fme:FEATURE_ID>1001283348</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831193</fme:EASTING>
<fme:NORTHING>822869</fme:NORTHING>
<fme:ST_CODE>75577</fme:ST_CODE>
<fme:ENGLISHNAME>The Salvation Army Lai King Home</fme:ENGLISHNAME>
<fme:CHINESENAME>救世軍荔景院</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822869.00287 831192.99810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf10dbf44-4d73-430c-b520-c4a0f802267b">
<fme:FEATURE_ID>1210004874</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832695</fme:EASTING>
<fme:NORTHING>822875</fme:NORTHING>
<fme:ST_CODE>72126</fme:ST_CODE>
<fme:ENGLISHNAME>The Neighbourhood Advice-Action Council Fairyland</fme:ENGLISHNAME>
<fme:CHINESENAME>鄰舍輔導會怡菁山莊</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822875.00256 832694.99499 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0a5ed82c-18b4-439b-986e-b6d3e49dcbd7">
<fme:FEATURE_ID>1210002511</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831710.99</fme:EASTING>
<fme:NORTHING>822893.03</fme:NORTHING>
<fme:ST_CODE>77881</fme:ST_CODE>
<fme:ENGLISHNAME>Lai Chi Kok Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822893.03022 831710.98729 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf514c9d7-7921-482c-b673-a8aefc50ca25">
<fme:FEATURE_ID>1001278595</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832128</fme:EASTING>
<fme:NORTHING>822902</fme:NORTHING>
<fme:ST_CODE>68170</fme:ST_CODE>
<fme:ENGLISHNAME>Kau Wa Keng</fme:ENGLISHNAME>
<fme:CHINESENAME>九華徑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822902.00277 832127.99590 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idda493084-376f-4868-8b22-cc494832d378">
<fme:FEATURE_ID>1310015813</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831615</fme:EASTING>
<fme:NORTHING>822958</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Caritas Jockey Club Lai King Rehabilitation Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>明愛賽馬會荔景社會服務中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20240531</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822958.00000 831615.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idcaae8b01-516d-430c-8a30-05d68fe8a08d">
<fme:FEATURE_ID>1001278594</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831957</fme:EASTING>
<fme:NORTHING>822961</fme:NORTHING>
<fme:ST_CODE>68169</fme:ST_CODE>
<fme:ENGLISHNAME>Kau Wa Keng San Tsuen</fme:ENGLISHNAME>
<fme:CHINESENAME>九華徑新村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822960.99599 831957.00037 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id41baed4c-138d-4b4a-a681-94f99a4b7c4b">
<fme:FEATURE_ID>1210007866</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833470</fme:EASTING>
<fme:NORTHING>823010</fme:NORTHING>
<fme:ST_CODE>71526</fme:ST_CODE>
<fme:ENGLISHNAME>Hong Kong Air Cradet Corps Piper's Hill Adventure Activities Base</fme:ENGLISHNAME>
<fme:CHINESENAME>香港航空青年團琵琶山歷奇活動基地</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823010.00385 833469.99655 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id696b9871-28d8-4714-b087-81faa0fd8503">
<fme:FEATURE_ID>1210002474</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832655.72</fme:EASTING>
<fme:NORTHING>823011.41</fme:NORTHING>
<fme:ST_CODE>70960</fme:ST_CODE>
<fme:ENGLISHNAME>Kau Wa Keng No.2 Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>九華徑二號食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823011.40978 832655.71471 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0a6036f7-5798-4a29-b5e5-7cd71682dac1">
<fme:FEATURE_ID>1210002519</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833470.46</fme:EASTING>
<fme:NORTHING>823012.19</fme:NORTHING>
<fme:ST_CODE>71525</fme:ST_CODE>
<fme:ENGLISHNAME>Tai Po Road Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>大埔道食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823012.19045 833470.45792 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="iddc679c6b-d6b2-4a72-91b0-dd5d315f41e1">
<fme:FEATURE_ID>1310012214</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831309</fme:EASTING>
<fme:NORTHING>823039</fme:NORTHING>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:ENGLISHNAME>Cho Yiu Chuen</fme:ENGLISHNAME>
<fme:CHINESENAME>祖堯邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823039.00000 831309.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id135fbc8c-555f-460e-88c0-2f8653be05b4">
<fme:FEATURE_ID>1001283870</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833440</fme:EASTING>
<fme:NORTHING>823091</fme:NORTHING>
<fme:ST_CODE>71193</fme:ST_CODE>
<fme:ENGLISHNAME>Tai Po Road Water Treatment Works</fme:ENGLISHNAME>
<fme:CHINESENAME>大埔道濾水廠</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823091.00438 833440.00212 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id85729544-882d-4d5c-9ae2-531de79a3a15">
<fme:FEATURE_ID>1210002428</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832586.87</fme:EASTING>
<fme:NORTHING>823175.25</fme:NORTHING>
<fme:ST_CODE>70959</fme:ST_CODE>
<fme:ENGLISHNAME>Kau Wa Keng Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>九華徑食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823175.24758 832586.86984 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id2a4e1815-db9f-4dd6-aa0b-e46be9280ecc">
<fme:FEATURE_ID>1001278592</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831144</fme:EASTING>
<fme:NORTHING>823195</fme:NORTHING>
<fme:ST_CODE>75552</fme:ST_CODE>
<fme:ENGLISHNAME>Yuet Lai Court</fme:ENGLISHNAME>
<fme:CHINESENAME>悅麗苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823194.99932 831144.00345 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id5179acbc-c58b-450a-aa75-2283ad1093b2">
<fme:FEATURE_ID>1001283652</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831598</fme:EASTING>
<fme:NORTHING>823218</fme:NORTHING>
<fme:ST_CODE>77092</fme:ST_CODE>
<fme:ENGLISHNAME>Lai King Disciplined Services Quarters</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景紀律部隊宿舍</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823218.00078 831598.00106 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id1adcef17-0106-41cf-b70b-acd16174112a">
<fme:FEATURE_ID>1001282387</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831081</fme:EASTING>
<fme:NORTHING>823281</fme:NORTHING>
<fme:ST_CODE>75239</fme:ST_CODE>
<fme:ENGLISHNAME>YIN LAI COURT</fme:ENGLISHNAME>
<fme:CHINESENAME>賢麗苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823280.99588 831081.00065 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id9ba9c9ec-34e5-46c3-b787-f7356b1f8f5e">
<fme:FEATURE_ID>1210002403</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833030.82</fme:EASTING>
<fme:NORTHING>823325.87</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Shek Lei Pui Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>石梨貝食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823325.87352 833030.81908 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id23100425-a44d-4732-92ce-c908af3ea701">
<fme:FEATURE_ID>1310012312</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831045</fme:EASTING>
<fme:NORTHING>823345</fme:NORTHING>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:ENGLISHNAME>Lai King Estate</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823345.00000 831045.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc76d8aa6-9fc0-456c-bbcc-fe93df93473c">
<fme:FEATURE_ID>1001283869</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832995</fme:EASTING>
<fme:NORTHING>823392</fme:NORTHING>
<fme:ST_CODE>71194</fme:ST_CODE>
<fme:ENGLISHNAME>Shek Lei Pui Water Treatment Works</fme:ENGLISHNAME>
<fme:CHINESENAME>石梨貝濾水廠</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823391.99903 832995.00254 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idecc88a4c-9358-4612-b4d2-f740ad64bdd6">
<fme:FEATURE_ID>1001278585</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831570</fme:EASTING>
<fme:NORTHING>823432</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Ha Kwai Chung</fme:ENGLISHNAME>
<fme:CHINESENAME>下葵涌</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823431.99485 831569.99732 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id2f7fb73e-319c-4494-87f9-726e66f59b93">
<fme:FEATURE_ID>1001279876</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831864</fme:EASTING>
<fme:NORTHING>823439</fme:NORTHING>
<fme:ST_CODE>75165</fme:ST_CODE>
<fme:ENGLISHNAME>Wah Yuen Chuen</fme:ENGLISHNAME>
<fme:CHINESENAME>華員邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823439.00288 831863.99502 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id53817b44-403d-40ea-8b50-ba404a22522c">
<fme:FEATURE_ID>1001280849</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831483</fme:EASTING>
<fme:NORTHING>823464</fme:NORTHING>
<fme:ST_CODE>76697</fme:ST_CODE>
<fme:ENGLISHNAME>Highland Park</fme:ENGLISHNAME>
<fme:CHINESENAME>浩景臺</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823463.99607 831483.00291 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf345622a-2150-4b96-a9c3-a4fcc1b90474">
<fme:FEATURE_ID>1310012164</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833027</fme:EASTING>
<fme:NORTHING>823499</fme:NORTHING>
<fme:ST_CODE>82951</fme:ST_CODE>
<fme:ENGLISHNAME>Kowloon Reception Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>九龍接收水塘</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823499.00000 833027.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id55866206-0e44-4db6-b208-b87cb2c33932">
<fme:FEATURE_ID>1310012166</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833640</fme:EASTING>
<fme:NORTHING>823510</fme:NORTHING>
<fme:ST_CODE>82950</fme:ST_CODE>
<fme:ENGLISHNAME>Kowloon Byewash Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>九龍副水塘</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823510.00000 833640.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idbd9afe07-d12e-474a-a83f-ceaf4818b032">
<fme:FEATURE_ID>1001278597</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832636</fme:EASTING>
<fme:NORTHING>823527</fme:NORTHING>
<fme:ST_CODE>64119</fme:ST_CODE>
<fme:ENGLISHNAME>Shek Lei Tau</fme:ENGLISHNAME>
<fme:CHINESENAME>石梨頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823527.00189 832636.00341 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf2ed7ddb-8866-4098-af5d-00df7f18509e">
<fme:FEATURE_ID>1210002343</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831492.92</fme:EASTING>
<fme:NORTHING>823573.34</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Lai King Headland Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823573.34339 831492.92267 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id3de0aa49-a418-4177-aedb-041fba8340fb">
<fme:FEATURE_ID>1001278591</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832222</fme:EASTING>
<fme:NORTHING>823586</fme:NORTHING>
<fme:ST_CODE>75783</fme:ST_CODE>
<fme:ENGLISHNAME>Regency Park</fme:ENGLISHNAME>
<fme:CHINESENAME>海峰花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823585.99459 832221.99568 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc5cb6063-52be-48ec-aa9d-71098863e4ef">
<fme:FEATURE_ID>1001280924</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832451</fme:EASTING>
<fme:NORTHING>823626</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Cheung Hang Village</fme:ENGLISHNAME>
<fme:CHINESENAME>長坑村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823626.00267 832450.99761 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id7aaf580d-4aa4-4196-92ac-e5f683def3d9">
<fme:FEATURE_ID>1001283621</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830876</fme:EASTING>
<fme:NORTHING>823740</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Ever Gain Plaza</fme:ENGLISHNAME>
<fme:CHINESENAME>永得利廣場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823739.99552 830876.00162 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idbae9f91c-1e2c-4162-90f9-13c3fdafa44c">
<fme:FEATURE_ID>1310012225</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831555.17</fme:EASTING>
<fme:NORTHING>823761.38</fme:NORTHING>
<fme:ST_CODE>75169</fme:ST_CODE>
<fme:ENGLISHNAME>Lai Yiu Estate</fme:ENGLISHNAME>
<fme:CHINESENAME>麗瑤邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823761.37500 831555.16700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id2b3e8b0e-32c3-4541-8cab-27bcad347c74">
<fme:FEATURE_ID>1210005326</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830830</fme:EASTING>
<fme:NORTHING>823790</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Kwai Shun Industrial Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>葵順工業中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823790.00000 830830.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idff6c7205-b62b-4586-87a6-69e0242c071d">
<fme:FEATURE_ID>1001283796</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830781</fme:EASTING>
<fme:NORTHING>823814</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Golden Industrial Building</fme:ENGLISHNAME>
<fme:CHINESENAME>金德工業大廈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823814.00000 830781.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id88e8c5f0-bd60-46aa-b3ae-158d111a31ab">
<fme:FEATURE_ID>1001278590</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832050</fme:EASTING>
<fme:NORTHING>823868</fme:NORTHING>
<fme:ST_CODE>75167</fme:ST_CODE>
<fme:ENGLISHNAME>Wonderland Villas</fme:ENGLISHNAME>
<fme:CHINESENAME>華景山莊</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823868.00372 832049.99538 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id308c73a5-3243-4dac-a022-cef06cb787fd">
<fme:FEATURE_ID>1001283810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830718</fme:EASTING>
<fme:NORTHING>823945</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Kwai Chung Industrial Wastewater Pumping Station</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌工業污水泵房</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823945.00300 830717.99868 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
</gml:FeatureCollection>
