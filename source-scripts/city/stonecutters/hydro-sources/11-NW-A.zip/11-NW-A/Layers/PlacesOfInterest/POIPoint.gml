<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821029.03700 830070.61699 0.00000</gml:lowerCorner>
<gml:upperCorner>823992.41932 833740.10423 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPoint gml:id="ida00d819f-8060-42b1-aaae-cadc0ca208cf">
<fme:FEATURE_ID>1210033213</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832155.5</fme:EASTING>
<fme:NORTHING>821029.04</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821029.03700 832155.50275 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf87d21ec-e4df-44c7-a3bd-479567da0887">
<fme:FEATURE_ID>1210034707</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832919.57</fme:EASTING>
<fme:NORTHING>821032.17</fme:NORTHING>
<fme:ENGLISHNAME>Jetty</fme:ENGLISHNAME>
<fme:CHINESENAME>渡頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821032.17300 832919.56500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id77a31bec-784a-4108-ac4e-3e2039ebb368">
<fme:FEATURE_ID>1000985821</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833090.77</fme:EASTING>
<fme:NORTHING>821072.61</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821072.60614 833090.77383 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id22753e99-2688-4d26-95a4-13ea6349a964">
<fme:FEATURE_ID>1310060372</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833328.17</fme:EASTING>
<fme:NORTHING>821085.73</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821085.73207 833328.17014 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id234f5dfb-db10-445c-89ba-8bb844d72e8b">
<fme:FEATURE_ID>1310063271</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833651.93</fme:EASTING>
<fme:NORTHING>821098.96</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHA WAN (HOI TAT ESTATE) BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣(海達邨)總站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250327</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821098.96143 833651.92604 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5ac2ad8a-efbe-4247-aa55-a73b05236640">
<fme:FEATURE_ID>1210036012</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832031.06</fme:EASTING>
<fme:NORTHING>821132.45</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 8</fme:ENGLISHNAME>
<fme:CHINESENAME>八號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821132.44616 832031.06391 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id28f5f37f-c965-4fa0-8447-b7fe9acd25c2">
<fme:FEATURE_ID>1310063279</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833709</fme:EASTING>
<fme:NORTHING>821137</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Tat Public Transport Interchange</fme:ENGLISHNAME>
<fme:CHINESENAME>海達公共運輸交匯處</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241230</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821137.00000 833709.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7fb1a76c-049d-4957-94b8-cb27e6804fc2">
<fme:FEATURE_ID>1210033022</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831311.74</fme:EASTING>
<fme:NORTHING>821190.29</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821190.29114 831311.73617 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8f57ab65-fdd3-4a2d-ba59-ba2adbe512da">
<fme:FEATURE_ID>1310060358</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833392.92</fme:EASTING>
<fme:NORTHING>821254.36</fme:NORTHING>
<fme:ENGLISHNAME>Sham Shui Po Sports Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>深水埗體育館</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821254.36246 833392.91872 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id81564198-b63b-4b4e-aac4-56bea6bcb990">
<fme:FEATURE_ID>1310063052</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>LIB</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833412.78</fme:EASTING>
<fme:NORTHING>821254.79</fme:NORTHING>
<fme:ENGLISHNAME>Sham Shui Po Public Library</fme:ENGLISHNAME>
<fme:CHINESENAME>深水埗公共圖書館</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821254.78994 833412.77876 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id54237d9f-d458-425a-8a14-4ac3f1e5d449">
<fme:FEATURE_ID>1210033191</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831325.21</fme:EASTING>
<fme:NORTHING>821255.39</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821255.38827 831325.21114 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8ec9c8a0-e5da-4278-b96b-d4c1d165331c">
<fme:FEATURE_ID>1210033447</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833673.27</fme:EASTING>
<fme:NORTHING>821287.2</fme:NORTHING>
<fme:ENGLISHNAME>ST. MARGARET'S CO-EDUCATIONAL ENGLISH SECONDARY AND PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>聖瑪加利男女英文中小學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821287.19466 833673.26865 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3932e2f0-8986-49c7-ad87-aa8b0e56cf64">
<fme:FEATURE_ID>1210033386</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833258.37</fme:EASTING>
<fme:NORTHING>821288.35</fme:NORTHING>
<fme:ENGLISHNAME>S.K.H. ST. ANDREW'S PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>聖公會聖安德烈小學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821288.34645 833258.37170 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id52773736-7b4f-423b-bd2c-849bad02604b">
<fme:FEATURE_ID>1310052657</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833459</fme:EASTING>
<fme:NORTHING>821292</fme:NORTHING>
<fme:ENGLISHNAME>Sham Mong Road Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>深旺道遊樂場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821292.00000 833459.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide9f56d2d-90af-43fb-87d7-96054cd609a9">
<fme:FEATURE_ID>1210028724</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832657.6</fme:EASTING>
<fme:NORTHING>821305.4</fme:NORTHING>
<fme:ENGLISHNAME>Lai Wan Interchange Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔灣交匯變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821305.40384 832657.60036 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc179b877-322c-45ad-81ef-c90a9bd5f7b4">
<fme:FEATURE_ID>1000986062</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833705.66</fme:EASTING>
<fme:NORTHING>821307.17</fme:NORTHING>
<fme:ENGLISHNAME>ST. MARGARET'S CO-EDUCATIONAL ENGLISH SECONDARY AND PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>聖瑪加利男女英文中小學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821307.16529 833705.65593 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id56d9a528-1466-49c0-9867-3781f4aef031">
<fme:FEATURE_ID>1210033050</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831302.24</fme:EASTING>
<fme:NORTHING>821329.14</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821329.13862 831302.24185 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5c286efb-37a8-407c-b924-0798baa0df72">
<fme:FEATURE_ID>1210033193</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831096.61</fme:EASTING>
<fme:NORTHING>821338.6</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821338.59474 831096.60472 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8651ad94-67b3-48a3-872a-f001dcbd5a70">
<fme:FEATURE_ID>1000986071</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833291.11</fme:EASTING>
<fme:NORTHING>821354.38</fme:NORTHING>
<fme:ENGLISHNAME>S.K.H. ST. MARY'S CHURCH MOK HING YIU COLLEGE</fme:ENGLISHNAME>
<fme:CHINESENAME>聖公會聖馬利亞堂莫慶堯中學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821354.38284 833291.11010 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id619dafc8-18b7-4baf-a570-752284ec2d58">
<fme:FEATURE_ID>1000985852</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832602.78</fme:EASTING>
<fme:NORTHING>821366.9</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Traction Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角牽引配電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821366.89582 832602.78422 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5d4fe757-8638-4c10-99e5-18db68ac284b">
<fme:FEATURE_ID>1210034965</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831310</fme:EASTING>
<fme:NORTHING>821367</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 7</fme:ENGLISHNAME>
<fme:CHINESENAME>七號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821367.00000 831310.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd228badb-fdeb-4e54-a0ea-56dcd5bed9a2">
<fme:FEATURE_ID>1210034247</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833074.61</fme:EASTING>
<fme:NORTHING>821378.36</fme:NORTHING>
<fme:ENGLISHNAME>MARYKNOLL FATHERS' SCHOOL (PRIMARY SECTION)</fme:ENGLISHNAME>
<fme:CHINESENAME>瑪利諾神父教會學校（小學部）</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821378.35681 833074.60891 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id331ac356-bd83-4574-9bf0-a1e49219a97a">
<fme:FEATURE_ID>1000986069</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833461.7</fme:EASTING>
<fme:NORTHING>821439.07</fme:NORTHING>
<fme:ENGLISHNAME>TACK CHING GIRLS' SECONDARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>德貞女子中學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821439.06618 833461.70321 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idacfeca77-e446-49dd-83f3-07ffa4921c26">
<fme:FEATURE_ID>1210002282</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831858.29</fme:EASTING>
<fme:NORTHING>821441.48</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH (STT 3782)</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路 (STT 3782)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821441.48397 831858.28628 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb895874e-a0ed-47c8-a924-3f738bc95f7d">
<fme:FEATURE_ID>1000985733</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833238.94</fme:EASTING>
<fme:NORTHING>821452.03</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Lai Estate</fme:ENGLISHNAME>
<fme:CHINESENAME>海麗邨</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821452.03468 833238.94358 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2363fea8-be9f-40c1-a649-810ff33f62ec">
<fme:FEATURE_ID>1420001968</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833352.7</fme:EASTING>
<fme:NORTHING>821491.51</fme:NORTHING>
<fme:ENGLISHNAME>AEON Lai Chi Kok Store-Department store</fme:ENGLISHNAME>
<fme:CHINESENAME>AEON荔枝角店-綜合百貨</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821491.50690 833352.69925 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5ca72f28-5144-4799-838a-9cb302f42443">
<fme:FEATURE_ID>1000986070</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833544.1</fme:EASTING>
<fme:NORTHING>821506.15</fme:NORTHING>
<fme:ENGLISHNAME>TSUNG TSIN CHRISTIAN ACADEMY</fme:ENGLISHNAME>
<fme:CHINESENAME>基督教崇真中學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821506.15204 833544.10011 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida5c30571-76e1-4667-a829-f58461c89807">
<fme:FEATURE_ID>1000985947</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833168.09</fme:EASTING>
<fme:NORTHING>821508.83</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Lai Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>海麗商場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821508.83281 833168.08652 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idafc98636-c6c2-4b28-94be-f1f65ce69f04">
<fme:FEATURE_ID>1210041503</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833519</fme:EASTING>
<fme:NORTHING>821520</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821520.00000 833519.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb63cd424-2fef-45c6-af66-36519c4d7c28">
<fme:FEATURE_ID>1210032792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833484.71</fme:EASTING>
<fme:NORTHING>821523.66</fme:NORTHING>
<fme:ENGLISHNAME>Hing Wah Street West Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>興華街西遊樂場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821523.66117 833484.71296 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6e68d277-7996-4d22-af97-a8b5061b7ee7">
<fme:FEATURE_ID>1310064488</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833189</fme:EASTING>
<fme:NORTHING>821526</fme:NORTHING>
<fme:ENGLISHNAME>HOI LAI ESTATE BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>海麗邨巴士總站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240321</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821526.00000 833189.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7697d113-a330-4730-b771-c78abdf6720d">
<fme:FEATURE_ID>1210041380</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833511</fme:EASTING>
<fme:NORTHING>821536</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821536.00000 833511.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idaa003093-2525-469b-97de-da7c2fccb125">
<fme:FEATURE_ID>1210033194</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831628</fme:EASTING>
<fme:NORTHING>821536.84</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821536.83579 831628.00128 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6def915b-11af-4b83-881c-9aa94325f8ce">
<fme:FEATURE_ID>1210041504</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833534</fme:EASTING>
<fme:NORTHING>821561</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821561.00000 833534.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0d2bcfd9-2828-4c21-97f4-314e32488539">
<fme:FEATURE_ID>1210032131</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832558.23</fme:EASTING>
<fme:NORTHING>821561.94</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821561.93693 832558.22793 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8d1e1206-52cb-4f7d-a5fd-b2516e9589e1">
<fme:FEATURE_ID>1210033204</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831392.28</fme:EASTING>
<fme:NORTHING>821568.57</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821568.56572 831392.28136 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2e8200b9-6bd2-4674-a29a-f47e69a1bd6f">
<fme:FEATURE_ID>1000985849</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833116.16</fme:EASTING>
<fme:NORTHING>821579.4</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821579.39980 833116.15902 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id29f10c9e-8d39-4c2a-ac2f-9c5960e85eeb">
<fme:FEATURE_ID>1210033513</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833254.83</fme:EASTING>
<fme:NORTHING>821583.8</fme:NORTHING>
<fme:ENGLISHNAME>SHAM SHUI PO GOVERNMENT PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>深水埗官立小學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821583.79727 833254.82645 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3f73313d-7ca7-4523-a6cc-c331245a9905">
<fme:FEATURE_ID>1000985991</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832597.62</fme:EASTING>
<fme:NORTHING>821588.71</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821588.70572 832597.61985 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id03eef8d8-6493-4e97-9c78-f825a32261f7">
<fme:FEATURE_ID>1210033518</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833415.53</fme:EASTING>
<fme:NORTHING>821595.25</fme:NORTHING>
<fme:ENGLISHNAME>LAICHIKOK CATHOLIC PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角天主教小學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821595.25200 833415.53204 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id52317c5d-df67-40a8-bde9-404bad96b831">
<fme:FEATURE_ID>1000985846</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832684.32</fme:EASTING>
<fme:NORTHING>821598.35</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821598.34687 832684.32291 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id59c5eb1d-551c-4467-9848-92a959a7db01">
<fme:FEATURE_ID>1000985986</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832493.79</fme:EASTING>
<fme:NORTHING>821612.79</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821612.79234 832493.78792 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1f362d67-1098-4555-94ed-567694a2281f">
<fme:FEATURE_ID>1000985835</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831765.27</fme:EASTING>
<fme:NORTHING>821616.65</fme:NORTHING>
<fme:ENGLISHNAME>Container Port Road Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭路變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821616.64725 831765.27443 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcc5394d8-b3dc-4354-977c-8c4c9666d1a7">
<fme:FEATURE_ID>1210033020</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831008.46</fme:EASTING>
<fme:NORTHING>821619.98</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821619.97750 831008.45773 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ideab1b0e9-974c-4d43-abc0-78b242255d40">
<fme:FEATURE_ID>1210041196</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SEC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833012.39</fme:EASTING>
<fme:NORTHING>821620.74</fme:NORTHING>
<fme:ENGLISHNAME>THE CHURCH OF CHRIST IN CHINA, MONGKOK CHURCH KAI OI SCHOOL (SECONDARY SECTION)</fme:ENGLISHNAME>
<fme:CHINESENAME>中華基督教會望覺堂啟愛學校(中學部)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821620.74156 833012.39061 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5508a9ab-3b00-4d5e-8405-4bbb842a3af7">
<fme:FEATURE_ID>1000986029</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832501</fme:EASTING>
<fme:NORTHING>821629</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821636.55942 832503.63934 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idefe4ba83-38e8-42f0-8333-215f1c5d6697">
<fme:FEATURE_ID>1210041712</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833065.8</fme:EASTING>
<fme:NORTHING>821637.29</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821637.29161 833065.80437 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf0c1d421-04ab-4f8a-a8cc-b685809ff5b2">
<fme:FEATURE_ID>1000985772</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833193.34</fme:EASTING>
<fme:NORTHING>821650.86</fme:NORTHING>
<fme:ENGLISHNAME>Banyan Garden Public Lorry Car Park</fme:ENGLISHNAME>
<fme:CHINESENAME>泓景臺公眾貨車停車場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821650.85871 833193.33797 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6b148d88-b5f5-47d3-a2a4-97a61aec057a">
<fme:FEATURE_ID>1210015519</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832602.41</fme:EASTING>
<fme:NORTHING>821651</fme:NORTHING>
<fme:ENGLISHNAME>Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>遊樂場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821651.00223 832602.40600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc7b4a63f-ec15-4bc3-803a-6e48904853eb">
<fme:FEATURE_ID>1210015515</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832441.22</fme:EASTING>
<fme:NORTHING>821652.56</fme:NORTHING>
<fme:ENGLISHNAME>Square Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>方亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821652.56000 832441.22000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2c25d4c2-04e9-4e14-a88a-53b9fe185999">
<fme:FEATURE_ID>1210019569</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CMC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833317</fme:EASTING>
<fme:NORTHING>821661</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Community Hall</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角社區會堂</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821661.00000 833317.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4693e52d-ccb3-4d4e-badc-f49c760ebfd8">
<fme:FEATURE_ID>1210011940</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832786.3</fme:EASTING>
<fme:NORTHING>821668.92</fme:NORTHING>
<fme:ENGLISHNAME>PO LUN STREET (KX 3026)</fme:ENGLISHNAME>
<fme:CHINESENAME>寶輪街 (KX 3026)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821668.91457 832786.29583 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id79649e03-870a-4e15-9b95-cd62a0c19401">
<fme:FEATURE_ID>1000985850</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833032.32</fme:EASTING>
<fme:NORTHING>821681.48</fme:NORTHING>
<fme:ENGLISHNAME>Water Boat Dock P/STN Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>水船街泵房變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821681.48251 833032.31624 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5865cd9c-37e6-4d2a-a4c5-af176665cc63">
<fme:FEATURE_ID>1210015514</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832419.4</fme:EASTING>
<fme:NORTHING>821682.22</fme:NORTHING>
<fme:ENGLISHNAME>Stone Boat</fme:ENGLISHNAME>
<fme:CHINESENAME>船舫</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821682.22000 832419.40000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida4945210-1724-420e-b77f-2d67a8bed626">
<fme:FEATURE_ID>1000985960</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832335.67</fme:EASTING>
<fme:NORTHING>821684.95</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Park</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821684.94884 832335.66986 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id48ef4527-66fd-46e6-afd2-8925c3d6dde9">
<fme:FEATURE_ID>1000985773</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833410.93</fme:EASTING>
<fme:NORTHING>821698.08</fme:NORTHING>
<fme:ENGLISHNAME>LIBERTE</fme:ENGLISHNAME>
<fme:CHINESENAME>昇悅居</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821698.08218 833410.92456 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6094e263-2ace-4d3f-b048-53744a8eec2c">
<fme:FEATURE_ID>1210015512</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832366.31</fme:EASTING>
<fme:NORTHING>821701.45</fme:NORTHING>
<fme:ENGLISHNAME>South Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>南門</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821701.45000 832366.31000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide7870094-aa71-42ef-bfd9-e2305f7e95bf">
<fme:FEATURE_ID>1000985989</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832463.27</fme:EASTING>
<fme:NORTHING>821710.08</fme:NORTHING>
<fme:ENGLISHNAME>Hexagonal Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>六角亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821710.07848 832463.27336 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id81960a74-e8c4-44d9-a016-2c07875d4cda">
<fme:FEATURE_ID>1000985990</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832340.36</fme:EASTING>
<fme:NORTHING>821715.41</fme:NORTHING>
<fme:ENGLISHNAME>Chess Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>奕亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821715.40701 832340.36202 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf7458592-5b50-4315-9c72-7304872cb761">
<fme:FEATURE_ID>1000985899</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833104.75</fme:EASTING>
<fme:NORTHING>821718.79</fme:NORTHING>
<fme:ENGLISHNAME>Sham Mong Road Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>深旺道變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821718.78758 833104.75139 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc91f264e-be66-4721-a1c0-53fcb75838f6">
<fme:FEATURE_ID>1210019781</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833342.68</fme:EASTING>
<fme:NORTHING>821721.32</fme:NORTHING>
<fme:ENGLISHNAME>Liberte Place</fme:ENGLISHNAME>
<fme:CHINESENAME>昇悅商場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821721.32086 833342.67901 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida9bccf2e-e6a4-4de5-9a1d-4235d696619e">
<fme:FEATURE_ID>1210015508</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832409.05</fme:EASTING>
<fme:NORTHING>821721.62</fme:NORTHING>
<fme:ENGLISHNAME>Water Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>水榭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821721.62000 832409.05000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide02553b9-6231-4247-a944-b0fdae2bec8b">
<fme:FEATURE_ID>1000986095</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832200.84</fme:EASTING>
<fme:NORTHING>821722.95</fme:NORTHING>
<fme:ENGLISHNAME>Gatetball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>門球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821722.94711 832200.83977 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1b5e1273-238e-4088-927e-0a1e16f28e3d">
<fme:FEATURE_ID>1310063346</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>LPG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833071</fme:EASTING>
<fme:NORTHING>821723.06</fme:NORTHING>
<fme:ENGLISHNAME>Sinopec Liquefied Petroleum Gas Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>中國石化 加氣站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230925</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821723.05700 833070.99700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0d6f0205-495b-4296-8172-166b63be8010">
<fme:FEATURE_ID>1210015509</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832365.33</fme:EASTING>
<fme:NORTHING>821724.26</fme:NORTHING>
<fme:ENGLISHNAME>Rock Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>石亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821724.26000 832365.33000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idef9a2af4-b2c5-4b04-b181-5d92e40bbe71">
<fme:FEATURE_ID>1210015252</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833626.12</fme:EASTING>
<fme:NORTHING>821727.74</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Temporary Wholesale Poultry Market (No.4 Hing Wah Street)</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣臨時家禽批發市場(興華街4號)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821727.73482 833626.11810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3247760f-4f1d-4074-9921-47a75d08f24c">
<fme:FEATURE_ID>1210034966</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831178</fme:EASTING>
<fme:NORTHING>821738</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 6</fme:ENGLISHNAME>
<fme:CHINESENAME>六號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821738.00000 831178.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6321a867-541c-4780-9c43-c1b1c6280c1d">
<fme:FEATURE_ID>1000985902</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833142.5</fme:EASTING>
<fme:NORTHING>821740.38</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Rd 875 Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角道875號電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821740.37588 833142.49910 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8e086024-2d00-426c-b3e9-677e8e990bd5">
<fme:FEATURE_ID>1000985948</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833251.62</fme:EASTING>
<fme:NORTHING>821742.2</fme:NORTHING>
<fme:ENGLISHNAME>Banyan Mall</fme:ENGLISHNAME>
<fme:CHINESENAME>泓景滙商場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821742.20120 833251.62183 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb6c6361c-a5da-4815-ad39-c3aff737eff6">
<fme:FEATURE_ID>1000986086</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832310.31</fme:EASTING>
<fme:NORTHING>821755.97</fme:NORTHING>
<fme:ENGLISHNAME>Grass Gateball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>草地門球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821755.97079 832310.30658 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id39725b86-e04b-4352-8036-8ebbeb28a44a">
<fme:FEATURE_ID>1000986090</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832107.68</fme:EASTING>
<fme:NORTHING>821758.6</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821758.59873 832107.67734 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc42341f6-2d5f-439b-94e6-84a821846a75">
<fme:FEATURE_ID>1210013882</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832718</fme:EASTING>
<fme:NORTHING>821778</fme:NORTHING>
<fme:ENGLISHNAME>Manhattan Mid-Town</fme:ENGLISHNAME>
<fme:CHINESENAME>曼坊</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821758.66422 832706.19500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcc3334f0-bb79-4ac3-8826-952dd3268db9">
<fme:FEATURE_ID>1000985985</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832277.19</fme:EASTING>
<fme:NORTHING>821759.26</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821759.25802 832277.19361 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idff278612-e52c-4f29-9e6c-933b1f8a87df">
<fme:FEATURE_ID>1000985978</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832380.31</fme:EASTING>
<fme:NORTHING>821765.48</fme:NORTHING>
<fme:ENGLISHNAME>North Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚門</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821765.47818 832380.31112 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7106a2ed-76b0-46c3-9163-17669abf15fd">
<fme:FEATURE_ID>1210033550</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832553.22</fme:EASTING>
<fme:NORTHING>821770.23</fme:NORTHING>
<fme:ENGLISHNAME>DELIA ENGLISH PRIMARY SCHOOL &amp; KINDERGARTEN</fme:ENGLISHNAME>
<fme:CHINESENAME>地利亞英文小學暨幼稚園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821770.23313 832553.22234 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id754783e9-e845-45dc-af8e-bbeb919f4249">
<fme:FEATURE_ID>1210033195</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830956.08</fme:EASTING>
<fme:NORTHING>821775.36</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821775.35563 830956.07462 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb6cc382a-4eb9-44ce-bbf5-2fc2cab242a2">
<fme:FEATURE_ID>1210015882</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832267.07</fme:EASTING>
<fme:NORTHING>821782.61</fme:NORTHING>
<fme:ENGLISHNAME>Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>遊樂場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821782.60563 832267.07042 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc710478e-985b-46cf-ae20-e25f4a938c20">
<fme:FEATURE_ID>1210013107</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833449.69</fme:EASTING>
<fme:NORTHING>821782.9</fme:NORTHING>
<fme:ENGLISHNAME>The Pacifica Mall</fme:ENGLISHNAME>
<fme:CHINESENAME>宇晴滙</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821782.89485 833449.68562 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5610dec1-7840-41be-be76-905356950415">
<fme:FEATURE_ID>1000986027</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833678.51</fme:EASTING>
<fme:NORTHING>821783.76</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Temporary Wholesale Poultry Market Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣臨時家禽批發市場廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821783.76087 833678.50729 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1ea76be4-9fe7-405d-b84c-f19763cad6cf">
<fme:FEATURE_ID>1000985996</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832669.32</fme:EASTING>
<fme:NORTHING>821800.02</fme:NORTHING>
<fme:ENGLISHNAME>Esso-Broadway Street Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>埃索-百老匯街加油站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821800.02400 832669.32426 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide6070f85-53dd-4e5a-954b-17baf245fdbd">
<fme:FEATURE_ID>1000985866</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833543.04</fme:EASTING>
<fme:NORTHING>821806.37</fme:NORTHING>
<fme:ENGLISHNAME>Temp Poultry Market Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>臨時家禽批發市場變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821806.37427 833543.03972 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida497d919-8324-43ec-ba23-b6c3d58a8abb">
<fme:FEATURE_ID>1000986091</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832046.07</fme:EASTING>
<fme:NORTHING>821820.79</fme:NORTHING>
<fme:ENGLISHNAME>7-a-side Hard-surfaced Soccer Pitch</fme:ENGLISHNAME>
<fme:CHINESENAME>7人硬地足球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821820.78862 832046.06869 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idca8925a6-db0e-424b-97cf-d6052d21ea39">
<fme:FEATURE_ID>1210009068</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833423.47</fme:EASTING>
<fme:NORTHING>821826.25</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai Chi Kok Station-D4 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔枝角站-D4進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821826.24652 833423.47407 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbcb7f8c7-7673-402d-a9e4-da691cee5871">
<fme:FEATURE_ID>1000985933</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833575.09</fme:EASTING>
<fme:NORTHING>821826.9</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Temporary Wholesale Poultry Market (No.1 Hing Wah Street)</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣臨時家禽批發市場(興華街1號)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821826.89713 833575.08827 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2b98bb9c-35b3-429e-b0ee-a479aee33e83">
<fme:FEATURE_ID>1000986038</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833627.11</fme:EASTING>
<fme:NORTHING>821828.69</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Temporary Wholesale Poultry Market Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣臨時家禽批發市場廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821828.68649 833627.10783 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide7ca59d8-2ea1-47fd-97d6-c658a9f28d43">
<fme:FEATURE_ID>1310063295</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TEI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833079</fme:EASTING>
<fme:NORTHING>821829</fme:NORTHING>
<fme:ENGLISHNAME>HKU SPACE Community College (Kowloon West Campus)</fme:ENGLISHNAME>
<fme:CHINESENAME>香港大學附屬學院 (九龍西分校)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230925</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821829.00000 833079.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="iddf9447b3-69c0-4e31-8f2f-12c9cde99f6c">
<fme:FEATURE_ID>1210033035</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831125.33</fme:EASTING>
<fme:NORTHING>821831.88</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821831.88290 831125.33115 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd323387a-7a6f-4d93-8b4b-90b47b44d17c">
<fme:FEATURE_ID>1310062018</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831794.7</fme:EASTING>
<fme:NORTHING>821835.76</fme:NORTHING>
<fme:ENGLISHNAME>CHING CHEUNG ROAD (STT 3713)</fme:ENGLISHNAME>
<fme:CHINESENAME>呈祥道 (STT 3713)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821835.75600 831794.70300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id38245252-d4b3-4d1a-aaf6-83b4003821d5">
<fme:FEATURE_ID>1000986068</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832541.03</fme:EASTING>
<fme:NORTHING>821836.22</fme:NORTHING>
<fme:ENGLISHNAME>DELIA MEMORIAL SCHOOL (BROADWAY )</fme:ENGLISHNAME>
<fme:CHINESENAME>地利亞修女紀念學校﹝百老匯﹞</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821836.22424 832541.02556 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id85a1bfd9-dbaf-4373-8862-f079a532422e">
<fme:FEATURE_ID>1000986012</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833130.02</fme:EASTING>
<fme:NORTHING>821842.91</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHA WAN POLICE STATION</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣警署</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821842.90637 833130.01936 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id180a9b45-91fd-4e61-bd77-d8d488855e7c">
<fme:FEATURE_ID>1210033198</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831581.08</fme:EASTING>
<fme:NORTHING>821852.59</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821852.59206 831581.08403 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide33c60e7-d8da-4eee-841e-5a4dd95ed692">
<fme:FEATURE_ID>1000986075</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833669.17</fme:EASTING>
<fme:NORTHING>821879.27</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821879.26473 833669.17211 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf3503e1a-9f44-49fb-948c-80169c6aa773">
<fme:FEATURE_ID>1210031915</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832590</fme:EASTING>
<fme:NORTHING>821880</fme:NORTHING>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Stage IV Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨四期商場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821880.00000 832590.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0b941997-362f-4639-9045-cb1de6387783">
<fme:FEATURE_ID>1000986039</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832059.89</fme:EASTING>
<fme:NORTHING>821884.46</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821884.46212 832059.88899 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ideb2bc5dd-3689-4bf4-8455-6e77c83e653d">
<fme:FEATURE_ID>1000986040</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833079.6</fme:EASTING>
<fme:NORTHING>821886.61</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Shun Street Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長順街公廁</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821886.60844 833079.60432 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id741fedb4-0ee6-4667-ae4d-47e0dadcb876">
<fme:FEATURE_ID>1000985853</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832795.4</fme:EASTING>
<fme:NORTHING>821888.04</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Junction Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角聯合變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821888.03676 832795.40320 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id86c1ebd2-3bf1-4973-8195-a2b82f91fc53">
<fme:FEATURE_ID>1210037658</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833376</fme:EASTING>
<fme:NORTHING>821898</fme:NORTHING>
<fme:ENGLISHNAME>D2 Place ONE</fme:ENGLISHNAME>
<fme:CHINESENAME>D2 Place 一期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821898.00000 833376.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id615e2c04-5e4f-4286-9dc9-06b4a29f1cf2">
<fme:FEATURE_ID>1000986014</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833721.49</fme:EASTING>
<fme:NORTHING>821898.64</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821898.63841 833721.48581 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id06419d95-278c-4d29-9773-4230367e4b17">
<fme:FEATURE_ID>1210037657</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833243.93</fme:EASTING>
<fme:NORTHING>821903.85</fme:NORTHING>
<fme:ENGLISHNAME>D2 Place TWO</fme:ENGLISHNAME>
<fme:CHINESENAME>D2 Place 二期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821903.84961 833243.93316 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4884de11-d512-4ebc-9253-821ecdf370df">
<fme:FEATURE_ID>1000986003</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833075.94</fme:EASTING>
<fme:NORTHING>821904.36</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Road / Cheung Shun Street Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣道/長順街遊樂場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821904.35779 833075.93486 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide0ec8ccb-a4cc-4a20-b4aa-9b4b4488b1a6">
<fme:FEATURE_ID>1000985908</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832798.62</fme:EASTING>
<fme:NORTHING>821905.83</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Fire Station</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角消防局</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821905.83331 832798.62199 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8f6f1784-3b25-4ad9-8aee-7218cd05a2ad">
<fme:FEATURE_ID>1210008906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833321.85</fme:EASTING>
<fme:NORTHING>821906.73</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai Chi Kok Station-D2 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔枝角站-D2進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821906.72766 833321.84514 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ideb188d3b-36a6-4bfb-a856-0ef2aca827c9">
<fme:FEATURE_ID>1210028104</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833410.18</fme:EASTING>
<fme:NORTHING>821910.29</fme:NORTHING>
<fme:ENGLISHNAME>D2 Place one</fme:ENGLISHNAME>
<fme:CHINESENAME>D2 Place one</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240321</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821910.28752 833410.18135 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id41e5fc13-c438-49f0-a484-5c4b0dceb189">
<fme:FEATURE_ID>1210041364</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TNC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833263.23</fme:EASTING>
<fme:NORTHING>821912.72</fme:NORTHING>
<fme:ENGLISHNAME>D2 Place Cinema</fme:ENGLISHNAME>
<fme:CHINESENAME>D2 Place 戲院</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20231211</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821912.71851 833263.23265 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4b95b691-ba14-4d9b-a4b8-4f4c9e418c26">
<fme:FEATURE_ID>1000985879</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833567.68</fme:EASTING>
<fme:NORTHING>821917.98</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Road Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角道８００號變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821917.98398 833567.68089 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id84fa2831-939e-4898-9b14-7afe6d172569">
<fme:FEATURE_ID>1210028729</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833481.63</fme:EASTING>
<fme:NORTHING>821924.58</fme:NORTHING>
<fme:ENGLISHNAME>PetroChina-Lai Chi Kok Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>中國石油-荔枝角加油站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821924.58098 833481.63239 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id59852dd8-ecdf-40f3-a264-8ec1e81c1a72">
<fme:FEATURE_ID>1000986092</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832081.52</fme:EASTING>
<fme:NORTHING>821925.41</fme:NORTHING>
<fme:ENGLISHNAME>Tennis Court</fme:ENGLISHNAME>
<fme:CHINESENAME>網球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821925.40711 832081.52272 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf29cd71a-2e07-45c5-8399-3962fa6c9e38">
<fme:FEATURE_ID>1000986080</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833622.34</fme:EASTING>
<fme:NORTHING>821927.7</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821927.69539 833622.34108 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbaa91dd2-1aec-40b0-b5ba-8f1de67dbeb9">
<fme:FEATURE_ID>1210008754</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833314.36</fme:EASTING>
<fme:NORTHING>821927.74</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai Chi Kok Station-D1 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔枝角站-D1進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821927.74292 833314.36003 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4da6fa44-d8b6-4f38-a955-2946459b6fdd">
<fme:FEATURE_ID>1000985880</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832045.39</fme:EASTING>
<fme:NORTHING>821934.67</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821934.66926 832045.38606 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6da4053b-8710-47ab-b886-36e50b25b5bf">
<fme:FEATURE_ID>1000986030</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832249</fme:EASTING>
<fme:NORTHING>821939</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821943.04469 832241.41353 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id246b927b-0589-4618-8cb7-38056baa5141">
<fme:FEATURE_ID>1000986077</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833679.77</fme:EASTING>
<fme:NORTHING>821953.35</fme:NORTHING>
<fme:ENGLISHNAME>Sham Shui Po Sports Ground</fme:ENGLISHNAME>
<fme:CHINESENAME>深水埗運動場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821953.34892 833679.76608 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc3ded75b-e2bb-4dcf-babd-a59fd1463f19">
<fme:FEATURE_ID>1210008950</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832501.91</fme:EASTING>
<fme:NORTHING>821955.02</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Mei Foo Station-A Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路美孚站-A進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821955.02089 832501.90553 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id539338e1-9651-41ea-a468-874b309124b4">
<fme:FEATURE_ID>1210034623</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831662.55</fme:EASTING>
<fme:NORTHING>821957.97</fme:NORTHING>
<fme:ENGLISHNAME>TAT YEUNG ROAD (STT 3754)</fme:ENGLISHNAME>
<fme:CHINESENAME>達洋路 (STT 3754)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821957.97066 831662.54514 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf61a1aab-0199-495e-af34-f566b7ccb6a7">
<fme:FEATURE_ID>1210014791</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833554.78</fme:EASTING>
<fme:NORTHING>821960.14</fme:NORTHING>
<fme:ENGLISHNAME>BILLION PLAZA</fme:ENGLISHNAME>
<fme:CHINESENAME>億京廣場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821960.14227 833554.77464 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb71c2042-7a4b-43f8-ae26-c4332f7cd84c">
<fme:FEATURE_ID>1000985861</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831918.11</fme:EASTING>
<fme:NORTHING>821969.8</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821969.80472 831918.11024 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd7c75ddc-714d-4a32-8b29-6e5167e410b2">
<fme:FEATURE_ID>1310057508</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832534</fme:EASTING>
<fme:NORTHING>821977</fme:NORTHING>
<fme:ENGLISHNAME>MEI LAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>美荔道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821977.00000 832534.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8ed95509-9caa-461f-877f-3b4351e4eaab">
<fme:FEATURE_ID>1000985881</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832094.93</fme:EASTING>
<fme:NORTHING>821980.07</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821980.07201 832094.93026 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida984547d-1cfd-4657-8842-5745c38dd103">
<fme:FEATURE_ID>1210034489</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831705</fme:EASTING>
<fme:NORTHING>821984</fme:NORTHING>
<fme:ENGLISHNAME>TAT YEUNG ROAD (STT 3744)</fme:ENGLISHNAME>
<fme:CHINESENAME>達洋路 (STT 3744)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821983.99900 831705.00300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idfa181060-36f1-4b95-8ff9-f51bcda0b0aa">
<fme:FEATURE_ID>1210008795</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833169.92</fme:EASTING>
<fme:NORTHING>821992.03</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai Chi Kok Station-C Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔枝角站-C進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821992.02660 833169.91766 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf9054517-88f3-490c-9905-06769535d42e">
<fme:FEATURE_ID>1310057453</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832539.26</fme:EASTING>
<fme:NORTHING>821998.6</fme:NORTHING>
<fme:ENGLISHNAME>MEI LAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>美荔道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821998.59912 832539.25550 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5617a3cc-d0ee-4c88-97cf-5d03c642bcbd">
<fme:FEATURE_ID>1210011339</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832991</fme:EASTING>
<fme:NORTHING>821999</fme:NORTHING>
<fme:ENGLISHNAME>KOM TSUN STREET BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>甘泉街巴士總站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821999.00000 832991.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc17d8d54-ea13-4c06-9c51-59fc543dc679">
<fme:FEATURE_ID>1000985834</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833611.96</fme:EASTING>
<fme:NORTHING>822006.57</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Sport Grd Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣運動場變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822006.56830 833611.96084 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id79180a47-008b-46bc-b218-be54a503aee1">
<fme:FEATURE_ID>1210033197</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831567.85</fme:EASTING>
<fme:NORTHING>822012.79</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822012.78786 831567.84931 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id697df9eb-8b2e-473e-844d-2d218c365b58">
<fme:FEATURE_ID>1000985729</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833364.26</fme:EASTING>
<fme:NORTHING>822017.5</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG SHA WAN BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣巴士總站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822017.49983 833364.25764 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="iddac55ad8-0c98-40c4-ba15-a29ce09cdfcf">
<fme:FEATURE_ID>1000985959</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832667.85</fme:EASTING>
<fme:NORTHING>822020.43</fme:NORTHING>
<fme:ENGLISHNAME>Castle Peak Road Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>青山道休憩處</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822020.43409 832667.85205 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id80a3a696-6615-45f4-8da2-c6a8fdff39bf">
<fme:FEATURE_ID>1000985941</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833394.72</fme:EASTING>
<fme:NORTHING>822023.42</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Plaza</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣廣場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822023.42293 833394.72154 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id04eda9d3-7bed-47c3-a2aa-b602ad31c762">
<fme:FEATURE_ID>1000986026</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832457.21</fme:EASTING>
<fme:NORTHING>822023.81</fme:NORTHING>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Bus Terminus Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨巴士總站公廁</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822023.80571 832457.20821 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida5b75d43-11f9-4387-bc48-719a88ab256b">
<fme:FEATURE_ID>1210038398</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833565.74</fme:EASTING>
<fme:NORTHING>822024.06</fme:NORTHING>
<fme:ENGLISHNAME>Billion Plaza 2</fme:ENGLISHNAME>
<fme:CHINESENAME>億京廣場二期</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822024.05526 833565.73523 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id825ca028-63e9-4b8b-a277-07f110c0a48d">
<fme:FEATURE_ID>1000985732</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832486.62</fme:EASTING>
<fme:NORTHING>822028.88</fme:NORTHING>
<fme:ENGLISHNAME>MEI FOO BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚巴士總站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822028.87968 832486.61878 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd119ad2e-637f-41d9-956d-1c9f0a6f65b6">
<fme:FEATURE_ID>1000985796</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831810.24</fme:EASTING>
<fme:NORTHING>822031.69</fme:NORTHING>
<fme:ENGLISHNAME>TAT YEUNG ROAD (KX 2839)</fme:ENGLISHNAME>
<fme:CHINESENAME>達洋路 (KX 2839)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822031.68864 831810.24040 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id30b589e5-ab7e-4d46-90a7-1732e5ec38e9">
<fme:FEATURE_ID>1210014229</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833420.06</fme:EASTING>
<fme:NORTHING>822031.71</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Plaza</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣廣場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822031.70943 833420.05576 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide1895e0a-c819-49af-af59-68a6674e12d3">
<fme:FEATURE_ID>1420002646</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831971.67</fme:EASTING>
<fme:NORTHING>822032.29</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>中國石化石油氣葵青石油氣瓶裝車停車場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822032.29085 831971.67208 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idce3730fd-a48a-4c1a-be5b-bb9e7bcc49c6">
<fme:FEATURE_ID>1000985999</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833123.29</fme:EASTING>
<fme:NORTHING>822036.19</fme:NORTHING>
<fme:ENGLISHNAME>Shell-Tung Chau Street Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>蜆殼-通州街加油站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822036.19292 833123.28819 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id18e91b71-ca4b-4cdd-8a2d-0f2cb78ab183">
<fme:FEATURE_ID>1210008486</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833386.27</fme:EASTING>
<fme:NORTHING>822036.81</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai Chi Kok Station-A Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔枝角站-A進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822036.80630 833386.27311 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id280967b3-f3bb-4b5d-ad06-ffff3501460e">
<fme:FEATURE_ID>1310052661</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833301</fme:EASTING>
<fme:NORTHING>822044</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI KOK STATION</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822044.00000 833301.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9e3da506-97fd-4a1a-aef6-9a67a9c11e23">
<fme:FEATURE_ID>1000985818</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832575.2</fme:EASTING>
<fme:NORTHING>822047.5</fme:NORTHING>
<fme:ENGLISHNAME>Mei Lai Road Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>美荔道電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822047.49896 832575.19581 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id11e91612-7501-4ee9-aa83-a90404a11cec">
<fme:FEATURE_ID>1210029186</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833331.97</fme:EASTING>
<fme:NORTHING>822052.97</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai Chi Kok Station-B2 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔枝角站-B2進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822052.97064 833331.97064 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd06a518b-c081-496b-987f-d3b407e9ae94">
<fme:FEATURE_ID>1310063286</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832912.3</fme:EASTING>
<fme:NORTHING>822056.65</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230925</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822056.65300 832912.30300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9853f555-44c7-412d-818d-035fba6c1669">
<fme:FEATURE_ID>1210003822</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CSC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832609.07</fme:EASTING>
<fme:NORTHING>822057.24</fme:NORTHING>
<fme:ENGLISHNAME>Mei Foo Government Complex</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚政府綜合大樓</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822057.23479 832609.06742 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbb6ee448-2498-4362-ad44-e4abf1aae946">
<fme:FEATURE_ID>1000985965</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833615.65</fme:EASTING>
<fme:NORTHING>822066.41</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822066.41346 833615.64898 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id20f35055-8636-4141-9b4d-1250395bdede">
<fme:FEATURE_ID>1210020149</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CSD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832847</fme:EASTING>
<fme:NORTHING>822069</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Reception Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角收押所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822069.00000 832847.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida7e67bc8-effe-4395-aae6-0846cce8990f">
<fme:FEATURE_ID>1210008638</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832448.89</fme:EASTING>
<fme:NORTHING>822070.76</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Mei Foo Station-B Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路美孚站-B進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822070.75536 832448.88969 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida4902cee-983a-407d-ac16-0b8cb737e7ad">
<fme:FEATURE_ID>1210008875</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833401.92</fme:EASTING>
<fme:NORTHING>822077.64</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai Chi Kok Station-B1 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔枝角站-B1進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822077.63577 833401.91710 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id35863c0a-bb92-406e-82aa-defbd6846a60">
<fme:FEATURE_ID>1000985952</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833626.18</fme:EASTING>
<fme:NORTHING>822080.12</fme:NORTHING>
<fme:ENGLISHNAME>Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>花園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822080.11908 833626.17993 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id293307c0-cceb-4d3f-9493-94eee9d25e8f">
<fme:FEATURE_ID>1210031820</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832362.69</fme:EASTING>
<fme:NORTHING>822083.86</fme:NORTHING>
<fme:ENGLISHNAME>Mount Sterling Mall Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>萬事達廣場購物中心</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250916</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822083.85646 832362.68769 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0c5484e9-de97-4996-af1f-e717810b0214">
<fme:FEATURE_ID>1000985905</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832594.09</fme:EASTING>
<fme:NORTHING>822088.02</fme:NORTHING>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822088.02312 832594.09270 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1c3308d9-27f9-4f15-8ef0-b903db358071">
<fme:FEATURE_ID>1210009040</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832231.64</fme:EASTING>
<fme:NORTHING>822097.1</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Mei Foo Station-D Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路美孚站-D進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822097.09547 832231.64211 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc05d669e-a0d2-4dd7-b061-3ba6cd00b2cc">
<fme:FEATURE_ID>1000985761</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831604.72</fme:EASTING>
<fme:NORTHING>822104.87</fme:NORTHING>
<fme:ENGLISHNAME>TAT YEUNG ROAD (STT 3727)</fme:ENGLISHNAME>
<fme:CHINESENAME>達洋路 (STT 3727)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822104.86812 831604.72099 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd404f877-52be-4163-8452-b50ba2af648e">
<fme:FEATURE_ID>1210021104</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832684</fme:EASTING>
<fme:NORTHING>822109</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822106.38555 832691.65661 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3dfe1edf-f9b8-4cf5-9d51-891648dea93d">
<fme:FEATURE_ID>1210011950</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832351.44</fme:EASTING>
<fme:NORTHING>822107.21</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角花園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822107.21022 832351.44067 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3f08ad47-17e7-4da6-92c9-8835c3bbd6af">
<fme:FEATURE_ID>1210022070</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ART</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832720.21</fme:EASTING>
<fme:NORTHING>822109.99</fme:NORTHING>
<fme:ENGLISHNAME>Jao Tsung-I Academy</fme:ENGLISHNAME>
<fme:CHINESENAME>饒宗頤文化館</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822109.99241 832720.20755 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0bfe1125-47b9-4e54-8688-ee0a29f8b9dd">
<fme:FEATURE_ID>1000986010</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POF</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832228.88</fme:EASTING>
<fme:NORTHING>822115.25</fme:NORTHING>
<fme:ENGLISHNAME>Mei Foo Sun Chuen Post Office</fme:ENGLISHNAME>
<fme:CHINESENAME>美孚新邨郵政局</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822115.24955 832228.87465 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id72ed9491-153e-4887-ba31-172f50ceea33">
<fme:FEATURE_ID>1210008716</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832342.92</fme:EASTING>
<fme:NORTHING>822123.33</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Mei Foo Station-C2 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路美孚站-C2進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822123.33192 832342.91515 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id46d39415-50a1-44e4-9664-8b0c4c8213f2">
<fme:FEATURE_ID>1210016815</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833624.27</fme:EASTING>
<fme:NORTHING>822124.91</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Path Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣徑休憩處</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822124.90874 833624.26478 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf341a7dd-66e1-4dd8-a424-2070dc788b8b">
<fme:FEATURE_ID>1000985857</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832986.42</fme:EASTING>
<fme:NORTHING>822126.92</fme:NORTHING>
<fme:ENGLISHNAME>Link Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>瓊林街變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822126.92034 832986.42242 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id019b08d4-f43e-47ac-8fb2-53b31c78d5aa">
<fme:FEATURE_ID>1210020397</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832326</fme:EASTING>
<fme:NORTHING>822130</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Mei Foo Station-E Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路美孚站-E進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822130.00000 832326.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id30358a77-0c10-40d5-908c-9bfc63c17922">
<fme:FEATURE_ID>1420000802</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832521.97</fme:EASTING>
<fme:NORTHING>822140.1</fme:NORTHING>
<fme:ENGLISHNAME>Esso-ESSO NASSAU STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>Esso-ESSO 蘭秀道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822140.10397 832521.97070 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3f6ff5ac-61b8-479e-bae5-16cf4fd5df30">
<fme:FEATURE_ID>1000985788</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833186.26</fme:EASTING>
<fme:NORTHING>822141.44</fme:NORTHING>
<fme:ENGLISHNAME>Trendy Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>潮流工貿中心</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822141.43502 833186.26139 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id22cb53b9-8416-4644-a270-2476f7eff82b">
<fme:FEATURE_ID>1000985767</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831713.24</fme:EASTING>
<fme:NORTHING>822144.13</fme:NORTHING>
<fme:ENGLISHNAME>TAT YEUNG ROAD (STT 3756)</fme:ENGLISHNAME>
<fme:CHINESENAME>達洋路 (STT 3756)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822144.13373 831713.23478 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id461045fc-aeb8-4c3d-b1be-7776c6ac2a15">
<fme:FEATURE_ID>1000985863</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833383.98</fme:EASTING>
<fme:NORTHING>822146.78</fme:NORTHING>
<fme:ENGLISHNAME>Tai Nan West Street Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>大南西街電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822146.77841 833383.97695 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1a17b292-1567-475f-a730-05c19baf5bf4">
<fme:FEATURE_ID>1210008728</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832297.36</fme:EASTING>
<fme:NORTHING>822147.41</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Mei Foo Station-C1 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路美孚站-C1進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822147.41137 832297.36103 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id77b90e55-d027-4e63-b723-1d2ba551a7ee">
<fme:FEATURE_ID>1000985984</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832207.14</fme:EASTING>
<fme:NORTHING>822150.52</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822150.52431 832207.13937 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id431d55ef-fc67-4c6e-8a68-d77af6e72a9a">
<fme:FEATURE_ID>1000985747</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833447.93</fme:EASTING>
<fme:NORTHING>822153.66</fme:NORTHING>
<fme:ENGLISHNAME>Kowloon Plaza</fme:ENGLISHNAME>
<fme:CHINESENAME>九龍廣場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822153.66388 833447.92931 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id19d943a0-e1b5-4ce6-b022-2f91522cab76">
<fme:FEATURE_ID>1000985798</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833515.14</fme:EASTING>
<fme:NORTHING>822157.56</fme:NORTHING>
<fme:ENGLISHNAME>Clifford Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>香港中心</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822157.55472 833515.13906 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcd2cfb95-aa79-433a-87b8-da725ee04307">
<fme:FEATURE_ID>1000986028</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832172.15</fme:EASTING>
<fme:NORTHING>822166.65</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822166.64498 832172.14812 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idefd6420b-d17a-48b7-962d-15306523af23">
<fme:FEATURE_ID>1000986031</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832690</fme:EASTING>
<fme:NORTHING>822173</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822167.94783 832686.05540 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id39559567-f76e-42f1-88be-9d0f0e11ab69">
<fme:FEATURE_ID>1210008478</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832132.02</fme:EASTING>
<fme:NORTHING>822181.63</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Mei Foo Station-F Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路美孚站-F進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822181.62927 832132.01620 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd1508568-28a2-4648-9018-1d5dba2dee0c">
<fme:FEATURE_ID>1210049241</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POF</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833727.82</fme:EASTING>
<fme:NORTHING>822185.36</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Post Office</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣郵政局</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822185.36382 833727.81848 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc4c6fb65-7560-405a-bd6f-43253ef19825">
<fme:FEATURE_ID>1210032872</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832116</fme:EASTING>
<fme:NORTHING>822190</fme:NORTHING>
<fme:ENGLISHNAME>Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>遊樂場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822190.00000 832116.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3bf1da14-b4f0-4878-ab72-4856b4e6f5bd">
<fme:FEATURE_ID>1210015901</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832170</fme:EASTING>
<fme:NORTHING>822190</fme:NORTHING>
<fme:ENGLISHNAME>Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>遊樂場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822190.00000 832170.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idec3310ff-a954-4294-a8f6-59d445490893">
<fme:FEATURE_ID>1420004178</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832230.28</fme:EASTING>
<fme:NORTHING>822200.69</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Park</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822200.68987 832230.27889 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8f02875d-da14-4fb2-bd32-24b064995fd4">
<fme:FEATURE_ID>1210050602</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HTL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832691.31</fme:EASTING>
<fme:NORTHING>822202.85</fme:NORTHING>
<fme:ENGLISHNAME>JAO TSUNG-I ACADEMY</fme:ENGLISHNAME>
<fme:CHINESENAME>饒宗頤文化館</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822202.85377 832691.30966 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5d2668a5-20f6-4a5c-b802-29f760dca436">
<fme:FEATURE_ID>1210029139</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832665.84</fme:EASTING>
<fme:NORTHING>822208.11</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822208.10539 832665.83635 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5482f0f0-eeb2-4161-8e23-f301d66e8c3b">
<fme:FEATURE_ID>1210014772</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833360.72</fme:EASTING>
<fme:NORTHING>822215.93</fme:NORTHING>
<fme:ENGLISHNAME>Easy Tower</fme:ENGLISHNAME>
<fme:CHINESENAME>永義廣場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822215.92719 833360.71498 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id72470620-4809-408a-9d7d-81ea1a516434">
<fme:FEATURE_ID>1000985966</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832226.31</fme:EASTING>
<fme:NORTHING>822219.52</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822219.51787 832226.30963 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id169ac385-2bc4-4da7-85dd-6abc4ef3604b">
<fme:FEATURE_ID>1000986060</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832558.94</fme:EASTING>
<fme:NORTHING>822228.05</fme:NORTHING>
<fme:ENGLISHNAME>PO LEUNG KUK TONG NAI KAN JUNIOR SECONDARY COLLEGE</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局唐乃勤初中書院</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822228.05022 832558.93735 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="iddadece74-814b-4659-915e-feceedc39f77">
<fme:FEATURE_ID>1210031927</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833692.65</fme:EASTING>
<fme:NORTHING>822237.84</fme:NORTHING>
<fme:ENGLISHNAME>Lai Sun Commercial Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>麗新商業中心</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822237.83989 833692.64584 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4354b518-e7d7-4981-822b-4ff8760ac035">
<fme:FEATURE_ID>1210041258</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TNC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833710.1</fme:EASTING>
<fme:NORTHING>822242.62</fme:NORTHING>
<fme:ENGLISHNAME>MCL Cheung Sha Wan Cinema</fme:ENGLISHNAME>
<fme:CHINESENAME>MCL 長沙灣戲院</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822242.62413 833710.10332 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id27fe7227-c472-4961-877e-6bf0e4d5a004">
<fme:FEATURE_ID>1210040258</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832943.62</fme:EASTING>
<fme:NORTHING>822253.76</fme:NORTHING>
<fme:ENGLISHNAME>CHRISTIAN ALLIANCE INTERNATIONAL SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>宣道國際學校</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822253.76274 832943.61951 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id88cf0357-158a-4fff-a1cd-05f5fbbc63c7">
<fme:FEATURE_ID>1000986078</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832193.19</fme:EASTING>
<fme:NORTHING>822254.13</fme:NORTHING>
<fme:ENGLISHNAME>7-a-side Hard-surfaced Soccer Pitch</fme:ENGLISHNAME>
<fme:CHINESENAME>7人硬地足球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822254.12962 832193.19022 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd8379352-2735-4d6d-815e-f28b44bb12c4">
<fme:FEATURE_ID>1000985823</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833684.65</fme:EASTING>
<fme:NORTHING>822255.8</fme:NORTHING>
<fme:ENGLISHNAME>Kwong Cheung Street Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>光昌街變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822255.79803 833684.64937 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id70160ba4-57f2-428e-9bef-dce11687e9fa">
<fme:FEATURE_ID>1210033172</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832302.36</fme:EASTING>
<fme:NORTHING>822264.07</fme:NORTHING>
<fme:ENGLISHNAME>Lai Wan Road Park Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔灣道公園變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822264.06510 832302.35653 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id579246da-5003-4ced-a966-0657ce6df4b2">
<fme:FEATURE_ID>1210034529</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831001</fme:EASTING>
<fme:NORTHING>822269</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 4</fme:ENGLISHNAME>
<fme:CHINESENAME>四號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822269.00000 831001.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida05ae27b-c71f-421f-add1-7c4c58d279fc">
<fme:FEATURE_ID>1210027968</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832906.68</fme:EASTING>
<fme:NORTHING>822269.95</fme:NORTHING>
<fme:ENGLISHNAME>Butterfly Valley Road Pet Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>蝴蝶谷道寵物公園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822269.94844 832906.67811 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id27dce5b7-a735-4a90-a4cb-8569c18c873a">
<fme:FEATURE_ID>1210040254</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832929.46</fme:EASTING>
<fme:NORTHING>822270.71</fme:NORTHING>
<fme:ENGLISHNAME>CHRISTIAN ALLIANCE INTERNATIONAL SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>宣道國際學校</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822270.70573 832929.46434 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id72ab1dc6-4bbd-47ba-b26d-2c0a6cb17a73">
<fme:FEATURE_ID>1210024532</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832288</fme:EASTING>
<fme:NORTHING>822272</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Park</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822272.00000 832288.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6a1f1094-69e3-4b37-82a4-a836a52d8d28">
<fme:FEATURE_ID>1210000982</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832626.69</fme:EASTING>
<fme:NORTHING>822275.25</fme:NORTHING>
<fme:ENGLISHNAME>Castle Peak Road/Ching Cheung Road Rest Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>青山道/呈祥道休憩花園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822275.25000 832626.68750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4db87c01-0948-40a6-916d-0f8b5cf85511">
<fme:FEATURE_ID>1210027211</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832145.9</fme:EASTING>
<fme:NORTHING>822275.27</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822275.26534 832145.89647 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idaa8bb258-d296-429a-b63a-4de4a3951425">
<fme:FEATURE_ID>1000985997</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833631.76</fme:EASTING>
<fme:NORTHING>822276.84</fme:NORTHING>
<fme:ENGLISHNAME>Esso-Castle Peak Road Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>埃索-青山道加油站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822276.83992 833631.76065 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id215bab04-4731-4234-a08d-1b62acadb2fc">
<fme:FEATURE_ID>1000985872</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831815.11</fme:EASTING>
<fme:NORTHING>822277.24</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822277.23980 831815.11365 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb20630a0-e29e-48ab-98b3-1845afd4bfe4">
<fme:FEATURE_ID>1310066032</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833142.05</fme:EASTING>
<fme:NORTHING>822280.04</fme:NORTHING>
<fme:ENGLISHNAME>Portas</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241016</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822280.03755 833142.05027 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id80d0780c-9efc-45ed-86a1-7e36fde65a47">
<fme:FEATURE_ID>1210033112</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832689.8</fme:EASTING>
<fme:NORTHING>822281.9</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822281.90436 832689.79780 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id07f01616-6eed-4ca3-b2bc-7a138a38f410">
<fme:FEATURE_ID>1210027826</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833569.85</fme:EASTING>
<fme:NORTHING>822284.83</fme:NORTHING>
<fme:ENGLISHNAME>Peninsula Tower</fme:ENGLISHNAME>
<fme:CHINESENAME>半島大廈</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822284.82793 833569.84871 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idfeb04bd1-089d-4c6d-98fb-dc3136300d91">
<fme:FEATURE_ID>1210033051</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830924.8</fme:EASTING>
<fme:NORTHING>822298.49</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822298.48671 830924.79922 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id26da269d-b955-47fe-b577-cd98ee136767">
<fme:FEATURE_ID>1210008790</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832101.98</fme:EASTING>
<fme:NORTHING>822304.1</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Mei Foo Station-G Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路美孚站-G進出口</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822304.10220 832101.98216 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id93fa85f5-c9b2-4b61-96ef-2e1c56138129">
<fme:FEATURE_ID>1210038339</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833441.67</fme:EASTING>
<fme:NORTHING>822307.1</fme:NORTHING>
<fme:ENGLISHNAME>The Globe</fme:ENGLISHNAME>
<fme:CHINESENAME>創匯國際中心</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822307.09480 833441.66705 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idfe14be8f-200f-474e-a9f6-d0edc722bb7f">
<fme:FEATURE_ID>1000985937</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832036.82</fme:EASTING>
<fme:NORTHING>822307.42</fme:NORTHING>
<fme:ENGLISHNAME>Ching Lai Commercial Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>清麗商場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822307.41609 832036.81785 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8035dd02-cf38-480d-9198-7344f55b4a00">
<fme:FEATURE_ID>1310059187</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HTL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833645.16</fme:EASTING>
<fme:NORTHING>822316.56</fme:NORTHING>
<fme:ENGLISHNAME>HOTEL YX LAI CHI KOK</fme:ENGLISHNAME>
<fme:CHINESENAME>HOTEL YX LAI CHI KOK</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250916</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822316.56041 833645.15939 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idac653bf2-ddc8-4526-9398-b62e8b5d5bbb">
<fme:FEATURE_ID>1210015902</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832109</fme:EASTING>
<fme:NORTHING>822322</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822322.00000 832109.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id18e49679-1a86-4af4-a661-719d49d9c0bc">
<fme:FEATURE_ID>1000985891</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831852.9</fme:EASTING>
<fme:NORTHING>822329.3</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822329.30275 831852.89977 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida5845720-6b71-4718-af6c-c9caf4452533">
<fme:FEATURE_ID>1000985967</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833613.54</fme:EASTING>
<fme:NORTHING>822333.92</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822333.92195 833613.53883 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf1fd5d73-fd82-48fd-9d8c-a763dec1cde4">
<fme:FEATURE_ID>1000985917</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>LIB</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832309.11</fme:EASTING>
<fme:NORTHING>822354.88</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Public Library</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公共圖書館</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822354.88403 832309.11423 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf5ce7027-d11d-4682-b0f3-d7fb44012622">
<fme:FEATURE_ID>1000985910</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>GOF</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832323.87</fme:EASTING>
<fme:NORTHING>822355.37</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Government Offices</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角政府合署</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822355.37368 832323.86775 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8308773c-18d6-4f30-9ac6-26f05fcc9dfc">
<fme:FEATURE_ID>1000986021</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833666.78</fme:EASTING>
<fme:NORTHING>822356.92</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822364.06453 833666.23011 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9f1a7c5f-b61a-4844-8383-30f1c9a10797">
<fme:FEATURE_ID>1000986099</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832205.04</fme:EASTING>
<fme:NORTHING>822365.68</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Park Swimming Pool</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公園游泳池</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822365.68331 832205.03489 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd908ffaf-19a9-469a-a608-8f81515f1ca5">
<fme:FEATURE_ID>1000985912</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HOS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831924.01</fme:EASTING>
<fme:NORTHING>822368.73</fme:NORTHING>
<fme:ENGLISHNAME>Princess Margaret Hospital</fme:ENGLISHNAME>
<fme:CHINESENAME>瑪嘉烈醫院</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822368.73312 831924.00666 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id46c6de05-9a2c-441c-9610-b5cd636f9419">
<fme:FEATURE_ID>1000985955</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833642.21</fme:EASTING>
<fme:NORTHING>822368.73</fme:NORTHING>
<fme:ENGLISHNAME>Wing Hong Street Rest Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>永康街休憩花園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822368.73433 833642.20896 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5d352c18-20dc-4b24-b8b6-2ae26c93fb35">
<fme:FEATURE_ID>1210033203</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831176.44</fme:EASTING>
<fme:NORTHING>822375.44</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822375.44316 831176.43738 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd678420f-8a87-48db-b166-00c36a5e96a6">
<fme:FEATURE_ID>1000986033</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832184.87</fme:EASTING>
<fme:NORTHING>822388.66</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Park Swimming Pool Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公園游泳池廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822388.65679 832184.87323 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide97e538f-5c78-4692-92f2-4385690d57d4">
<fme:FEATURE_ID>1000985873</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832223.91</fme:EASTING>
<fme:NORTHING>822394.74</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Park Stage 1 Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公園第1期變電站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822394.74297 832223.90910 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0b892d2b-5089-49a8-83fe-83bc1386d471">
<fme:FEATURE_ID>1000986061</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833633.76</fme:EASTING>
<fme:NORTHING>822401.93</fme:NORTHING>
<fme:ENGLISHNAME>NAM WAH CATHOLIC SECONDARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>天主教南華中學</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822401.93160 833633.76344 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idccf45e82-e303-4fa8-b713-63a5432e575e">
<fme:FEATURE_ID>1000985915</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832295.52</fme:EASTING>
<fme:NORTHING>822408.95</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Park Sports Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公園體育館</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822408.94475 832295.51780 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id507d67fc-4caf-49db-9667-d1b9f99920dc">
<fme:FEATURE_ID>1210028555</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833556</fme:EASTING>
<fme:NORTHING>822411</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822411.00000 833556.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id927af0b0-3f61-411f-9038-fa6b1ddf4391">
<fme:FEATURE_ID>1000986034</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832213.4</fme:EASTING>
<fme:NORTHING>822414.21</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Park Swimming Pool Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角公園游泳池廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822414.20567 832213.40461 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id08c3e161-d49b-4e73-b51c-56af2b71f93e">
<fme:FEATURE_ID>1210033200</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830696.67</fme:EASTING>
<fme:NORTHING>822419.54</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822419.54375 830696.67211 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idce1227bb-bfc2-4bde-8938-5a20e9a9426f">
<fme:FEATURE_ID>1000986022</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833366.86</fme:EASTING>
<fme:NORTHING>822442.16</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822442.15664 833366.85793 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc9f830c4-786f-4ebf-a736-843ee63c919d">
<fme:FEATURE_ID>1000985892</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832261.73</fme:EASTING>
<fme:NORTHING>822448.69</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822448.68605 832261.73141 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6ed9adc7-850b-49f8-811a-4a24137df6f2">
<fme:FEATURE_ID>1000985731</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832109.1</fme:EASTING>
<fme:NORTHING>822473.7</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI KOK BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角巴士總站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822473.70204 832109.10361 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id24eb38de-6a44-4ecb-8c0c-1acf757cc6b4">
<fme:FEATURE_ID>1000985822</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831827.05</fme:EASTING>
<fme:NORTHING>822477.04</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822477.04093 831827.05228 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb173669a-9620-4872-bfa3-d71506c47d87">
<fme:FEATURE_ID>1000985814</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832733.9</fme:EASTING>
<fme:NORTHING>822480.86</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok 400kv Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角４００仟伏變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822480.85945 832733.90290 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc9e875cd-c6e9-4160-9006-edb60ef94ed1">
<fme:FEATURE_ID>1210031827</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832189</fme:EASTING>
<fme:NORTHING>822507</fme:NORTHING>
<fme:ENGLISHNAME>Nob Hill Square</fme:ENGLISHNAME>
<fme:CHINESENAME>盈暉薈</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822507.00000 832189.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id15019b22-84ca-4c53-b80c-b50f23f505db">
<fme:FEATURE_ID>1310057543</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831161.83</fme:EASTING>
<fme:NORTHING>822516.95</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 4</fme:ENGLISHNAME>
<fme:CHINESENAME>四號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822516.95250 831161.82499 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3def2976-f318-47d7-84f8-333145435217">
<fme:FEATURE_ID>1210034534</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830713</fme:EASTING>
<fme:NORTHING>822524</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 3</fme:ENGLISHNAME>
<fme:CHINESENAME>三號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822524.00000 830713.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5cd7fee3-3acb-43a8-be62-9cf1ddb5a5ca">
<fme:FEATURE_ID>1310054402</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831904</fme:EASTING>
<fme:NORTHING>822529.24</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Chung Hospital</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌醫院</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822529.23749 831904.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6e2fc2c3-5846-4fd2-81d1-53f4799a18d5">
<fme:FEATURE_ID>1000985769</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832082.39</fme:EASTING>
<fme:NORTHING>822529.42</fme:NORTHING>
<fme:ENGLISHNAME>LAI CHI KOK BAY GARDEN</fme:ENGLISHNAME>
<fme:CHINESENAME>荔灣花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822529.41583 832082.38812 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id763ded83-221e-453e-abee-f8cea0305f1c">
<fme:FEATURE_ID>1210033059</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831185.9</fme:EASTING>
<fme:NORTHING>822539.95</fme:NORTHING>
<fme:ENGLISHNAME>Container Term Berth 4 Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>四號貨櫃碼頭變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822539.95014 831185.89959 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcf983120-d719-4adb-ba20-40a971d7879c">
<fme:FEATURE_ID>1210033201</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831338.86</fme:EASTING>
<fme:NORTHING>822557.45</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822557.44553 831338.85913 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idafb9889f-5092-4eb6-90c7-5e903f423e16">
<fme:FEATURE_ID>1000985972</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833713.93</fme:EASTING>
<fme:NORTHING>822562.98</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822562.97483 833713.93298 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7f07a8c1-9a14-4a20-8ca0-95c0c9f13e88">
<fme:FEATURE_ID>1000986109</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CEM</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833330</fme:EASTING>
<fme:NORTHING>822579</fme:NORTHING>
<fme:ENGLISHNAME>ST. RAPHAEL'S CATHOLIC CEMETERY</fme:ENGLISHNAME>
<fme:CHINESENAME>聖辣法厄爾天主教墳場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822579.00000 833330.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb09658ca-3269-441f-9b57-bc6aaf292e46">
<fme:FEATURE_ID>1210033405</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832128.39</fme:EASTING>
<fme:NORTHING>822588.5</fme:NORTHING>
<fme:ENGLISHNAME>THE CHURCH OF CHRIST IN CHINA KEI CHUN PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>中華基督教會基真小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822588.49700 832128.39400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5e7ff21d-7169-4784-a870-b67bc9468d96">
<fme:FEATURE_ID>1210014600</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CHU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833377</fme:EASTING>
<fme:NORTHING>822593</fme:NORTHING>
<fme:ENGLISHNAME>Church</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822593.00000 833377.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6320ee32-7fec-4b9b-8efa-1ea660eb8af3">
<fme:FEATURE_ID>1000985964</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833740.1</fme:EASTING>
<fme:NORTHING>822593.24</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822593.23933 833740.10423 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd05644d7-0cdf-434b-a59c-e09756694bd1">
<fme:FEATURE_ID>1000986103</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TMP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833698.07</fme:EASTING>
<fme:NORTHING>822615.05</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>福德念佛社</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822615.04869 833698.06606 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id87ddf71a-91ea-478c-a9f0-0e802466b481">
<fme:FEATURE_ID>1000985963</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833514.96</fme:EASTING>
<fme:NORTHING>822617.07</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822617.07235 833514.96202 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1f0436a9-bc4b-4ba7-8912-c274a47b3d99">
<fme:FEATURE_ID>1210037548</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TMP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833661.88</fme:EASTING>
<fme:NORTHING>822617.76</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>集德堂</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822617.76145 833661.87657 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8c16aad7-7775-4f39-b8d8-66f8f6110280">
<fme:FEATURE_ID>1000986085</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832253.22</fme:EASTING>
<fme:NORTHING>822620.18</fme:NORTHING>
<fme:ENGLISHNAME>Wah Lai Estate Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>華荔邨籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822620.17793 832253.22050 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idad668805-3f9f-4545-9f49-739f5ae9daa8">
<fme:FEATURE_ID>1210037551</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TMP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833701.73</fme:EASTING>
<fme:NORTHING>822639.3</fme:NORTHING>
<fme:ENGLISHNAME>Temple</fme:ENGLISHNAME>
<fme:CHINESENAME>廟宇</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822639.30097 833701.72538 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9e47c9ce-97e3-4c12-8092-e585014ef298">
<fme:FEATURE_ID>1310066424</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831484.2</fme:EASTING>
<fme:NORTHING>822643.99</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250327</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822643.99200 831484.19600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida0d2cc89-b51e-45ef-a408-4496faca59b9">
<fme:FEATURE_ID>1210033199</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831079.15</fme:EASTING>
<fme:NORTHING>822644.8</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822644.80435 831079.14682 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9661d219-e199-47f5-921c-aee528b25dee">
<fme:FEATURE_ID>1000985760</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832238.86</fme:EASTING>
<fme:NORTHING>822647.32</fme:NORTHING>
<fme:ENGLISHNAME>Wah Lai Car Park</fme:ENGLISHNAME>
<fme:CHINESENAME>華荔停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822647.32031 832238.86056 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide91a3a7b-f289-4083-a0e5-be2dead64bab">
<fme:FEATURE_ID>1000985914</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HOS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831781.38</fme:EASTING>
<fme:NORTHING>822664.56</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Chung Hospital</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌醫院</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822648.67970 831787.73023 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3652811f-4b09-44ec-b3f6-98b4fec21c5b">
<fme:FEATURE_ID>1210037552</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TMP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833735.42</fme:EASTING>
<fme:NORTHING>822665.65</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>活佛堂</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822665.64633 833735.42441 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idafd6b7cb-9ac1-4cf0-9926-096ac8361ec6">
<fme:FEATURE_ID>1210038772</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832188.19</fme:EASTING>
<fme:NORTHING>822691.05</fme:NORTHING>
<fme:ENGLISHNAME>Tennis Court</fme:ENGLISHNAME>
<fme:CHINESENAME>網球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822691.04674 832188.18683 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idaca683c5-a9dd-4fef-9222-2d5f956ba1cb">
<fme:FEATURE_ID>1000985971</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833203.88</fme:EASTING>
<fme:NORTHING>822717.97</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822717.97078 833203.87683 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id072d392a-fd38-47b1-a5af-e72a6eb52966">
<fme:FEATURE_ID>1210033185</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830680.23</fme:EASTING>
<fme:NORTHING>822722.22</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822722.21817 830680.23309 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9e8aab31-4491-4cec-93ea-3fa279b18876">
<fme:FEATURE_ID>1000985949</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833217.26</fme:EASTING>
<fme:NORTHING>822724.08</fme:NORTHING>
<fme:ENGLISHNAME>Rest Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>休憩花園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822724.07614 833217.25625 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8e55fe10-8933-47b8-9414-6236e55ecfb7">
<fme:FEATURE_ID>1210037677</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SEC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831372.73</fme:EASTING>
<fme:NORTHING>822766.42</fme:NORTHING>
<fme:ENGLISHNAME>HONG CHI WINIFRED MARY CHEUNG MORNINGHOPE SCHOOL (SECONDARY SECTION)</fme:ENGLISHNAME>
<fme:CHINESENAME>匡智張玉瓊晨輝學校(中學部)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822766.42254 831372.72595 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd7d60054-de6a-4ee7-802a-9a501ca69367">
<fme:FEATURE_ID>1000985895</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831476.89</fme:EASTING>
<fme:NORTHING>822780.62</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Kok Salt Water Pumping Station Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝角海水抽水站電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822780.61824 831476.88580 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5a69cfef-35d5-42aa-bf6b-627e17a76067">
<fme:FEATURE_ID>1000986094</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833450.54</fme:EASTING>
<fme:NORTHING>822780.62</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822780.62309 833450.53496 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id04b20811-b970-4476-baa6-ea20e4f9f92a">
<fme:FEATURE_ID>1210027007</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831464</fme:EASTING>
<fme:NORTHING>822821</fme:NORTHING>
<fme:ENGLISHNAME>Kai Chun Lau B Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>啟真樓B電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>X</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822822.51980 831471.01447 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb8e39d81-b77b-42df-9fcb-c32f80126f9a">
<fme:FEATURE_ID>1000986072</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833329.78</fme:EASTING>
<fme:NORTHING>822836.4</fme:NORTHING>
<fme:ENGLISHNAME>PO LEUNG KUK CHOI KAI YAU SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局蔡繼有學校</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822836.40295 833329.78333 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id516a58dc-8c42-402a-9d94-8e48daf23711">
<fme:FEATURE_ID>1210034138</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833312.56</fme:EASTING>
<fme:NORTHING>822836.45</fme:NORTHING>
<fme:ENGLISHNAME>PO LEUNG KUK CHOI KAI YAU SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局蔡繼有學校</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822836.44872 833312.55775 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1af76abb-5a90-4dbb-b310-74b16b10f02b">
<fme:FEATURE_ID>1000985906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833434.99</fme:EASTING>
<fme:NORTHING>822841.76</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822841.76320 833434.98517 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id191b7f0d-6a4e-43a2-9a4b-04bd6ff23aec">
<fme:FEATURE_ID>1210026841</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832720</fme:EASTING>
<fme:NORTHING>822848</fme:NORTHING>
<fme:ENGLISHNAME>Fairyland Sewage Treatment Plant Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>怡菁山莊污水處理廠電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>X</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822843.06182 832717.05998 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida9577679-7405-453d-8c71-64342c3e8cbb">
<fme:FEATURE_ID>1000985886</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831237</fme:EASTING>
<fme:NORTHING>822859</fme:NORTHING>
<fme:ENGLISHNAME>Salvation Army Home Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>救世軍荔景院變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822855.64830 831242.23843 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide4aba4a5-e875-4d4e-8b3b-d60cb40a0c32">
<fme:FEATURE_ID>1210034967</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830619</fme:EASTING>
<fme:NORTHING>822868</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 2</fme:ENGLISHNAME>
<fme:CHINESENAME>二號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822868.00000 830619.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idaba0c6d7-8910-4a0d-9ffe-59ce4506d2e1">
<fme:FEATURE_ID>1000986025</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832201.39</fme:EASTING>
<fme:NORTHING>822872.65</fme:NORTHING>
<fme:ENGLISHNAME>Kau Wah Keng Tsuen Aqua Privy</fme:ENGLISHNAME>
<fme:CHINESENAME>九華徑村旱廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822872.65470 832201.39214 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc3453ef7-4137-47ef-b004-4758b05a87ac">
<fme:FEATURE_ID>1210017990</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833728</fme:EASTING>
<fme:NORTHING>822874</fme:NORTHING>
<fme:ENGLISHNAME>Piper's Hill Television Transmission Station</fme:ENGLISHNAME>
<fme:CHINESENAME>琵琶山電視發射站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822874.00000 833728.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0548db6d-e44c-43d4-8e0d-d1ea7b0e10e6">
<fme:FEATURE_ID>1000985961</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831638.52</fme:EASTING>
<fme:NORTHING>822887.61</fme:NORTHING>
<fme:ENGLISHNAME>Lai Chi Ling Road Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>荔枝嶺路休憩處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822887.61046 831638.51462 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id077f3018-1a37-4f0b-b3b0-dd706ebc8b48">
<fme:FEATURE_ID>1210016679</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831562</fme:EASTING>
<fme:NORTHING>822914</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822914.00000 831562.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcf133492-d501-4475-970a-0ac86a1f1fe6">
<fme:FEATURE_ID>1310054732</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831756.74</fme:EASTING>
<fme:NORTHING>822914.68</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822914.67844 831756.73736 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id64976e00-ce25-4cc0-9be5-01cd4ad2fe92">
<fme:FEATURE_ID>1000985983</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832378.1</fme:EASTING>
<fme:NORTHING>822917.55</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822917.54901 832378.09940 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1e82d9ce-914e-4311-9b36-43f77e120b49">
<fme:FEATURE_ID>1420005276</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831246.99</fme:EASTING>
<fme:NORTHING>822924.71</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822924.70565 831246.98647 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id58ae9566-8e26-4c09-8502-064ebe46d231">
<fme:FEATURE_ID>1000986058</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831358.55</fme:EASTING>
<fme:NORTHING>822925.88</fme:NORTHING>
<fme:ENGLISHNAME>THE HONG KONG S.Y.C. &amp; I.A. CHAN NAM CHONG MEMORIAL COLLEGE</fme:ENGLISHNAME>
<fme:CHINESENAME>香港四邑商工總會陳南昌紀念中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822925.87930 831358.54551 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1f670dc7-8b0b-4dfa-9dc5-6e839b46ea74">
<fme:FEATURE_ID>1210015794</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831277</fme:EASTING>
<fme:NORTHING>822928</fme:NORTHING>
<fme:ENGLISHNAME>Cho Yiu Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>祖堯坊</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822928.00000 831276.25301 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id911b9d74-8fb0-4fa1-b800-a44a619fac4d">
<fme:FEATURE_ID>1000986093</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831184</fme:EASTING>
<fme:NORTHING>822933</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822932.99867 831183.99454 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2d7ecab8-957e-44c7-8de6-f92af455472f">
<fme:FEATURE_ID>1210019851</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TTH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832077.38</fme:EASTING>
<fme:NORTHING>822935.67</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>吳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822934.89121 832087.28344 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id85c24da2-c415-4392-a115-9a906c30bf50">
<fme:FEATURE_ID>1310065017</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831043.09</fme:EASTING>
<fme:NORTHING>822936.29</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Estate Car Park D</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景邨停車場D</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250121</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822936.29000 831043.08649 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcc6e46c9-06ee-4428-b6ed-fac2a8e5daa5">
<fme:FEATURE_ID>1000986024</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831160.71</fme:EASTING>
<fme:NORTHING>822941.4</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822941.39872 831160.70925 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2b2714e5-bf3a-49cb-9bcb-08a23767f3b8">
<fme:FEATURE_ID>1000985809</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CMC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831307.07</fme:EASTING>
<fme:NORTHING>822958.73</fme:NORTHING>
<fme:ENGLISHNAME>The Boys' and Girls' Clubs Association of Hong Kong Jockey Club Kwai Chung (South) Children and Youth Integrated Services Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>香港小童群益會賽馬會南葵涌青少年綜合服務中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822958.72757 831307.06582 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1a3acfcb-3acc-4b33-87ee-1703875f0788">
<fme:FEATURE_ID>1210004564</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831244</fme:EASTING>
<fme:NORTHING>822970</fme:NORTHING>
<fme:ENGLISHNAME>Cho Yiu Comm &amp; Ctl Plaza Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>祖堯邨商場及中央廣場變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822964.71472 831238.64415 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb0a2404a-24fe-49ba-9199-bb97b67d0c08">
<fme:FEATURE_ID>1210033473</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831138.53</fme:EASTING>
<fme:NORTHING>822968.24</fme:NORTHING>
<fme:ENGLISHNAME>ASBURY METHODIST PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>亞斯理衛理小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822968.24199 831138.53147 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide2fa0919-579e-4c04-9b79-127ff7237cf0">
<fme:FEATURE_ID>1000986048</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831367.67</fme:EASTING>
<fme:NORTHING>822970.45</fme:NORTHING>
<fme:ENGLISHNAME>CHO YIU CATHOLIC PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>祖堯天主教小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822970.45035 831367.66777 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id68121f84-7bfc-4120-a849-96e3e554874c">
<fme:FEATURE_ID>1000986007</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831201.74</fme:EASTING>
<fme:NORTHING>822972.14</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Hill Road Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山路遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822972.13785 831201.73720 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcf8615c4-0102-47f4-b2ee-f256550e4ddc">
<fme:FEATURE_ID>1000985969</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831237.79</fme:EASTING>
<fme:NORTHING>822981.9</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822981.90403 831237.78806 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida8b8d4e9-1b6a-4577-a18b-eee84497f9b7">
<fme:FEATURE_ID>1310061810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831299.34</fme:EASTING>
<fme:NORTHING>822988.32</fme:NORTHING>
<fme:ENGLISHNAME>CHO YIU CHUEN BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>祖堯邨巴士總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822988.31750 831299.33503 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idea9ab441-b28f-42d4-bb75-6d120ee1d5b3">
<fme:FEATURE_ID>1210009996</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830874.96</fme:EASTING>
<fme:NORTHING>822988.84</fme:NORTHING>
<fme:ENGLISHNAME>Mariner's Club O/D Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>海員俱樂部變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822988.84085 830874.95902 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9fab5e95-dd35-4f3f-9078-86ecd67cf2f7">
<fme:FEATURE_ID>1000985968</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831167.95</fme:EASTING>
<fme:NORTHING>822989.77</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822989.77193 831167.94959 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id358b48c2-80f2-4c02-80a3-89268c0a6aaf">
<fme:FEATURE_ID>1000986089</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830993.21</fme:EASTING>
<fme:NORTHING>823000.01</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823000.01181 830993.20914 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8d3bfb41-b0f7-48ca-9365-7e0db57acff7">
<fme:FEATURE_ID>1000985870</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831419.5</fme:EASTING>
<fme:NORTHING>823003.6</fme:NORTHING>
<fme:ENGLISHNAME>KAI LIM LAU SUBSTATION</fme:ENGLISHNAME>
<fme:CHINESENAME>祖堯邨啟廉樓變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823003.59565 831419.50230 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3f1da0ff-b615-4b91-ae11-f93015d94c54">
<fme:FEATURE_ID>1000986096</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831991.94</fme:EASTING>
<fme:NORTHING>823006.57</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823006.57216 831991.94442 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1b712839-6000-485b-8268-9175497cc7be">
<fme:FEATURE_ID>1000985808</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CMC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831119.36</fme:EASTING>
<fme:NORTHING>823010.83</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Community Hall</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景社區會堂</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823010.83015 831119.35600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idba82e2bb-9e64-4c47-b10e-b2af2a91ac8b">
<fme:FEATURE_ID>1310062661</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831291.47</fme:EASTING>
<fme:NORTHING>823013.78</fme:NORTHING>
<fme:ENGLISHNAME>CHO YIU CHUEN</fme:ENGLISHNAME>
<fme:CHINESENAME>祖堯邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823013.77749 831291.47083 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7c45bc12-f335-483e-aaec-46da1dea9d43">
<fme:FEATURE_ID>1000986011</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POF</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831060.36</fme:EASTING>
<fme:NORTHING>823015.09</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Post Office</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景郵政局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823015.08634 831060.36308 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8d7715ed-7552-471f-92bb-8e237ddf631e">
<fme:FEATURE_ID>1210033225</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831331.37</fme:EASTING>
<fme:NORTHING>823020.12</fme:NORTHING>
<fme:ENGLISHNAME>Kai King Lau Upper Zone Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>啟敬樓高層變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823020.11964 831331.36887 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id700aed14-737e-4e7c-aed9-e4f94bdcb3c8">
<fme:FEATURE_ID>1000985929</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831291.48</fme:EASTING>
<fme:NORTHING>823027.5</fme:NORTHING>
<fme:ENGLISHNAME>Cho Yiu Chuen Market Store</fme:ENGLISHNAME>
<fme:CHINESENAME>祖堯邨街市</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823027.49625 831291.47480 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idba1a5cab-b7bd-42b7-95d7-7ec9a4ee3388">
<fme:FEATURE_ID>1210041287</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832389</fme:EASTING>
<fme:NORTHING>823035</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823035.00000 832389.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id358daf70-68f0-4d9d-8d59-1b3f72ddb5ed">
<fme:FEATURE_ID>1000985828</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831112.95</fme:EASTING>
<fme:NORTHING>823048.04</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823048.03862 831112.94726 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4edef6e5-0948-4a59-8366-048206016a94">
<fme:FEATURE_ID>1310054873</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832697.73</fme:EASTING>
<fme:NORTHING>823048.85</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823048.84600 832697.73100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="iddbff6bbb-774d-4810-bc94-f3a455319079">
<fme:FEATURE_ID>1210021377</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CSD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831723</fme:EASTING>
<fme:NORTHING>823061</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Correctional Institution</fme:ENGLISHNAME>
<fme:CHINESENAME>勵敬懲教所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823061.00000 831723.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4d69f7be-cdfc-4b96-84bb-960950210fee">
<fme:FEATURE_ID>1210021146</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VTI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831104</fme:EASTING>
<fme:NORTHING>823081</fme:NORTHING>
<fme:ENGLISHNAME>Clothing Industry Training Authority Lai King Training Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>製衣業訓練局荔景訓練中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823081.00000 831104.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1da16178-643a-4df0-83d3-cc91d46c75f8">
<fme:FEATURE_ID>1210033037</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830789.2</fme:EASTING>
<fme:NORTHING>823085.16</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823085.15827 830789.19747 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id09148ff4-b73f-419c-b2cf-0c7d7c4664c6">
<fme:FEATURE_ID>1000986013</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832719.39</fme:EASTING>
<fme:NORTHING>823086.76</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Yuen Road Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長源路公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823086.75466 832719.39157 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5e1c07df-5f2a-4284-b4d4-802a920c6773">
<fme:FEATURE_ID>1000985970</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832664.96</fme:EASTING>
<fme:NORTHING>823094.59</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823094.58612 832664.96422 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id41122734-85b1-4b07-b55a-f5dd48cea8e1">
<fme:FEATURE_ID>1210035018</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833504</fme:EASTING>
<fme:NORTHING>823109</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823109.00001 833503.99999 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id06dd7239-6a22-42a9-bfc5-34c85a7d0386">
<fme:FEATURE_ID>1210004647</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831219</fme:EASTING>
<fme:NORTHING>823124</fme:NORTHING>
<fme:ENGLISHNAME>Kai Hang Lau C Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>啟恆樓C電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823124.16191 831208.92785 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8a04a30e-6d36-44bf-8544-cecacec7d389">
<fme:FEATURE_ID>1000985883</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831007.75</fme:EASTING>
<fme:NORTHING>823129.79</fme:NORTHING>
<fme:ENGLISHNAME>Yeung King House B Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>仰景樓B電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823129.79378 831007.75047 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0aadd2b2-4f22-4e5d-91cc-212a77515126">
<fme:FEATURE_ID>1420000263</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HOS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831543.41</fme:EASTING>
<fme:NORTHING>823151.92</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Building of Princess Margaret Hospital</fme:ENGLISHNAME>
<fme:CHINESENAME>瑪嘉烈醫院老人科日間醫院</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250410</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823151.92000 831543.41000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id647b688d-7f89-4387-896a-1ed0b937b6c0">
<fme:FEATURE_ID>1000985810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CMC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831048.11</fme:EASTING>
<fme:NORTHING>823162.1</fme:NORTHING>
<fme:ENGLISHNAME>The Boys' and Girls' Clubs Association of Hong Kong Jockey Club Kwai Chung (South) Children and Youth Integrated Services Centre(Sub-base)</fme:ENGLISHNAME>
<fme:CHINESENAME>香港小童群益會賽馬會南葵涌青少年綜合服務中心(分處)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823162.09791 831048.10735 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idef6abd23-0a57-4a94-8325-9e4b36917fe9">
<fme:FEATURE_ID>1210041502</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831705.69</fme:EASTING>
<fme:NORTHING>823177.09</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823177.08952 831705.69272 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id524d5e53-2380-431b-8b60-0bdfc3e47daa">
<fme:FEATURE_ID>1210034528</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830520</fme:EASTING>
<fme:NORTHING>823179</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 1</fme:ENGLISHNAME>
<fme:CHINESENAME>一號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823179.00000 830520.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide9f3a561-79cd-4c31-89c3-fa2e0e778246">
<fme:FEATURE_ID>1420000380</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831367.32</fme:EASTING>
<fme:NORTHING>823190.46</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250410</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823190.45722 831367.32185 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2ceaf873-e781-4192-b2c5-b6c761562ef1">
<fme:FEATURE_ID>1000985795</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831137.65</fme:EASTING>
<fme:NORTHING>823194.13</fme:NORTHING>
<fme:ENGLISHNAME>Yuet Lai Court</fme:ENGLISHNAME>
<fme:CHINESENAME>悅麗苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823194.12777 831137.64678 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id14dd3029-6cd3-460e-9727-0c349b2ebf54">
<fme:FEATURE_ID>1210008727</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831044.88</fme:EASTING>
<fme:NORTHING>823213.82</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai King Station-A3 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔景站-A3進出口</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823204.56139 831050.70295 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida8dd84fa-1fe4-456a-8f93-c5d19aad7362">
<fme:FEATURE_ID>1210026398</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833121</fme:EASTING>
<fme:NORTHING>823207</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823207.00000 833121.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1c58aa28-27ed-45f9-957a-1a773f76bc2a">
<fme:FEATURE_ID>1000985824</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830752.08</fme:EASTING>
<fme:NORTHING>823208.52</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823208.52229 830752.08098 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6f51565a-db8c-46e2-a126-33f5e3740c73">
<fme:FEATURE_ID>1000986023</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832687.95</fme:EASTING>
<fme:NORTHING>823214.57</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hang Village Aqua Privy</fme:ENGLISHNAME>
<fme:CHINESENAME>長坑村旱廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823214.57225 832687.94721 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8bfc5e27-89b7-4ce8-af8b-7e6bc0e59f22">
<fme:FEATURE_ID>1210008793</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831082.53</fme:EASTING>
<fme:NORTHING>823172.73</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai King Station-A1 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔景站-A1進出口</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823218.77096 831079.35258 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5576fe0e-3cf4-4b46-98b9-0811d55ba3f4">
<fme:FEATURE_ID>1210027190</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831250</fme:EASTING>
<fme:NORTHING>823226</fme:NORTHING>
<fme:ENGLISHNAME>Kai Min Lau C Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>啟勉樓C電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>X</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823220.72366 831258.01222 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id846f25ce-6e2d-4c65-9ce5-5f2a38102ee2">
<fme:FEATURE_ID>1210008792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831078.06</fme:EASTING>
<fme:NORTHING>823246.54</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai King Station-A2 Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔景站-A2進出口</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823246.54375 831078.06412 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide0045812-94d3-4d1d-bc85-e53374299c0a">
<fme:FEATURE_ID>1210008870</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831047</fme:EASTING>
<fme:NORTHING>823250</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai King Station</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔景站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823250.00000 831047.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idce6d417c-477d-4699-b008-fa068f002896">
<fme:FEATURE_ID>1210035058</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833493.07</fme:EASTING>
<fme:NORTHING>823253.22</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823253.21951 833493.07224 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd645d4b4-ab13-4ace-951c-7f6d8766c1b9">
<fme:FEATURE_ID>1210008559</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830994.22</fme:EASTING>
<fme:NORTHING>823287.82</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai King Station-B Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔景站-B進出口</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823263.89849 831006.42785 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id37edfa98-f95b-47b9-b1ca-d61aaf75e13b">
<fme:FEATURE_ID>1000985936</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831081.88</fme:EASTING>
<fme:NORTHING>823282.05</fme:NORTHING>
<fme:ENGLISHNAME>Yin Lai Court Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>賢麗苑購物中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823282.04821 831081.87597 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idaa767b63-6eaa-4f54-9c2d-e9e6d3b53905">
<fme:FEATURE_ID>1210034872</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830186</fme:EASTING>
<fme:NORTHING>823284</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 5</fme:ENGLISHNAME>
<fme:CHINESENAME>五號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823284.00000 830186.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idca4de514-e6ac-4c97-8132-987d693cc847">
<fme:FEATURE_ID>1210008556</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831011.44</fme:EASTING>
<fme:NORTHING>823334.61</fme:NORTHING>
<fme:ENGLISHNAME>Mass Transit Railway Lai King Station-C Access</fme:ENGLISHNAME>
<fme:CHINESENAME>香港鐵路荔景站-C進出口</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823305.50633 831032.33728 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id42f15d5c-d24f-492f-979a-4dcdd6978d37">
<fme:FEATURE_ID>1000985958</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831900.97</fme:EASTING>
<fme:NORTHING>823323.76</fme:NORTHING>
<fme:ENGLISHNAME>Castle Peak Road Garden (6Ms)</fme:ENGLISHNAME>
<fme:CHINESENAME>青山公路六咪花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823323.75705 831900.96505 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id531010f1-0d0f-467b-8824-fa5c085e7e45">
<fme:FEATURE_ID>1000985832</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831653.13</fme:EASTING>
<fme:NORTHING>823334.69</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Fire Station Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景消防局電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823334.68799 831653.12750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id845193bd-9316-4d6e-aa87-49bf2e123957">
<fme:FEATURE_ID>1000985980</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833354.25</fme:EASTING>
<fme:NORTHING>823339.11</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823339.10507 833354.24738 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id847953f8-0c0c-45fd-940b-0ad0798ee616">
<fme:FEATURE_ID>1310059116</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831491</fme:EASTING>
<fme:NORTHING>823355</fme:NORTHING>
<fme:ENGLISHNAME>Lai Kong Street</fme:ENGLISHNAME>
<fme:CHINESENAME>荔崗街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823355.00000 831491.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1397924c-ff85-4496-91ca-7e1943daae9f">
<fme:FEATURE_ID>1000985907</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831633.3</fme:EASTING>
<fme:NORTHING>823374.4</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Fire Station</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景消防局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823374.39944 831633.29963 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id578bae2d-5329-4a4c-9307-806c127122d0">
<fme:FEATURE_ID>1210035057</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VEB</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830734.78</fme:EASTING>
<fme:NORTHING>823386.48</fme:NORTHING>
<fme:ENGLISHNAME>Barred Access</fme:ENGLISHNAME>
<fme:CHINESENAME>路障</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823386.47552 830734.77705 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ideb805c40-6b16-42db-ad27-2f4026100ff1">
<fme:FEATURE_ID>1000985829</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830070.62</fme:EASTING>
<fme:NORTHING>823386.6</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Bridge 'East' Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣橋＂東＂變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823386.60430 830070.61699 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id148f0ddc-fb7e-4026-8cdf-32343d7680c1">
<fme:FEATURE_ID>1000985754</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831068.25</fme:EASTING>
<fme:NORTHING>823388.99</fme:NORTHING>
<fme:ENGLISHNAME>Yin Lai Car Park</fme:ENGLISHNAME>
<fme:CHINESENAME>賢麗停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823388.99400 831068.24666 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9419559a-bb14-42d6-b8c1-7157fe5ec3d6">
<fme:FEATURE_ID>1210012996</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830888.46</fme:EASTING>
<fme:NORTHING>823410</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH (STT 3701)</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路 (STT 3701)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823410.00000 830888.46152 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idedf83f58-bd2e-4eb0-8d8a-6709e064da57">
<fme:FEATURE_ID>1000985932</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831079.41</fme:EASTING>
<fme:NORTHING>823415.71</fme:NORTHING>
<fme:ENGLISHNAME>Market</fme:ENGLISHNAME>
<fme:CHINESENAME>市場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823415.71000 831079.41157 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6e27de59-ae5d-4582-b4b0-2a7b564b90cb">
<fme:FEATURE_ID>1210041397</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831047</fme:EASTING>
<fme:NORTHING>823420</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Assessment Centre Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景評核中心變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823420.00000 831047.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id506613d9-e523-4e7d-8e06-2c9485398b55">
<fme:FEATURE_ID>1000985916</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831200.39</fme:EASTING>
<fme:NORTHING>823424.91</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Sports Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景體育館</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823424.91118 831200.38502 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id20dda7bf-47eb-4814-87ba-bb559b950e5a">
<fme:FEATURE_ID>1210032334</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833371</fme:EASTING>
<fme:NORTHING>823427</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823427.00000 833371.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ideec77368-c45b-478c-99e6-595696b42340">
<fme:FEATURE_ID>1420005275</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832024.94</fme:EASTING>
<fme:NORTHING>823428.31</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823428.31017 832024.94328 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0d0ccc68-d9ff-478f-877d-a2827e503337">
<fme:FEATURE_ID>1000986081</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831208.5</fme:EASTING>
<fme:NORTHING>823456.24</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Soccer Pitch</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823456.23783 831208.49909 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf2be10ce-f927-47a9-9792-ebe0241bcb8a">
<fme:FEATURE_ID>1210011215</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831738</fme:EASTING>
<fme:NORTHING>823458</fme:NORTHING>
<fme:ENGLISHNAME>Esso-Kwai Chung Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>埃索-葵涌加油站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823460.67740 831740.46567 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0e9c32af-51cf-49eb-b077-40872950ab51">
<fme:FEATURE_ID>1310061988</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>LPG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831722.38</fme:EASTING>
<fme:NORTHING>823465.14</fme:NORTHING>
<fme:ENGLISHNAME>ExxonMobil-Liquefied Petroleum Gas Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>埃克森美孚-加氣站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823465.14400 831722.37900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idca7fba48-4dc1-4db2-9cbc-79094a75aecd">
<fme:FEATURE_ID>1310062443</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831613.65</fme:EASTING>
<fme:NORTHING>823469.54</fme:NORTHING>
<fme:ENGLISHNAME>Tsui Yiu Court</fme:ENGLISHNAME>
<fme:CHINESENAME>翠瑤苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823469.53704 831613.65225 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd02a95a6-3276-4394-9d5f-453942461cf1">
<fme:FEATURE_ID>1310059118</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832017</fme:EASTING>
<fme:NORTHING>823473</fme:NORTHING>
<fme:ENGLISHNAME>Wah Yuen Drive</fme:ENGLISHNAME>
<fme:CHINESENAME>華員徑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823473.00000 832017.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf095c28b-6f34-4ae9-8d46-815ef1246e07">
<fme:FEATURE_ID>1000985854</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831039.44</fme:EASTING>
<fme:NORTHING>823473.49</fme:NORTHING>
<fme:ENGLISHNAME>Ming King House 'B' Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景邨明景樓Ｂ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823473.49224 831039.44406 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9a0ee9f6-5369-4aec-9448-b9805e915bd7">
<fme:FEATURE_ID>1420005274</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832061.35</fme:EASTING>
<fme:NORTHING>823475.72</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823475.72359 832061.35002 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida3c9dc63-5262-4fd0-9caa-ad2b8ff96162">
<fme:FEATURE_ID>1000985950</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831209.44</fme:EASTING>
<fme:NORTHING>823491.15</fme:NORTHING>
<fme:ENGLISHNAME>Rest Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>休憩公園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823491.15425 831209.44065 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3226b0fc-2310-4862-8ed2-d2c118d1b798">
<fme:FEATURE_ID>1000985825</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831115.66</fme:EASTING>
<fme:NORTHING>823495.05</fme:NORTHING>
<fme:ENGLISHNAME>Yat King House 'B' Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景邨日景樓Ｂ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823495.04807 831115.65815 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8685b594-3cfe-4a1c-b2c3-a4637ad6755f">
<fme:FEATURE_ID>1210028722</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>LPG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831714.24</fme:EASTING>
<fme:NORTHING>823498.33</fme:NORTHING>
<fme:ENGLISHNAME>Sinopec-Liquefied Petroleum Gas Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>中國石化-加氣站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823498.32668 831714.23472 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id69fd5316-c27f-42a1-8730-6102a0385ba2">
<fme:FEATURE_ID>1000986066</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831817.51</fme:EASTING>
<fme:NORTHING>823527.11</fme:NORTHING>
<fme:ENGLISHNAME>CARMEL ALISON LAM FOUNDATION SECONDARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>迦密愛禮信中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823527.11301 831817.51043 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida79f98c3-770c-4117-8691-27311df371b9">
<fme:FEATURE_ID>1000985992</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831211.27</fme:EASTING>
<fme:NORTHING>823529.2</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823529.19554 831211.27397 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id47618d80-12db-420c-8315-02faf2183c64">
<fme:FEATURE_ID>1210033061</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830376.2</fme:EASTING>
<fme:NORTHING>823534.55</fme:NORTHING>
<fme:ENGLISHNAME>Container Terminal Berth 5 Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>五號貨櫃碼頭變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823534.55366 830376.20296 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf8e83484-81f4-472d-a592-2911493891df">
<fme:FEATURE_ID>1420005273</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831128.91</fme:EASTING>
<fme:NORTHING>823555.05</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823555.04974 831128.90693 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id26549423-d336-4c79-968b-c4317ddffd86">
<fme:FEATURE_ID>1000985764</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832179.67</fme:EASTING>
<fme:NORTHING>823595.57</fme:NORTHING>
<fme:ENGLISHNAME>Wah King Hill Road Commercial Complex Open Car Park</fme:ENGLISHNAME>
<fme:CHINESENAME>華景商場停車場(室外)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823595.57412 832179.66742 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9c8f9cbf-1b7a-466d-8c0b-b9606cf5255c">
<fme:FEATURE_ID>1000985951</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831186.45</fme:EASTING>
<fme:NORTHING>823597.65</fme:NORTHING>
<fme:ENGLISHNAME>Lai King Hill Road North Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景山路北休憩處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823597.64804 831186.45154 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1beeecda-f35a-4130-8469-00a2976e442b">
<fme:FEATURE_ID>1420005252</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830667.35</fme:EASTING>
<fme:NORTHING>823614.22</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823614.21877 830667.35445 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id25990948-d36f-42e3-af2d-56c4c6dabea0">
<fme:FEATURE_ID>1000985726</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831158.71</fme:EASTING>
<fme:NORTHING>823620.6</fme:NORTHING>
<fme:ENGLISHNAME>LAI KING NORTH BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景北巴士總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823620.59875 831158.71273 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcb26848f-515b-4f38-987c-56e8736ee667">
<fme:FEATURE_ID>1310055183</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832201.27</fme:EASTING>
<fme:NORTHING>823622.62</fme:NORTHING>
<fme:ENGLISHNAME>Wah King Hill Road</fme:ENGLISHNAME>
<fme:CHINESENAME>華景山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823622.61748 832201.27127 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf606665f-d42a-4d05-92f5-242c0e872437">
<fme:FEATURE_ID>1000985981</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832297.62</fme:EASTING>
<fme:NORTHING>823625.16</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823625.15611 832297.61856 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id95e45e56-8ba6-4a62-8458-6e8f2547d979">
<fme:FEATURE_ID>1000985934</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832149.95</fme:EASTING>
<fme:NORTHING>823631.72</fme:NORTHING>
<fme:ENGLISHNAME>Wonderland Villas Commercial Complex</fme:ENGLISHNAME>
<fme:CHINESENAME>華景商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823631.71567 832149.94737 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8fd00b52-0d1e-45ff-8c28-e01b03105f2a">
<fme:FEATURE_ID>1000985739</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830840</fme:EASTING>
<fme:NORTHING>823635</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TAI ROAD (STT 3852)</fme:ENGLISHNAME>
<fme:CHINESENAME>葵泰路 (STT 3852)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823635.00343 830840.00364 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id125b8daf-ab11-45f6-80f1-bc2c5f309f02">
<fme:FEATURE_ID>1420007072</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831115.74</fme:EASTING>
<fme:NORTHING>823641.92</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823641.91485 831115.73799 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf821aa82-09df-4cef-9f49-72e62c907f67">
<fme:FEATURE_ID>1210042610</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831170</fme:EASTING>
<fme:NORTHING>823650</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823650.00000 831170.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3927f371-c40e-4d2f-8f3a-2abd997033bf">
<fme:FEATURE_ID>1210015104</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831780</fme:EASTING>
<fme:NORTHING>823657</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823657.00000 831780.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb29eba40-e851-449c-9b12-c17339e79add">
<fme:FEATURE_ID>1000985755</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830939.57</fme:EASTING>
<fme:NORTHING>823658.42</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH (STT 3821)</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路 (STT 3821)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823658.41996 830939.57055 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5c1f7f50-8a02-4ead-989b-eaf2c00ccf53">
<fme:FEATURE_ID>1000985817</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830869.2</fme:EASTING>
<fme:NORTHING>823659.52</fme:NORTHING>
<fme:ENGLISHNAME>Evergain Plaza 'B' Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>永得利廣場Ｂ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823659.52442 830869.19751 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id222f1691-39c5-457c-afde-a8ae067427b4">
<fme:FEATURE_ID>1210027236</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832175</fme:EASTING>
<fme:NORTHING>823680</fme:NORTHING>
<fme:ENGLISHNAME>Wah King Hill Road Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>華景山路花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823680.00000 832175.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc6448251-1203-4f4b-93c3-b97788729945">
<fme:FEATURE_ID>1000986063</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831491.18</fme:EASTING>
<fme:NORTHING>823681.1</fme:NORTHING>
<fme:ENGLISHNAME>KWAI CHUNG METHODIST COLLEGE</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌循道中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823681.09868 831491.18210 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2dd9e843-83a7-4159-bf09-94914f46001f">
<fme:FEATURE_ID>1210038497</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832153.73</fme:EASTING>
<fme:NORTHING>823684.53</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823684.52912 832153.73118 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id74df2ae0-a3f4-4fae-8a63-3d75ff874cb8">
<fme:FEATURE_ID>1000985736</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPM</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832089.64</fme:EASTING>
<fme:NORTHING>823693.03</fme:NORTHING>
<fme:ENGLISHNAME>Wonderland Villas (Southern Carpark)</fme:ENGLISHNAME>
<fme:CHINESENAME>華景山莊南停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823693.03398 832089.63987 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida64696b5-0baa-487c-b184-516e81bd94ac">
<fme:FEATURE_ID>1000985805</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CLI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831236.32</fme:EASTING>
<fme:NORTHING>823695.19</fme:NORTHING>
<fme:ENGLISHNAME>Ha Kwai Chung Family Medicine Clinic</fme:ENGLISHNAME>
<fme:CHINESENAME>下葵涌家庭醫學診所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260224</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823695.18481 831236.32264 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id65cae9d7-9faa-4fe7-8663-421e903b5c73">
<fme:FEATURE_ID>1000985855</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830184.52</fme:EASTING>
<fme:NORTHING>823718.99</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823718.99269 830184.51636 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id008c6f2e-5fe5-4a04-98cf-4ff76d5edd74">
<fme:FEATURE_ID>1000985815</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830799.92</fme:EASTING>
<fme:NORTHING>823723.32</fme:NORTHING>
<fme:ENGLISHNAME>Ha Kwai Chung Sub-station</fme:ENGLISHNAME>
<fme:CHINESENAME>下葵涌變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823723.32325 830799.91896 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1d066298-11d9-4600-8475-69ddca10939e">
<fme:FEATURE_ID>1000986015</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830216.73</fme:EASTING>
<fme:NORTHING>823728.31</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823728.30900 830216.72500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0231b719-7bcf-4775-bf7e-5a53a49ff8a8">
<fme:FEATURE_ID>1000985957</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830754.16</fme:EASTING>
<fme:NORTHING>823737.02</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Tak Street Rest Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>葵德街休憩花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823737.01758 830754.16327 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb7e942cd-af75-46a4-8ad7-d7e289cce407">
<fme:FEATURE_ID>1000986064</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831132.22</fme:EASTING>
<fme:NORTHING>823738.36</fme:NORTHING>
<fme:ENGLISHNAME>LAI KING CATHOLIC SECONDARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>荔景天主教中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823738.36153 831132.22159 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc77389a2-be1b-4c49-8d74-c2daacec8d9a">
<fme:FEATURE_ID>1420003188</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830259.4</fme:EASTING>
<fme:NORTHING>823750.86</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823750.85800 830259.39500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5d0514ab-ee25-4914-aa6c-7fd74c547aed">
<fme:FEATURE_ID>1000985727</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831636.91</fme:EASTING>
<fme:NORTHING>823755.38</fme:NORTHING>
<fme:ENGLISHNAME>LAI YIU BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>麗瑤巴士總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823755.38030 831636.91006 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0a4560f1-8483-4e96-994f-9cf54843a332">
<fme:FEATURE_ID>1420003186</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830209.56</fme:EASTING>
<fme:NORTHING>823765.37</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823765.37231 830209.56199 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2782c382-8c61-4871-b351-34b481075218">
<fme:FEATURE_ID>1000986065</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831206.03</fme:EASTING>
<fme:NORTHING>823781.56</fme:NORTHING>
<fme:ENGLISHNAME>LINGNAN DR. CHUNG WING KWONG MEMORIAL SECONDARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>嶺南鍾榮光博士紀念中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823781.55679 831206.02765 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide44d3ea9-e2df-49c7-a5d6-557821afc968">
<fme:FEATURE_ID>1000985827</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831595</fme:EASTING>
<fme:NORTHING>823781.89</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Yiu House B Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>貴瑤樓B電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823781.89041 831595.00328 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7b84f09e-a268-4220-918c-21a01ab9d72a">
<fme:FEATURE_ID>1210034116</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831414.91</fme:EASTING>
<fme:NORTHING>823788.29</fme:NORTHING>
<fme:ENGLISHNAME>T.W.G.HS KO HO NING MEMORIAL PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>東華三院高可寧紀念小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823788.28661 831414.90523 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8edb7642-8104-47aa-b7bd-83ab0814e50e">
<fme:FEATURE_ID>1420003187</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830216.1</fme:EASTING>
<fme:NORTHING>823804.18</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823804.18217 830216.09952 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id290d34ea-7c16-450f-8a49-b67ff464a3d1">
<fme:FEATURE_ID>1000985973</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832162.33</fme:EASTING>
<fme:NORTHING>823806.32</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823806.32249 832162.33000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id873ef72f-b72b-47eb-aab1-8478b98bbf6d">
<fme:FEATURE_ID>1000985777</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830623.47</fme:EASTING>
<fme:NORTHING>823809.77</fme:NORTHING>
<fme:ENGLISHNAME>KWAI WO STREET (STT 3783)</fme:ENGLISHNAME>
<fme:CHINESENAME>葵和街 (STT 3783)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823809.76507 830623.47434 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idba7d136e-d644-4e07-ab06-12c00b833b20">
<fme:FEATURE_ID>1420003204</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830103.03</fme:EASTING>
<fme:NORTHING>823832.45</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823832.44599 830103.02467 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id39e256db-a6b8-4b09-b5f6-d9bc1225019d">
<fme:FEATURE_ID>1420003189</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830143.53</fme:EASTING>
<fme:NORTHING>823837.05</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823837.05338 830143.53244 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida5ee291a-e006-4dcf-93e0-46b900891040">
<fme:FEATURE_ID>1000985744</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831621.35</fme:EASTING>
<fme:NORTHING>823843.62</fme:NORTHING>
<fme:ENGLISHNAME>Lai Yiu Estate Car Park</fme:ENGLISHNAME>
<fme:CHINESENAME>麗瑤邨停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823843.62061 831621.35072 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf674b473-a1e7-485d-81e1-09afc965f475">
<fme:FEATURE_ID>1420003185</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830194.43</fme:EASTING>
<fme:NORTHING>823857.45</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823857.44749 830194.42779 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2f59bb68-d912-47c7-b94c-002109d3326a">
<fme:FEATURE_ID>1000985830</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831483.95</fme:EASTING>
<fme:NORTHING>823863.29</fme:NORTHING>
<fme:ENGLISHNAME>Lai Yiu 'TB' Restaurant Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>麗瑤酒樓變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823863.28944 831483.94733 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id651c203c-d7a9-4e03-9960-c75f88fa5b42">
<fme:FEATURE_ID>1000986016</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830872.51</fme:EASTING>
<fme:NORTHING>823866.88</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Shun Street Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>葵順街公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823866.88156 830872.50826 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcfa2026f-824e-4410-8cb7-2e96d3dca2df">
<fme:FEATURE_ID>1000985780</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831040.29</fme:EASTING>
<fme:NORTHING>823868.79</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD (STT 3706)</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭路 (STT 3706)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823868.79433 831040.29147 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf642ab4e-d978-455c-b9fa-941bbd1ef054">
<fme:FEATURE_ID>1420003184</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830190.62</fme:EASTING>
<fme:NORTHING>823873.43</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823873.42835 830190.61779 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6aab77b4-45bc-4c79-9943-72137dfcbefa">
<fme:FEATURE_ID>1000985930</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831514.38</fme:EASTING>
<fme:NORTHING>823875.56</fme:NORTHING>
<fme:ENGLISHNAME>Lai Yiu Estate Market</fme:ENGLISHNAME>
<fme:CHINESENAME>麗瑤邨街市</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823875.56332 831514.37970 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0acd52b9-7887-4b6e-8701-72c8108685ef">
<fme:FEATURE_ID>1000985943</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831556.48</fme:EASTING>
<fme:NORTHING>823883.38</fme:NORTHING>
<fme:ENGLISHNAME>Lai Yiu Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>麗瑤商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823883.37622 831556.48361 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idfb7dd605-93cf-46c0-9188-bd0f231912a8">
<fme:FEATURE_ID>1210011202</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830833.32</fme:EASTING>
<fme:NORTHING>823888.45</fme:NORTHING>
<fme:ENGLISHNAME>KWAI SHUN STREET COOKED FOOD MARKET</fme:ENGLISHNAME>
<fme:CHINESENAME>葵順街熟食市場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823888.44487 830833.31776 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="iddb828228-b672-4158-b466-857f8c4041ac">
<fme:FEATURE_ID>1000985845</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830133.54</fme:EASTING>
<fme:NORTHING>823919.94</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823919.94497 830133.54341 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1bbbd3d9-617a-47ee-9aeb-70ff9a3b0c17">
<fme:FEATURE_ID>1210049954</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830984.98</fme:EASTING>
<fme:NORTHING>823922.75</fme:NORTHING>
<fme:ENGLISHNAME>Sinopec-Container Port Road Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>中國石化-貨櫃碼頭路油站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823922.74783 830984.97951 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id446a2260-30e1-4fcf-aa80-a6bbc4a0eac4">
<fme:FEATURE_ID>1000985975</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831687.73</fme:EASTING>
<fme:NORTHING>823928.47</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823928.46675 831687.72462 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id72b5c738-5d8a-400a-870d-ce1dd911f833">
<fme:FEATURE_ID>1000986006</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830809.32</fme:EASTING>
<fme:NORTHING>823940.68</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Shun Street Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>葵順街遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823940.67887 830809.32345 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8e9d803b-8a65-4e7d-9130-75240848f1a4">
<fme:FEATURE_ID>1210041302</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831086.24</fme:EASTING>
<fme:NORTHING>823950.07</fme:NORTHING>
<fme:ENGLISHNAME>KWAI FONG (SOUTH) BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>葵芳(南)總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823950.06686 831086.24369 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9e0d14d3-5037-47fa-acff-ec033a7cdada">
<fme:FEATURE_ID>1000985794</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPM</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832089.92</fme:EASTING>
<fme:NORTHING>823950.83</fme:NORTHING>
<fme:ENGLISHNAME>Wonderland Villas (Northern Carpark)</fme:ENGLISHNAME>
<fme:CHINESENAME>華景山莊北停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823950.83241 832089.92216 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3306e730-a898-480c-8db2-bc3f5cc8cd97">
<fme:FEATURE_ID>1210010835</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831610</fme:EASTING>
<fme:NORTHING>823959</fme:NORTHING>
<fme:ENGLISHNAME>Ha Kwai Chung Village O/D Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>下葵涌村戶外變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823959.00000 831610.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf0ac2924-c79a-48a4-964c-9cb5ad4db7dc">
<fme:FEATURE_ID>1310057539</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831084.49</fme:EASTING>
<fme:NORTHING>823962.88</fme:NORTHING>
<fme:ENGLISHNAME>Container Port Road Public Transport Interchange Minibus Terminus</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭路公共運輸交匯處小巴總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823962.87630 831084.49124 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4965c652-896c-43ba-9bcc-1c509c60e353">
<fme:FEATURE_ID>1000985974</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833241.84</fme:EASTING>
<fme:NORTHING>823971.14</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823971.14370 833241.84215 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id115727eb-0bd9-41fb-bc01-fbd8fb8a3fb8">
<fme:FEATURE_ID>1000986036</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831230.55</fme:EASTING>
<fme:NORTHING>823987.65</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823987.64754 831230.55237 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb89fbf1f-7b2f-46a3-8251-5e545859858a">
<fme:FEATURE_ID>1000986082</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831257.35</fme:EASTING>
<fme:NORTHING>823989.04</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823989.04320 831257.34930 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idad34027d-9f15-459f-96e2-33614213bcc1">
<fme:FEATURE_ID>1000985977</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831656.34</fme:EASTING>
<fme:NORTHING>823992.42</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823992.41932 831656.33996 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
</gml:FeatureCollection>
