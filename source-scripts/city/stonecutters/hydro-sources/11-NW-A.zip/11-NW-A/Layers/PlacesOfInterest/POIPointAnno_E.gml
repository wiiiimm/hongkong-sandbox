<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821015.78727 830115.44043</gml:lowerCorner>
<gml:upperCorner>823854.43840 833716.49878</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id3cd4a7e6-19b0-4c02-9456-2a4be4589c8b">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Sham Shui Po
Sports Ground</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.6094844264706</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001089405</fme:FEATURE_ID>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:EASTING>833716.469</fme:EASTING>
<fme:NORTHING>821983.084</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986077</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821983.05943 833716.49878</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idfd15eed9-d057-4b03-8b82-f43d53398bce">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Wholesale
Poultry Market</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>49.8282386820287</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001089401</fme:FEATURE_ID>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:EASTING>833653.997</fme:EASTING>
<fme:NORTHING>821750.102</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985933</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821750.07709 833654.02635</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id1e70a97d-2f01-4b52-8470-b0e95fd6fb39">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai Chi Kok Park</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.652755703455612</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001089404</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>832321.527</fme:EASTING>
<fme:NORTHING>821658.631</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985960</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821658.63131 832321.52674</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id74e1cce0-3c82-455a-acfe-79e3d4c84e00">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Kwai Chung Hospital</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001089402</fme:FEATURE_ID>
<fme:FEATURECODE>HOS</fme:FEATURECODE>
<fme:EASTING>831780.704</fme:EASTING>
<fme:NORTHING>822632.668</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985914</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822616.79272 831787.05387</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id22bb86f5-6631-4d64-b862-8dd9d14f60a9">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>St. Raphael's
Catholic Cemetery
</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001089400</fme:FEATURE_ID>
<fme:FEATURECODE>CEM</fme:FEATURECODE>
<fme:EASTING>833357.362</fme:EASTING>
<fme:NORTHING>822513.231</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986109</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822513.11466 833357.36218</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id0eb45c06-7566-4978-8e38-53b5bb7745ea">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Princess Margaret Hospital</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001089403</fme:FEATURE_ID>
<fme:FEATURECODE>HOS</fme:FEATURECODE>
<fme:EASTING>831910.461</fme:EASTING>
<fme:NORTHING>822341.537</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985912</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822341.53728 831910.46143</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idfc659175-92f6-4e90-9d81-0c4ffcc32d24">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>International
BMX Park</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.652755703455612</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000042</fme:FEATURE_ID>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:EASTING>830115.441</fme:EASTING>
<fme:NORTHING>823707.984</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823707.94509 830115.44043</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idfaa3e424-1fe5-49a6-91bc-46154171717c">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001192</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>830990.69723583</fme:EASTING>
<fme:NORTHING>823297.16551762</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008559</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823277.17712 831005.75603</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id9d570b33-c69a-401a-9510-10e6a8e5387a">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>C1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001210</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>832288.73640024</fme:EASTING>
<fme:NORTHING>822132.4449907</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008728</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822135.50251 832294.76317</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id59447197-7ab6-4d1e-8fb3-692c77e21111">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001256</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>833336.641</fme:EASTING>
<fme:NORTHING>821908.132</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008906</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821908.13241 833336.64104</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id222f2e74-8181-4057-b311-9893ef46868f">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>C</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001326</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>831005.79436484</fme:EASTING>
<fme:NORTHING>823319.23987881</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008556</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823312.50781 831020.88521</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id49a8dba8-9384-4616-bd0b-1f7746f7f8d1">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001341</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>831067.21659285</fme:EASTING>
<fme:NORTHING>823231.8052306</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008792</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823257.61697 831082.26050</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id230a25db-d64a-469f-a78c-2fed682fd4f4">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>C</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001345</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>833177.22743677</fme:EASTING>
<fme:NORTHING>821983.97154826</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008795</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821987.02908 833180.41201</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ida6f0535e-4257-42f1-a785-93842b69e469">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001347</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>831076.969</fme:EASTING>
<fme:NORTHING>823182.293</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008793</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823229.12453 831080.14440</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id1af936de-38d7-48a3-9dd3-d46133437543">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001357</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>832436.00657134</fme:EASTING>
<fme:NORTHING>822071.17201278</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008638</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822074.22954 832438.94783</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id7a848c6f-3cd9-4088-baba-0760d11ac8cb">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001373</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>832219.303</fme:EASTING>
<fme:NORTHING>822097.542</fme:NORTHING>
<fme:LINKFEATURE_ID>1210009040</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822097.54186 832219.30338</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id2f271948-2739-4b36-9662-5eec6766a942">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001385</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>833319.742</fme:EASTING>
<fme:NORTHING>821937.262</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008754</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821937.26155 833319.74196</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ida5c5cf33-604b-410e-9168-1cff53900690">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D4</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001386</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>833409.907</fme:EASTING>
<fme:NORTHING>821823.169</fme:NORTHING>
<fme:LINKFEATURE_ID>1210009068</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821823.16944 833409.90674</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id9e34dac4-14c1-4a6b-8d1c-a2d80e06b58d">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001389</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>832512.344</fme:EASTING>
<fme:NORTHING>821958.731</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008950</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821958.73107 832512.34382</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idaa833f6e-b841-4bb4-9e5f-bb178308f512">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>C2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001398</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>832329.35089085</fme:EASTING>
<fme:NORTHING>822109.69319873</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008716</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822112.75072 832335.37766</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id40c2fc90-2f37-4773-b5ef-8d08bb165c75">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>F</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001399</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>832133.23426612</fme:EASTING>
<fme:NORTHING>822167.36445985</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008478</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822170.42199 832135.92791</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id1030981a-15b9-42c2-94e1-49af361dc3fb">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001514</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>833410.38461998</fme:EASTING>
<fme:NORTHING>822070.55113187</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008875</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822073.60866 833416.16809</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id6ce462d5-5782-472b-858c-2bcfd877631a">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>G</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001535</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>832109.34234411</fme:EASTING>
<fme:NORTHING>822298.14130209</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008790</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822301.19883 832112.77237</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id1fe52aa8-3160-4895-81aa-28eee6172d34">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001571</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>833392.91682152</fme:EASTING>
<fme:NORTHING>822042.07100201</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008486</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822045.12853 833395.85808</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ideb4c5725-50ea-4f5a-a582-b11314756147">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001587</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>831053.26777079</fme:EASTING>
<fme:NORTHING>823210.68270965</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008727</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260710</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823204.47980 831064.87208</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idcab9f51b-6416-4059-969b-96daf54d67a8">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai King Station</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-55.2014431846197</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001588</fme:FEATURE_ID>
<fme:FEATURECODE>RSN</fme:FEATURECODE>
<fme:EASTING>831008.55217501</fme:EASTING>
<fme:NORTHING>823292.60462779</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008870</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823262.58526 831033.13847</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="iddc201e4d-47ec-4e4b-a0cd-3e3865011c35">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai Chi Kok Park
Swimming Pool</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005206</fme:FEATURE_ID>
<fme:FEATURECODE>SPL</fme:FEATURECODE>
<fme:EASTING>832203.382</fme:EASTING>
<fme:NORTHING>822337.027</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986099</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822336.98814 832203.38211</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id8578b18b-7eac-47c4-a8e7-f09b41363710">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai Chi Kok
Reception Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.1020099195058</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005207</fme:FEATURE_ID>
<fme:FEATURECODE>CSD</fme:FEATURECODE>
<fme:EASTING>832836.003</fme:EASTING>
<fme:NORTHING>822083.949</fme:NORTHING>
<fme:LINKFEATURE_ID>1210020149</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822083.91287 832836.01594</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id642a4182-2a55-4efc-a00c-9978ed021f08">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>E</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007808</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>832315.605</fme:EASTING>
<fme:NORTHING>822123.543</fme:NORTHING>
<fme:LINKFEATURE_ID>1210020397</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822123.54340 832315.60503</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id447b0400-f443-4cff-a1e1-669b94d2316a">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007828</fme:FEATURE_ID>
<fme:FEATURECODE>MTA</fme:FEATURECODE>
<fme:EASTING>833318.96</fme:EASTING>
<fme:NORTHING>822046.832</fme:NORTHING>
<fme:LINKFEATURE_ID>1210029186</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822046.83160 833318.95962</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id4f6a94e1-854a-4ce3-abc5-3481e742a66b">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008818</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830562.978</fme:EASTING>
<fme:NORTHING>823247.327</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034528</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823247.32682 830562.97839</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id09364cab-6001-4aa2-8306-0160a9076a67">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008819</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830173.365</fme:EASTING>
<fme:NORTHING>823264.438</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034872</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823264.43761 830173.36522</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idda850ed5-ec17-49a8-83da-2718cbf33cec">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008820</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830604.021</fme:EASTING>
<fme:NORTHING>822972.917</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034967</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822972.91728 830604.02055</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idb4998e3c-bc84-4925-b5d7-35423e89fec3">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008821</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830676.355</fme:EASTING>
<fme:NORTHING>822596.709</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034534</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822596.70933 830676.35527</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id55e13b63-1f6c-4de0-8e6c-1b5e3b059264">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 4</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008834</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>831076.29</fme:EASTING>
<fme:NORTHING>822278.109</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034529</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822278.10858 831076.28980</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idd7572e67-e2b6-4154-8747-cff1704300a6">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008835</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>831202.229</fme:EASTING>
<fme:NORTHING>821680.632</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034966</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821680.63191 831202.22891</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ide7708d13-dbde-4327-aa9b-d5e8e63bc327">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Jetty</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008836</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832960.523</fme:EASTING>
<fme:NORTHING>821015.787</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034707</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821015.78727 832960.52337</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id67ee2713-ad32-42d8-9873-70e702b50ab3">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 7</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008837</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>831416.955</fme:EASTING>
<fme:NORTHING>821410.294</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034965</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821410.29376 831416.95466</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id14cd3f5b-9e98-4afc-9640-59fe3f1ebae0">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 8</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008874</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>832061.036</fme:EASTING>
<fme:NORTHING>821058.452</fme:NORTHING>
<fme:LINKFEATURE_ID>1210036012</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821058.45155 832061.03569</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idb30d5294-c116-41ae-835a-09467a1131f0">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai King
Correctional Institution</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015311</fme:FEATURE_ID>
<fme:FEATURECODE>CSD</fme:FEATURECODE>
<fme:EASTING>831699.503</fme:EASTING>
<fme:NORTHING>823064.214</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021377</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823064.17533 831696.12917</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id1b6bec64-aaac-4a48-8da0-769875d3d3f3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D2 Place ONE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>12.4958222108936</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011976</fme:FEATURE_ID>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:EASTING>833378.821</fme:EASTING>
<fme:NORTHING>821888.336</fme:NORTHING>
<fme:LINKFEATURE_ID>1210037658</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821888.33584 833378.82120</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id7b929036-b41b-4609-a748-4633d46c5607">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D2 Place TWO</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>18.8203307488363</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011977</fme:FEATURE_ID>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:EASTING>833251.529</fme:EASTING>
<fme:NORTHING>821893.636</fme:NORTHING>
<fme:LINKFEATURE_ID>1210037657</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821893.63566 833251.52876</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id2b2cf1a3-3a79-4ab6-9673-791c60a958fd">
<fme:AnnotationClassID>7</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Christian Alliance
International School</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.4620616279434</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310013316</fme:FEATURE_ID>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:EASTING>833001.719</fme:EASTING>
<fme:NORTHING>822218.832</fme:NORTHING>
<fme:LINKFEATURE_ID>1210040258</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20231115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822218.79573 833001.73216</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ide54fe519-b8bb-4dbe-86e9-9457cf846220">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Kwai Chung Park</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810043978</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>830141.976</fme:EASTING>
<fme:NORTHING>823854.438</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823854.43840 830141.97623</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ideb9b77bc-2cdb-4ff7-99c3-7bef2e1d673e">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai Chi Kok Park</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000985956</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>832231.393</fme:EASTING>
<fme:NORTHING>822169.788</fme:NORTHING>
<fme:LINKFEATURE_ID>1420004178</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822169.78789 832231.39262</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
