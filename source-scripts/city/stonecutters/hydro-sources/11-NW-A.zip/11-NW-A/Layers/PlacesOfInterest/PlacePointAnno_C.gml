<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821036.58159 830022.74894</gml:lowerCorner>
<gml:upperCorner>823967.55006 833660.92455</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idced160f9-a6c2-4bb7-8818-f733764518e7">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>浩景臺</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965095</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831449.064</fme:EASTING>
<fme:NORTHING>823343.033</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76697</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280849</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823343.33177 831448.94630</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9424915e-6267-4f8a-be7b-d34535a65dd8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九華徑新村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965123</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>831840.18701145</fme:EASTING>
<fme:NORTHING>822975.64584821</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>68169</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278594</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822979.65877 831873.87696</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id0a9876c0-7523-4a61-a1f9-bec7c0f25695">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>紀律部隊宿舍</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-74.5575594293334</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965138</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831580.184</fme:EASTING>
<fme:NORTHING>823236.676</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77092</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283652</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823236.31624 831580.50536</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1b161672-08b0-4795-a874-c65c0d3c505f">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>泓景臺</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965115</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833253.443</fme:EASTING>
<fme:NORTHING>821678.891</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79185</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281266</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821679.19035 833253.33181</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2a81d5e7-8d9e-4140-8ea8-189f119e100a">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>祖堯邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965113</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831239.064</fme:EASTING>
<fme:NORTHING>823071.085</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310012214</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823071.38432 831239.15609</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2bb24146-16ab-4b7f-8e0f-60c7050cc1f8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長坑村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965124</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>832418.56131395</fme:EASTING>
<fme:NORTHING>823648.25948952</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>68338</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280924</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823652.27241 832438.31719</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idd2c87349-6c8e-4208-bab8-dcedfb9a9cce">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>郝德傑山</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965114</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833472.178</fme:EASTING>
<fme:NORTHING>822882.736</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79452</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281526</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822882.99230 833472.15649</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idddf9efbc-12db-450f-8b80-2d60608901ea">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗瑤邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965098</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831576.723</fme:EASTING>
<fme:NORTHING>823864.929</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75169</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310012225</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20231217</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823865.22774 831576.90239</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idbf6915e7-06c4-491b-bc90-101b81083a7d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔灣花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-73.9154242899287</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965099</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832071.431</fme:EASTING>
<fme:NORTHING>822567.757</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76862</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281286</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822567.68044 832071.71952</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="iddd250f46-b271-43fa-8c60-a4e247a0e570">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>消防處
新界工程部</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965135</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831655.98</fme:EASTING>
<fme:NORTHING>822531.078</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210010959</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822531.63878 831655.98019</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id71c4e930-6b9f-410b-94ea-5ef83f674cd9">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>美孚新邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965094</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832406.651</fme:EASTING>
<fme:NORTHING>821915.401</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279438</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821915.70023 832406.75544</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id48419305-e060-438f-aa0b-7ca98d0e1fc8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>美孚新邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965093</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832411.526</fme:EASTING>
<fme:NORTHING>822157.832</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279438</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822158.13081 832411.63087</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idea05e951-231b-4fc9-895e-576ab64082c0">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>嘉珀山</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965118</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833546.032</fme:EASTING>
<fme:NORTHING>822791.285</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79451</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281515</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822791.28498 833546.03190</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id68d0ecae-cad7-4eac-80a4-037ab54c7762">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長沙灣廣場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1045385999789</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965134</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833336.69900405</fme:EASTING>
<fme:NORTHING>821990.57944621</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822001.54747 833358.32422</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id12592310-8dac-4d86-9fce-7619cc6e5f3f">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965111</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831055.309</fme:EASTING>
<fme:NORTHING>823118.274</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278593</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823118.57352 831055.24764</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="iddcdd71f9-e58d-4c91-8dd8-85d751e9f93a">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>樂園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965102</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832208.758</fme:EASTING>
<fme:NORTHING>822693.284</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76839</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280188</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822693.53990 832208.50417</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id10dbaf4c-4b40-4d0f-b7f6-7e05eb674022">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965090</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>832820.283</fme:EASTING>
<fme:NORTHING>821717.391</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278598</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821717.98890 832819.96137</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id8e8dbcc4-100d-448f-ab90-9bc6d42a43ba">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>石梨貝水塘</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965171</fme:FEATURE_ID>
<fme:FEATURECODE>RES</fme:FEATURECODE>
<fme:EASTING>833337.315</fme:EASTING>
<fme:NORTHING>823967.251</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310012158</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823967.55006 833337.78373</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idf6fc1e36-c926-4244-8438-2a8f88183ee3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>盈暉臺</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965106</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832131.727</fme:EASTING>
<fme:NORTHING>822506.221</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76864</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281078</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822506.52041 832131.59751</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1216fcf9-6294-47dd-8e2c-e892827152a5">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九華徑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965125</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>832099.49303269</fme:EASTING>
<fme:NORTHING>822891.48505881</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>68170</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278595</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822891.48506 832099.49303</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id64c13462-3465-4bc9-a464-09a34c112b88">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景臺</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965108</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831781.331</fme:EASTING>
<fme:NORTHING>822304.569</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77886</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280181</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822304.82562 831781.22474</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1a590bf9-046d-4638-97b4-661d983c8fa0">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>石梨頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.370601426051794</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965127</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>832463.55541453</fme:EASTING>
<fme:NORTHING>823322.58246472</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64119</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278597</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823322.73871 832487.71166</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idfa57150d-0572-4899-b1ae-c3a4ff27c16d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九龍接收水塘</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965172</fme:FEATURE_ID>
<fme:FEATURECODE>RES</fme:FEATURECODE>
<fme:EASTING>833041.686</fme:EASTING>
<fme:NORTHING>823542.149</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310012164</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823542.44823 833042.67989</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idb3a1a9a6-507e-474d-8127-676d4eb6ad6f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九龍副水塘</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>42.7845643511223</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965170</fme:FEATURE_ID>
<fme:FEATURECODE>RES</fme:FEATURECODE>
<fme:EASTING>833572.542</fme:EASTING>
<fme:NORTHING>823467.331</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310012166</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823467.89799 833572.71430</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2bc575fa-4796-4533-9edf-53d78b4c1932">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>曼克頓山</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.5376904566974</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965122</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832695.166</fme:EASTING>
<fme:NORTHING>821700.365</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79749</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281593</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821700.36516 832695.16566</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id07578563-73be-4503-8b91-025b8b4d044c">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海麗邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.3645188329594</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965117</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833088.36305244</fme:EASTING>
<fme:NORTHING>821483.74159194</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281561</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821470.19531 833104.29986</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9e0329e3-bb81-42fa-bd3e-6834e537a486">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>宇晴軒</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-86.088004615171</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965116</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833459.985</fme:EASTING>
<fme:NORTHING>821736.49</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79334</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281493</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821736.49001 833459.98457</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id0a43bca4-06c8-4efd-b573-f2c7bca4300e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華荔邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965101</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832235.274</fme:EASTING>
<fme:NORTHING>822604.706</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77063</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280965</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822605.00546 832235.10736</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id7cdc0c0e-7f2e-4160-b2c4-9200a0f47384">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長沙灣</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>12.0000997438863</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965089</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>833626.316</fme:EASTING>
<fme:NORTHING>822145.804</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278601</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822146.31656 833626.66535</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2a1166d5-6259-4fd1-8a87-616274d87d91">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>救世軍荔景院</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965140</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831157.947</fme:EASTING>
<fme:NORTHING>822874.092</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283348</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822874.30556 831158.27753</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id925881fa-4e87-4231-bb0e-04f4ac655cb0">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨櫃場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965152</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831905.170175</fme:EASTING>
<fme:NORTHING>821582.40899</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821582.62264 831905.36421</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ide323e871-379c-4f03-a9ec-6522df792984">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965131</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830764.25</fme:EASTING>
<fme:NORTHING>823285.9375</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823285.93750 830783.25632</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1329a7bf-acd5-4fab-a91c-ee2598dc0807">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大蒸場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965126</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>832533.675</fme:EASTING>
<fme:NORTHING>822894.06</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75079</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278596</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822894.06046 832533.67545</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2f44cb7b-6fcc-47f3-abe8-b58e60e14dde">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華景山莊</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965109</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831952.08967966</fme:EASTING>
<fme:NORTHING>823935.89825483</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75167</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278590</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823939.91117 831977.63033</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id6e5c72d6-39ff-48d4-87f4-d6ca66fde192">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>昇悅居</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965110</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833373.618</fme:EASTING>
<fme:NORTHING>821720.723</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79184</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281270</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821721.02161 833373.80896</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id8bfcf192-2fb5-4766-b005-dc5761fedfd9">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>財利船廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.8342047488457</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965167</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832757.0901451</fme:EASTING>
<fme:NORTHING>821044.23198275</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821036.58159 832774.84682</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idab25d4a8-2b1a-4c89-a361-7d15fc643b69">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海峰花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965105</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832208.791</fme:EASTING>
<fme:NORTHING>823557.047</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75783</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278591</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823557.34654 832208.71093</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ida5712964-d756-448b-9f30-652922b8dbac">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965097</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831065.967</fme:EASTING>
<fme:NORTHING>823469.71</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310012312</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823470.00938 831065.90523</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idbd31a696-0a40-4d0c-b47a-1348c68a7151">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華員邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965092</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831966.921</fme:EASTING>
<fme:NORTHING>823491.783</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75165</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279876</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823492.08254 831966.78478</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idb4a7983a-314c-4971-8be2-9bbccb03de6d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>清麗苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965107</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831922.728</fme:EASTING>
<fme:NORTHING>822216.813</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278600</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822217.11204 831923.11070</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id66774b14-ada2-46b2-bfe6-15489762da8b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碧海藍天</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965119</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833342.638</fme:EASTING>
<fme:NORTHING>821545.208</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79335</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281530</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821545.50755 833343.10728</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ide23d8858-d090-4c0b-a094-6a3730cf1256">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>下葵涌</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965088</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>831347.153</fme:EASTING>
<fme:NORTHING>823631.897</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278585</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823631.89720 831347.15288</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idcde93726-b18f-4fdc-9cfa-a75bc68c57e3">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>蝴蝶谷</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>9.00010000223099</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965173</fme:FEATURE_ID>
<fme:FEATURECODE>HIL</fme:FEATURECODE>
<fme:EASTING>832886.96</fme:EASTING>
<fme:NORTHING>822843.791</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001282090</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822844.17565 832887.21392</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id71cf36af-6b6d-4922-aa06-5cd94425452b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>悅麗苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965100</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831133.818</fme:EASTING>
<fme:NORTHING>823215.876</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75552</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278592</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823216.17512 831134.26890</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idc3acdb14-838b-4a57-af5f-6aace5704860">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>翠瑤苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965091</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831609.875</fme:EASTING>
<fme:NORTHING>823536.68193943</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823536.68194 831617.40625</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idbfc72a79-c729-45f5-aaae-f411b7c579ab">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>賢麗苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965096</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831059.694</fme:EASTING>
<fme:NORTHING>823359.366</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75239</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282387</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823359.66524 831060.07055</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idc48d19b9-1d54-4a70-9c01-c029c15b29b8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>鍾山臺</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965121</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832254.755</fme:EASTING>
<fme:NORTHING>822818.411</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75054</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278599</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822818.66783 832254.22556</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ida9ffbaaf-d6a5-48bc-859c-a2863898c39a">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>船廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.6306719650871</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965139</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832850.17419872</fme:EASTING>
<fme:NORTHING>821074.61756745</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283505</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821072.20380 832859.55862</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2c71a448-b256-4ee3-ad10-e7b7bccd4b64">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>石梨貝濾水廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965154</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832907.06820932</fme:EASTING>
<fme:NORTHING>823373.40543276</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71194</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283869</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823376.27181 832935.95694</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idc4942cf0-0b43-431a-8b7d-db69bfa1c012">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渠務
保養廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965143</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830919.663</fme:EASTING>
<fme:NORTHING>822851.477</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283812</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822852.03723 830919.66323</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="iddab0981d-bf56-4281-b4a3-0ecd89ab05c9">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔欣苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965112</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832132.823</fme:EASTING>
<fme:NORTHING>822670.034</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76863</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280986</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822670.33313 832133.31048</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id3b6e2cc9-ec60-4045-bb65-a1792e140037">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西九龍緊急
支援中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-35.8376442946352</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965142</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831908.896</fme:EASTING>
<fme:NORTHING>821747.925</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283838</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821748.37885 831909.22425</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1ed8d43a-b71c-4b0a-884d-26b6773be18a">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965130</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830759.625</fme:EASTING>
<fme:NORTHING>823449.25</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823452.11638 830778.63132</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id8f0d33e4-fe14-4af3-939c-da3ebcc00a02">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>鐘山小築</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>1.78273827192104e-5</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965120</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832306.375</fme:EASTING>
<fme:NORTHING>822822.374</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210003909</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822822.58787 832306.37527</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id37624a55-2aef-4fb1-9c11-d781fea81dd6">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨物裝卸區</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>81.0119351293245</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000965129</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830021.875</fme:EASTING>
<fme:NORTHING>823744.1875</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823768.06011 830022.74894</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id45a9fec2-f258-4223-9950-6d341d3f0f66">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>一號．西九龍</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-85.8535251308335</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002542</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833168.165</fme:EASTING>
<fme:NORTHING>821694.346</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>80006</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210004483</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821695.76910 833168.31869</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idaaf7c55d-2e9d-4785-b928-2e9e56cb8e77">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>污水泵房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006150</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830719.483</fme:EASTING>
<fme:NORTHING>823917.245</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283810</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823917.45884 830719.60658</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id7b59cbd5-4aa4-4868-91c1-a3cd68927dfa">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>金德工業大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.1829221372881</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006152</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830775.244</fme:EASTING>
<fme:NORTHING>823808.997</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283796</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823809.51851 830775.23190</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idfbde10c0-4558-420e-8896-994783364fae">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永得利廣場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.3996047563876</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006154</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830865.901</fme:EASTING>
<fme:NORTHING>823741.735</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283621</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823742.28520 830865.89899</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id35e478c1-24db-45d6-940c-5e394fb5a5bb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>石梨貝食水配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006155</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>833027.464</fme:EASTING>
<fme:NORTHING>823309.55</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210002403</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823309.76330 833028.39855</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="iddb03fdca-6e25-4269-80ab-8e2181eaae86">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景山食水
配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006156</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>831492.863</fme:EASTING>
<fme:NORTHING>823556.848</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210002343</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823557.40849 831492.86333</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id98103cde-5837-46a5-b2b1-7eb88e30dd75">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大埔道濾水廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.240756736480223</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006157</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833350.905</fme:EASTING>
<fme:NORTHING>823087.064</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71193</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283870</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823087.27423 833351.70805</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id49b2954d-2347-4908-be11-72d8be3d15b0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九華徑二號
食水配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006158</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>832654.412</fme:EASTING>
<fme:NORTHING>822989.15</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70960</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002474</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822989.71054 832654.41213</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2bc11314-d8a8-4ebb-847c-2a4c778ed789">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>鄰舍輔導會
怡菁山莊</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006159</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832684.044</fme:EASTING>
<fme:NORTHING>822892.83</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>72126</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210004874</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822893.39006 832684.04439</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id63138e88-4947-4e6c-abf9-c893b7362409">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>蝴蝶谷食水主配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006161</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>833076.376</fme:EASTING>
<fme:NORTHING>822586.551</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70422</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002402</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822586.76466 833077.41688</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9fe88d9c-0302-431c-91f5-bd4c1c003893">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>琵琶山
海水配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006162</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>833516.508</fme:EASTING>
<fme:NORTHING>822554.945</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210002437</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822555.50549 833516.50753</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ida40a9a31-7199-4592-8c74-e0450e82ac06">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>饒宗頤文化館</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006169</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832665.479</fme:EASTING>
<fme:NORTHING>822137.43</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75080</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007906</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822137.64383 832666.28987</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id8713894a-9d3f-4386-b44c-9a267dce5ed2">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵順工業中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.4491223292344</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006249</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830817.206</fme:EASTING>
<fme:NORTHING>823785.01</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210005326</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823785.25072 830817.07411</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id931a99cd-e457-44d9-b7d4-e20e9e8e3931">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九華徑食水
配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006319</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>832586.424</fme:EASTING>
<fme:NORTHING>823156.957</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70959</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002428</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823157.51704 832586.42442</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id4f49417d-f832-4a66-aacf-3016a740685b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>祖堯邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008939</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831311.188</fme:EASTING>
<fme:NORTHING>823228.252</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823228.55137 831311.28069</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id6cd90f64-eaec-4711-80a8-dc9aebd80778">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>祖堯邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008940</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831432.831</fme:EASTING>
<fme:NORTHING>822899.386</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822899.68471 831432.92368</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id64d14da0-c827-44c1-b6ca-3246010a4bc7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>有蓋配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210009990</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>831528.07</fme:EASTING>
<fme:NORTHING>822789.785</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210007886</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822789.99914 831528.41791</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9835bc36-e78c-4623-b1c0-513ce657e3dc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>琵琶山
海水配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210009991</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>833483.607</fme:EASTING>
<fme:NORTHING>822712.089</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71531</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002408</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822712.64985 833483.60721</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ide4378a08-0ee1-4f97-b2be-e19f8794e4a1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角食水配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010350</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>831707.783</fme:EASTING>
<fme:NORTHING>822880.004</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77881</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002511</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822880.21753 831708.61600</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id63d6fa26-5868-4f22-8470-052b0fe25a3f">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>琵琶山
歷奇活動基地</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010352</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833469.914</fme:EASTING>
<fme:NORTHING>822991.891</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71526</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007866</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822992.45120 833469.91435</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id82b85258-0e07-4503-8c3e-bdb679efbdcb">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>建造業議會達美路訓練場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210013292</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831748.799</fme:EASTING>
<fme:NORTHING>821773.395</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82366</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006651</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821773.60867 831750.81378</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idcaa1e5c9-8aef-4fc7-8bb9-3fcb22e0b88e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海盈邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015150</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833330.997</fme:EASTING>
<fme:NORTHING>821066.301</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82683</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210009947</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821066.55725 833331.10319</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id336c119d-b620-4fca-806d-25b79836debd">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>第五期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015710</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832392.501</fme:EASTING>
<fme:NORTHING>822267.536</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282648</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822267.74931 832392.34675</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idba9023ec-dfa5-4ebd-b594-c15c5ccc011d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>第六期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015711</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832444.327</fme:EASTING>
<fme:NORTHING>822199.453</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282649</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822199.66636 832444.20798</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idc5af2871-b5ff-4ec8-9fcc-5b6e505411c9">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>第七期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015712</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832308.907</fme:EASTING>
<fme:NORTHING>822073.222</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282650</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822073.43598 832308.72201</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id6de7df61-10c3-4d76-a978-04b50fb0acc3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>第一期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015713</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832261.081</fme:EASTING>
<fme:NORTHING>821966.405</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282651</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821966.61891 832261.21330</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idccd26fbf-5f99-403c-a781-e40cc66f981a">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>第八期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015714</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832647.215</fme:EASTING>
<fme:NORTHING>821733.263</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282655</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821733.47678 832647.15333</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="iddbbe6d81-1c9b-4647-86ed-5430ef83f8d3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>第三期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015715</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832477.125</fme:EASTING>
<fme:NORTHING>821888.504</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282653</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821888.71781 832476.75447</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idec1d7501-7170-4fa1-a8c9-cac9827a2588">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>第二期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015716</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832356.644</fme:EASTING>
<fme:NORTHING>821955.663</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282652</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821955.87643 832356.36654</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id174406bb-dc62-4357-9d0f-fb3075110b4b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>第四期</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015717</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832615.56</fme:EASTING>
<fme:NORTHING>821877.854</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282654</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821878.06723 832615.24676</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9f137828-f6bc-4d30-81aa-05cad18bc244">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>翠雅山房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017470</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832747.262</fme:EASTING>
<fme:NORTHING>822191.982</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>80264</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006652</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822192.19556 832746.87823</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id10c1bcd0-278a-4186-9dc5-c7e9928eff5c">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>食物環境衛生署
運輸組達美路車房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.3844158819361</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017490</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832150.678</fme:EASTING>
<fme:NORTHING>821589.913</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821590.42376 832150.90909</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id3b726fa0-c4df-4e50-b113-dcad764c80ed">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>排水口</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017491</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832976.589</fme:EASTING>
<fme:NORTHING>821124.295</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>80211</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210005258</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821124.50845 832976.05569</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idbe9c4bbe-5408-476a-8261-80d224b4cabf">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>凱德苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017510</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833626.663</fme:EASTING>
<fme:NORTHING>821305.411</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210010560</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821305.66696 833627.16009</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idae1c888f-3278-48b0-9151-2908ac57c387">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海達邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310018290</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833567.612</fme:EASTING>
<fme:NORTHING>821212.533</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210009885</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821212.78929 833567.75433</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idc93666e0-eff6-4d04-8c19-2f6117890779">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>車廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310022130</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833096.339</fme:EASTING>
<fme:NORTHING>821181.839</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015166</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821182.05311 833096.21606</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idd0797011-094d-4901-a80e-ddef7e1a50f3">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵青貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>9.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310022630</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831038.254</fme:EASTING>
<fme:NORTHING>821845.219</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015111</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821845.60319 831038.25433</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id4b2ba1da-912d-46ff-be6b-883e0712cda8">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>污水泵房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310022670</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832999.458</fme:EASTING>
<fme:NORTHING>821731.367</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310014626</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821731.58091 832999.45765</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idcb524842-ef78-4998-884f-e4f56edcc066">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>嘉里鴻基貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310022671</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833660.925</fme:EASTING>
<fme:NORTHING>821482.609</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310014596</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821482.82268 833660.92455</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id21c042ff-9c92-4914-b436-915c7960da3b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>社會服務中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>51.7288522594114</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310022690</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831613.22</fme:EASTING>
<fme:NORTHING>822958.905</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015813</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822959.03752 831613.05254</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
