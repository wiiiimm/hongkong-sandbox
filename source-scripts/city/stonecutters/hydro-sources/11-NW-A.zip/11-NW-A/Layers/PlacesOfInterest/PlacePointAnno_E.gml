<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821050.24544 830039.41817</gml:lowerCorner>
<gml:upperCorner>823944.94023 833627.15991</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9263d28e-88fc-4334-9236-d49fac8b51c3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI CHI KOK</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971888</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>832825.335</fme:EASTING>
<fme:NORTHING>821683.642</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278598</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821683.64207 832825.33466</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id81eac259-6373-404d-9ad4-da1b02f6ec0d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tai Ching Cheung</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.329400780486794</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971919</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>832535.603</fme:EASTING>
<fme:NORTHING>822876.25</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75079</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278596</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822876.25001 832535.60311</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id183ecdf2-e7f6-4d6d-915e-f7e5f6a52438">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Kau Wa Keng
San Tsuen</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.311387040274828</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971916</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>831809.98368905</fme:EASTING>
<fme:NORTHING>822949.2933955</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>68169</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278594</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822958.66738 831864.33150</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id8e9b7672-4d0d-4956-a5da-850471d123ad">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Mei Foo Sun Chuen</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.481718797495251</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971890</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832418.199</fme:EASTING>
<fme:NORTHING>822139.702</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279438</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822139.70161 832418.19913</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idd39a6b79-4470-45fd-94c2-fb42ee1090c9">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Aqua Marine</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971913</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833342.747</fme:EASTING>
<fme:NORTHING>821529.737</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79335</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281530</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821529.73733 833342.74680</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="ide0785b6a-de28-4c38-a893-4d859fef8fd1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Banyan Garden</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971909</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833252.575</fme:EASTING>
<fme:NORTHING>821663.396</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79185</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281266</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821663.39611 833252.57506</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idca2cd0fd-8bb0-4e15-b3c0-f0fa24b62a95">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cheung Hang
Village</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971917</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>832393.61436523</fme:EASTING>
<fme:NORTHING>823622.62777621</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>68338</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280924</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823631.55905 832441.96181</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id984f9078-ee11-45b9-9acc-84b34d73cee7">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cheung Sha Wan Plaza</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.3804491582151</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971927</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833308.47316549</fme:EASTING>
<fme:NORTHING>821968.17937104</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821990.97509 833363.42344</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9b4b8a24-5cfa-420f-b805-90616589191e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Kau Wa Keng</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971918</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>832086.86135643</fme:EASTING>
<fme:NORTHING>822875.45134013</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>68170</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278595</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822875.45134 832086.86136</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id04f9a406-23d8-4f64-bf7f-8b869b07f3d1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HA KWAI CHUNG</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971886</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>831347.736</fme:EASTING>
<fme:NORTHING>823594.563</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278585</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823594.56282 831347.73615</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idef60e6ed-1e62-43a2-b6ea-fe0b7f600b90">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hoi Lai Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-38.659803975944</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971911</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833121.03351454</fme:EASTING>
<fme:NORTHING>821454.65692441</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79462</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281561</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821420.20571 833161.87158</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id32c46806-6e80-4646-9e8e-7ab4de1026ac">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open
Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.149207421856732</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971924</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830770.5</fme:EASTING>
<fme:NORTHING>823257.75</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823265.36883 830788.37433</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id1d25686b-fe7d-4951-a4fd-7e21286b9cbc">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Caldecott Hill</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971908</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833461.839</fme:EASTING>
<fme:NORTHING>822869.104</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79452</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281526</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822869.10369 833461.83942</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="ida62dc015-251c-487c-9c56-e391d842713d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG SHA WAN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>12</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971887</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>833627.16</fme:EASTING>
<fme:NORTHING>822114.852</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278601</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822114.85218 833627.15991</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id46328aa0-1239-41d8-8796-20b75ce76c50">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Liberte</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971904</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833375.428</fme:EASTING>
<fme:NORTHING>821705.411</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79184</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281270</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821705.41123 833375.42835</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idfa5f5bd2-efea-406b-b9f5-72e86b427827">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KOWLOON BYEWASH RESERVOIR</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>42.9599986097345</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971951</fme:FEATURE_ID>
<fme:FEATURECODE>RES</fme:FEATURECODE>
<fme:EASTING>833593.54</fme:EASTING>
<fme:NORTHING>823453.221</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310012166</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823453.22083 833593.53999</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id7e316d60-48a8-46c8-84ce-4a131bb026e3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai King Terrace</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971898</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831782.684</fme:EASTING>
<fme:NORTHING>822292.472</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77886</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280181</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822292.47222 831782.68419</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id2ab40224-34c9-4b93-94f5-d5887403570b">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cargo Handling Area</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.7760777178947</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971922</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830034.4375</fme:EASTING>
<fme:NORTHING>823822.25</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823871.99501 830039.41817</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="ida9f30d20-0cb1-4702-8fb0-39507d4ccc75">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>The Pacifica</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-86.0881325534473</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971910</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833444.873</fme:EASTING>
<fme:NORTHING>821733.804</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79334</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281493</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821733.80421 833444.87257</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idd7858ee5-4218-4784-a725-7653c5af2258">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai King Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.0298415491313845</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971895</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831069.15</fme:EASTING>
<fme:NORTHING>823452.771</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75236</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310012312</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823452.77054 831069.15034</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idde5f5c20-46ab-4450-8005-5ef1df9ee0eb">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Ching Lai Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971902</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831922.914</fme:EASTING>
<fme:NORTHING>822201.688</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75040</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278600</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822201.68794 831922.91411</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id4379523f-2042-4c5d-80ba-3836b06f2f64">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Manhattan Hill</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.2657654788151</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971915</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832715.29</fme:EASTING>
<fme:NORTHING>821810.157</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79749</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281593</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821810.15662 832715.28982</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idab9b65b9-0bb5-49e6-88e0-902baa24ce81">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Wah Lai Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971897</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832229.713</fme:EASTING>
<fme:NORTHING>822590.58</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77063</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280965</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822590.58048 832229.71251</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id45e99291-720c-46b7-86ba-89076934667e">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Shek Lei Pui
Water Treatment Works</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971939</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832912.926</fme:EASTING>
<fme:NORTHING>823359.923</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71194</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283869</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823359.88415 832912.92643</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id4463c47f-a52e-4827-89d9-275af37f1ea9">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Yuet Lai
Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.354158961659642</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971889</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831133.19</fme:EASTING>
<fme:NORTHING>823172.622</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75552</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278592</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823172.58004 831133.18980</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idf4342b81-2ea7-42b8-9c6e-2aa0267aeb07">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tunnel Portal</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971940</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833208.88000182</fme:EASTING>
<fme:NORTHING>822979.34679626</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822999.52922 833232.72299</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idea4a055c-ba42-4d32-af55-453ae755c554">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Yin Lai
Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971894</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831059.203</fme:EASTING>
<fme:NORTHING>823337.868</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75239</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282387</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823337.82885 831059.20305</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id8df371da-c97e-4187-9a04-28a2ae278b1f">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>The Caldecott</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971912</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833542.256</fme:EASTING>
<fme:NORTHING>822777.796</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79451</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281515</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822777.79598 833542.25642</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id1aa2eb36-3f3c-4a5e-9926-0deea191cbbc">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Happy
Villa</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971899</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832212.954</fme:EASTING>
<fme:NORTHING>822676.071</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76839</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280188</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822676.03207 832212.95405</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id7d6709dd-44be-4f6e-89df-0590b24d3cb9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SHEK LEI PUI RESERVOIR</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971952</fme:FEATURE_ID>
<fme:FEATURECODE>RES</fme:FEATURECODE>
<fme:EASTING>833350.031</fme:EASTING>
<fme:NORTHING>823944.94</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310012158</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823944.94023 833350.03137</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idf97dcf1a-0838-4a20-8ed3-8292d3ab7fd0">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cho Yiu Chuen</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971907</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831239.97</fme:EASTING>
<fme:NORTHING>823053.965</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75572</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310012214</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823053.96519 831239.96999</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id72628bb4-047c-4992-9e7d-7f39dbd55ae3">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971937</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831906.243005</fme:EASTING>
<fme:NORTHING>821568.826975</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821568.82698 831906.24301</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id5ee9176d-e3c6-4639-8db7-5a05f5534056">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Shipyard</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-32.118017487832</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971929</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832852.708</fme:EASTING>
<fme:NORTHING>821062.558</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283505</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821062.55813 832852.70775</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id36df0210-85ef-4397-862b-582af0f25d24">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Shek Lei Tau</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971920</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>832433.10160358</fme:EASTING>
<fme:NORTHING>823306.56892079</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64119</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278597</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823306.43203 832489.32756</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id20ff52f8-16b1-4532-a061-8638a36cb202">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>BUTTERFLY VALLEY</fme:TextString>
<fme:FontName>Candara</fme:FontName>
<fme:FontSize>9.00000000223099</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971954</fme:FEATURE_ID>
<fme:FEATURECODE>HIL</fme:FEATURECODE>
<fme:EASTING>832893.192</fme:EASTING>
<fme:NORTHING>822817.676</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001282090</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822817.67604 832893.73089</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idfa6166df-48a0-4a66-9ce1-d2a73d457c7f">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971923</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830744.3125</fme:EASTING>
<fme:NORTHING>823436.3125</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823439.37002 830777.03021</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id424383ba-9f26-462d-a38f-d83478f2887d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KOWLOON RECEPTION
RESERVOIR</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971953</fme:FEATURE_ID>
<fme:FEATURECODE>RES</fme:FEATURECODE>
<fme:EASTING>833032.743</fme:EASTING>
<fme:NORTHING>823517.999</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310012164</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823517.95696 833032.74298</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id23048139-1505-4bc5-961d-50ede3f04f96">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Nob Hill</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971901</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832130.496</fme:EASTING>
<fme:NORTHING>822493.101</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76864</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281078</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822493.10121 832130.49602</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idfb74e25e-b617-4a80-99e8-e76ff2dcf241">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Regency Park</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971900</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832214.104</fme:EASTING>
<fme:NORTHING>823543.096</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75783</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278591</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823543.09553 832214.10443</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id65e195ee-fa31-4a4b-b0b8-b54361fdb7a1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Wonderland
Villas</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>1.06847541268739</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971903</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831921.82336871</fme:EASTING>
<fme:NORTHING>823905.4472109</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75167</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278590</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823915.21651 831970.17280</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id4cdb49be-4264-47ea-9004-d4c3514b6fe5">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai Yan
Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971906</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832135.122</fme:EASTING>
<fme:NORTHING>822648.424</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76863</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280986</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822648.38224 832135.12243</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id29eac693-f911-4023-864d-9214dbcf243d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Wah Yuen
Chuen</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.306938739709203</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971891</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831966.895</fme:EASTING>
<fme:NORTHING>823468.202</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75165</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279876</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823468.16013 831966.89464</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id1c86023d-b381-4ce2-aa61-c7690b6098b7">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai Yiu Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.852552839732753</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971896</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831566.982</fme:EASTING>
<fme:NORTHING>823849.739</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75169</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310012225</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20231217</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823849.73913 831566.98179</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id981433ae-fcd6-4cdc-80bc-d290a36747e0">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Highland Park</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000971893</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>831428.551</fme:EASTING>
<fme:NORTHING>823326.758</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76697</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280849</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823326.75806 831428.55142</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idf1fb47a4-34f2-4efc-a484-620a7c87b51a">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Golden Industrial Building</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.1206895059598</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004885</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830786.024</fme:EASTING>
<fme:NORTHING>823808.174</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283796</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823808.17443 830786.02450</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idf67b49f1-ae8e-46c8-9bae-7e706bccaa69">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Ever Gain Plaza</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.4427519488454</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004887</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830879.685</fme:EASTING>
<fme:NORTHING>823737.288</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283621</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823737.28825 830879.68485</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id24c6f919-1212-486d-9a34-c87c55ab305b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Shek Lei Pui
Fresh Water
Service Reservoir</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.151978741944176</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004888</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>833031.145</fme:EASTING>
<fme:NORTHING>823288.318</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210002403</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823288.24071 833031.14491</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idee4b49e5-5ca3-49fe-850d-4dd22fdc11f1">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tai Po Road
Water Treatment
Works</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004903</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833345.465</fme:EASTING>
<fme:NORTHING>823066.085</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71193</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283870</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823066.00724 833345.46479</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idbe46d23c-8c34-4c17-96e5-f315cc5affe3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Butterfly Valley
Fresh Water Primary
Service Reservoir</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004923</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>833078.235</fme:EASTING>
<fme:NORTHING>822566.209</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70422</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002402</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822566.13098 833078.23497</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id18a0fdcc-8ee0-4d07-ba43-f9b1794259ce">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Jao Tsung-I Academy</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004943</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832688.253</fme:EASTING>
<fme:NORTHING>822126.996</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75080</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007906</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822126.99573 832688.25285</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id0ffe361f-4ddf-4b87-aebf-2a12cacdb8b6">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Kwai Shun
Industrial Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.3924996864055</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004983</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830830.817</fme:EASTING>
<fme:NORTHING>823781.304</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210005326</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823781.28908 830830.85234</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id45c0a41c-6e51-46e4-983b-417fe027cb96">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>The Neighbourhood
Advice-Action
Council Fairyland</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005044</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832682.988</fme:EASTING>
<fme:NORTHING>822866.974</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>72126</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210004874</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822866.89659 832682.98765</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="iddec2dc66-e335-4502-851e-4a1ea47c47e6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lai Chi Kok 
Fresh Water 
Service Reservoir</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008559</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>831709.883</fme:EASTING>
<fme:NORTHING>822858.433</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77881</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002511</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822858.35568 831709.88341</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id8d4b54d1-4d8c-45d8-a228-36fb247c420c">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hoi Ying Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012419</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833337.769</fme:EASTING>
<fme:NORTHING>821050.245</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82683</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210009947</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821050.24544 833337.76870</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id56e651d8-8818-486e-988e-9dada287591d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stage 5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012979</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832394.525</fme:EASTING>
<fme:NORTHING>822256.709</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282648</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822256.70930 832394.52548</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9796398d-5b77-4f09-b171-d49c4b4e97cd">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stage 6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012980</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832444.819</fme:EASTING>
<fme:NORTHING>822189.394</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282649</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822189.39435 832444.81945</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id5fd5aeb6-c4c6-443f-a156-63d96c27864d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stage 7</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012981</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832310.776</fme:EASTING>
<fme:NORTHING>822062.093</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282650</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822062.09341 832310.77647</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id636493b7-44d6-4f57-9ae8-d7e91311cad9">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stage 1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012982</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832263.013</fme:EASTING>
<fme:NORTHING>821955.191</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282651</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821955.19092 832263.01261</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id631582ff-7072-4fa9-a3de-6fdcccb3b12e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stage 8</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012983</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832649.076</fme:EASTING>
<fme:NORTHING>821721.856</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282655</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821721.85610 832649.07567</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idca7eb57f-77f4-4b59-8642-84cf741b72bc">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stage 3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012984</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832473.586</fme:EASTING>
<fme:NORTHING>821878.11</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282653</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821878.10957 832473.58581</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id98a765cd-8da3-4a88-a10b-372a4069baf8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stage 2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012985</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832348.553</fme:EASTING>
<fme:NORTHING>821943.603</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282652</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821943.60264 832348.55295</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id403f971f-9b76-4315-95a3-f8246ce174f8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stage 4</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012986</fme:FEATURE_ID>
<fme:FEATURECODE>SUS</fme:FEATURECODE>
<fme:EASTING>832616.85</fme:EASTING>
<fme:NORTHING>821867.191</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001282654</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821867.19070 832616.85031</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id583ed5f4-711e-4226-abb7-233e4d33e4b5">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Mei Foo Sun Chuen</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012987</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>832414.218</fme:EASTING>
<fme:NORTHING>821900.274</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75041</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279438</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821900.27444 832414.21789</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id8e0e6840-c379-4f3b-9a8a-7f171a00c1f4">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Heritage Lodge</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017470</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832754.181</fme:EASTING>
<fme:NORTHING>822180.705</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>80264</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006652</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822180.70455 832754.18127</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id141a4968-790f-4442-b620-43fe2d21db98">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hoi Tak Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014619</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833625.473</fme:EASTING>
<fme:NORTHING>821293.207</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210010560</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821293.20710 833625.47253</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id94168a89-c4a4-4d9b-94c2-b72cada3af4f">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hoi Tat Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310015120</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833575.011</fme:EASTING>
<fme:NORTHING>821193.746</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210009885</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821193.74597 833575.01130</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idad043f3d-d773-4dc6-9a73-7a8d7bee00b6">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>DEPOT</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310017660</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833096.076</fme:EASTING>
<fme:NORTHING>821170.02</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015166</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821170.02048 833096.07627</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idfa39cd86-bc36-4525-89fc-726d74e49772">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Kwai Tsing Container Terminals</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>9</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310017901</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831033.761</fme:EASTING>
<fme:NORTHING>821811.022</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015111</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821811.02222 831033.76097</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id23e80267-fba3-4c3a-a2fc-2fdb97193674">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Portas</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310013856</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833140.738</fme:EASTING>
<fme:NORTHING>822256.296</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310016854</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250619</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822256.29570 833140.73811</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
