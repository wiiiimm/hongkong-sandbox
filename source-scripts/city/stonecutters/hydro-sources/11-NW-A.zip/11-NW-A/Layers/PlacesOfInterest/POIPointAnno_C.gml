<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821027.29742 830063.39203</gml:lowerCorner>
<gml:upperCorner>823931.47259 833707.12556</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id2bb51def-1966-4c00-afbe-8e62262f70eb">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>深水埗運動場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.3257406247677</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001088992</fme:FEATURE_ID>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:EASTING>833701.715</fme:EASTING>
<fme:NORTHING>821995.102</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986077</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821995.80534 833702.02048</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id12fc07e8-e181-4334-9a8e-fd94910fc5f0">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角公園游泳池</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001088988</fme:FEATURE_ID>
<fme:FEATURECODE>SPL</fme:FEATURECODE>
<fme:EASTING>832202.851</fme:EASTING>
<fme:NORTHING>822352.482</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986099</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822352.69547 832202.85121</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id66b01efe-b948-437b-805f-b80c2c5eb692">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>瑪嘉烈醫院</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001088986</fme:FEATURE_ID>
<fme:FEATURECODE>HOS</fme:FEATURECODE>
<fme:EASTING>831923.026</fme:EASTING>
<fme:NORTHING>822353.977</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985912</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822353.97682 831923.02593</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idf0775d1e-ae62-4486-b14f-ee06d643d3ee">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌醫院</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001088985</fme:FEATURE_ID>
<fme:FEATURECODE>HOS</fme:FEATURECODE>
<fme:EASTING>831776.89</fme:EASTING>
<fme:NORTHING>822648.66</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985914</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822632.99861 831783.45168</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id55cc6750-a18b-44f8-a211-ecf4d98920e3">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>聖辣法厄爾天主教墳場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001088982</fme:FEATURE_ID>
<fme:FEATURECODE>CEM</fme:FEATURECODE>
<fme:EASTING>833356.22</fme:EASTING>
<fme:NORTHING>822530.792</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986109</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822531.00541 833356.21962</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id7b9e8cb1-8f25-4595-a79f-5b0d2874f8ad">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角公園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001088989</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>832321.872</fme:EASTING>
<fme:NORTHING>821672.351</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985960</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821672.56429 832321.81474</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id1ec5b43c-d572-4149-bbf0-bfc63f662ff4">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>家禽批發市場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>29.473984111379</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001088984</fme:FEATURE_ID>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:EASTING>833585.335</fme:EASTING>
<fme:NORTHING>821810.992</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985933</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821811.43626 833585.68630</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id2b39fa4f-4600-471b-a4a6-8255c686edab">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>國際小輪車場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000064</fme:FEATURE_ID>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:EASTING>830116.317</fme:EASTING>
<fme:NORTHING>823723.556</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823723.76998 830116.66076</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id4fedd56e-c2a1-43ca-be7a-125eb9b275ef">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-53.8067936609042</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001557</fme:FEATURE_ID>
<fme:FEATURECODE>RSN</fme:FEATURECODE>
<fme:EASTING>831033.60018781</fme:EASTING>
<fme:NORTHING>823279.33456636</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008870</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823269.74206 831044.17087</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idd3492132-2754-44c2-b7ff-c105e2ecd65c">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>永康街
休憩花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005369</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>833635.27</fme:EASTING>
<fme:NORTHING>822350.977</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985955</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822351.53720 833635.26986</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id50e202f3-7184-4a5d-abc8-85d97809a00a">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角收押所</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>19.1511027958107</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005370</fme:FEATURE_ID>
<fme:FEATURECODE>CSD</fme:FEATURECODE>
<fme:EASTING>832827.093</fme:EASTING>
<fme:NORTHING>822109.326</fme:NORTHING>
<fme:LINKFEATURE_ID>1210020149</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822109.61460 832827.27324</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id29c062aa-3798-4c17-8614-29a90a1a7c1f">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長沙灣
警署</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005371</fme:FEATURE_ID>
<fme:FEATURECODE>PSN</fme:FEATURECODE>
<fme:EASTING>833130.047</fme:EASTING>
<fme:NORTHING>821825.385</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986012</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821825.94533 833130.04713</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id44f7ea42-5c4a-4012-9330-bee70c872882">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景
體育館</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005559</fme:FEATURE_ID>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:EASTING>831202.894</fme:EASTING>
<fme:NORTHING>823403.241</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985916</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823403.80147 831202.89421</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id295ca3d7-a73e-4826-9ec5-fed4da694c35">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵順街遊樂場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005694</fme:FEATURE_ID>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:EASTING>830840.292</fme:EASTING>
<fme:NORTHING>823915.51</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986006</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823914.74120 830841.36300</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id87007041-355b-494f-8139-f16f19cde585">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角公園
體育館</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-55.6697837128902</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005697</fme:FEATURE_ID>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:EASTING>832280.211</fme:EASTING>
<fme:NORTHING>822398.047</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985915</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822398.36281 832280.67397</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idb27fb0f2-fa7c-434e-92fd-4e53765fb875">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角
政府合署</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005698</fme:FEATURE_ID>
<fme:FEATURECODE>GOF</fme:FEATURECODE>
<fme:EASTING>832322.004</fme:EASTING>
<fme:NORTHING>822335.898</fme:NORTHING>
<fme:LINKFEATURE_ID>1000985910</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822336.45843 832322.00360</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idb2c49a48-4bc5-428c-940b-8fb4e8e835d8">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.6051206732161</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005699</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>832386.699</fme:EASTING>
<fme:NORTHING>822089.152</fme:NORTHING>
<fme:LINKFEATURE_ID>1210011950</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822089.33366 832386.81566</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idd0ecad8c-b9ef-4eff-bd70-97cf9826890d">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景山路
遊樂場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008897</fme:FEATURE_ID>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:EASTING>831201.806</fme:EASTING>
<fme:NORTHING>822949.992</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986007</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822950.55240 831201.80574</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id17a7076e-dfdc-4104-9d1f-3a4f1438452a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>中葵涌公園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.880002373791921</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008917</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>831725.411</fme:EASTING>
<fme:NORTHING>823931.252</fme:NORTHING>
<fme:LINKFEATURE_ID>1000982946</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823931.47259 831724.96928</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idcbe9b190-ee0d-47bb-afe5-adc1b318e751">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>琵琶山運動場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008918</fme:FEATURE_ID>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:EASTING>833449.369</fme:EASTING>
<fme:NORTHING>822767.993</fme:NORTHING>
<fme:LINKFEATURE_ID>1000986094</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822768.20638 833449.55856</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id70989209-17d4-4a5e-95a5-9406d32964eb">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>一號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010405</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830563.827</fme:EASTING>
<fme:NORTHING>823262.019</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034528</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823262.27580 830565.06000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id2c580a13-459e-45bf-9f06-952b6ff50e6e">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>五號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010406</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830177.376</fme:EASTING>
<fme:NORTHING>823279.763</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034872</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823280.01903 830178.26502</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idd70353f1-a28e-4544-8c0f-78e2e905cbfe">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>二號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010409</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830607.083</fme:EASTING>
<fme:NORTHING>822986.977</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034967</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822987.23383 830607.82352</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id01b40b9b-fe48-4bbe-abe5-c5fa61f0c20c">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>三號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010410</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830680.454</fme:EASTING>
<fme:NORTHING>822609.882</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034534</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822610.13816 830681.08370</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id6eba8dd8-fa0a-4a36-9071-93f1a2c44d57">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>四號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010421</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>831079.457</fme:EASTING>
<fme:NORTHING>822292.137</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034529</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822292.39330 831080.15558</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idf439d283-ae47-4e5b-8cd9-64e280ac781b">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>六號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010422</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>831204.403</fme:EASTING>
<fme:NORTHING>821694.248</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034966</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821694.50409 831205.33368</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idb2d6c60b-7550-4746-9c12-0a23df8ca10a">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渡頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010423</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832960.183</fme:EASTING>
<fme:NORTHING>821027.084</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034707</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821027.29742 832960.26270</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idd14f5dd0-e853-41f9-9975-f59a103dbf9f">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>七號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010424</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>831420.854</fme:EASTING>
<fme:NORTHING>821423.535</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034965</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821423.79090 831421.70526</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id3b3a42a9-e38f-4b9b-bd0c-80947d5b46c7">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>八號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010461</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>832064.907</fme:EASTING>
<fme:NORTHING>821072.722</fme:NORTHING>
<fme:LINKFEATURE_ID>1210036012</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821072.97825 832065.90660</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id820698dc-7f5a-4c06-8d17-9e83e04e0505">
<fme:AnnotationClassID>7</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔景訓練中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011802</fme:FEATURE_ID>
<fme:FEATURECODE>TEI</fme:FEATURECODE>
<fme:EASTING>831112.528</fme:EASTING>
<fme:NORTHING>823072.95</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021146</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823072.81654 831112.52805</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id389ed7e2-18e8-415c-8dd3-74686fa1fbd7">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>興華街西
遊樂場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014190</fme:FEATURE_ID>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:EASTING>833484.672</fme:EASTING>
<fme:NORTHING>821500.323</fme:NORTHING>
<fme:LINKFEATURE_ID>1210032792</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821500.88393 833484.67195</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id7c26a472-10ff-4eb9-b709-f9df96fb13d7">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>勵敬懲教所</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015311</fme:FEATURE_ID>
<fme:FEATURECODE>CSD</fme:FEATURECODE>
<fme:EASTING>831698.974</fme:EASTING>
<fme:NORTHING>823081.171</fme:NORTHING>
<fme:LINKFEATURE_ID>1210021377</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823081.38511 831696.31452</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id9424e7c4-b850-4d82-957c-47f302af689f">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>麗新
商業中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015331</fme:FEATURE_ID>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:EASTING>833707.126</fme:EASTING>
<fme:NORTHING>822217.493</fme:NORTHING>
<fme:LINKFEATURE_ID>1210031927</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822218.05325 833707.12556</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idf0ce17a9-5ebb-4eb3-9aaf-46b1ae1fe047">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>極限運動場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.7273210697185</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015351</fme:FEATURE_ID>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:EASTING>832130.607</fme:EASTING>
<fme:NORTHING>821803.325</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821802.98722 832130.96737</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id7a1c8341-512d-46a2-9477-a39d8687c8eb">
<fme:AnnotationClassID>7</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>宣道國際學校</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.2221596429552</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310017893</fme:FEATURE_ID>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:EASTING>832994.038</fme:EASTING>
<fme:NORTHING>822232.17</fme:NORTHING>
<fme:LINKFEATURE_ID>1210040258</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20231115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822232.42655 832994.11696</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id747575ca-532b-4e74-b867-50884aa8c778">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000662</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>830062.493</fme:EASTING>
<fme:NORTHING>821452.998</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821453.21165 830063.39203</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id85802eb6-c156-4f61-8530-e0c9e04c666f">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵涌公園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010002235174</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420001422</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>830141.976</fme:EASTING>
<fme:NORTHING>823868.628</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823868.84208 830141.92768</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id54a53c09-8775-4dd1-87cd-365078949d7b">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>石油氣瓶裝車
停車場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420001242</fme:FEATURE_ID>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:EASTING>831967.324</fme:EASTING>
<fme:NORTHING>822010.145</fme:NORTHING>
<fme:LINKFEATURE_ID>1420002646</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20251115</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822010.70539 831967.32447</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idca56f343-7b98-42c7-a5f8-4fc112c5ba8f">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>荔枝角公園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001088990</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>832230.51</fme:EASTING>
<fme:NORTHING>822184.077</fme:NORTHING>
<fme:LINKFEATURE_ID>1420004178</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822184.29076 832230.45245</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
