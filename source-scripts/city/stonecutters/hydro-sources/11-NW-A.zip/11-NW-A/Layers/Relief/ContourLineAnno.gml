<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme ContourLineAnno.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>822152.61643 830110.81951</gml:lowerCorner>
<gml:upperCorner>823980.55423 833731.37474</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id56441c86-1dbf-4d9a-8815-ce221dc7652f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>81.3044631754412</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103387</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832749.353</fme:EASTING>
<fme:NORTHING>822557.17</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822557.17048 832749.35251</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id8387c3b9-51b0-4a8b-8754-f0fd25ee788c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>70.3461712689064</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103373</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833228.456991</fme:EASTING>
<fme:NORTHING>823894.5290345</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823903.22025 833228.31433</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idb2d25849-d7d1-4460-98a7-33d6eaa59d6a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-77.0535260016339</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103427</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832446.05359721</fme:EASTING>
<fme:NORTHING>823605.42400537</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823598.17897 832450.85640</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idd60c2d9f-0769-4704-8cfe-629506ab1312">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-84.1439591267958</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103393</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>830977.64901345</fme:EASTING>
<fme:NORTHING>823085.6081911</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823074.15292 830978.82392</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id3955de0d-9bd0-4a59-844d-2461c84b431d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.723608349374</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103420</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831946.19049257</fme:EASTING>
<fme:NORTHING>823705.18962607</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823703.51179 831954.71941</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id1f20344f-90fd-45e4-9d83-5af58f90a847">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.6306779428275</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103374</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833191.6323633</fme:EASTING>
<fme:NORTHING>823597.8187681</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823606.04863 833194.43004</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id42ebb16f-bb8d-492c-9306-756bb475cf51">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-5.19448366674276</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103391</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831543.17609789</fme:EASTING>
<fme:NORTHING>822874.38873536</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822873.65205 831551.27959</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id244d1ca1-51d8-45f3-b9a6-7666bccc97a8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>39.5596576207535</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103406</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831377.53912694</fme:EASTING>
<fme:NORTHING>823497.52895182</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823504.03171 831385.41090</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="ide09481d6-1305-45c9-87b5-98de1294d13c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>32.0053683790423</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103396</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831865.91975472</fme:EASTING>
<fme:NORTHING>823881.50434043</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823888.40967 831871.19935</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id00c7d8f2-58ae-4318-b7ab-e20e88f48438">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.5560794059551</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103382</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832572.4063778</fme:EASTING>
<fme:NORTHING>823246.670841</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823240.52849 832578.55692</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id328d5b23-aae7-48f5-99c0-f9b490478959">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>63.4349615501006</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103411</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833300.31392582</fme:EASTING>
<fme:NORTHING>823110.216949</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823118.86219 833301.21813</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc6297dbe-7072-4ff4-b869-27d9b7c965f4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-85.0302396120754</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103436</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832449.56082625</fme:EASTING>
<fme:NORTHING>822451.58215121</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822446.57224 832453.06555</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id9274363b-6433-418f-8ae6-11594f77b2a3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>85.6013105672966</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103428</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832549.82549146</fme:EASTING>
<fme:NORTHING>823711.91866469</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823720.26609 832547.40104</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id515fa045-0fbd-4501-b306-ef4628811e4d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>140</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-15.376234609111</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103403</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>831589.21101155</fme:EASTING>
<fme:NORTHING>823035.16815179</fme:NORTHING>
<fme:CONTOURHEIGHT>140</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823033.62810 831594.81118</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id8e3f1089-f42d-4069-948e-5056078ad1dd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>57.1549589407454</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103431</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832897.7945485</fme:EASTING>
<fme:NORTHING>823241.89959195</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823248.13327 832901.81883</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6a8d1dfa-e890-41b5-a799-58dd4c877926">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-59.8586287738418</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103380</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833645.2761821</fme:EASTING>
<fme:NORTHING>822660.2392344</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822654.73782 833652.00613</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id7ecd3633-4d70-47e3-81d2-b28afb59d511">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>80</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-21.2505140081129</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103379</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832426.9906113</fme:EASTING>
<fme:NORTHING>822522.8891876</fme:NORTHING>
<fme:CONTOURHEIGHT>80</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822523.81978 832433.03348</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6afa6da2-02d1-45ab-ae08-d398c01a656f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103410</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832772.98864617</fme:EASTING>
<fme:NORTHING>822753.9679169</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822762.83426 832775.51977</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="ida1a515a2-5706-44d0-96e7-90ca1f391e8a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>30</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-74.0462804088405</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103400</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832632.251</fme:EASTING>
<fme:NORTHING>822152.616</fme:NORTHING>
<fme:CONTOURHEIGHT>30</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822152.61643 832632.25147</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id4605b440-7148-485a-9bd4-7cde0737d227">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>46.4687970495604</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103433</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833236.46125246</fme:EASTING>
<fme:NORTHING>823178.65839879</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823182.76321 833240.36082</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idff5edef8-9977-40c1-969b-3bbbd7355407">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-8.91494922533117</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103404</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>831549.93986136</fme:EASTING>
<fme:NORTHING>822673.7473489</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822672.62732 831557.08007</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idb3f79aee-1de8-4cab-985a-9ba059beafec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>22.9320833967351</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103429</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832657.06715359</fme:EASTING>
<fme:NORTHING>822586.74844169</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822592.73478 832663.36964</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id5cf7f92e-fcaa-41f1-ba7d-cb4458bc7111">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103413</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833182.45182813</fme:EASTING>
<fme:NORTHING>822815.08583258</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822821.78626 833188.74656</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id153bf3c3-d556-4e42-b1a2-30748da6a88d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>1.81500574607426</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103418</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831725.98592396</fme:EASTING>
<fme:NORTHING>823194.2287323</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823197.54244 831734.02190</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id87decf53-0699-430d-8848-296ea5479986">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>160</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>75.5792580203552</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103409</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>833654.52885183</fme:EASTING>
<fme:NORTHING>822945.81091393</fme:NORTHING>
<fme:CONTOURHEIGHT>160</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822954.45289 833653.59407</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id601cf354-7a06-4276-a112-e94fa6e19bf0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.4692417165876</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103408</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833695.34017355</fme:EASTING>
<fme:NORTHING>823965.43828506</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823963.06058 833703.70104</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6e19984b-a723-4c8c-bc2a-5adff1e55357">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-60.7511766571086</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103385</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833700.49414238</fme:EASTING>
<fme:NORTHING>823018.85971035</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823013.25414 833707.13757</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6335cf59-b11b-47ae-bcb1-e0d822e859a9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-34.8232246912364</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103398</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>830253.965</fme:EASTING>
<fme:NORTHING>823576.989</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823576.98874 830253.96469</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id7807d68a-ec32-41dc-9a97-bfb1e8d3292d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>130</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-58.1344471562716</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103368</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>831467.13730721</fme:EASTING>
<fme:NORTHING>823109.33017979</fme:NORTHING>
<fme:CONTOURHEIGHT>130</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823104.03375 831474.02974</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id8c867f10-7cea-44b3-83f1-edc0579546ef">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>30</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>42.3974877393866</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103378</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>831413.7955405</fme:EASTING>
<fme:NORTHING>822744.0629846</fme:NORTHING>
<fme:CONTOURHEIGHT>30</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822749.89097 831415.64399</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id9104d79e-04ef-4715-aa80-afa912623c70">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-2.96090339488102</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103402</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831714.94107629</fme:EASTING>
<fme:NORTHING>823437.90725411</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823437.62713 831720.35689</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idfc7d10a4-d4c7-4a9e-8654-bebd6f4d14d4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-33.6900784287078</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103370</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832351.9083001</fme:EASTING>
<fme:NORTHING>823253.0338622</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823251.06434 832360.37462</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc617ce96-aeed-4b9e-920f-d9a6f8629ff2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-44.6098092006218</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103417</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832016.47959245</fme:EASTING>
<fme:NORTHING>823122.07277405</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823120.53111 832022.39614</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idcea1e635-a490-440c-aaaf-37208f35c810">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-34.7960653691016</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103415</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833459.02082646</fme:EASTING>
<fme:NORTHING>822640.98474706</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822638.85218 833467.44756</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id2265305d-b6ea-4e86-9aa7-c756ea2cad52">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.9623955639194</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103383</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>831736.33330391</fme:EASTING>
<fme:NORTHING>822314.25892353</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822310.41474 831741.08772</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id9cdd4ab2-0523-4c95-85bc-f542e8877617">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.71615027250683</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103395</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833047.08319502</fme:EASTING>
<fme:NORTHING>823172.34383943</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823175.50283 833055.18125</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id3a449a49-50a6-4936-a12a-14ade54f82a0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-57.7243643766979</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103421</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832541.19806124</fme:EASTING>
<fme:NORTHING>823436.52083806</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823431.27387 832548.12821</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id802401cb-2f31-4fad-bd22-e88f2c012a43">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103412</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832388.61295553</fme:EASTING>
<fme:NORTHING>823849.92368321</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823853.65794 832396.99575</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6f738360-d2ea-4c13-84ce-af6533c54642">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>1.92192588775132</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103419</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831909.54849211</fme:EASTING>
<fme:NORTHING>823600.8037948</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823604.13249 831917.57827</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id04d2d74d-fb93-49ad-aad3-c82e9aeaa502">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-57.8477378517098</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103425</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833724.45589569</fme:EASTING>
<fme:NORTHING>823315.69499854</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823310.43313 833731.37474</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idb33a59fb-8204-4e25-8d86-150c17f276af">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-52.1249918310144</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103386</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833637.84582236</fme:EASTING>
<fme:NORTHING>822827.86335948</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822823.31762 833645.25486</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6cc4e652-03a0-41c9-a335-4c87c24f19c9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-32.2287927484523</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103392</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>831133.54130552</fme:EASTING>
<fme:NORTHING>822847.35073803</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822843.21324 831140.10424</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id17af32c0-fd0d-4534-b823-f1c254c6a9e1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>41.8880317648511</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103399</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832796.44</fme:EASTING>
<fme:NORTHING>822194.354</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822194.35366 832796.44006</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id605a7405-5ca4-4dd3-b45e-c1441822e8e9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-66.2973871467696</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103435</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832880.69525617</fme:EASTING>
<fme:NORTHING>822564.12332577</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822560.50437 832885.62328</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id1ca5ce1f-5af8-4f1c-9b61-6401f712f5c1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-5.48726311525061</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103416</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832360.21556903</fme:EASTING>
<fme:NORTHING>823341.23814911</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823343.50358 832368.60756</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idf6d78689-6443-4d77-8048-2e0808e6581b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103397</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>830104.46097922</fme:EASTING>
<fme:NORTHING>823469.09697401</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823471.52248 830110.81951</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idbb7975a5-5fca-4b32-ba4e-9a2d530846a3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>5.29012610105674</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103394</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832921.43443614</fme:EASTING>
<fme:NORTHING>823088.87091682</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823092.66564 832929.25478</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="iddbcc8d06-4fc6-4522-a210-7e2eb5d7617b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>27.8972876580283</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103377</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833643.4358682</fme:EASTING>
<fme:NORTHING>823338.1738078</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823344.68318 833649.19659</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id5cc08f7d-733b-49bd-96e5-bfbc88d25240">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>30</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-29.7449387171616</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103426</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>833561.19983894</fme:EASTING>
<fme:NORTHING>822397.73736943</fme:NORTHING>
<fme:CONTOURHEIGHT>30</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822397.76514 833567.31388</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idd711ab46-7f31-4aed-a4f4-ce7a488b8865">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-77.7352021860853</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103389</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832255.4033594</fme:EASTING>
<fme:NORTHING>822958.32644442</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822953.80211 832259.51586</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id40a4e46c-4c72-424e-b1ed-2ad4bbc6fed2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-23.8387259245832</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103401</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831420.05243909</fme:EASTING>
<fme:NORTHING>823243.27335407</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823239.99196 831427.47876</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id59789786-3b00-4b2f-81ee-5e662ca8943d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-74.4757844847001</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103369</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831837.4226996</fme:EASTING>
<fme:NORTHING>823109.1117459</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823104.82856 831841.78579</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="ide9d736e3-4681-4ec3-afcb-76f72826c913">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-62.1027347657021</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103372</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832602.5683134</fme:EASTING>
<fme:NORTHING>823887.5358249</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823881.77510 832609.07767</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id8c0157ba-399e-421c-944c-f8e7cb47144e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-28.8107994377779</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103430</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833097.54615833</fme:EASTING>
<fme:NORTHING>822431.00055755</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822429.75829 833106.14932</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc3b86a92-f54a-4814-9855-ea4e8dc5f79f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.2894004651463</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103432</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833556.48868147</fme:EASTING>
<fme:NORTHING>823667.05449329</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823663.06223 833561.36811</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id56a82306-f2a8-428c-9c09-8487a3c90e89">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-61.5570688988436</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103390</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831917.19315907</fme:EASTING>
<fme:NORTHING>822698.93775753</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822694.28218 831919.71493</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id76376e5c-5f84-476a-bac7-8b23daf3194c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>46.4687864655594</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103375</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833448.7021541</fme:EASTING>
<fme:NORTHING>823800.7692016</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823808.77432 833452.08973</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6ab0e755-3849-41fc-90fe-29c55808f269">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.5014173533892</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103388</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832428.21926843</fme:EASTING>
<fme:NORTHING>822827.77626425</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822825.39385 832436.57880</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc6af8f21-9a7a-490d-8b86-8ec76d3f4209">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-62.3005333705817</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103407</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832298.15553816</fme:EASTING>
<fme:NORTHING>823145.31169177</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823140.76477 832300.54268</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id05f35b7f-3e6f-4e65-adf4-2ce9450f962e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>37.0424696446477</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103405</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831348.56193602</fme:EASTING>
<fme:NORTHING>823580.3535517</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823584.91689 831354.60836</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id4e7913fa-08fc-459d-834a-cacac6deefc9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-57.0613108146627</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103423</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832352.82405022</fme:EASTING>
<fme:NORTHING>822942.69255784</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822937.52615 832359.81446</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id388679f0-c842-45b0-8c25-1bf0a62ff71a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-12.9946740393489</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103376</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833230.7733563</fme:EASTING>
<fme:NORTHING>823370.2433835</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823371.39294 833239.38940</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id27ae4d77-b752-4749-b561-327995feb7b5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103422</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833222.48564728</fme:EASTING>
<fme:NORTHING>823988.55593607</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823980.55423 833227.16580</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="ide715c6b8-94ba-482c-9b0b-f25771413f82">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-90</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103381</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832607.819482</fme:EASTING>
<fme:NORTHING>823485.7716567</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823477.63476 832610.87700</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc4b43975-49b3-4fd3-993e-5ca4d75d7a5d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-54.9587943072355</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103424</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833623.38632067</fme:EASTING>
<fme:NORTHING>822526.2591598</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822523.67972 833628.92967</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idf3d3072d-5f57-49ca-8d98-9bb78da7b22a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-59.7436502106468</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103434</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>833055.01937914</fme:EASTING>
<fme:NORTHING>823378.00982871</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823372.70954 833058.11121</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc15f0867-398e-4e74-a106-fb51a0a917b3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-64.7988358405986</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103371</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832776.4446933</fme:EASTING>
<fme:NORTHING>823823.4339533</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823817.37342 832782.67587</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
</gml:FeatureCollection>
