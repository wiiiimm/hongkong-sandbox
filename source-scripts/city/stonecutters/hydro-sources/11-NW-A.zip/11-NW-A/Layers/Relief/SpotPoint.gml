<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme SpotPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821008.23484 830024.43400 0.00000</gml:lowerCorner>
<gml:upperCorner>823986.65200 833725.79590 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:SpotPoint gml:id="id3e73ba6e-a249-4db3-ba7b-644ba4a51ea2">
<fme:FEATURE_ID>1001130017</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832180.11</fme:EASTING>
<fme:NORTHING>821008.23</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821008.23484 832180.10589 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0916de88-d3f4-41e4-a262-b0aa784dba57">
<fme:FEATURE_ID>1001130046</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833698.46</fme:EASTING>
<fme:NORTHING>821013.49</fme:NORTHING>
<fme:SPOTHEIGHT>11.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821013.49139 833698.46041 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida7bcc2c1-f9f9-4d8a-8c2e-3fd330d6c08a">
<fme:FEATURE_ID>1001130072</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833497.76</fme:EASTING>
<fme:NORTHING>821035.52</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821035.52133 833497.76299 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc9b96bc0-ec77-4884-9738-9a4b52153409">
<fme:FEATURE_ID>1001130071</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832212.8</fme:EASTING>
<fme:NORTHING>821044.52</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821044.52385 832212.79712 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id95d9650e-cf63-40b7-88e7-68f1f171c834">
<fme:FEATURE_ID>1001129761</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832857.55</fme:EASTING>
<fme:NORTHING>821048.07</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821048.06984 832857.55135 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id45b67c02-c20c-43d5-89c0-9f825156a195">
<fme:FEATURE_ID>1001129769</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832134.5</fme:EASTING>
<fme:NORTHING>821062.64</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821062.63925 832134.49955 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc59cde2c-0b53-43a7-b350-6cfc7bdcc252">
<fme:FEATURE_ID>1001130048</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833053.5</fme:EASTING>
<fme:NORTHING>821096.14</fme:NORTHING>
<fme:SPOTHEIGHT>6.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821096.14355 833053.49932 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id172328dd-65f1-4ea0-aeaa-e6502a2e006b">
<fme:FEATURE_ID>1001130013</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831979.04</fme:EASTING>
<fme:NORTHING>821110.12</fme:NORTHING>
<fme:SPOTHEIGHT>4.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821110.11588 831979.03553 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfef7383e-d71e-49b2-8ef7-438fad1af334">
<fme:FEATURE_ID>1001129969</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832412.92</fme:EASTING>
<fme:NORTHING>821140.14</fme:NORTHING>
<fme:SPOTHEIGHT>5.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821140.13859 832412.92114 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9d194a1a-56e8-48e5-84ca-9f80872eea33">
<fme:FEATURE_ID>1001129787</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833226.08</fme:EASTING>
<fme:NORTHING>821145.74</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821145.74035 833226.07682 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc7bb3f64-30f0-4c85-8f7d-9e103e2c8a6f">
<fme:FEATURE_ID>1310007850</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833478.46</fme:EASTING>
<fme:NORTHING>821167.91</fme:NORTHING>
<fme:SPOTHEIGHT>6.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821167.91329 833478.46337 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id12c5cb90-03c6-4a88-8a86-42e94d1f15aa">
<fme:FEATURE_ID>1001129758</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831221.54</fme:EASTING>
<fme:NORTHING>821194.69</fme:NORTHING>
<fme:SPOTHEIGHT>4.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821194.69232 831221.53581 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id939b78e0-c420-4a16-81c5-27d4bad2dff7">
<fme:FEATURE_ID>1001129977</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832868.8</fme:EASTING>
<fme:NORTHING>821200.11</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821200.11000 832868.80000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id70094579-2179-4ecc-93cd-35bf8942ae97">
<fme:FEATURE_ID>1001129978</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833143.87</fme:EASTING>
<fme:NORTHING>821210.63</fme:NORTHING>
<fme:SPOTHEIGHT>6.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821210.63379 833143.87318 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfdbe218b-520f-45e2-b30f-d13058812a5c">
<fme:FEATURE_ID>1001130049</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833639.29</fme:EASTING>
<fme:NORTHING>821215.43</fme:NORTHING>
<fme:SPOTHEIGHT>7.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821215.43139 833639.29197 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf6840b55-e887-4a73-9842-ba8503717022">
<fme:FEATURE_ID>1001129762</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832840.37</fme:EASTING>
<fme:NORTHING>821228.16</fme:NORTHING>
<fme:SPOTHEIGHT>7.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821228.16000 832840.37000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id463f3605-d013-409f-9618-3322db11593c">
<fme:FEATURE_ID>1001129765</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832670.69</fme:EASTING>
<fme:NORTHING>821240.03</fme:NORTHING>
<fme:SPOTHEIGHT>7.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821240.03000 832670.69000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcdc7a3e0-0f5f-439c-8acc-03da73b0e291">
<fme:FEATURE_ID>1001129976</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832894.25</fme:EASTING>
<fme:NORTHING>821262.3</fme:NORTHING>
<fme:SPOTHEIGHT>10.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821262.30000 832894.25000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id077d15b7-2758-4e69-8d4a-a3f74abcb2ec">
<fme:FEATURE_ID>1001130011</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831855.21</fme:EASTING>
<fme:NORTHING>821292.32</fme:NORTHING>
<fme:SPOTHEIGHT>4.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821292.31668 831855.20680 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1016a2bb-6573-4fc9-8f14-b5a8e06ba15a">
<fme:FEATURE_ID>1001129760</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832980.8</fme:EASTING>
<fme:NORTHING>821303.9</fme:NORTHING>
<fme:SPOTHEIGHT>21</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821303.89801 832980.80065 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf0830144-c0c2-4691-92fa-84ad414f25b7">
<fme:FEATURE_ID>1001130067</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833087.26</fme:EASTING>
<fme:NORTHING>821305.94</fme:NORTHING>
<fme:SPOTHEIGHT>5.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821305.94000 833087.26200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddc073580-98d0-4aa7-96eb-555a9667e118">
<fme:FEATURE_ID>1001130055</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830082.13</fme:EASTING>
<fme:NORTHING>821310.78</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821310.78207 830082.12794 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5b4ee871-c299-4a41-8816-d7e5bca32c19">
<fme:FEATURE_ID>1210003322</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832613.16</fme:EASTING>
<fme:NORTHING>821320.53</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821320.52900 832613.15600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1f62f130-3ed1-492f-a943-b74f4f6f855d">
<fme:FEATURE_ID>1001129763</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832808.4</fme:EASTING>
<fme:NORTHING>821347.75</fme:NORTHING>
<fme:SPOTHEIGHT>11.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821347.75000 832808.40000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5fea9243-0498-43a8-9601-c0ffa35a6b72">
<fme:FEATURE_ID>1001130043</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833139.28</fme:EASTING>
<fme:NORTHING>821362.85</fme:NORTHING>
<fme:SPOTHEIGHT>5.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821362.85119 833139.27708 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id48748e59-a3b2-4e98-ba28-631f6c4bb31e">
<fme:FEATURE_ID>1001130019</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832715.01</fme:EASTING>
<fme:NORTHING>821369.33</fme:NORTHING>
<fme:SPOTHEIGHT>6.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821369.33000 832715.01000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idaed4c8ed-f23f-43e4-b6a2-b00b6dff29fb">
<fme:FEATURE_ID>1001129771</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832040.2</fme:EASTING>
<fme:NORTHING>821374.95</fme:NORTHING>
<fme:SPOTHEIGHT>5.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821374.95025 832040.20401 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida00e2f41-f7c8-44e8-be11-d4202319eacb">
<fme:FEATURE_ID>1001130040</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832979.91</fme:EASTING>
<fme:NORTHING>821387.43</fme:NORTHING>
<fme:SPOTHEIGHT>10.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821387.42700 832979.90800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide9b76d20-52ea-42c8-acff-d70fb1996e5d">
<fme:FEATURE_ID>1001129973</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832538.87</fme:EASTING>
<fme:NORTHING>821387.86</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821387.86469 832538.87103 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id716a6cee-0812-4513-878e-700f43b58ce6">
<fme:FEATURE_ID>1001129788</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833376.06</fme:EASTING>
<fme:NORTHING>821389.1</fme:NORTHING>
<fme:SPOTHEIGHT>5.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>2</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821389.10236 833376.05613 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfe66e735-9e88-482d-a62b-4ca0f95ddb5b">
<fme:FEATURE_ID>1001129975</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832755.99</fme:EASTING>
<fme:NORTHING>821411.91</fme:NORTHING>
<fme:SPOTHEIGHT>19.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821411.91000 832755.99000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbe2e2957-7680-4cd7-aaff-4cf45580b984">
<fme:FEATURE_ID>1001130042</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833295.72</fme:EASTING>
<fme:NORTHING>821440.91</fme:NORTHING>
<fme:SPOTHEIGHT>6.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821440.91401 833295.72062 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6faa4074-35ad-4c6a-921e-d9d70d251630">
<fme:FEATURE_ID>1001129786</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833558.71</fme:EASTING>
<fme:NORTHING>821444.51</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821444.50976 833558.70525 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3d25fce1-21a8-4b2e-805e-5115d8ec0697">
<fme:FEATURE_ID>1001129974</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832543.3</fme:EASTING>
<fme:NORTHING>821446.14</fme:NORTHING>
<fme:SPOTHEIGHT>12.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821446.14000 832543.30000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id28aefda7-22ef-43c5-a44c-b19e4ebe2ff1">
<fme:FEATURE_ID>1001130073</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832910.78</fme:EASTING>
<fme:NORTHING>821449.71</fme:NORTHING>
<fme:SPOTHEIGHT>8.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821449.70922 832910.77647 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf3058dfe-e336-4a93-897d-263ce5f34517">
<fme:FEATURE_ID>1001129770</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831950.05</fme:EASTING>
<fme:NORTHING>821451.98</fme:NORTHING>
<fme:SPOTHEIGHT>5.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821451.97997 831950.04940 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb80ca6b7-9354-468c-a761-b52a483e75cf">
<fme:FEATURE_ID>1001129764</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832290.41</fme:EASTING>
<fme:NORTHING>821534.53</fme:NORTHING>
<fme:SPOTHEIGHT>10.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821534.53000 832290.41000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida3db8edf-f637-4d69-9216-73e146d6661c">
<fme:FEATURE_ID>1001130018</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832073.25</fme:EASTING>
<fme:NORTHING>821552.59</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821552.59313 832073.25236 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id64695ec4-e0a5-4747-8571-f4993474d544">
<fme:FEATURE_ID>1001130039</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832756.45</fme:EASTING>
<fme:NORTHING>821561.87</fme:NORTHING>
<fme:SPOTHEIGHT>5.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821561.87469 832756.45099 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfb7ba820-fb41-43ef-9c79-be437fe60732">
<fme:FEATURE_ID>1001129967</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831743.38</fme:EASTING>
<fme:NORTHING>821577.04</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821577.03969 831743.37817 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1c254d4b-89b8-43a9-b36b-03a7e9881522">
<fme:FEATURE_ID>1001130009</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830933.87</fme:EASTING>
<fme:NORTHING>821591.07</fme:NORTHING>
<fme:SPOTHEIGHT>4.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821591.06709 830933.87067 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb5020b43-d5a6-4011-93ac-7112c6bca931">
<fme:FEATURE_ID>1001130044</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833010.88</fme:EASTING>
<fme:NORTHING>821599.68</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821599.67490 833010.88399 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7d37554b-08b5-468e-8574-11fc9d9904c3">
<fme:FEATURE_ID>1001129810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833492.01</fme:EASTING>
<fme:NORTHING>821604.27</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821604.26770 833492.00501 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida9200363-4f2c-4008-8eb5-98edc5823938">
<fme:FEATURE_ID>1001129819</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832364.32</fme:EASTING>
<fme:NORTHING>821607.27</fme:NORTHING>
<fme:SPOTHEIGHT>10.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821607.27130 832364.32143 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf6d9798b-cd18-4877-acc8-f8ad9f4bc228">
<fme:FEATURE_ID>1001129813</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833331.99</fme:EASTING>
<fme:NORTHING>821632.37</fme:NORTHING>
<fme:SPOTHEIGHT>3.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821632.36968 833331.98706 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb486520c-7d2c-4d8b-b6d6-df4d96ac8ca6">
<fme:FEATURE_ID>1001129783</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831603.86</fme:EASTING>
<fme:NORTHING>821635.87</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821635.86837 831603.85654 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc6267886-70b1-41e4-88a3-0a945119307f">
<fme:FEATURE_ID>1001130056</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830041.31</fme:EASTING>
<fme:NORTHING>821644.13</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821644.13442 830041.31289 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf3b7321d-d62f-4843-8d25-2292c0eb5e87">
<fme:FEATURE_ID>1001129824</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832725.32</fme:EASTING>
<fme:NORTHING>821645.27</fme:NORTHING>
<fme:SPOTHEIGHT>3.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821645.27017 832725.32445 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7e9f3ed2-0437-43c3-85b4-fa5d8812b618">
<fme:FEATURE_ID>1001129970</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832189.32</fme:EASTING>
<fme:NORTHING>821647.86</fme:NORTHING>
<fme:SPOTHEIGHT>20.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821647.85890 832189.31788 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id69547081-39d6-4fd1-be3c-aab1e35a7d93">
<fme:FEATURE_ID>1001129968</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831995.38</fme:EASTING>
<fme:NORTHING>821680.1</fme:NORTHING>
<fme:SPOTHEIGHT>6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821680.09860 831995.38176 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide9c1566b-4994-4b9b-a1ca-94f995a6d827">
<fme:FEATURE_ID>1001130038</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833118.86</fme:EASTING>
<fme:NORTHING>821684.16</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821684.15715 833118.85903 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfb149665-7445-4fe1-afaf-e2b4bc2b5d2f">
<fme:FEATURE_ID>1001129825</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832330.46</fme:EASTING>
<fme:NORTHING>821708.08</fme:NORTHING>
<fme:SPOTHEIGHT>7.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821708.07768 832330.45607 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1491dcad-81ed-4fca-b5da-cffef6ce6dc9">
<fme:FEATURE_ID>1001130020</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831970.9</fme:EASTING>
<fme:NORTHING>821773.26</fme:NORTHING>
<fme:SPOTHEIGHT>21.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821773.25978 831970.90313 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2b423567-91ef-4e6b-9d4b-089457a190ba">
<fme:FEATURE_ID>1001129812</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833067.41</fme:EASTING>
<fme:NORTHING>821781.12</fme:NORTHING>
<fme:SPOTHEIGHT>3.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821781.12045 833067.40604 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id132a96e6-c654-4078-a676-f916ea537b05">
<fme:FEATURE_ID>1001129785</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831781.8</fme:EASTING>
<fme:NORTHING>821784</fme:NORTHING>
<fme:SPOTHEIGHT>5.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821784.00000 831781.80000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id593ea346-25f2-4997-ba46-a61a54db6f99">
<fme:FEATURE_ID>1001129936</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831669.16</fme:EASTING>
<fme:NORTHING>821808.81</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821808.81374 831669.16193 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5b28297d-4ea0-4c57-b57f-ee2820603a02">
<fme:FEATURE_ID>1001129809</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833685.59</fme:EASTING>
<fme:NORTHING>821826.37</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821826.37371 833685.58936 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3197e0d4-69ed-47d2-b335-a3d07df7c89f">
<fme:FEATURE_ID>1001129778</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831979.16</fme:EASTING>
<fme:NORTHING>821836.16</fme:NORTHING>
<fme:SPOTHEIGHT>5.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821836.16000 831979.16000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3a04f133-c141-4804-8182-2f59487e054f">
<fme:FEATURE_ID>1001129980</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833163.55</fme:EASTING>
<fme:NORTHING>821836.52</fme:NORTHING>
<fme:SPOTHEIGHT>4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821836.51671 833163.55278 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id05ac77c8-2440-4579-aac1-bc7205d1fe03">
<fme:FEATURE_ID>1001129979</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833451.07</fme:EASTING>
<fme:NORTHING>821843.93</fme:NORTHING>
<fme:SPOTHEIGHT>12.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821843.92834 833451.06646 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id80650572-c72d-4a3f-a4bc-9946dec3ee14">
<fme:FEATURE_ID>1001129808</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833054.59</fme:EASTING>
<fme:NORTHING>821855.2</fme:NORTHING>
<fme:SPOTHEIGHT>4.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821855.19789 833054.59472 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9240a743-a92a-4761-80ac-a171b4b29e4d">
<fme:FEATURE_ID>1001129759</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831489.47</fme:EASTING>
<fme:NORTHING>821860.14</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821860.14345 831489.47037 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9fe42009-7533-405c-8ca4-19837ce79d1d">
<fme:FEATURE_ID>1001129966</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831641.67</fme:EASTING>
<fme:NORTHING>821863.17</fme:NORTHING>
<fme:SPOTHEIGHT>5.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821863.17287 831641.66880 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id970ad76f-c024-48e4-a761-fe3a55f7b38e">
<fme:FEATURE_ID>1001130032</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833524.2</fme:EASTING>
<fme:NORTHING>821899.64</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821899.63913 833524.20331 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8fd869c6-5027-46f8-aa9e-10f23806c3d1">
<fme:FEATURE_ID>1001129775</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831849.82</fme:EASTING>
<fme:NORTHING>821906.59</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821906.58699 831849.81987 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida83d5876-2313-4e8b-b226-7e2078b72d87">
<fme:FEATURE_ID>1001129807</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833004.92</fme:EASTING>
<fme:NORTHING>821933.04</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821933.04098 833004.92121 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1dda6b5c-56d5-402b-a7bc-2033c5ef8cd5">
<fme:FEATURE_ID>1001130064</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832561.69</fme:EASTING>
<fme:NORTHING>821940.54</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821940.53910 832561.69350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idec5dc921-e973-45ce-94d2-aa7c8eafa294">
<fme:FEATURE_ID>1001130066</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833298.16</fme:EASTING>
<fme:NORTHING>821942.16</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821942.15848 833298.15923 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb262cc27-3f68-4ad7-b264-ce517ed27167">
<fme:FEATURE_ID>1001129937</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832798.05</fme:EASTING>
<fme:NORTHING>821944.92</fme:NORTHING>
<fme:SPOTHEIGHT>4.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821944.91980 832798.04696 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb2b69832-6301-4aec-b64c-46a2b2f0d1f9">
<fme:FEATURE_ID>1001129820</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832926.75</fme:EASTING>
<fme:NORTHING>821947.63</fme:NORTHING>
<fme:SPOTHEIGHT>10.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821947.63449 832926.74845 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7df569fb-c391-4871-a2d3-78e9ff265a0f">
<fme:FEATURE_ID>1001129774</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832199.89</fme:EASTING>
<fme:NORTHING>821960.71</fme:NORTHING>
<fme:SPOTHEIGHT>3.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821960.70797 832199.88790 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idebd06896-addf-4b09-bd1d-f4ec1da8bc74">
<fme:FEATURE_ID>1001129782</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831988.69</fme:EASTING>
<fme:NORTHING>821963.69</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821963.68598 831988.68718 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7eb542e1-b28d-4069-9ebf-d3f2d0465751">
<fme:FEATURE_ID>1001129815</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833155.24</fme:EASTING>
<fme:NORTHING>821973</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821972.99999 833155.23826 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idebfdeb83-4639-46db-b162-d093f79b4186">
<fme:FEATURE_ID>1001129818</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832498.39</fme:EASTING>
<fme:NORTHING>821991.67</fme:NORTHING>
<fme:SPOTHEIGHT>10.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821991.66730 832498.38662 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf616fb43-0351-4be0-8c5f-b7e379f8d1aa">
<fme:FEATURE_ID>1001129773</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831910.31</fme:EASTING>
<fme:NORTHING>821998.27</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821998.27000 831910.31000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf65a5abe-1244-4913-928c-0b6e21cc25a7">
<fme:FEATURE_ID>1001129784</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831610.9</fme:EASTING>
<fme:NORTHING>822012.59</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822012.59000 831610.90000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb26034e9-c98a-401e-8e8c-bd2771a3909a">
<fme:FEATURE_ID>1001129779</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832045.02</fme:EASTING>
<fme:NORTHING>822014.39</fme:NORTHING>
<fme:SPOTHEIGHT>4.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822014.39000 832045.02000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5551948d-0df8-4a3a-b0cc-0d9e2d630dd0">
<fme:FEATURE_ID>1001130030</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833024.67</fme:EASTING>
<fme:NORTHING>822036.52</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822036.51574 833024.66579 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1497733d-eb10-4c03-a7ac-bc45b1a5e06b">
<fme:FEATURE_ID>1001129776</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832243.81</fme:EASTING>
<fme:NORTHING>822045</fme:NORTHING>
<fme:SPOTHEIGHT>12</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822044.99504 832243.81308 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd96bd1e3-1d78-401d-b9de-074dc03d5236">
<fme:FEATURE_ID>1001129817</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832452.59</fme:EASTING>
<fme:NORTHING>822045.75</fme:NORTHING>
<fme:SPOTHEIGHT>6.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822045.75128 832452.59153 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcea45549-b508-48da-bdad-568bd77b35e3">
<fme:FEATURE_ID>1001130047</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832247.5</fme:EASTING>
<fme:NORTHING>822071.57</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822071.56893 832247.50124 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id540ddf7a-be7b-4401-8bc8-a6572f706940">
<fme:FEATURE_ID>1001129814</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833433.63</fme:EASTING>
<fme:NORTHING>822087.39</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822087.38899 833433.62763 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbb00c53c-b7fe-47ca-9fc5-95b1e80cc0f1">
<fme:FEATURE_ID>1001129816</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832561.7</fme:EASTING>
<fme:NORTHING>822089.15</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822089.14617 832561.69735 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id63a8c0dd-0b08-4ce9-aa53-4a26c91d8063">
<fme:FEATURE_ID>1001129965</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831876.31</fme:EASTING>
<fme:NORTHING>822090.68</fme:NORTHING>
<fme:SPOTHEIGHT>14.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822090.67795 831876.31107 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id57877c2a-c2f6-4123-92d4-57b9e08de4c7">
<fme:FEATURE_ID>1001129780</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831820.43</fme:EASTING>
<fme:NORTHING>822093.57</fme:NORTHING>
<fme:SPOTHEIGHT>9.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822093.56595 831820.42794 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide8f17910-126b-4921-a6f5-b0eb5de1bf15">
<fme:FEATURE_ID>1001130037</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832639.03</fme:EASTING>
<fme:NORTHING>822100.79</fme:NORTHING>
<fme:SPOTHEIGHT>18.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822100.78786 832639.02593 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id29959165-c1d9-4fa2-b066-83200a0f9ef0">
<fme:FEATURE_ID>1001129781</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832036.33</fme:EASTING>
<fme:NORTHING>822124.28</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822124.27572 832036.32621 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf8824c68-90b3-49df-a7ad-611458703516">
<fme:FEATURE_ID>1001130012</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830766.92</fme:EASTING>
<fme:NORTHING>822141.98</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822141.98044 830766.91810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4b962ae6-d6a8-482e-872e-eae003d79590">
<fme:FEATURE_ID>1001129963</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831886.3</fme:EASTING>
<fme:NORTHING>822153.41</fme:NORTHING>
<fme:SPOTHEIGHT>9.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822153.40812 831886.29751 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id70a0ca4a-aaa9-4961-95ad-60750210c30d">
<fme:FEATURE_ID>1001129935</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831792.57</fme:EASTING>
<fme:NORTHING>822172.33</fme:NORTHING>
<fme:SPOTHEIGHT>6.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822172.32838 831792.57424 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2b7d6b6c-cc68-4398-b39a-f790328198ac">
<fme:FEATURE_ID>1001129772</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832027.54</fme:EASTING>
<fme:NORTHING>822173.16</fme:NORTHING>
<fme:SPOTHEIGHT>18.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822173.15516 832027.54080 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb067fb27-02af-4d33-942e-321dd6ac598f">
<fme:FEATURE_ID>1001129962</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831644.1</fme:EASTING>
<fme:NORTHING>822178.24</fme:NORTHING>
<fme:SPOTHEIGHT>23.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822178.24008 831644.09819 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id90a95117-5abe-492f-82f2-619af4ffffa1">
<fme:FEATURE_ID>1001129811</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833683.52</fme:EASTING>
<fme:NORTHING>822182.04</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822182.03645 833683.52334 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3df9952c-12b8-4afd-a1d1-c6ccb31eab24">
<fme:FEATURE_ID>1001129805</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833078.42</fme:EASTING>
<fme:NORTHING>822192.35</fme:NORTHING>
<fme:SPOTHEIGHT>6.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822192.34997 833078.42047 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id037f0c5f-152e-4942-8702-11ce494bbc49">
<fme:FEATURE_ID>1001129934</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831529.03</fme:EASTING>
<fme:NORTHING>822222.76</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822222.75566 831529.03084 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbba780e3-e9d1-4384-83f8-2d587549439a">
<fme:FEATURE_ID>1001129794</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833377.88</fme:EASTING>
<fme:NORTHING>822232.29</fme:NORTHING>
<fme:SPOTHEIGHT>6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822232.29393 833377.88487 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id78d8cff2-0214-4a2a-bf55-b53fe0a34a55">
<fme:FEATURE_ID>1001130068</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832746.94</fme:EASTING>
<fme:NORTHING>822249.86</fme:NORTHING>
<fme:SPOTHEIGHT>75.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822249.85900 832746.93650 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idaf240327-12a8-4812-ba4f-3b061411911f">
<fme:FEATURE_ID>1001130035</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831640</fme:EASTING>
<fme:NORTHING>822267.2</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822267.20320 831640.00094 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida026c511-b9ad-4e6f-8c2c-74cd8ed8d78f">
<fme:FEATURE_ID>1001129880</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831376.53</fme:EASTING>
<fme:NORTHING>822270.21</fme:NORTHING>
<fme:SPOTHEIGHT>3.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822270.20945 831376.53046 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1d161b08-ffe7-471a-9d93-7556943c6188">
<fme:FEATURE_ID>1001129890</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832055.96</fme:EASTING>
<fme:NORTHING>822281.66</fme:NORTHING>
<fme:SPOTHEIGHT>13.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822281.65937 832055.96032 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf369acdb-f2c1-4073-9e7b-24f8d5a5f3e4">
<fme:FEATURE_ID>1001129793</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833696.48</fme:EASTING>
<fme:NORTHING>822283.27</fme:NORTHING>
<fme:SPOTHEIGHT>5.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822283.26811 833696.48043 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id78b85096-2e3d-4434-a0ed-f091ecfcb11c">
<fme:FEATURE_ID>1001129964</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831980.97</fme:EASTING>
<fme:NORTHING>822295.26</fme:NORTHING>
<fme:SPOTHEIGHT>28.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822295.26197 831980.96689 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id37646fb2-e53a-4bb4-9c24-0a52bd91470a">
<fme:FEATURE_ID>1001129961</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831839.43</fme:EASTING>
<fme:NORTHING>822308.73</fme:NORTHING>
<fme:SPOTHEIGHT>38.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822308.73356 831839.43287 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id11c1121f-50c0-4fac-91ca-e225814b0484">
<fme:FEATURE_ID>1001129798</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833104.89</fme:EASTING>
<fme:NORTHING>822313.39</fme:NORTHING>
<fme:SPOTHEIGHT>33.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822313.38671 833104.89000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id330330d8-88d4-415e-b4f5-b76b08fb09d7">
<fme:FEATURE_ID>1001129899</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832516.85</fme:EASTING>
<fme:NORTHING>822332.56</fme:NORTHING>
<fme:SPOTHEIGHT>31.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822332.55602 832516.85049 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7098fc02-1b45-49e5-b6d1-0753214f8774">
<fme:FEATURE_ID>1001129803</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833481.33</fme:EASTING>
<fme:NORTHING>822334.27</fme:NORTHING>
<fme:SPOTHEIGHT>6.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822334.26551 833481.33094 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id76984f84-4dd8-4d05-a01d-b8df5f0a785d">
<fme:FEATURE_ID>1001129898</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832364.98</fme:EASTING>
<fme:NORTHING>822339.27</fme:NORTHING>
<fme:SPOTHEIGHT>5.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822339.27267 832364.98272 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id66c95e02-2a4c-46c6-aa29-058d858ef923">
<fme:FEATURE_ID>1001129802</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833673.82</fme:EASTING>
<fme:NORTHING>822341.26</fme:NORTHING>
<fme:SPOTHEIGHT>6.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822341.26340 833673.82286 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4bb098a9-fdca-49ba-a088-dca9c8c4e6ca">
<fme:FEATURE_ID>1001129804</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833578.56</fme:EASTING>
<fme:NORTHING>822351.74</fme:NORTHING>
<fme:SPOTHEIGHT>15</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822351.73568 833578.55666 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0068464d-823a-49ac-83aa-003fae24fdcf">
<fme:FEATURE_ID>1001129902</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832585.31</fme:EASTING>
<fme:NORTHING>822353.75</fme:NORTHING>
<fme:SPOTHEIGHT>44.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822353.75002 832585.31435 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb14992d5-0db9-4cd2-9bf2-c8b12299578b">
<fme:FEATURE_ID>1001129903</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832741.54</fme:EASTING>
<fme:NORTHING>822354.49</fme:NORTHING>
<fme:SPOTHEIGHT>31.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822354.48713 832741.54405 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id89d254e6-55fc-425c-bd81-1ada2ef3dec5">
<fme:FEATURE_ID>1001129960</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831600.52</fme:EASTING>
<fme:NORTHING>822363.27</fme:NORTHING>
<fme:SPOTHEIGHT>7.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822363.26974 831600.52260 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idaa47f407-3f14-4470-9859-4cb97ed8efda">
<fme:FEATURE_ID>1001129959</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831581.96</fme:EASTING>
<fme:NORTHING>822365.72</fme:NORTHING>
<fme:SPOTHEIGHT>12.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822365.72059 831581.95619 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd1fbe486-e5d5-423c-8dc5-16ffd7d2a5ba">
<fme:FEATURE_ID>1001129889</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831667.29</fme:EASTING>
<fme:NORTHING>822403.4</fme:NORTHING>
<fme:SPOTHEIGHT>13.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822403.39679 831667.28853 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide84d4fd5-cd06-43a3-aaa8-707a80bb442c">
<fme:FEATURE_ID>1001129971</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832619.33</fme:EASTING>
<fme:NORTHING>822439.45</fme:NORTHING>
<fme:SPOTHEIGHT>37.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822439.44966 832619.33030 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id713f42fd-f577-4bf7-9952-7a6cb8aa9af1">
<fme:FEATURE_ID>1001129894</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831832.96</fme:EASTING>
<fme:NORTHING>822448.93</fme:NORTHING>
<fme:SPOTHEIGHT>73.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822448.93470 831832.96305 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide28197f3-eecf-40b1-b9fc-f3caaca12b8a">
<fme:FEATURE_ID>1001130054</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831478.54</fme:EASTING>
<fme:NORTHING>822456.49</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822456.49125 831478.53842 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id10f1210b-819f-4000-93fd-867b0d88bbbb">
<fme:FEATURE_ID>1001129897</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832090.19</fme:EASTING>
<fme:NORTHING>822456.55</fme:NORTHING>
<fme:SPOTHEIGHT>6.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822456.54865 832090.19161 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idad465422-6ad6-4866-993a-22b27b5432e0">
<fme:FEATURE_ID>1001130027</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832056.79</fme:EASTING>
<fme:NORTHING>822462.11</fme:NORTHING>
<fme:SPOTHEIGHT>16.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822462.10790 832056.78574 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id537c215c-6d5f-4376-a0de-6528579bb9a8">
<fme:FEATURE_ID>1001129879</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831239.15</fme:EASTING>
<fme:NORTHING>822488.07</fme:NORTHING>
<fme:SPOTHEIGHT>4.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822488.07106 831239.15213 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbddd7c9b-f746-410a-9961-db4748d87818">
<fme:FEATURE_ID>1001130059</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832277.68</fme:EASTING>
<fme:NORTHING>822496.95</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822496.95237 832277.68275 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id63ac838d-2cfd-471d-b11c-16a08bd93356">
<fme:FEATURE_ID>1001129801</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833671.27</fme:EASTING>
<fme:NORTHING>822501.5</fme:NORTHING>
<fme:SPOTHEIGHT>47.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822501.49997 833671.27310 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3e41b475-d088-41bc-8da4-fd9dd64d1b2f">
<fme:FEATURE_ID>1001129887</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831571.88</fme:EASTING>
<fme:NORTHING>822513.96</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822513.95857 831571.88270 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf2c21423-a894-4e9d-8115-1976523a0d5f">
<fme:FEATURE_ID>1001129799</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833419</fme:EASTING>
<fme:NORTHING>822536.09</fme:NORTHING>
<fme:SPOTHEIGHT>47.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822536.09298 833419.00074 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id27dd405e-2bd4-4f3b-8be2-bc1f94bb17f2">
<fme:FEATURE_ID>1001129886</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831689.72</fme:EASTING>
<fme:NORTHING>822536.59</fme:NORTHING>
<fme:SPOTHEIGHT>36.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822536.58803 831689.71596 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbdc33515-e1a0-4b8d-8cf8-5fb96a51195c">
<fme:FEATURE_ID>1001129883</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831410.65</fme:EASTING>
<fme:NORTHING>822547.45</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822547.44932 831410.64519 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id76d2d03e-c41d-43f6-849d-e4ded427ea33">
<fme:FEATURE_ID>1001129892</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831598.12</fme:EASTING>
<fme:NORTHING>822556.57</fme:NORTHING>
<fme:SPOTHEIGHT>23</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822556.56573 831598.11615 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd64b403f-c75e-47e4-b089-d6000e4a5336">
<fme:FEATURE_ID>1001129826</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830705.16</fme:EASTING>
<fme:NORTHING>822557.45</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822557.45314 830705.15727 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0d7e751b-f4bb-48b1-b965-8830b7776730">
<fme:FEATURE_ID>1001130022</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831166.29</fme:EASTING>
<fme:NORTHING>822574.76</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822574.75697 831166.28555 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id44c0f7e7-6fe6-4b85-9d63-d695a6113633">
<fme:FEATURE_ID>1001129991</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831552.55</fme:EASTING>
<fme:NORTHING>822577.32</fme:NORTHING>
<fme:SPOTHEIGHT>23.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822577.31873 831552.55021 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfb01d92f-07b2-44d7-a0d2-e9316e66c0e0">
<fme:FEATURE_ID>1001129994</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831723.22</fme:EASTING>
<fme:NORTHING>822579.84</fme:NORTHING>
<fme:SPOTHEIGHT>53.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822579.83941 831723.21549 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6b10b7c2-794f-42c3-b238-c27092cbbb01">
<fme:FEATURE_ID>1001129884</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831477.05</fme:EASTING>
<fme:NORTHING>822587.71</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822587.71058 831477.04702 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id967b87ef-3e84-41f6-98d2-09c9ac978e0e">
<fme:FEATURE_ID>1420001180</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831761.39</fme:EASTING>
<fme:NORTHING>822596.49</fme:NORTHING>
<fme:SPOTHEIGHT>68.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822596.48494 831761.39380 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2f746429-d4cc-4d35-815f-8edee690e345">
<fme:FEATURE_ID>1001129878</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831293.45</fme:EASTING>
<fme:NORTHING>822597.94</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822597.94185 831293.44540 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id704aae78-20b1-416b-afea-616ad683c206">
<fme:FEATURE_ID>1420001181</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831905.66</fme:EASTING>
<fme:NORTHING>822601.63</fme:NORTHING>
<fme:SPOTHEIGHT>71.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260116</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822601.62845 831905.65550 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3e0c155c-b4d8-474c-b368-4f14761892a1">
<fme:FEATURE_ID>1001130001</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831406.08</fme:EASTING>
<fme:NORTHING>822610.29</fme:NORTHING>
<fme:SPOTHEIGHT>21.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822610.28731 831406.08424 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc7c5a757-818e-4a1a-b695-8d06fe8d4643">
<fme:FEATURE_ID>1420001920</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>0</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833096.12</fme:EASTING>
<fme:NORTHING>822610.67</fme:NORTHING>
<fme:SPOTHEIGHT>100.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260421</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822610.66925 833096.11537 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id15afb0f2-68d6-4d3e-ae0a-1c9512aa3285">
<fme:FEATURE_ID>1001129896</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832175.37</fme:EASTING>
<fme:NORTHING>822641.96</fme:NORTHING>
<fme:SPOTHEIGHT>5.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822641.95637 832175.36778 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id36ab1f02-b933-4af0-b20e-e00bb38bcdae">
<fme:FEATURE_ID>1001129993</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831643.46</fme:EASTING>
<fme:NORTHING>822650.02</fme:NORTHING>
<fme:SPOTHEIGHT>29.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822650.02400 831643.46255 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id22c4f164-d2dd-4a06-a202-1162fd552bea">
<fme:FEATURE_ID>1001129800</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833488.59</fme:EASTING>
<fme:NORTHING>822660.67</fme:NORTHING>
<fme:SPOTHEIGHT>115.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822660.66990 833488.58824 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb031c21f-d3f5-497a-a65e-323e5b296ee7">
<fme:FEATURE_ID>1001129881</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831055.59</fme:EASTING>
<fme:NORTHING>822661.33</fme:NORTHING>
<fme:SPOTHEIGHT>4.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822661.32547 831055.58561 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida774af17-cf85-4277-822d-e35f6b9dde41">
<fme:FEATURE_ID>1001129901</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832267.45</fme:EASTING>
<fme:NORTHING>822683.25</fme:NORTHING>
<fme:SPOTHEIGHT>5.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822683.24716 832267.44971 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id595b7fd1-f1a1-4a0d-bdde-50873ec5aa74">
<fme:FEATURE_ID>1001129944</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832745.72</fme:EASTING>
<fme:NORTHING>822691.15</fme:NORTHING>
<fme:SPOTHEIGHT>77.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822691.15184 832745.71896 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id34a63ca0-58d6-4805-ab0f-7f274c08e1e1">
<fme:FEATURE_ID>1001130058</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832380.97</fme:EASTING>
<fme:NORTHING>822707.14</fme:NORTHING>
<fme:SPOTHEIGHT>38.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822707.14021 832380.96560 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id42d970fd-f171-4c43-8a08-92dc72e8e9bf">
<fme:FEATURE_ID>1001129895</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832044.41</fme:EASTING>
<fme:NORTHING>822710.08</fme:NORTHING>
<fme:SPOTHEIGHT>6.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822710.07978 832044.41190 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0d2ebcf3-cbe2-46bf-a8a4-74704722f3ef">
<fme:FEATURE_ID>1001129891</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831552.23</fme:EASTING>
<fme:NORTHING>822730.22</fme:NORTHING>
<fme:SPOTHEIGHT>31.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822730.22097 831552.22826 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0ca516b4-ebab-4b60-9f8a-397683bba0dd">
<fme:FEATURE_ID>1001129900</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832335.51</fme:EASTING>
<fme:NORTHING>822748.31</fme:NORTHING>
<fme:SPOTHEIGHT>48.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822748.30739 832335.50503 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1366c0a9-bcd6-4ccf-914b-4389d8898b1d">
<fme:FEATURE_ID>1001129952</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831069.48</fme:EASTING>
<fme:NORTHING>822762.98</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822762.97610 831069.48090 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id63054d69-d245-46a8-945b-11602bfb7f1e">
<fme:FEATURE_ID>1001129796</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833253.12</fme:EASTING>
<fme:NORTHING>822777.6</fme:NORTHING>
<fme:SPOTHEIGHT>111.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822777.60124 833253.11706 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id06b19d2f-0f6e-40d1-aeee-9ca2adac6248">
<fme:FEATURE_ID>1001129990</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832380.14</fme:EASTING>
<fme:NORTHING>822778.56</fme:NORTHING>
<fme:SPOTHEIGHT>56.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822778.55577 832380.13636 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfd85e560-b68c-4f36-b217-ef04d80bf7a2">
<fme:FEATURE_ID>1001129885</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831163.76</fme:EASTING>
<fme:NORTHING>822785.01</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822785.00880 831163.75948 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8081e1bc-e24a-4aee-8148-4ba48fd60823">
<fme:FEATURE_ID>1001130053</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832160.55</fme:EASTING>
<fme:NORTHING>822788.73</fme:NORTHING>
<fme:SPOTHEIGHT>3.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822788.72732 832160.55011 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf60bd130-8b41-4e91-b672-78d29cec4e06">
<fme:FEATURE_ID>1001129905</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832582.53</fme:EASTING>
<fme:NORTHING>822792.79</fme:NORTHING>
<fme:SPOTHEIGHT>135.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822792.79444 832582.53331 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2326720b-d3a8-4967-aa26-daee2cd229d9">
<fme:FEATURE_ID>1001129866</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831031.07</fme:EASTING>
<fme:NORTHING>822818.79</fme:NORTHING>
<fme:SPOTHEIGHT>14</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822818.79464 831031.06574 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide8c3fb10-be4d-4826-91eb-3ed65b85c741">
<fme:FEATURE_ID>1001129985</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832750.11</fme:EASTING>
<fme:NORTHING>822825.74</fme:NORTHING>
<fme:SPOTHEIGHT>127.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822825.74330 832750.10961 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6ac13a3b-de8f-457e-880c-3d5b534353a7">
<fme:FEATURE_ID>1001129869</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831369.53</fme:EASTING>
<fme:NORTHING>822837.11</fme:NORTHING>
<fme:SPOTHEIGHT>38.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822837.11000 831369.53300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id835c2459-701a-4348-bc11-e60fcea035eb">
<fme:FEATURE_ID>1001130060</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833581.09</fme:EASTING>
<fme:NORTHING>822842.57</fme:NORTHING>
<fme:SPOTHEIGHT>132.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822842.56607 833581.08584 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idad056e0b-5fc3-477a-964c-034ce7e42e8c">
<fme:FEATURE_ID>1001129995</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831788.65</fme:EASTING>
<fme:NORTHING>822849.9</fme:NORTHING>
<fme:SPOTHEIGHT>89</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822849.89630 831788.64677 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5616dce5-16e0-4dc8-97f4-01c2c18039e3">
<fme:FEATURE_ID>1001129870</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831452.42</fme:EASTING>
<fme:NORTHING>822876.43</fme:NORTHING>
<fme:SPOTHEIGHT>60.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822876.42800 831452.41800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3122196b-8d60-413f-a8ec-758140a07c87">
<fme:FEATURE_ID>1001129865</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831091.19</fme:EASTING>
<fme:NORTHING>822890.69</fme:NORTHING>
<fme:SPOTHEIGHT>21.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822890.69200 831091.19000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id34c5d30a-3a59-41ee-997a-e2d3d4fb16e0">
<fme:FEATURE_ID>1001129989</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832032.31</fme:EASTING>
<fme:NORTHING>822899.37</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822899.36680 832032.30561 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idea2b1f7e-6b5d-4a44-8610-3a471472b6db">
<fme:FEATURE_ID>1001129992</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831673.25</fme:EASTING>
<fme:NORTHING>822915.53</fme:NORTHING>
<fme:SPOTHEIGHT>113</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822915.52750 831673.24859 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb3bd378a-1e1c-4ea5-b5da-59367065f27b">
<fme:FEATURE_ID>1001130062</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832760.07</fme:EASTING>
<fme:NORTHING>822925.19</fme:NORTHING>
<fme:SPOTHEIGHT>111.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822925.18817 832760.07324 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id62b3327e-cd33-449d-b261-e1ce34a9f0f4">
<fme:FEATURE_ID>1001129909</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832624.42</fme:EASTING>
<fme:NORTHING>822925.29</fme:NORTHING>
<fme:SPOTHEIGHT>129.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822925.29269 832624.41686 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id035a1166-8d72-4701-ad5f-8bca7c66b51d">
<fme:FEATURE_ID>1001129873</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831234.18</fme:EASTING>
<fme:NORTHING>822926.12</fme:NORTHING>
<fme:SPOTHEIGHT>56.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822926.11600 831234.18000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id47d5e84a-c60c-4199-b366-486f1a41d67c">
<fme:FEATURE_ID>1310008170</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831049.3</fme:EASTING>
<fme:NORTHING>822927.79</fme:NORTHING>
<fme:SPOTHEIGHT>34</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822927.79200 831049.30400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2b70de6c-2220-4efd-ae93-dc7fa6c86d3d">
<fme:FEATURE_ID>1001130033</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831126.45</fme:EASTING>
<fme:NORTHING>822936.67</fme:NORTHING>
<fme:SPOTHEIGHT>40</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822936.66800 831126.44800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcfbc6b51-f2f2-42f6-acb2-34409a9cf04b">
<fme:FEATURE_ID>1001129864</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830876.82</fme:EASTING>
<fme:NORTHING>822947.83</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822947.83200 830876.81900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1787b1bd-70b1-4552-8f17-e79f23ecf2a1">
<fme:FEATURE_ID>1001129752</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832388.88</fme:EASTING>
<fme:NORTHING>822952.99</fme:NORTHING>
<fme:SPOTHEIGHT>106.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822952.99183 832388.88486 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ideb64ff3f-7b53-43d2-936e-ecc990d47e12">
<fme:FEATURE_ID>1001129947</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832489.49</fme:EASTING>
<fme:NORTHING>822965.32</fme:NORTHING>
<fme:SPOTHEIGHT>94.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822965.31889 832489.49270 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddecd1946-087f-4b50-aa48-68de2e135821">
<fme:FEATURE_ID>1001129981</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833583.57</fme:EASTING>
<fme:NORTHING>822971.09</fme:NORTHING>
<fme:SPOTHEIGHT>116.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822971.08871 833583.56868 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id29731e5f-eff6-4c12-9558-8b0dd23788e9">
<fme:FEATURE_ID>1001129868</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830960.9</fme:EASTING>
<fme:NORTHING>822978.67</fme:NORTHING>
<fme:SPOTHEIGHT>13.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822978.67292 830960.89611 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id76c83495-e73b-4388-8d5c-803ff1f78d4f">
<fme:FEATURE_ID>1001129912</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831597.21</fme:EASTING>
<fme:NORTHING>822988.97</fme:NORTHING>
<fme:SPOTHEIGHT>118.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822988.97440 831597.20795 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide757bc12-cc3d-45c6-99d5-f4564d2fa11b">
<fme:FEATURE_ID>1001130000</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831250.43</fme:EASTING>
<fme:NORTHING>822995.95</fme:NORTHING>
<fme:SPOTHEIGHT>53.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822995.95300 831250.43400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3e427916-afcb-48c7-8e30-bdaa3724db68">
<fme:FEATURE_ID>1001129871</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831347.19</fme:EASTING>
<fme:NORTHING>822997.07</fme:NORTHING>
<fme:SPOTHEIGHT>56.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822997.07400 831347.18700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf78d38af-af8c-4070-9050-77e04ea3fc15">
<fme:FEATURE_ID>1001129946</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832656.53</fme:EASTING>
<fme:NORTHING>823023.27</fme:NORTHING>
<fme:SPOTHEIGHT>135.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823023.26936 832656.53077 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcbd1ca52-c4a9-40c4-a070-badc3cafb253">
<fme:FEATURE_ID>1001129790</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833475.97</fme:EASTING>
<fme:NORTHING>823029.71</fme:NORTHING>
<fme:SPOTHEIGHT>93.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823029.71032 833475.96593 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idec65f30f-0474-4ceb-9174-3c0e92bd6a14">
<fme:FEATURE_ID>1001129907</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832514.22</fme:EASTING>
<fme:NORTHING>823032.29</fme:NORTHING>
<fme:SPOTHEIGHT>106</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823032.28558 832514.22248 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4d7cc8a9-c824-4ae8-8782-845b5088624e">
<fme:FEATURE_ID>1001129872</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831399.02</fme:EASTING>
<fme:NORTHING>823035.48</fme:NORTHING>
<fme:SPOTHEIGHT>60.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823035.48400 831399.02000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id590c5a86-0041-48ef-94cd-80f27cc87d0d">
<fme:FEATURE_ID>1001129997</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831629.66</fme:EASTING>
<fme:NORTHING>823052.7</fme:NORTHING>
<fme:SPOTHEIGHT>127.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823052.69560 831629.65979 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb86c8a19-b7d9-4d2b-9b40-3e6eb1d49e38">
<fme:FEATURE_ID>1001129751</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832724.02</fme:EASTING>
<fme:NORTHING>823058.75</fme:NORTHING>
<fme:SPOTHEIGHT>127.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823058.74535 832724.02292 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0ef9f235-4a5e-4e5f-84cf-6c4762998b0f">
<fme:FEATURE_ID>1001129945</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832647.27</fme:EASTING>
<fme:NORTHING>823078.99</fme:NORTHING>
<fme:SPOTHEIGHT>119.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823078.98771 832647.26615 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2df4fc10-0c99-49b7-9d07-45d66adc22c6">
<fme:FEATURE_ID>1001130023</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830815.31</fme:EASTING>
<fme:NORTHING>823083.08</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823083.08100 830815.30600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddbbe8cbc-a7d9-4269-aae1-7d7db95b9c78">
<fme:FEATURE_ID>1001129908</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832640.82</fme:EASTING>
<fme:NORTHING>823097.58</fme:NORTHING>
<fme:SPOTHEIGHT>127.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823097.57518 832640.81797 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4f6aa823-912d-4eb6-818b-b5a455ba69cb">
<fme:FEATURE_ID>1001129988</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832235.07</fme:EASTING>
<fme:NORTHING>823107.96</fme:NORTHING>
<fme:SPOTHEIGHT>72.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823107.96176 832235.07083 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1750dba7-301c-49b8-9c53-7a59c84f5013">
<fme:FEATURE_ID>1001129863</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831087.95</fme:EASTING>
<fme:NORTHING>823109.87</fme:NORTHING>
<fme:SPOTHEIGHT>40.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823109.86700 831087.94700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id288eef8e-66ec-40f7-9357-a7c11ec845cf">
<fme:FEATURE_ID>1001129875</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831196.81</fme:EASTING>
<fme:NORTHING>823115.03</fme:NORTHING>
<fme:SPOTHEIGHT>64.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823115.02600 831196.80600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id763ff267-12af-4f45-a28e-68458acdd17e">
<fme:FEATURE_ID>1001130002</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830466.77</fme:EASTING>
<fme:NORTHING>823115.13</fme:NORTHING>
<fme:SPOTHEIGHT>3.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823115.12601 830466.76960 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6226a46b-a3ea-45db-afd2-5f2ef44ec063">
<fme:FEATURE_ID>1001129874</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831346.04</fme:EASTING>
<fme:NORTHING>823116.17</fme:NORTHING>
<fme:SPOTHEIGHT>62.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823116.17100 831346.03900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd79bbc04-0c06-4457-a998-4cb594d07660">
<fme:FEATURE_ID>1001129792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833517.76</fme:EASTING>
<fme:NORTHING>823116.87</fme:NORTHING>
<fme:SPOTHEIGHT>102.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823116.87300 833517.76329 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9379d1eb-2822-4690-936b-bce04f91f09f">
<fme:FEATURE_ID>1001129750</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832940.29</fme:EASTING>
<fme:NORTHING>823124.88</fme:NORTHING>
<fme:SPOTHEIGHT>153.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823124.87879 832940.29266 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2c6ae468-d387-4873-9b4d-d1ae71eb885a">
<fme:FEATURE_ID>1001129867</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830843.79</fme:EASTING>
<fme:NORTHING>823140.43</fme:NORTHING>
<fme:SPOTHEIGHT>18.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823140.43374 830843.79429 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbc49156b-23d0-4a53-af89-30a454f9d4b1">
<fme:FEATURE_ID>1001129913</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831935.47</fme:EASTING>
<fme:NORTHING>823142.67</fme:NORTHING>
<fme:SPOTHEIGHT>26.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823142.67243 831935.46692 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbc56e878-5e7a-4608-887a-d2006ea1d9da">
<fme:FEATURE_ID>1001129906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832763.46</fme:EASTING>
<fme:NORTHING>823160.39</fme:NORTHING>
<fme:SPOTHEIGHT>123.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823160.38975 832763.45931 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id802e6259-f6bc-4b7d-9d77-516bb93be1e2">
<fme:FEATURE_ID>1001130024</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830916.26</fme:EASTING>
<fme:NORTHING>823163.13</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823163.13203 830916.25791 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9a78fe85-a243-4d9f-b3b7-cdbc8b8c1d5b">
<fme:FEATURE_ID>1001130029</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832649.98</fme:EASTING>
<fme:NORTHING>823163.99</fme:NORTHING>
<fme:SPOTHEIGHT>128.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823163.98896 832649.98293 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id40f665bf-902a-4a80-8013-b9af1bbf1d36">
<fme:FEATURE_ID>1001129915</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831707.27</fme:EASTING>
<fme:NORTHING>823166.01</fme:NORTHING>
<fme:SPOTHEIGHT>103.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823166.01310 831707.27424 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idaa280ca1-c782-45a5-bf69-f0d26d804ebc">
<fme:FEATURE_ID>1001129862</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831229.16</fme:EASTING>
<fme:NORTHING>823167.41</fme:NORTHING>
<fme:SPOTHEIGHT>78</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823167.40700 831229.16000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id65a5f8a5-70e2-4cc2-919c-facfbde45f37">
<fme:FEATURE_ID>1001129749</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832849.53</fme:EASTING>
<fme:NORTHING>823189.38</fme:NORTHING>
<fme:SPOTHEIGHT>161.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823189.37528 832849.52877 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbbfa5506-45ac-4885-9e87-552ad9d1326a">
<fme:FEATURE_ID>1001129829</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830067.07</fme:EASTING>
<fme:NORTHING>823229.44</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823229.44100 830067.07000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfdb549d5-03c5-4ca9-98ed-45c154e1a332">
<fme:FEATURE_ID>1001129951</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831351.39</fme:EASTING>
<fme:NORTHING>823230.09</fme:NORTHING>
<fme:SPOTHEIGHT>98.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823230.08600 831351.38900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8cc5f691-7a16-40c1-af9b-588ed7e87905">
<fme:FEATURE_ID>1001129877</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831473.15</fme:EASTING>
<fme:NORTHING>823237.12</fme:NORTHING>
<fme:SPOTHEIGHT>152.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823237.11600 831473.15200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide55e19ed-9dc9-4a38-97df-ef364f635c86">
<fme:FEATURE_ID>1001130061</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831703.59</fme:EASTING>
<fme:NORTHING>823252.47</fme:NORTHING>
<fme:SPOTHEIGHT>101.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823252.46944 831703.59192 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6c2a6361-1cf4-4fe8-bf79-bf77f0e477bb">
<fme:FEATURE_ID>1001129747</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833157.02</fme:EASTING>
<fme:NORTHING>823257.3</fme:NORTHING>
<fme:SPOTHEIGHT>161.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823257.29910 833157.01854 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id00d5be13-b05a-40b8-b4c1-4bd196456414">
<fme:FEATURE_ID>1001129791</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833038.76</fme:EASTING>
<fme:NORTHING>823266.96</fme:NORTHING>
<fme:SPOTHEIGHT>136.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823266.96129 833038.75847 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2bfdc524-ce50-42c9-bd46-6bd9e6534db2">
<fme:FEATURE_ID>1001129941</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833573.27</fme:EASTING>
<fme:NORTHING>823290.35</fme:NORTHING>
<fme:SPOTHEIGHT>130.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823290.35316 833573.26735 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb1551508-7266-4406-85c6-a80f0ddb5337">
<fme:FEATURE_ID>1001129861</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830858.9</fme:EASTING>
<fme:NORTHING>823299.43</fme:NORTHING>
<fme:SPOTHEIGHT>18.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823299.43333 830858.90341 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb4064c48-f9a0-483d-920c-1cf570dd2888">
<fme:FEATURE_ID>1001129876</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831377.65</fme:EASTING>
<fme:NORTHING>823318.87</fme:NORTHING>
<fme:SPOTHEIGHT>163.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823318.87132 831377.64554 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbf9a95d1-7cc1-4149-b8ad-af98e6f7a09b">
<fme:FEATURE_ID>1001129914</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831733.7</fme:EASTING>
<fme:NORTHING>823321.73</fme:NORTHING>
<fme:SPOTHEIGHT>90.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823321.72977 831733.70264 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id714b7149-6e21-4473-ae83-471bfaed732a">
<fme:FEATURE_ID>1001129943</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833368.05</fme:EASTING>
<fme:NORTHING>823330.06</fme:NORTHING>
<fme:SPOTHEIGHT>118.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823330.05926 833368.05428 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5ba949a9-6c50-4256-b12a-c8342e09f3e2">
<fme:FEATURE_ID>1001129757</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832803.7</fme:EASTING>
<fme:NORTHING>823341.01</fme:NORTHING>
<fme:SPOTHEIGHT>187.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823341.01279 832803.69903 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id239b32bb-f08e-440c-aca9-3d5fa4a7a8ff">
<fme:FEATURE_ID>1001130063</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833014.43</fme:EASTING>
<fme:NORTHING>823351.44</fme:NORTHING>
<fme:SPOTHEIGHT>134.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823351.43870 833014.43439 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id269d7f0e-a7d9-4826-a7fa-ba367cc34ce9">
<fme:FEATURE_ID>1001129911</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832095.1</fme:EASTING>
<fme:NORTHING>823351.58</fme:NORTHING>
<fme:SPOTHEIGHT>143.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823351.58148 832095.09707 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb2801f41-7849-43eb-81db-a870c0d276d8">
<fme:FEATURE_ID>1001129746</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833150.44</fme:EASTING>
<fme:NORTHING>823362.81</fme:NORTHING>
<fme:SPOTHEIGHT>162.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823362.81250 833150.43750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9090d53d-b0fd-4189-b06c-1f8770c2adcb">
<fme:FEATURE_ID>1001129860</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831078.17</fme:EASTING>
<fme:NORTHING>823368.82</fme:NORTHING>
<fme:SPOTHEIGHT>34</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823368.81700 831078.16900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida70ef214-ce99-49fd-a20d-18e4d4d8f088">
<fme:FEATURE_ID>1001129987</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832449.28</fme:EASTING>
<fme:NORTHING>823382.03</fme:NORTHING>
<fme:SPOTHEIGHT>186.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823382.02603 832449.27517 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id67c7059f-9d97-4c44-be79-0f942ad97e2d">
<fme:FEATURE_ID>1001129910</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831558.77</fme:EASTING>
<fme:NORTHING>823383.35</fme:NORTHING>
<fme:SPOTHEIGHT>130</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823383.35142 831558.76853 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4e57c09e-4ff7-49bf-beaa-fd5f76c6cf9c">
<fme:FEATURE_ID>1001129827</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830725.19</fme:EASTING>
<fme:NORTHING>823384.8</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823384.79900 830725.18800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1276e647-a6c2-43ea-9a37-20e9e7d645a8">
<fme:FEATURE_ID>1001130006</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830155.34</fme:EASTING>
<fme:NORTHING>823405.97</fme:NORTHING>
<fme:SPOTHEIGHT>25.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823405.97300 830155.33900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfffdaf46-2c9e-4a31-92ec-7029171842df">
<fme:FEATURE_ID>1001129953</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830852.38</fme:EASTING>
<fme:NORTHING>823407.69</fme:NORTHING>
<fme:SPOTHEIGHT>29.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823407.68839 830852.38446 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb23ec704-9743-4173-a8e5-6554b4e27154">
<fme:FEATURE_ID>1001129996</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831795.61</fme:EASTING>
<fme:NORTHING>823415.39</fme:NORTHING>
<fme:SPOTHEIGHT>101.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823415.38576 831795.60557 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd38c88db-d443-4b90-bda2-1cb81ecc6ee3">
<fme:FEATURE_ID>1001129854</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830998.59</fme:EASTING>
<fme:NORTHING>823432.18</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823432.18200 830998.58800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id99034e7a-f98c-45cb-be71-016a3935d697">
<fme:FEATURE_ID>1001129849</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831167.06</fme:EASTING>
<fme:NORTHING>823443.94</fme:NORTHING>
<fme:SPOTHEIGHT>44.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823443.94200 831167.06400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idce2a077b-62c2-41cc-9801-655ace2b388e">
<fme:FEATURE_ID>1001130005</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830396.68</fme:EASTING>
<fme:NORTHING>823456.32</fme:NORTHING>
<fme:SPOTHEIGHT>5.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823453.06900 830383.64900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd9b3ebae-5e8a-4087-b23a-a706972f1782">
<fme:FEATURE_ID>1001129753</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832296.77</fme:EASTING>
<fme:NORTHING>823462.46</fme:NORTHING>
<fme:SPOTHEIGHT>222.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823462.45800 832296.77400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida261be8d-9ca0-4216-88d6-7e16eca77a9c">
<fme:FEATURE_ID>1001129741</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830095.16</fme:EASTING>
<fme:NORTHING>823462.75</fme:NORTHING>
<fme:SPOTHEIGHT>50.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823462.74900 830095.15700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id579a9a9a-e21a-48f1-95aa-a680a4af30f6">
<fme:FEATURE_ID>1001130028</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832031.09</fme:EASTING>
<fme:NORTHING>823463.12</fme:NORTHING>
<fme:SPOTHEIGHT>156</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823463.12036 832031.08548 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id02d6eb32-26ee-42bc-898b-0fbee12c44c9">
<fme:FEATURE_ID>1001129842</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830129.31</fme:EASTING>
<fme:NORTHING>823467.64</fme:NORTHING>
<fme:SPOTHEIGHT>45.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823467.64234 830129.31033 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf85d8b79-8235-4a38-995d-45ab1b304603">
<fme:FEATURE_ID>1001129928</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831673.2</fme:EASTING>
<fme:NORTHING>823466.14</fme:NORTHING>
<fme:SPOTHEIGHT>107.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823468.84600 831675.69200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id18cacf45-225c-477b-bfc7-f0026f86f46a">
<fme:FEATURE_ID>1001129949</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831509.09</fme:EASTING>
<fme:NORTHING>823497.64</fme:NORTHING>
<fme:SPOTHEIGHT>153.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823497.63737 831509.09084 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id35117810-fdcc-415d-b7ff-781c073ed90b">
<fme:FEATURE_ID>1001129848</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830981.48</fme:EASTING>
<fme:NORTHING>823498.14</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823498.13600 830981.48000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc251cc46-3b53-450d-b5b3-42acc0ca6b62">
<fme:FEATURE_ID>1001129858</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831431.42</fme:EASTING>
<fme:NORTHING>823501.49</fme:NORTHING>
<fme:SPOTHEIGHT>166.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823501.48726 831431.41740 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb27dac9c-4a44-4b4a-b198-dc7a3834db10">
<fme:FEATURE_ID>1001129922</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831889.54</fme:EASTING>
<fme:NORTHING>823502.23</fme:NORTHING>
<fme:SPOTHEIGHT>115.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823502.22915 831889.54096 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idab30bfe8-78ca-4aa3-b41b-67b468de95b3">
<fme:FEATURE_ID>1001129756</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833378.9</fme:EASTING>
<fme:NORTHING>823509.81</fme:NORTHING>
<fme:SPOTHEIGHT>136.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823509.81430 833378.90450 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id93424958-3908-4d65-849a-7aa9516a5d91">
<fme:FEATURE_ID>1310009350</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830217.84</fme:EASTING>
<fme:NORTHING>823527.33</fme:NORTHING>
<fme:SPOTHEIGHT>32.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823527.32904 830217.83613 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id306e1836-d110-4c76-8c6c-71d8178b7591">
<fme:FEATURE_ID>1001129843</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830178.39</fme:EASTING>
<fme:NORTHING>823531.29</fme:NORTHING>
<fme:SPOTHEIGHT>22.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823531.29400 830178.39400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5c5df38c-13b0-4eea-8ee4-9274f5c98553">
<fme:FEATURE_ID>1001129929</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831723.72</fme:EASTING>
<fme:NORTHING>823557.21</fme:NORTHING>
<fme:SPOTHEIGHT>113.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823557.21454 831723.72426 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7c16b915-1101-46c3-a6f3-ae9163b617dc">
<fme:FEATURE_ID>1310009351</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830167.83</fme:EASTING>
<fme:NORTHING>823568.21</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823568.20725 830167.82978 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7aaf4fd9-0de3-4878-a0e3-86ecb4ca7c38">
<fme:FEATURE_ID>1001129742</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833251.85</fme:EASTING>
<fme:NORTHING>823569.73</fme:NORTHING>
<fme:SPOTHEIGHT>180.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823569.72830 833251.84760 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id39290b4a-21b3-4dc4-9092-67eed244cd80">
<fme:FEATURE_ID>1001129841</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830428.37</fme:EASTING>
<fme:NORTHING>823575.46</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823575.45700 830428.37300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcb1c1052-99e9-4649-bfcd-228b1b99fa5a">
<fme:FEATURE_ID>1001129927</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831627.38</fme:EASTING>
<fme:NORTHING>823579.57</fme:NORTHING>
<fme:SPOTHEIGHT>119.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823579.57231 831627.37619 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8657a4ed-8051-4505-baea-0c3228763ff4">
<fme:FEATURE_ID>1001129950</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831158.51</fme:EASTING>
<fme:NORTHING>823588.28</fme:NORTHING>
<fme:SPOTHEIGHT>28.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823588.28100 831158.51200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc9bf5273-efea-40e8-b1fc-e419255cead6">
<fme:FEATURE_ID>1001130004</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830334.8</fme:EASTING>
<fme:NORTHING>823589.11</fme:NORTHING>
<fme:SPOTHEIGHT>10.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823589.11300 830334.80400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id463f1e87-0ef3-4cf1-a93a-51f126ad8157">
<fme:FEATURE_ID>1001130041</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830904.31</fme:EASTING>
<fme:NORTHING>823589.72</fme:NORTHING>
<fme:SPOTHEIGHT>6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823589.71600 830904.31200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida6fbc9ee-1eb7-4bb2-af93-0cd7895c27cd">
<fme:FEATURE_ID>1001129837</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830214.65</fme:EASTING>
<fme:NORTHING>823596.41</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823596.41300 830214.64800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id28ff9d38-4976-40fa-b0ae-b677a19a210a">
<fme:FEATURE_ID>1001129855</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830952.15</fme:EASTING>
<fme:NORTHING>823597.19</fme:NORTHING>
<fme:SPOTHEIGHT>27.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823597.96100 830950.84300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id16aea38f-3a6e-44b1-bf22-53c57d3dfa7b">
<fme:FEATURE_ID>1001130003</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830160.33</fme:EASTING>
<fme:NORTHING>823613.39</fme:NORTHING>
<fme:SPOTHEIGHT>34.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823613.39000 830160.33000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id08203499-1e12-4c51-bc92-a9571d9fdc7d">
<fme:FEATURE_ID>1001129847</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830785.38</fme:EASTING>
<fme:NORTHING>823616.2</fme:NORTHING>
<fme:SPOTHEIGHT>5.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823616.20400 830785.38200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc8127f5d-2865-4211-b473-051c91870323">
<fme:FEATURE_ID>1001129754</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832380.5</fme:EASTING>
<fme:NORTHING>823619.4</fme:NORTHING>
<fme:SPOTHEIGHT>210.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823619.40100 832380.49600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id935f2281-4026-4557-b190-8f7197d4a373">
<fme:FEATURE_ID>1001129925</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831642.38</fme:EASTING>
<fme:NORTHING>823621.04</fme:NORTHING>
<fme:SPOTHEIGHT>100.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823621.03719 831642.38410 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id282d1b02-24dc-4d64-856d-cb29691b369d">
<fme:FEATURE_ID>1001129836</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830024.43</fme:EASTING>
<fme:NORTHING>823621.06</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823621.05600 830024.43400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8a84cf01-ed84-4a39-8ec5-59547e5114e4">
<fme:FEATURE_ID>1001129921</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831831</fme:EASTING>
<fme:NORTHING>823622.09</fme:NORTHING>
<fme:SPOTHEIGHT>107.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823622.09161 831831.00255 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf216df43-a660-4e8f-ac5d-8fe74198f3ea">
<fme:FEATURE_ID>1210000502</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830106.93</fme:EASTING>
<fme:NORTHING>823624.4</fme:NORTHING>
<fme:SPOTHEIGHT>17.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823624.40330 830106.93350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id60c8ce91-1fda-4dad-acc8-56808bcc0b71">
<fme:FEATURE_ID>1001129999</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831231.83</fme:EASTING>
<fme:NORTHING>823629.93</fme:NORTHING>
<fme:SPOTHEIGHT>26.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823629.92500 831231.82700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2eff5d97-2a5d-4ba5-b4fa-38164005b74d">
<fme:FEATURE_ID>1001130025</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830341.18</fme:EASTING>
<fme:NORTHING>823632.31</fme:NORTHING>
<fme:SPOTHEIGHT>5.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823632.30700 830341.17700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id435b1ffa-8c9c-4ba6-81f0-c0f7d9e2a3cc">
<fme:FEATURE_ID>1001129838</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830609.7</fme:EASTING>
<fme:NORTHING>823633.12</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823633.12200 830609.69800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf7d81136-e99e-441c-b076-bb585702f590">
<fme:FEATURE_ID>1001129744</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833375.29</fme:EASTING>
<fme:NORTHING>823633.16</fme:NORTHING>
<fme:SPOTHEIGHT>181.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823633.16270 833375.29220 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc6e0c9b4-6af1-48cf-846b-bd4d4dd564b1">
<fme:FEATURE_ID>1001129846</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831061.71</fme:EASTING>
<fme:NORTHING>823655.48</fme:NORTHING>
<fme:SPOTHEIGHT>13.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823655.48024 831061.71006 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5a5923aa-a29d-4283-9c88-2694a34bab80">
<fme:FEATURE_ID>1001129926</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831740.24</fme:EASTING>
<fme:NORTHING>823662.82</fme:NORTHING>
<fme:SPOTHEIGHT>102.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823662.82090 831740.24065 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id23abf9c1-20a0-4a5f-b87d-fb5a94d31605">
<fme:FEATURE_ID>1001129986</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832143.27</fme:EASTING>
<fme:NORTHING>823665.49</fme:NORTHING>
<fme:SPOTHEIGHT>216.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823665.49070 832143.26976 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7dc90b5a-5039-4740-a71f-a749a5787e65">
<fme:FEATURE_ID>1001129856</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831002.32</fme:EASTING>
<fme:NORTHING>823678.17</fme:NORTHING>
<fme:SPOTHEIGHT>10.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823678.16600 831002.32300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb0f2cdee-961e-4a6e-8382-7e7b17a756b7">
<fme:FEATURE_ID>1001129839</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830561.37</fme:EASTING>
<fme:NORTHING>823683.56</fme:NORTHING>
<fme:SPOTHEIGHT>33.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823683.56000 830561.37000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide982c3e8-e515-461c-b808-c28c733e46ee">
<fme:FEATURE_ID>1001129933</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832273.56</fme:EASTING>
<fme:NORTHING>823684.07</fme:NORTHING>
<fme:SPOTHEIGHT>208.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823684.07200 832273.56000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida8783858-6ee3-4607-9b85-0b71d47c9831">
<fme:FEATURE_ID>1001129845</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830968.74</fme:EASTING>
<fme:NORTHING>823690.31</fme:NORTHING>
<fme:SPOTHEIGHT>10.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823690.31200 830968.73700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2f42503b-5ad9-49f8-9530-120e601c41a6">
<fme:FEATURE_ID>1001129853</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830816.89</fme:EASTING>
<fme:NORTHING>823690.87</fme:NORTHING>
<fme:SPOTHEIGHT>5.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823690.87400 830816.89200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id707b5ccc-35de-4694-8595-35d955c17d1e">
<fme:FEATURE_ID>1001130051</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832348.34</fme:EASTING>
<fme:NORTHING>823712.13</fme:NORTHING>
<fme:SPOTHEIGHT>184.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823712.12500 832348.33700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3b7279ea-2c86-4fe9-b262-2707207cd275">
<fme:FEATURE_ID>1001129920</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831614.91</fme:EASTING>
<fme:NORTHING>823712.87</fme:NORTHING>
<fme:SPOTHEIGHT>85.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823712.86761 831614.91212 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb27d8b68-50f8-46c3-b1f7-d2b8a3911ce8">
<fme:FEATURE_ID>1001129755</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832409.82</fme:EASTING>
<fme:NORTHING>823731.48</fme:NORTHING>
<fme:SPOTHEIGHT>192.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823731.48000 832409.81500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4c310eb0-4426-4c49-8e2a-8b50344f1c67">
<fme:FEATURE_ID>1001129840</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830538.19</fme:EASTING>
<fme:NORTHING>823733.78</fme:NORTHING>
<fme:SPOTHEIGHT>34.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823733.78207 830538.18627 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id49bea4c7-db6c-4763-a310-ec80d461dc37">
<fme:FEATURE_ID>1001129834</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830383.31</fme:EASTING>
<fme:NORTHING>823738.02</fme:NORTHING>
<fme:SPOTHEIGHT>30.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823738.44500 830385.44700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2434b761-32ea-4c49-8732-c167c85700e9">
<fme:FEATURE_ID>1420000941</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830287.23</fme:EASTING>
<fme:NORTHING>823738.93</fme:NORTHING>
<fme:SPOTHEIGHT>28.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823738.93400 830287.23000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide22d4253-e4b2-47c2-b453-dcfebdcdd76e">
<fme:FEATURE_ID>1001129932</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832561.37</fme:EASTING>
<fme:NORTHING>823749.34</fme:NORTHING>
<fme:SPOTHEIGHT>153.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823749.33500 832561.37300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0dfbe94f-dd3a-4940-a752-e4c94febef2a">
<fme:FEATURE_ID>1001129857</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831080.89</fme:EASTING>
<fme:NORTHING>823755.96</fme:NORTHING>
<fme:SPOTHEIGHT>21.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823755.96349 831080.88652 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc5d8689a-838a-484d-b3e7-e860a31abce8">
<fme:FEATURE_ID>1001129998</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831461.25</fme:EASTING>
<fme:NORTHING>823764.4</fme:NORTHING>
<fme:SPOTHEIGHT>91.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823764.39900 831461.24700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id840e93b4-4308-4e1e-8322-24eabe96550a">
<fme:FEATURE_ID>1001129923</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831652.68</fme:EASTING>
<fme:NORTHING>823786.8</fme:NORTHING>
<fme:SPOTHEIGHT>65.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823786.80181 831652.68069 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6fc43c26-ec66-4882-ad4b-7031dc9b3126">
<fme:FEATURE_ID>1001129748</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833004.51</fme:EASTING>
<fme:NORTHING>823798.43</fme:NORTHING>
<fme:SPOTHEIGHT>186.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823798.43100 833004.50590 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc8f85339-452c-499c-a4af-c936855a1292">
<fme:FEATURE_ID>1001129930</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832077.17</fme:EASTING>
<fme:NORTHING>823813.6</fme:NORTHING>
<fme:SPOTHEIGHT>229.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823813.60230 832077.17188 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9598029c-401a-4e91-9ee7-1d64f00d2e99">
<fme:FEATURE_ID>1001129957</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830663.06</fme:EASTING>
<fme:NORTHING>823834.86</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823833.09600 830665.99800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idaceff275-168d-409c-ac63-f144d88a0afa">
<fme:FEATURE_ID>1001129859</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831473.65</fme:EASTING>
<fme:NORTHING>823847.49</fme:NORTHING>
<fme:SPOTHEIGHT>69.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823847.48600 831473.65200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id54e06808-1990-4878-a7fd-c32977547641">
<fme:FEATURE_ID>1001129789</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833725.8</fme:EASTING>
<fme:NORTHING>823851.95</fme:NORTHING>
<fme:SPOTHEIGHT>144.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823851.95220 833725.79590 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id09d638b5-2e55-4fb3-8dd3-e41d720b56ad">
<fme:FEATURE_ID>1001129844</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831274.93</fme:EASTING>
<fme:NORTHING>823860.13</fme:NORTHING>
<fme:SPOTHEIGHT>11.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823860.13300 831274.92600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id060f5204-131f-4ab1-a61f-4377b717af30">
<fme:FEATURE_ID>1001130026</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830921.79</fme:EASTING>
<fme:NORTHING>823865.91</fme:NORTHING>
<fme:SPOTHEIGHT>13.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823865.90600 830921.79200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id75d19100-f111-4e16-937d-05f4fe9ff0fa">
<fme:FEATURE_ID>1420000940</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830168.94</fme:EASTING>
<fme:NORTHING>823872.31</fme:NORTHING>
<fme:SPOTHEIGHT>18</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>2</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20251219</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823872.30500 830168.94100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd14998a8-19de-45b7-bef9-73590d9b0fec">
<fme:FEATURE_ID>1001129745</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833455.2</fme:EASTING>
<fme:NORTHING>823875.01</fme:NORTHING>
<fme:SPOTHEIGHT>220.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823875.01380 833455.20250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbf47f73f-a4bd-4c8d-b552-13adad849028">
<fme:FEATURE_ID>1001129851</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830797.49</fme:EASTING>
<fme:NORTHING>823889.71</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823889.70720 830797.49121 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id35fe8d0f-d9e5-4256-ac45-02c61b3e4326">
<fme:FEATURE_ID>1001129832</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830059</fme:EASTING>
<fme:NORTHING>823889.8</fme:NORTHING>
<fme:SPOTHEIGHT>5.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823889.80000 830059.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2bbd289a-84f4-4c64-bc75-e3ab6c47f65a">
<fme:FEATURE_ID>1001129743</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833253.42</fme:EASTING>
<fme:NORTHING>823891.68</fme:NORTHING>
<fme:SPOTHEIGHT>207</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823891.68270 833253.41750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfc7eca99-8419-4cce-9e5e-8d72616f101d">
<fme:FEATURE_ID>1001129831</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830620.78</fme:EASTING>
<fme:NORTHING>823928.18</fme:NORTHING>
<fme:SPOTHEIGHT>5.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823928.17500 830620.78100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5f56c331-9dfb-4523-a122-e12422cd0e80">
<fme:FEATURE_ID>1001129852</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830962.17</fme:EASTING>
<fme:NORTHING>823929.76</fme:NORTHING>
<fme:SPOTHEIGHT>5.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823929.76300 830962.17100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id396da7bc-9422-47b9-a95f-1f3121828a9e">
<fme:FEATURE_ID>1001129948</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832417.13</fme:EASTING>
<fme:NORTHING>823938.03</fme:NORTHING>
<fme:SPOTHEIGHT>183</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823938.03000 832417.12800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id73a0b335-8c4a-4b1d-8296-70c3c454330f">
<fme:FEATURE_ID>1210006410</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831124.27</fme:EASTING>
<fme:NORTHING>823953.27</fme:NORTHING>
<fme:SPOTHEIGHT>6.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823953.26899 831124.27358 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id75d8485c-223b-479d-9d13-3f49c202dd32">
<fme:FEATURE_ID>1001129918</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831503.13</fme:EASTING>
<fme:NORTHING>823964.23</fme:NORTHING>
<fme:SPOTHEIGHT>48.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823964.23160 831503.13021 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbc369e1c-3685-45a6-9296-a1673869240c">
<fme:FEATURE_ID>1001129924</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831662.13</fme:EASTING>
<fme:NORTHING>823967.25</fme:NORTHING>
<fme:SPOTHEIGHT>40.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823967.25000 831662.12500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id739c40ae-6ba2-4366-b407-6d5abac093e0">
<fme:FEATURE_ID>1001129850</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831378.91</fme:EASTING>
<fme:NORTHING>823969.49</fme:NORTHING>
<fme:SPOTHEIGHT>39.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823969.48700 831378.91200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ideb162c70-cfa6-4681-9c61-781588f124b3">
<fme:FEATURE_ID>1001130052</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830145.71</fme:EASTING>
<fme:NORTHING>823973.06</fme:NORTHING>
<fme:SPOTHEIGHT>35.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823973.06012 830145.70659 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida690d8b6-3b39-4c6b-916e-ef7e1a38680d">
<fme:FEATURE_ID>1001129955</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830330.69</fme:EASTING>
<fme:NORTHING>823981.62</fme:NORTHING>
<fme:SPOTHEIGHT>38.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823981.61500 830330.69210 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcc3388e5-70b5-49ae-bf90-4c52d19668da">
<fme:FEATURE_ID>1001129931</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832509.64</fme:EASTING>
<fme:NORTHING>823986.23</fme:NORTHING>
<fme:SPOTHEIGHT>167.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823986.23400 832509.64000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3218c53e-6f8d-4661-b4f9-e1d45d6a9c37">
<fme:FEATURE_ID>1001129830</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830468.91</fme:EASTING>
<fme:NORTHING>823986.39</fme:NORTHING>
<fme:SPOTHEIGHT>36.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823986.65200 830466.66000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
</gml:FeatureCollection>
