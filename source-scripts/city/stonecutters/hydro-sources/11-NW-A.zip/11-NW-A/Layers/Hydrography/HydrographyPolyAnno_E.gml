<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyPolyAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821097.19205 832229.51364</gml:lowerCorner>
<gml:upperCorner>823979.50962 833703.09699</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id6cd76320-b296-4efc-8650-56c94dc5938d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Nullah</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>53.3438805956372</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000848625</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>833052.03094703</fme:EASTING>
<fme:NORTHING>822784.87645733</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822801.26826 833064.22950</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idcad2345b-8e23-4285-b630-353b7c319b2b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-103.557453869099</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274760</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823979.50962 833703.09699</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id9efbc4e2-dc94-4901-99d2-6c18190d9ee9">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>139.737331438168</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274757</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823228.66615 833331.47390</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id89526716-bcb1-47d2-87b3-c07de0917ae5">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>152.949423934179</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274754</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823599.28878 833177.75544</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id5f0be8d9-870a-4eb2-8113-c5662d1cf993">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>123.486155463051</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274755</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823009.75153 832229.51364</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id1cf09a00-1058-4716-b2d2-d9f9b78489f8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-76.5690249386115</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274759</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823972.19544 833556.25239</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id0a53b066-d49c-40d9-9cc9-dc640c7959ba">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>31.6204872582624</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274761</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823009.75247 833310.14383</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idfa40d5bf-5262-4bbc-9b2b-6a83b293a4ac">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-74.6237126941189</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274762</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823341.38935 833300.66298</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idd4c83659-4088-4f45-a159-e7c963524d47">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>143.746130801417</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274764</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822772.03063 833044.28812</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id7540e116-38a1-45f9-a248-ced73d412136">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>147.197558328032</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001182</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821097.19205 832967.68859</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idc9b44642-70b5-44b9-823a-bf4fe615ac14">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-160.938457872071</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001902</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING>833089.159</fme:EASTING>
<fme:NORTHING>822786.453</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822786.45347 833089.15918</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
