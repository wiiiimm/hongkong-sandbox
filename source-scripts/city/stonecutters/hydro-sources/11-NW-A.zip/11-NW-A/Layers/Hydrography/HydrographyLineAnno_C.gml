<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyLineAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821075.64576 830015.07165</gml:lowerCorner>
<gml:upperCorner>823844.54173 832971.10088</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id546114a2-ac94-46dc-adda-a548ea1faa7b">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.5042587354761</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831698</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>832961.84638589</fme:EASTING>
<fme:NORTHING>821081.31786065</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821075.64576 832971.10088</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id7968d81c-151c-471d-bcdb-55fa7d47aaa1">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>16.3775166214685</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831694</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>830080.70303942</fme:EASTING>
<fme:NORTHING>823173.64997339</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823179.00002 830088.74161</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id67dd9fda-c496-42fb-8807-27aabfec451d">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-74.0428206898556</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831697</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>830950.19889278</fme:EASTING>
<fme:NORTHING>821477.6307391</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821469.55314 830955.48983</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id43da585a-6eda-4e9d-840b-d7c01e4ea336">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-71.5516988392953</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831695</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>830555.85989003</fme:EASTING>
<fme:NORTHING>822729.07694696</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822721.23695 830561.49692</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="ide6afcba7-9fd3-4def-88d1-346615e18e01">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.7459285287794</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831696</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>831333.04171454</fme:EASTING>
<fme:NORTHING>822179.90901839</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822171.95324 831338.51412</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id607e85ba-c3ee-4d14-8814-d6ea4c261963">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-71.5650475951694</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831693</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>831910.94446396</fme:EASTING>
<fme:NORTHING>821187.68459213</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821163.69394 831918.94135</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="idd670374a-5f3d-4843-bdeb-cb04718cca9f">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.7765654302034</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831699</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>830110.0936665</fme:EASTING>
<fme:NORTHING>821534.50892133</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821526.55021 830115.56182</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="idc2ba6398-724b-4c80-b4c4-394d30212a2d">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.953606710203</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831692</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>830016.4525251</fme:EASTING>
<fme:NORTHING>823834.98480201</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823844.54173 830015.07165</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
