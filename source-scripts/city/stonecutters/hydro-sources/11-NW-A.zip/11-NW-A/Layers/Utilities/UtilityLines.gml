<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityLines.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>822466.90480 830107.47900 0.00000</gml:lowerCorner>
<gml:upperCorner>824000.00000 833750.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityLines gml:id="id560af0ba-47d8-4418-855d-ae4278af10fa">
<fme:FEATURE_ID>1001171062</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172783</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822879.12417 833179.58695 0.00000 822878.95100 833160.07900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id5fc0cf64-8969-4cdc-84b7-0316a7ad4eee">
<fme:FEATURE_ID>1001171019</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172794</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823335.69000 832791.64000 0.00000 823330.44200 832805.02500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id6fe41a2c-a293-4f84-a3bd-08aa72df1dbf">
<fme:FEATURE_ID>1001166309</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822787.21249 832603.04767 0.00000 822789.27954 832624.44772 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id34b95747-e252-4fe9-a585-f57b931f6957">
<fme:FEATURE_ID>1001167985</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822871.32155 833187.16508 0.00000 823137.81166 833490.14603 0.00000 823142.67000 833597.44000 0.00000 823149.09000 833750.00000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id6642f84f-9433-4ddb-8e8c-fce83664a009">
<fme:FEATURE_ID>1210005046</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823692.67824 832541.66580 0.00000 823657.06695 832582.96406 0.00000 823587.87544 832612.88837 0.00000 823471.15709 832622.36666 0.00000 823375.56177 832629.00146 0.00000 823289.85096 832693.72463 0.00000 823161.35244 832739.62663 0.00000 823144.83314 832745.99063 0.00000 823123.71010 832742.19931 0.00000 823049.50863 832715.25389 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id27d59907-faa3-4a5a-9212-4449b960feb7">
<fme:FEATURE_ID>1001171075</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172780</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822781.90500 832625.42500 0.00000 822788.12000 832613.77000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id52c5cb8e-0d32-43b2-bf37-1cfc3fed8cad">
<fme:FEATURE_ID>1001170976</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172805</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823579.34626 832495.85752 0.00000 823592.05100 832505.33400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id14503b44-9380-442e-b28f-c19596bdf90d">
<fme:FEATURE_ID>1001166299</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822545.90331 832629.88317 0.00000 822466.90480 832693.55903 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id3ab10b78-7d98-4053-9c37-73159373f04f">
<fme:FEATURE_ID>1001166318</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823330.44200 832805.02500 0.00000 823052.74000 832878.28000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ide07ec2e6-5a0e-437a-83ba-a72117c5d54f">
<fme:FEATURE_ID>1001166280</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823255.94025 832549.79412 0.00000 823256.73000 832555.86000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ida5dd1b93-c762-4180-bdb8-b603f30c54eb">
<fme:FEATURE_ID>1001171061</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172783</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822879.25900 833194.77600 0.00000 822879.12417 833179.58695 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id895755bd-c5ae-464f-846f-495db297bd95">
<fme:FEATURE_ID>1001166306</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822564.63703 832766.16007 0.00000 822627.57070 832920.33943 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idae37f108-1e8e-401b-a881-81c6eb670473">
<fme:FEATURE_ID>1001166281</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823255.33000 832545.10700 0.00000 823255.94025 832549.79412 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id1d3777fc-efb9-42a4-bbb0-143303f61e9e">
<fme:FEATURE_ID>1001166327</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823306.90500 833263.19250 0.00000 823268.25800 833294.25700 0.00000 823205.04032 833344.61108 0.00000 823215.67600 833373.09400 0.00000 823267.00000 833478.83000 0.00000 823298.44800 833541.99900 0.00000 823322.46900 833590.70300 0.00000 823352.78100 833633.41400 0.00000 823384.04200 833690.37700 0.00000 823408.45900 833735.36000 0.00000 823418.51371 833749.99812 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id94fb1c7c-d5ba-405b-be6f-ba6e6ca22c7a">
<fme:FEATURE_ID>1001171071</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172781</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822802.75000 832647.60000 0.00000 822810.07000 832660.15000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id6794096a-e2d8-4a53-9f94-549823d80325">
<fme:FEATURE_ID>1001166319</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823324.70200 832782.89900 0.00000 823058.44000 832853.52000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ide8470c72-fb0f-42f5-906c-9a03064c2560">
<fme:FEATURE_ID>1001166308</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822606.30000 832925.94000 0.00000 822610.74122 832934.03282 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idfdd79512-8fdd-492b-b172-a908797c71b8">
<fme:FEATURE_ID>1001167995</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823592.05100 832505.33400 0.00000 823941.38000 832453.46000 0.00000 824000.00000 832444.53000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id19c51b21-0d9f-44a1-acd1-3da36af66577">
<fme:FEATURE_ID>1001171074</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172780</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822788.12000 832613.77000 0.00000 822794.60600 832602.19100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idb3bc687f-1a23-4c07-9efa-84da707490d9">
<fme:FEATURE_ID>1001171089</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172776</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822571.02000 832642.60000 0.00000 822557.60830 832642.52283 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idab633955-e1a8-4b30-a09b-0ba7db427be7">
<fme:FEATURE_ID>1001167992</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823557.48600 832721.21100 0.00000 824000.00000 832602.88000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id7ca6f9f9-4a96-42fa-bb83-e2990755e0f4">
<fme:FEATURE_ID>1001171072</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172781</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822810.07000 832660.15000 0.00000 822797.89000 832667.35000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id14efed5e-b20c-4604-8e52-c7d9e0745e41">
<fme:FEATURE_ID>1210007846</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822661.71569 832703.31898 0.00000 822570.20513 832746.07836 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id38c1104b-53ce-4f64-86c6-3031195ea05f">
<fme:FEATURE_ID>1001166284</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822612.07250 832932.94962 0.00000 822619.22551 832927.12953 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id5b9591aa-2d18-4982-b309-4726af646158">
<fme:FEATURE_ID>1001171093</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172775</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822552.76695 832777.15067 0.00000 822553.15000 832764.99000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id76af6e71-f437-4010-821d-21a8eb36b79d">
<fme:FEATURE_ID>1001166313</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823058.44000 832853.52000 0.00000 822814.10000 832644.49000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id988c112d-d91c-4c38-ab41-8448544078df">
<fme:FEATURE_ID>1001166286</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822568.67000 832654.55000 0.00000 822781.90500 832625.42500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id56f4147d-ff85-4d3e-87ca-51b3e9466bc8">
<fme:FEATURE_ID>1001171064</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172783</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822863.72600 833179.88200 0.00000 822878.92500 833179.78039 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id77e070cf-b20a-4bd6-b39b-ec7b3a0ac4e3">
<fme:FEATURE_ID>1001171092</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172775</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822565.02000 832777.85000 0.00000 822552.76695 832777.15067 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id2ff6f782-c150-40c8-b5e4-a422bfb5bcb3">
<fme:FEATURE_ID>1001166307</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822564.63703 832766.16007 0.00000 822540.39243 832788.51267 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id0840a259-3cdd-40b6-bbd9-72fc0bf39871">
<fme:FEATURE_ID>1001166293</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822647.09498 832683.02247 0.00000 822534.19400 832730.78700 0.00000 822528.70018 832720.86240 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idbddc536c-49ef-429f-9d29-7767c4a53ab2">
<fme:FEATURE_ID>1001171020</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172794</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823335.69000 832791.64000 0.00000 823324.70200 832782.89900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="iddd127113-ee8d-49e2-ac83-a9e09776b84e">
<fme:FEATURE_ID>1001166304</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822540.39243 832788.51267 0.00000 822606.30000 832925.94000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id644c154e-d93e-4168-b6c4-0c530200dd2a">
<fme:FEATURE_ID>1001166288</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822805.80000 832675.42000 0.00000 822673.19735 832699.43234 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id877e3d58-8289-4dd7-b3b0-499307fe632f">
<fme:FEATURE_ID>1001166302</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822545.90331 832629.88317 0.00000 822568.67000 832654.55000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id1105cc76-b942-41a5-96c2-5a712f7d095e">
<fme:FEATURE_ID>1001166294</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822657.44076 832678.64944 0.00000 822662.04119 832701.82197 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id426cd30b-7849-4ea6-aab1-db0fb739cbbd">
<fme:FEATURE_ID>1001171018</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172794</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823340.92200 832778.60800 0.00000 823335.69000 832791.64000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ida9598df7-9888-4dd8-89d2-7d8ec7bfe187">
<fme:FEATURE_ID>1001171090</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172776</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822557.60830 832642.52283 0.00000 822557.89114 832627.91926 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id51dbef4d-f471-47d4-8b41-0f624a5bcf8b">
<fme:FEATURE_ID>1001171037</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172789</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823150.48913 833485.98726 0.00000 823166.36090 833495.24782 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id44c5d0a8-8075-4b6c-9a2e-aec71f997857">
<fme:FEATURE_ID>1001171058</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172785</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823049.39000 832853.86000 0.00000 823055.83000 832864.24000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id7d26c4c0-d936-4cbf-a67e-7f1b80f61601">
<fme:FEATURE_ID>1001166274</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822692.36899 831645.84300 0.00000 822708.81861 831670.18059 0.00000 822744.78000 831721.04000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idfd144beb-987c-4099-939d-8be53167fdf2">
<fme:FEATURE_ID>1001171082</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172778</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822669.69550 832675.85510 0.00000 822660.13000 832690.48000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idefd51c29-104c-4f4a-b1f4-ce0247237eaa">
<fme:FEATURE_ID>1001166292</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823538.67000 832726.20400 0.00000 823400.00000 832763.08000 0.00000 823340.92200 832778.60800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idfd01c954-b7a9-4ad6-88a1-d1993cc00ed3">
<fme:FEATURE_ID>1001166282</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823150.48913 833485.98726 0.00000 823137.78100 833490.04100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id82ddfb2d-14bc-409b-aa22-fb37245f5d2d">
<fme:FEATURE_ID>1001166297</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822610.74122 832934.03282 0.00000 822612.07250 832932.94962 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id6ccb333d-87dd-49ab-abd5-7cf330a636a7">
<fme:FEATURE_ID>1001166300</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822779.70100 832603.91800 0.00000 822558.06541 832627.87138 0.00000 822545.90331 832629.88317 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id2734f122-a992-4c2e-97ee-d80068ce491a">
<fme:FEATURE_ID>1001171067</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172781</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822810.07000 832660.15000 0.00000 822817.15000 832672.28000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idc7e76ddd-a3a5-4cc7-b2e1-2b62d8863a20">
<fme:FEATURE_ID>1001166290</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822814.10000 832644.49000 0.00000 822805.80000 832675.42000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idbcf1ce40-f9fe-472a-a359-5aa85f8b94b6">
<fme:FEATURE_ID>1001171096</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172775</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822551.72000 832794.24000 0.00000 822552.76695 832777.15067 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id98105b23-2400-4b89-af90-68b861436561">
<fme:FEATURE_ID>1001170977</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172805</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823586.78200 832485.03200 0.00000 823579.34626 832495.85752 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idb33c5654-bbec-4fac-9545-db804c53b905">
<fme:FEATURE_ID>1001171056</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172785</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823067.48000 832856.89000 0.00000 823055.83000 832864.24000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id3706bc4e-d0d6-4728-b7a2-c1c603112191">
<fme:FEATURE_ID>1001170983</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172803</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823551.25000 832734.28000 0.00000 823557.48600 832721.21100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id6259a5e7-6c96-4808-b85d-cca3c74cecb2">
<fme:FEATURE_ID>1001166277</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823250.91432 832955.87947 0.00000 823248.11200 832952.10712 0.00000 823246.49528 832951.35265 0.00000 823227.31019 832950.38262 0.00000 823211.29036 832951.62224 0.00000 823208.18350 832952.59509 0.00000 823206.86544 832953.59933 0.00000 823205.35909 832955.85886 0.00000 823204.04102 832958.71466 0.00000 823199.10614 832977.04846 0.00000 823182.95000 832997.14000 0.00000 823178.41000 832999.31000 0.00000 823141.46000 832998.53000 0.00000 823136.93000 832998.19000 0.00000 823135.49000 832997.81000 0.00000 823133.64000 832997.79000 0.00000 823132.79000 832997.97000 0.00000 823131.31000 832998.51000 0.00000 823128.99000 832999.83000 0.00000 823120.45000 833006.31000 0.00000 823107.38000 833015.85000 0.00000 823103.77000 833018.89000 0.00000 823099.40000 833023.07000 0.00000 823092.70000 833030.96000 0.00000 823088.16000 833037.07000 0.00000 823083.81000 833044.05000 0.00000 823080.51000 833051.01000 0.00000 823068.61000 833080.73000 0.00000 823040.93644 833116.10803 0.00000 823044.07589 833125.90309 0.00000 823044.94733 833128.62201 0.00000 823045.90995 833138.40859 0.00000 823040.93644 833152.52693 0.00000 823025.69505 833159.74653 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id6e83ee4c-4a1a-4ff8-b905-4e10a3b6ccfa">
<fme:FEATURE_ID>1001170984</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172803</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823543.85100 832748.35200 0.00000 823551.25000 832734.28000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id5cf3bc10-6deb-47a3-bbc3-059d9df20a93">
<fme:FEATURE_ID>1001171023</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172793</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823250.22000 832550.82000 0.00000 823256.73000 832555.86000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idc433c5fc-f5a9-4b0b-8a03-35a6896427d6">
<fme:FEATURE_ID>1001171024</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172793</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823256.73000 832555.86000 0.00000 823250.19000 832565.12000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id05d90ec4-181c-4fb9-95e2-daa2b9d1a0c4">
<fme:FEATURE_ID>1001171076</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172780</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822788.12000 832613.77000 0.00000 822779.70100 832603.91800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id8e765611-efbe-4978-9c9f-605c9a15f99b">
<fme:FEATURE_ID>1001171087</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172777</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822617.64000 832939.73000 0.00000 822619.22551 832927.12953 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idc5d56958-8fc7-45e2-875c-7e2c7af60d79">
<fme:FEATURE_ID>1001166323</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822878.92500 833179.78039 0.00000 822871.32155 833187.16508 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id0045cfda-99ac-4453-ae3a-41c3f6371d4f">
<fme:FEATURE_ID>1001171038</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172789</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823150.48913 833485.98726 0.00000 823159.71871 833469.75643 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id03257d13-8c9b-4d4f-93b2-78b0276acda8">
<fme:FEATURE_ID>1210005049</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823471.15709 832622.36666 0.00000 823446.24273 832571.04849 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idd6641f9c-3590-415d-aef8-39c306fb7632">
<fme:FEATURE_ID>1001170982</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172803</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823564.92300 832742.78500 0.00000 823551.25000 832734.28000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id30399e68-1853-4c4c-968d-dff8cf0b2188">
<fme:FEATURE_ID>1001166324</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822888.82971 833170.16065 0.00000 823162.87000 833481.86000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idf3f9f5b5-b848-409f-9056-6a0d59596f24">
<fme:FEATURE_ID>1001166283</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822619.22551 832927.12953 0.00000 822625.96969 832921.64210 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id150abb87-368f-40f9-ba84-5e8650000499">
<fme:FEATURE_ID>1001171044</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172789</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823134.21000 833476.50000 0.00000 823150.48913 833485.98726 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idcdc9338b-7fd6-4ad9-9b94-45801a6dd538">
<fme:FEATURE_ID>1001166310</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823577.39453 832486.55576 0.00000 823581.45109 832506.83855 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id0546ac12-5523-48b4-b24a-078376bd4d47">
<fme:FEATURE_ID>1210005050</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823406.73490 831766.23350 0.00000 823390.61975 831771.89558 0.00000 823337.91885 831795.85053 0.00000 823290.00894 831825.61275 0.00000 823248.77739 831856.68160 0.00000 823156.00638 831908.22105 0.00000 823181.99388 831905.46260 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id571194c8-fac3-4191-b2e6-a5b845e94457">
<fme:FEATURE_ID>1210007844</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822661.18689 832703.68495 0.00000 822562.88951 832737.34682 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ide0661660-f2ff-42fb-bcce-9af729abcf24">
<fme:FEATURE_ID>1001171084</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172778</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822646.96667 832681.14521 0.00000 822660.13000 832690.48000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id877a802e-2b4c-424b-a39f-6625c24e235e">
<fme:FEATURE_ID>1001166320</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823162.87000 833481.86000 0.00000 823150.48913 833485.98726 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id1c5203c0-23c2-4050-98b2-e40692bcbfb1">
<fme:FEATURE_ID>1001166275</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822797.68000 831853.87000 0.00000 822795.97000 831858.26000 0.00000 822794.59000 831862.62000 0.00000 822792.81000 831870.20000 0.00000 822790.11000 831899.95000 0.00000 822789.44000 831911.49000 0.00000 822789.91000 831915.99000 0.00000 822794.71000 831931.74000 0.00000 822799.10000 831949.49000 0.00000 822801.05603 831968.05301 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id33732bb4-0b70-4d7a-bf65-ddf16458c530">
<fme:FEATURE_ID>1001166296</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822647.03696 832682.03553 0.00000 822528.70018 832720.86240 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id84bfa6dc-452b-45d9-b0e0-126e49181d89">
<fme:FEATURE_ID>1001167986</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823162.87000 833481.86000 0.00000 823172.34000 833750.00000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idd6a74458-c432-4883-9aac-4cdbe1701c67">
<fme:FEATURE_ID>1001166273</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823887.02300 830122.71600 0.00000 823890.69200 830124.42100 0.00000 823897.67000 830109.63800 0.00000 823892.81800 830107.47900 0.00000 823887.02300 830122.71600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id82070ad1-d5fa-44fe-9dfc-722298855226">
<fme:FEATURE_ID>1001166311</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823548.16639 832723.68405 0.00000 823554.51489 832745.53471 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id4db14249-bd1b-43dc-9f24-cbfecb8c99e7">
<fme:FEATURE_ID>1001166298</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822625.96969 832921.64210 0.00000 822627.57070 832920.33943 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ide93cfd62-89a2-4f76-ba58-6f945f536c9e">
<fme:FEATURE_ID>1001171022</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172793</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823262.27000 832548.66000 0.00000 823256.73000 832555.86000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id0e21874d-0949-40f4-a9eb-174debb7f375">
<fme:FEATURE_ID>1001166326</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822627.57070 832920.33943 0.00000 822888.82971 833170.16065 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idd7f137d1-55a4-43eb-817f-1bbd4e830336">
<fme:FEATURE_ID>1001166312</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823052.74000 832878.28000 0.00000 822962.59000 832804.50000 0.00000 822805.80000 832675.42000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id03172901-7100-4946-bd15-a5b811d0df6c">
<fme:FEATURE_ID>1001171021</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172793</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823256.73000 832555.86000 0.00000 823266.23000 832562.99000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idfdcf86d4-eefe-4796-9b4a-70b7a3b9ca75">
<fme:FEATURE_ID>1001166289</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822814.10000 832644.49000 0.00000 822669.69550 832675.85510 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id9ebea0a2-6fda-45b7-ac9a-f4b24a9b8b03">
<fme:FEATURE_ID>1001171041</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172789</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823140.93000 833501.96000 0.00000 823150.48913 833485.98726 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ida7f5d253-cf68-4b64-a9d7-9d9f9bddab3a">
<fme:FEATURE_ID>1001166303</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822501.08910 832769.78866 0.00000 822540.39243 832788.51267 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id56fc347c-2963-4472-a3fe-03e06c7b9499">
<fme:FEATURE_ID>1001166295</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822528.70018 832720.86240 0.00000 822523.21200 832710.94800 0.00000 822646.96667 832681.14521 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idb235e61f-afae-4821-9543-f336026b0d5a">
<fme:FEATURE_ID>1001166276</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823061.61441 832739.69840 0.00000 823069.56828 832758.58884 0.00000 823064.17101 832785.29112 0.00000 823069.00015 832807.44833 0.00000 823077.23808 832817.81676 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idb220559e-0747-4739-acdf-beac9fdb69ae">
<fme:FEATURE_ID>1001166314</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823332.54780 832780.82339 0.00000 823338.50427 832802.87845 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id7f4dcbcf-3d21-46e8-a783-b279408d7185">
<fme:FEATURE_ID>1001166287</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822796.34800 832623.51100 0.00000 823258.61800 832568.72500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idd331ff27-e9b5-4f73-a12c-85d18e861922">
<fme:FEATURE_ID>1001170985</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172803</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823551.25000 832734.28000 0.00000 823538.67000 832726.20400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id26b658ca-a2b2-4c92-8828-5194ae0ae1de">
<fme:FEATURE_ID>1001171068</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172781</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822822.73000 832652.68000 0.00000 822810.07000 832660.15000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id9f827f52-99e7-4fcf-9839-a12fe4a35366">
<fme:FEATURE_ID>1001171055</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172785</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823055.83000 832864.24000 0.00000 823062.17000 832874.48000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id59f564a9-80cb-475b-a4f6-dede4fa75214">
<fme:FEATURE_ID>1001171060</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172785</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823055.83000 832864.24000 0.00000 823044.40000 832871.46000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id88eb2a15-827a-4187-ae3f-3127d818e3ba">
<fme:FEATURE_ID>1001171088</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172777</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822619.22551 832927.12953 0.00000 822606.30000 832925.94000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ide3380bfc-2749-4e75-9908-212326bc3fd5">
<fme:FEATURE_ID>1001166316</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823568.40100 832488.20800 0.00000 823415.99000 832515.85000 0.00000 823400.00000 832518.98000 0.00000 823254.98000 832545.17000 0.00000 822794.60600 832602.19100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ide5f96c31-cdc3-4ef3-a306-bfb53031374b">
<fme:FEATURE_ID>1001171063</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172783</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822878.92500 833179.78039 0.00000 822898.13000 833179.65200 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id939c79df-0a65-4be3-924f-f9a423c30d84">
<fme:FEATURE_ID>1001166317</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823258.61800 832568.72500 0.00000 823400.00000 832541.94000 0.00000 823488.06000 832524.83000 0.00000 823513.48000 832519.69000 0.00000 823569.96100 832508.98100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id9f3f7d5d-ce2d-461b-a400-4db6f1708f8d">
<fme:FEATURE_ID>1001171081</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172778</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822660.13000 832690.48000 0.00000 822673.19735 832699.43234 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id2228a440-3f9f-4785-bcdb-5d680e30692d">
<fme:FEATURE_ID>1001171086</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172777</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822619.22551 832927.12953 0.00000 822620.32000 832914.58000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id8833727c-62e5-48f8-837f-a608045615d6">
<fme:FEATURE_ID>1210007845</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822661.71569 832703.31898 0.00000 822577.53880 832754.83145 0.00000 822562.88951 832737.34682 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idc28c9c0c-561f-44bb-b4aa-e96efa5ebcd2">
<fme:FEATURE_ID>1001166279</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823256.73000 832555.86000 0.00000 823257.93771 832564.08941 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idf4e1db8c-33f6-4b3a-bcd1-7a914623b4df">
<fme:FEATURE_ID>1001166305</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822524.32227 832749.03888 0.00000 822564.63703 832766.16007 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id0977316e-84a0-4265-9028-33c2e2901193">
<fme:FEATURE_ID>1001171091</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172776</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822557.34096 832658.20707 0.00000 822557.60830 832642.52283 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ide3b76a3a-48ec-48ee-970d-9c8df972ceb1">
<fme:FEATURE_ID>1001166278</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823257.93771 832564.08941 0.00000 823258.61800 832568.72500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idda98151a-78f6-4995-ab18-f8948384a6ac">
<fme:FEATURE_ID>1001170979</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172805</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823579.34626 832495.85752 0.00000 823569.96100 832508.98100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id7c3a1396-8f8c-43da-a8fb-7429125af5a6">
<fme:FEATURE_ID>1001166301</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822568.67000 832654.55000 0.00000 822491.21249 832720.98946 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id13cd89b4-451f-4150-a63c-74d2c36e83b8">
<fme:FEATURE_ID>1001171017</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172794</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823346.66924 832800.70456 0.00000 823335.69000 832791.64000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id7fb25500-b13e-4da9-91da-81e91bdc0b70">
<fme:FEATURE_ID>1001171073</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172780</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822796.34800 832623.51100 0.00000 822788.12000 832613.77000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id7f2de90d-bfac-4b98-aad9-45814dbc953e">
<fme:FEATURE_ID>1210005047</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823103.12867 832655.40527 0.00000 823105.29513 832666.37300 0.00000 823123.71010 832742.19931 0.00000 823126.14737 832752.49002 0.00000 823137.25051 832792.29884 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id98544892-5978-42ae-8282-ba1b76d5e570">
<fme:FEATURE_ID>1001166321</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822888.82971 833170.16065 0.00000 822879.12417 833179.58695 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idd6ee545f-deeb-46ba-9077-5da8b8d9e7c5">
<fme:FEATURE_ID>1001166272</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822487.12000 832004.82000 0.00000 822524.93000 831989.15000 0.00000 822561.24000 831974.72000 0.00000 822573.66000 831973.76000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id7dd04adc-cb2e-4eb4-8c4c-d135510c16d5">
<fme:FEATURE_ID>1001166291</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823058.44000 832853.52000 0.00000 823052.74000 832878.28000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ida7a64eab-bc83-43f4-bb7e-6cb894dddcf7">
<fme:FEATURE_ID>1001171099</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172776</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822557.60830 832642.52283 0.00000 822540.52071 832642.03747 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id6b313932-f401-4054-b67c-759b81e08241">
<fme:FEATURE_ID>1001171083</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172778</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822660.13000 832690.48000 0.00000 822649.98000 832706.52000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idc13426f2-3ec5-4131-af43-3fcfca012f09">
<fme:FEATURE_ID>1001170981</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172805</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823568.40100 832488.20800 0.00000 823579.34626 832495.85752 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ida781dd29-f240-4d44-8355-05dbce133e31">
<fme:FEATURE_ID>1001171085</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172777</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822631.45000 832928.49000 0.00000 822619.22551 832927.12953 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id4a7e3f9f-8dcc-4b56-bebf-fd8904570dfd">
<fme:FEATURE_ID>1001166285</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823346.66924 832800.70456 0.00000 823543.85100 832748.35200 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id8863ce2d-ac7a-4fd9-8912-d4ce199f0299">
<fme:FEATURE_ID>1210005048</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823161.35244 832739.62663 0.00000 823172.99720 832775.10251 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="idf9c8935b-7f2d-419c-84a7-291963c7daa2">
<fme:FEATURE_ID>1001166325</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822610.74122 832934.03282 0.00000 822871.32155 833187.16508 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id0a2a3d52-41d3-497e-9662-3f00ca0946d9">
<fme:FEATURE_ID>1001167993</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823564.92300 832742.78500 0.00000 824000.00000 832628.12000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="ide38d2cc3-81e4-453c-8f66-02849ec81964">
<fme:FEATURE_ID>1001171100</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001172775</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822552.76695 832777.15067 0.00000 822535.45000 832776.48000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLines gml:id="id4fd5e154-5c71-46ea-83f3-efe0f28ef8d4">
<fme:FEATURE_ID>1001167994</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POW</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823586.78200 832485.03200 0.00000 823682.81000 832469.66000 0.00000 823747.53000 832459.70000 0.00000 823922.61000 832432.06000 0.00000 823957.77000 832426.84000 0.00000 824000.00000 832419.79000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:UtilityLines>
</gml:featureMember>
</gml:FeatureCollection>
