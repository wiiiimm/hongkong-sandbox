<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityPolyAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821955.14654 831929.98630</gml:lowerCorner>
<gml:upperCorner>823042.33984 832754.65693</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="id4434afdb-b7f2-417e-bd98-b2b6e74cf4ff">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>氣體鼓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173728</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>831915.87487575</fme:EASTING>
<fme:NORTHING>821952.28016043</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821955.14654 831929.98630</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="idd8d391b5-1886-4728-9558-da0d1f5c9d88">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>調節池</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-35.5577011257487</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173729</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832426.23716901</fme:EASTING>
<fme:NORTHING>823048.20380332</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823042.33984 832439.36975</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="ida876d1dd-9bfb-4748-9718-533870aad727">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>儲水缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173726</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832740.47494679</fme:EASTING>
<fme:NORTHING>822220.73911043</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822223.60549 832754.65693</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
