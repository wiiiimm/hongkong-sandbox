<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityPoly.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821946.31125 830103.48831 0.00000</gml:lowerCorner>
<gml:upperCorner>823907.83500 833501.96000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityPoly gml:id="id9302dc2b-cd6b-4bee-8925-56ce80270e4f">
<fme:FEATURE_ID>1001172785</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832864.15</fme:EASTING>
<fme:NORTHING>823055.87</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823062.17000 832874.48000 0.00000 823044.40000 832871.46000 0.00000 823049.39000 832853.86000 0.00000 823067.48000 832856.89000 0.00000 823062.17000 832874.48000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id21de65bb-1f53-44e2-813f-836af4cda5c5">
<fme:FEATURE_ID>1001172348</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830106.58</fme:EASTING>
<fme:NORTHING>823882.08</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823879.30917 830107.95433 0.00000 823878.99474 830106.79395 0.00000 823879.14598 830105.60128 0.00000 823879.74009 830104.55611 0.00000 823880.74464 830103.78788 0.00000 823881.90894 830103.48831 0.00000 823883.09958 830103.65478 0.00000 823884.13707 830104.26220 0.00000 823884.86500 830105.21900 0.00000 823885.17556 830106.41361 0.00000 823885.00577 830107.60379 0.00000 823884.39546 830108.63958 0.00000 823883.43663 830109.36484 0.00000 823882.27384 830109.67022 0.00000 823881.08238 830109.50970 0.00000 823880.04187 830108.90748 0.00000 823879.30917 830107.95433 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="idd8a6c38b-5a00-4069-ba53-2386d7adba4f">
<fme:FEATURE_ID>1001172347</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830116.55</fme:EASTING>
<fme:NORTHING>823882.96</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823879.90791 830117.24570 0.00000 823879.87996 830115.99604 0.00000 823880.30973 830114.88822 0.00000 823881.17314 830113.98436 0.00000 823882.26014 830113.50435 0.00000 823883.50977 830113.47510 0.00000 823884.61803 830113.90373 0.00000 823885.48632 830114.71492 0.00000 823886.00393 830115.85269 0.00000 823886.03447 830117.10229 0.00000 823885.60700 830118.21100 0.00000 823884.78619 830119.08776 0.00000 823883.64681 830119.60181 0.00000 823882.45914 830119.63910 0.00000 823881.28975 830119.19754 0.00000 823880.38679 830118.33319 0.00000 823879.90791 830117.24570 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="idbe2ecf4e-26a9-4ed4-a437-8315997cc7c9">
<fme:FEATURE_ID>1001172351</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831705.19</fme:EASTING>
<fme:NORTHING>822921.36</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822930.51064 831716.08882 0.00000 822909.40304 831698.44148 0.00000 822911.47920 831695.84628 0.00000 822912.86330 831694.46218 0.00000 822933.62488 831712.62856 0.00000 822930.51064 831716.08882 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id1f12da9d-b001-49b8-8ca6-87387397d4c3">
<fme:FEATURE_ID>1001172794</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832791.81</fme:EASTING>
<fme:NORTHING>823335.68</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823330.44200 832805.02500 0.00000 823324.70200 832782.89900 0.00000 823332.54780 832780.82339 0.00000 823340.92200 832778.60800 0.00000 823346.66924 832800.70456 0.00000 823338.50427 832802.87845 0.00000 823330.44200 832805.02500 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id7337c802-7feb-4b4e-bfd3-54761977ad7d">
<fme:FEATURE_ID>1001172775</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832778.76</fme:EASTING>
<fme:NORTHING>822550.93</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822551.72000 832794.24000 0.00000 822535.45000 832776.48000 0.00000 822553.15000 832764.99000 0.00000 822565.02000 832777.85000 0.00000 822551.72000 832794.24000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id9bb89971-79b9-484b-884d-a7727a7af70a">
<fme:FEATURE_ID>1001172349</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832390.17</fme:EASTING>
<fme:NORTHING>823447.34</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823451.76500 832390.27800 0.00000 823448.48391 832392.59439 0.00000 823450.18700 832395.14200 0.00000 823448.08700 832396.49200 0.00000 823446.48481 832394.18013 0.00000 823442.48641 832388.46971 0.00000 823448.16200 832384.85000 0.00000 823451.76500 832390.27800 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id08b7959a-fdd9-46cb-b88d-a26fce2ae894">
<fme:FEATURE_ID>1001172352</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832735.55</fme:EASTING>
<fme:NORTHING>822217.8</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822225.62046 832735.74011 0.00000 822215.52836 832738.74209 0.00000 822216.51567 832741.96267 0.00000 822213.46658 832742.89006 0.00000 822210.82587 832733.96424 0.00000 822223.98608 832730.05780 0.00000 822225.62046 832735.74011 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id3831d2f7-2aba-4867-98d8-086a51f3f236">
<fme:FEATURE_ID>1001172803</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832734.84</fme:EASTING>
<fme:NORTHING>823551.29</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823543.85100 832748.35200 0.00000 823538.67000 832726.20400 0.00000 823548.16639 832723.68405 0.00000 823557.48600 832721.21100 0.00000 823564.92300 832742.78500 0.00000 823554.51489 832745.53471 0.00000 823543.85100 832748.35200 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id51d27f8c-4b26-45e4-9ec0-670ed4ef61b4">
<fme:FEATURE_ID>1001172350</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832435.05</fme:EASTING>
<fme:NORTHING>823034.95</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823028.94216 832472.74414 0.00000 823002.15622 832454.27306 0.00000 823041.21686 832397.27458 0.00000 823067.70255 832415.91467 0.00000 823050.34734 832441.15514 0.00000 823046.49245 832446.84406 0.00000 823028.94216 832472.74414 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id88ae5834-f643-4161-92f7-587fb5cbc841">
<fme:FEATURE_ID>1001172783</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833178.2</fme:EASTING>
<fme:NORTHING>822880.31</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822871.32155 833187.16508 0.00000 822863.72600 833179.88200 0.00000 822878.95100 833160.07900 0.00000 822888.82971 833170.16065 0.00000 822898.13000 833179.65200 0.00000 822879.25900 833194.77600 0.00000 822871.32155 833187.16508 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id012329ba-c077-44ad-9a80-201ada7a91bd">
<fme:FEATURE_ID>1001172793</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832557.22</fme:EASTING>
<fme:NORTHING>823257.32</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823257.93771 832564.08941 0.00000 823250.19000 832565.12000 0.00000 823250.22000 832550.82000 0.00000 823255.94025 832549.79412 0.00000 823262.27000 832548.66000 0.00000 823266.23000 832562.99000 0.00000 823257.93771 832564.08941 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id432b614a-37ba-42c4-9ae0-d4898d6fc6c5">
<fme:FEATURE_ID>1001172781</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832659.92</fme:EASTING>
<fme:NORTHING>822810.15</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822817.15000 832672.28000 0.00000 822797.89000 832667.35000 0.00000 822802.75000 832647.60000 0.00000 822822.73000 832652.68000 0.00000 822817.15000 832672.28000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id84642f2e-1ef9-4923-9fb2-8bb22101d573">
<fme:FEATURE_ID>1001172353</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831908.25</fme:EASTING>
<fme:NORTHING>821952.65</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>821948.77000 831914.17000 0.00000 821946.31125 831905.10998 0.00000 821956.52000 831902.33000 0.00000 821958.98497 831911.37561 0.00000 821948.77000 831914.17000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id3f433063-c69a-4561-85a6-d0b9e09f6a61">
<fme:FEATURE_ID>1001172789</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833485.86</fme:EASTING>
<fme:NORTHING>823150.3</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>R</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823137.78100 833490.04100 0.00000 823134.21000 833476.50000 0.00000 823159.71871 833469.75643 0.00000 823166.36090 833495.24782 0.00000 823140.93000 833501.96000 0.00000 823137.78100 833490.04100 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="ida15aa1ad-87e0-4666-8237-a745edb810fe">
<fme:FEATURE_ID>1001172780</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832613.71</fme:EASTING>
<fme:NORTHING>822788.12</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822781.90500 832625.42500 0.00000 822779.70100 832603.91800 0.00000 822787.21249 832603.04767 0.00000 822794.60600 832602.19100 0.00000 822796.34800 832623.51100 0.00000 822789.27954 832624.44772 0.00000 822781.90500 832625.42500 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id3b39f53d-1476-4155-8240-97825c47cf17">
<fme:FEATURE_ID>1001172778</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832690.58</fme:EASTING>
<fme:NORTHING>822659.8</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822649.98000 832706.52000 0.00000 822646.96667 832681.14521 0.00000 822657.44076 832678.64944 0.00000 822669.69550 832675.85510 0.00000 822673.19735 832699.43234 0.00000 822662.04119 832701.82197 0.00000 822649.98000 832706.52000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="idd41458dd-aadf-4a2f-93b7-3c2f891a71ae">
<fme:FEATURE_ID>1001172346</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830119.52</fme:EASTING>
<fme:NORTHING>823902.06</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823896.47549 830120.98985 0.00000 823896.29136 830119.79592 0.00000 823896.35949 830118.58979 0.00000 823896.64119 830117.51851 0.00000 823897.12213 830116.52067 0.00000 823897.78463 830115.63292 0.00000 823898.60435 830114.88790 0.00000 823899.55117 830114.31297 0.00000 823900.59029 830113.92927 0.00000 823901.78422 830113.74514 0.00000 823902.99035 830113.81327 0.00000 823904.06163 830114.09497 0.00000 823905.05947 830114.57591 0.00000 823905.94722 830115.23841 0.00000 823906.69224 830116.05813 0.00000 823907.26717 830117.00495 0.00000 823907.65087 830118.04407 0.00000 823907.83500 830119.23800 0.00000 823907.76687 830120.44412 0.00000 823907.48517 830121.51541 0.00000 823907.00423 830122.51325 0.00000 823906.34173 830123.40100 0.00000 823905.52201 830124.14602 0.00000 823904.57519 830124.72095 0.00000 823903.53607 830125.10465 0.00000 823902.34214 830125.28878 0.00000 823901.13601 830125.22065 0.00000 823900.06473 830124.93894 0.00000 823899.06689 830124.45801 0.00000 823898.17914 830123.79550 0.00000 823897.43412 830122.97579 0.00000 823896.85919 830122.02897 0.00000 823896.47549 830120.98985 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="idb5eaa362-7be7-4770-908a-5f76dad9e78c">
<fme:FEATURE_ID>1001172776</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832642.9</fme:EASTING>
<fme:NORTHING>822556.43</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822571.02000 832642.60000 0.00000 822557.33000 832658.85000 0.00000 822557.34096 832658.20707 0.00000 822540.52071 832642.03747 0.00000 822557.89114 832627.91926 0.00000 822571.02000 832642.60000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id5e52a70b-b85d-405b-afb3-377b3c48540c">
<fme:FEATURE_ID>1420000220</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831506.72</fme:EASTING>
<fme:NORTHING>823558.4</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250724</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823558.42071 831515.73941 0.00000 823549.62336 831507.29599 0.00000 823557.43344 831497.76531 0.00000 823567.64237 831506.13119 0.00000 823558.42071 831515.73941 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id829e2b0a-22e5-4b81-bc9f-60107879d94d">
<fme:FEATURE_ID>1001172805</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832497.11</fme:EASTING>
<fme:NORTHING>823579.35</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823569.96100 832508.98100 0.00000 823568.40100 832488.20800 0.00000 823577.39453 832486.55576 0.00000 823586.78200 832485.03200 0.00000 823592.05100 832505.33400 0.00000 823581.45109 832506.83855 0.00000 823569.96100 832508.98100 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPoly gml:id="id4dd146b9-258e-48a3-a2fb-fef5420fe2f2">
<fme:FEATURE_ID>1001172777</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PYL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832927.17</fme:EASTING>
<fme:NORTHING>822618.91</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>822612.07250 832932.94962 0.00000 822606.30000 832925.94000 0.00000 822620.32000 832914.58000 0.00000 822625.96969 832921.64210 0.00000 822631.45000 832928.49000 0.00000 822617.64000 832939.73000 0.00000 822612.07250 832932.94962 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:UtilityPoly>
</gml:featureMember>
</gml:FeatureCollection>
