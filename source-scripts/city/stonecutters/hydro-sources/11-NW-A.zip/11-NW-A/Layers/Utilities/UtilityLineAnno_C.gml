<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityLineAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>822554.42814 831683.10238</gml:lowerCorner>
<gml:upperCorner>823110.83976 833021.56437</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id6bc5ac9e-84eb-4e28-ad4d-482645ef38c5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162573</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>831922.9491115</fme:EASTING>
<fme:NORTHING>822799.39645995</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822802.40859 831937.64148</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id233812ed-4438-466d-9a1f-511fdd446930">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>35.3947830955557</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162574</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>831677.47955316</fme:EASTING>
<fme:NORTHING>822718.79591681</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822726.30734 831683.10238</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="idb6629ea2-92e3-4d04-8fb6-da2c23ee5e0f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162572</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>833013.14138138</fme:EASTING>
<fme:NORTHING>823117.099946</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823110.83976 833021.56437</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="idc8db310c-2806-4069-8926-f30d5661452e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-67.4901971945934</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162576</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>831981.72473513</fme:EASTING>
<fme:NORTHING>822564.53996019</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822554.42814 831985.91522</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id7347b370-95b8-4904-b1e8-28059fab1adb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>22.2115238013053</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162575</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>832738.90661579</fme:EASTING>
<fme:NORTHING>823068.51174528</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823071.26424 832745.64752</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
