<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityLineAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>822518.93060 831892.65773</gml:lowerCorner>
<gml:upperCorner>823052.05225 833136.35989</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="id869a7b47-76d1-4629-ae1f-de806df8b6ea">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162832</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>831867.14849809</fme:EASTING>
<fme:NORTHING>822800.04227372</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822796.43147 831892.65773</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="idead5631b-5958-4a07-bf3f-a01d5a0957d5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162833</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>833136.509</fme:EASTING>
<fme:NORTHING>823050.356</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823052.05225 833136.35989</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="idd8f26612-2d91-4c43-b921-143f55496e34">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-67.5572466334642</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162834</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>831993.14237256</fme:EASTING>
<fme:NORTHING>822535.69253887</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822518.93060 832000.06578</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
