<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingPoly.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>819614.46023 830643.19027 0.00000</gml:lowerCorner>
<gml:upperCorner>821000.00000 833750.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6dd6b409-3c3f-4aa5-8bde-2770ec280643">
<fme:FEATURE_ID>1210076255</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832523.91</fme:EASTING>
<fme:NORTHING>820493.59</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820482.36414 832541.29715 0.00000 820476.17708 832535.17975 0.00000 820505.11346 832506.42656 0.00000 820511.03012 832512.41510 0.00000 820482.36414 832541.29715 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1f57768e-5da0-461e-aeaa-eb8d4d63ad6d">
<fme:FEATURE_ID>1000116851</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832524.34</fme:EASTING>
<fme:NORTHING>820412.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820415.25825 832528.31561 0.00000 820408.97799 832522.02782 0.00000 820410.55215 832520.32112 0.00000 820416.93575 832526.70473 0.00000 820415.25825 832528.31561 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id69d1d370-44a2-4de0-b49c-7e67cc8105bb">
<fme:FEATURE_ID>1210013979</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832758.82</fme:EASTING>
<fme:NORTHING>820676.36</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820653.93290 832759.48310 0.00000 820657.38697 832756.02886 0.00000 820662.04216 832751.37367 0.00000 820686.35651 832727.05933 0.00000 820698.90383 832739.66012 0.00000 820696.19748 832742.40616 0.00000 820702.44579 832748.57410 0.00000 820698.10019 832754.48059 0.00000 820694.58551 832758.58533 0.00000 820674.68652 832778.53931 0.00000 820679.55501 832787.76326 0.00000 820667.89147 832793.71697 0.00000 820651.29791 832762.11792 0.00000 820653.81665 832759.59918 0.00000 820653.93290 832759.48310 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8c579f06-a60b-4592-b503-942e06a41138">
<fme:FEATURE_ID>1000116826</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832299.3</fme:EASTING>
<fme:NORTHING>820586.63</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820593.60652 832313.01670 0.00000 820574.44422 832289.83885 0.00000 820579.60968 832285.54720 0.00000 820598.84807 832308.80500 0.00000 820593.60652 832313.01670 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3194f0e0-62fa-4da0-8c62-561a9de024c6">
<fme:FEATURE_ID>1000116984</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831781.5</fme:EASTING>
<fme:NORTHING>820060.08</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820054.90381 831787.09106 0.00000 820052.56388 831780.97380 0.00000 820065.16560 831775.90324 0.00000 820067.65794 831782.01977 0.00000 820054.90381 831787.09106 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idef32c547-3b6a-40df-bfc3-50781f02d0f9">
<fme:FEATURE_ID>1000116865</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831982.49</fme:EASTING>
<fme:NORTHING>820350.68</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820347.50290 831982.53748 0.00000 820351.67865 831979.59560 0.00000 820353.87241 831982.44689 0.00000 820349.64626 831985.37270 0.00000 820347.50290 831982.53748 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id49a01fe7-490a-4b3d-bcc8-a7190566344c">
<fme:FEATURE_ID>1000116983</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832088.09</fme:EASTING>
<fme:NORTHING>820036.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820070.49320 832105.19550 0.00000 820066.96870 832105.83530 0.00000 820067.77130 832110.50270 0.00000 820055.43140 832112.79370 0.00000 820054.54870 832108.12100 0.00000 820051.66770 832108.62140 0.00000 820050.73360 832103.53700 0.00000 820022.20680 832108.89240 0.00000 820022.94090 832112.94230 0.00000 820024.52648 832113.34783 0.00000 820025.87940 832114.26876 0.00000 820026.83814 832115.59516 0.00000 820027.28824 832117.16867 0.00000 820027.15553 832118.88110 0.00000 820026.42090 832120.43362 0.00000 820025.18093 832121.62210 0.00000 820023.51820 832122.30730 0.00000 820021.98933 832122.36203 0.00000 820020.52443 832121.92101 0.00000 820019.33761 832121.08797 0.00000 820018.42496 832119.86016 0.00000 820018.03320 832118.80070 0.00000 820015.86440 832107.52740 0.00000 820010.88980 832108.39910 0.00000 820006.74140 832086.02750 0.00000 820011.75380 832085.09220 0.00000 820009.38220 832072.45870 0.00000 820006.85800 832058.57690 0.00000 820025.78220 832055.07070 0.00000 820027.30534 832063.25656 0.00000 820032.99880 832062.26390 0.00000 820033.72170 832066.17930 0.00000 820028.03790 832067.25030 0.00000 820028.87630 832071.70560 0.00000 820015.79310 832074.12100 0.00000 820017.15350 832081.65150 0.00000 820045.73500 832076.35540 0.00000 820043.87790 832066.59070 0.00000 820059.03930 832063.75490 0.00000 820060.01320 832068.41780 0.00000 820063.58830 832067.75560 0.00000 820070.49320 832105.19550 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0e900b27-1a81-4348-9e5e-6794932ea1d8">
<fme:FEATURE_ID>1000116862</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831976.79</fme:EASTING>
<fme:NORTHING>820357.71</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820354.92876 831976.25704 0.00000 820357.99637 831973.98791 0.00000 820360.43921 831977.24547 0.00000 820357.51341 831979.65113 0.00000 820354.92876 831976.25704 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbbf4b7ed-b507-4396-be27-8859a48d9932">
<fme:FEATURE_ID>1000116902</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831708.74</fme:EASTING>
<fme:NORTHING>820247.53</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820253.94605 831714.96090 0.00000 820243.03487 831715.10977 0.00000 820243.07860 831707.06700 0.00000 820240.82903 831707.01764 0.00000 820240.88196 831702.10984 0.00000 820246.49983 831702.20857 0.00000 820250.99073 831702.28749 0.00000 820250.97139 831707.24020 0.00000 820253.96073 831707.30580 0.00000 820253.94605 831714.96090 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd3368b0b-555d-4ab9-8674-1119e293c16b">
<fme:FEATURE_ID>1210076562</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833764.23</fme:EASTING>
<fme:NORTHING>820926.98</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820945.00533 833750.00000 0.00000 820930.36623 833750.00000 0.00000 820945.79151 833729.95945 0.00000 820952.97493 833735.53183 0.00000 820951.60603 833737.39849 0.00000 820955.71271 833741.00739 0.00000 820951.73048 833746.35850 0.00000 820949.11714 833744.36739 0.00000 820945.00533 833750.00000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idcdbf2c5f-8f22-4492-ac49-7cc2b822cb41">
<fme:FEATURE_ID>1000116858</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832687.32</fme:EASTING>
<fme:NORTHING>820374.04</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820373.74761 832690.45134 0.00000 820370.87502 832687.77537 0.00000 820374.34573 832684.18145 0.00000 820377.20639 832686.86054 0.00000 820373.74761 832690.45134 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2260d95b-4113-40cc-8792-27c44c6bd3f8">
<fme:FEATURE_ID>1000116962</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832273.89</fme:EASTING>
<fme:NORTHING>820122.76</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820120.29370 832282.19670 0.00000 820117.48290 832267.02280 0.00000 820125.21140 832265.55310 0.00000 820128.03930 832280.78170 0.00000 820120.29370 832282.19670 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id606e07bc-7acc-428a-b0ea-e37386c3959a">
<fme:FEATURE_ID>1000117064</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832883.06</fme:EASTING>
<fme:NORTHING>819827.08</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819821.48821 832887.21300 0.00000 819820.15912 832883.04418 0.00000 819832.59428 832878.89880 0.00000 819833.99966 832883.11834 0.00000 819827.96800 832885.09234 0.00000 819821.48821 832887.21300 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id54b2cde0-2764-410b-8e93-489aa7043696">
<fme:FEATURE_ID>1000116957</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831931.85</fme:EASTING>
<fme:NORTHING>820129.09</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820124.00690 831934.97549 0.00000 820130.14848 831925.89715 0.00000 820134.19453 831928.70665 0.00000 820128.01347 831937.81577 0.00000 820124.00690 831934.97549 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id94594981-e747-4aa8-87d7-32ec3b6fa7bf">
<fme:FEATURE_ID>1000116884</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831947.32</fme:EASTING>
<fme:NORTHING>820295.86</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820296.05836 831950.69797 0.00000 820292.61163 831947.31427 0.00000 820295.53548 831943.95324 0.00000 820299.17198 831947.31874 0.00000 820296.05836 831950.69797 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6f904c15-222d-475d-a643-c51a36115a71">
<fme:FEATURE_ID>1210013999</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>US</fme:DATALEVEL>
<fme:EASTING>831301.36</fme:EASTING>
<fme:NORTHING>820158.87</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820157.94611 831306.58350 0.00000 820154.80371 831297.96112 0.00000 820159.80050 831296.14010 0.00000 820162.94312 831304.76233 0.00000 820157.94611 831306.58350 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd56cc702-7047-4065-8ffd-a0588b464b36">
<fme:FEATURE_ID>1000117057</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832792.2</fme:EASTING>
<fme:NORTHING>819854.41</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819862.83199 832810.29621 0.00000 819835.55983 832785.57393 0.00000 819845.89718 832774.13312 0.00000 819873.24521 832798.70264 0.00000 819862.83199 832810.29621 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idfb1f76f1-116b-48ae-9d1a-822c24a1a74d">
<fme:FEATURE_ID>1210058452</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832562.93</fme:EASTING>
<fme:NORTHING>820655.38</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820657.23939 832568.10020 0.00000 820650.23433 832560.97727 0.00000 820653.46744 832557.74417 0.00000 820660.53984 832564.86709 0.00000 820657.23939 832568.10020 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida568081d-2bf8-4b5f-b96b-d4fbd45a530e">
<fme:FEATURE_ID>1210077730</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833467.68</fme:EASTING>
<fme:NORTHING>821008.9</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:multiSurfaceProperty>
<gml:MultiSurface srsName="EPSG:2326" srsDimension="3">
<gml:surfaceMember>
<gml:Surface>
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>821000.00000 833489.80737 0.00000 820999.76899 833489.78690 0.00000 821000.00000 833486.93181 0.00000 821000.00000 833489.80737 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceMember>
<gml:surfaceMember>
<gml:Surface>
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>821000.00000 833475.75657 0.00000 820989.34198 833468.24748 0.00000 820998.47013 833455.01828 0.00000 821000.00000 833456.02546 0.00000 821000.00000 833475.75657 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceMember>
</gml:MultiSurface>
</gml:multiSurfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb50ffc9c-3c85-4fd6-879f-e2e4381a6cba">
<fme:FEATURE_ID>1000116901</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832611.44</fme:EASTING>
<fme:NORTHING>820254.39</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820257.07841 832611.51284 0.00000 820254.85129 832615.51117 0.00000 820253.73569 832614.84749 0.00000 820251.30679 832609.52704 0.00000 820253.54292 832608.17766 0.00000 820257.66819 832610.52945 0.00000 820257.07841 832611.51284 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6f42ce0b-063d-4963-aeed-f355717f9356">
<fme:FEATURE_ID>1000117120</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831410.74</fme:EASTING>
<fme:NORTHING>820096.39</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820099.86292 831424.16830 0.00000 820084.81752 831403.00282 0.00000 820092.97109 831397.28835 0.00000 820107.96088 831418.57685 0.00000 820099.86292 831424.16830 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb54f9c15-519e-4b2b-9ba4-9b5962cd9680">
<fme:FEATURE_ID>1000116989</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832888.06</fme:EASTING>
<fme:NORTHING>820037.64</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820048.47313 832903.99136 0.00000 820035.22318 832894.70975 0.00000 820037.58456 832891.36086 0.00000 820025.35133 832882.50815 0.00000 820027.09864 832880.08826 0.00000 820024.80954 832878.36319 0.00000 820028.18282 832873.85752 0.00000 820046.43860 832887.01914 0.00000 820043.00941 832891.70921 0.00000 820050.68279 832900.97493 0.00000 820048.47313 832903.99136 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1ba9691d-9ef3-48e1-89c6-a6e8f691f6cc">
<fme:FEATURE_ID>1210076285</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831155.56</fme:EASTING>
<fme:NORTHING>820089.18</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820071.03718 831148.27083 0.00000 820060.71841 831141.92081 0.00000 820062.95220 831137.73962 0.00000 820051.52405 831130.19088 0.00000 820053.00832 831127.96448 0.00000 820092.73433 831154.24492 0.00000 820090.48016 831157.70131 0.00000 820096.32439 831162.51420 0.00000 820094.83264 831164.75183 0.00000 820085.32471 831157.33282 0.00000 820087.50753 831153.95938 0.00000 820073.37377 831144.62347 0.00000 820071.03718 831148.27083 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida34a5657-fac0-44f4-a31e-a9e743b94036">
<fme:FEATURE_ID>1000117106</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832627.72</fme:EASTING>
<fme:NORTHING>820598.47</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250726</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820586.83735 832649.59904 0.00000 820570.47651 832633.42846 0.00000 820569.11009 832632.07793 0.00000 820599.42631 832601.70658 0.00000 820601.16398 832603.45730 0.00000 820627.93312 832630.42746 0.00000 820610.54929 832647.40551 0.00000 820599.98206 832636.76117 0.00000 820586.83735 832649.59904 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb6ebd2a1-1197-4a62-84fd-b0523f29526f">
<fme:FEATURE_ID>1310094377</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832677.23</fme:EASTING>
<fme:NORTHING>820690.51</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240315</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820692.45564 832697.27364 0.00000 820688.28844 832692.97415 0.00000 820689.87594 832691.25435 0.00000 820677.70509 832678.88506 0.00000 820675.98529 832680.40642 0.00000 820670.69361 832674.91630 0.00000 820687.62698 832658.18137 0.00000 820709.58744 832680.34027 0.00000 820692.45564 832697.27364 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9dec2b6e-26fa-4c50-bf5e-c09e154ec9f4">
<fme:FEATURE_ID>1000116961</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831997.01</fme:EASTING>
<fme:NORTHING>820123.18</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820124.47354 832001.96921 0.00000 820118.22244 831995.87116 0.00000 820121.73517 831991.98844 0.00000 820128.21545 831998.21251 0.00000 820124.47354 832001.96921 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc4a7d668-b75a-4161-8ae2-4d415d154eb1">
<fme:FEATURE_ID>1310097942</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832830.99</fme:EASTING>
<fme:NORTHING>819756.28</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819757.18804 832827.44687 0.00000 819759.62689 832829.85338 0.00000 819755.44178 832834.51125 0.00000 819752.90178 832832.13000 0.00000 819757.18804 832827.44687 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide319fde9-75bc-4b52-b138-7781b5eb8d33">
<fme:FEATURE_ID>1000116805</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832292.74</fme:EASTING>
<fme:NORTHING>820810.82</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820785.76000 832307.57400 0.00000 820785.62900 832278.12900 0.00000 820835.87900 832277.90600 0.00000 820836.01000 832307.35100 0.00000 820785.76000 832307.57400 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide16fc736-73aa-4e2b-b64a-4dd7407a97a0">
<fme:FEATURE_ID>1210020523</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831990.77</fme:EASTING>
<fme:NORTHING>820591.76</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820593.20235 831996.95942 0.00000 820585.83026 831988.47035 0.00000 820590.96838 831984.56091 0.00000 820597.44688 831993.60847 0.00000 820593.20235 831996.95942 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="iddd251fe4-be1c-403b-8766-ffeb735d50c8">
<fme:FEATURE_ID>1000116877</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831796.31</fme:EASTING>
<fme:NORTHING>820294.14</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820278.37900 831815.37500 0.00000 820271.04700 831804.09200 0.00000 820310.00500 831777.30800 0.00000 820317.33800 831788.32800 0.00000 820278.37900 831815.37500 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id882fb85f-b33b-43b0-9745-b0774a03dd71">
<fme:FEATURE_ID>1000117056</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832742.77</fme:EASTING>
<fme:NORTHING>819867.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819870.14615 832748.19227 0.00000 819862.25939 832740.93272 0.00000 819865.55336 832737.39073 0.00000 819873.49060 832744.49756 0.00000 819870.14615 832748.19227 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3a16724d-af8e-48fa-b1b6-25784d52fbaf">
<fme:FEATURE_ID>1000116942</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830893.48</fme:EASTING>
<fme:NORTHING>820149.04</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820146.91604 830911.38553 0.00000 820135.08170 830904.88951 0.00000 820151.17067 830875.57884 0.00000 820163.00502 830882.07486 0.00000 820146.91604 830911.38553 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5f2de06d-468a-4efd-8694-8742cf465f16">
<fme:FEATURE_ID>1310094378</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832395.89</fme:EASTING>
<fme:NORTHING>820876.22</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240315</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820878.50596 832402.01571 0.00000 820870.40969 832392.96694 0.00000 820873.98157 832389.75225 0.00000 820882.03815 832398.88039 0.00000 820878.50596 832402.01571 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idfb3c4db1-11b2-4748-a56c-ecef56f04455">
<fme:FEATURE_ID>1210077728</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833393.67</fme:EASTING>
<fme:NORTHING>820986.86</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820994.09411 833417.04001 0.00000 820981.46023 833393.71694 0.00000 820958.20331 833406.54926 0.00000 820951.24191 833393.37025 0.00000 820977.90844 833378.59896 0.00000 820979.14512 833380.96400 0.00000 820981.26179 833379.74030 0.00000 820980.20620 833373.43612 0.00000 820976.33392 833372.10044 0.00000 820980.76570 833359.86344 0.00000 820984.53602 833361.28557 0.00000 820985.42899 833358.77203 0.00000 820993.26728 833361.61630 0.00000 820992.34124 833364.12985 0.00000 820996.21078 833365.48584 0.00000 820991.74593 833377.72285 0.00000 820987.18185 833376.23456 0.00000 820986.32196 833378.64889 0.00000 820988.90165 833381.29473 0.00000 820991.67978 833379.77337 0.00000 820994.19401 833384.43629 0.00000 820990.88603 833386.42104 0.00000 820994.59020 833393.00256 0.00000 820998.19516 833391.08433 0.00000 821000.00000 833394.38012 0.00000 821000.00000 833414.61339 0.00000 820998.72433 833414.40078 0.00000 820994.09411 833417.04001 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1a18a1d1-d6b1-4e23-bdac-dc450fd3c19f">
<fme:FEATURE_ID>1000116794</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832174.87</fme:EASTING>
<fme:NORTHING>820892.24</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820874.58423 832180.16753 0.00000 820874.39812 832178.68169 0.00000 820874.54023 832177.48904 0.00000 820874.94827 832176.35951 0.00000 820875.77742 832175.11257 0.00000 820876.90680 832174.12762 0.00000 820878.25668 832173.47500 0.00000 820879.73170 832173.19773 0.00000 820880.92776 832173.28167 0.00000 820882.34557 832173.75923 0.00000 820883.33079 832174.43406 0.00000 820911.67000 832165.48000 0.00000 820913.52000 832171.41000 0.00000 820885.27000 832180.29000 0.00000 820884.81479 832181.39957 0.00000 820883.71650 832182.82049 0.00000 820882.49140 832183.68498 0.00000 820880.78224 832184.24266 0.00000 820879.28294 832184.26109 0.00000 820877.83436 832183.88019 0.00000 820876.54008 832183.12650 0.00000 820875.67835 832182.29030 0.00000 820874.88619 832181.01845 0.00000 820874.58423 832180.16753 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7d25426f-4f2c-457a-9023-5199506f54fc">
<fme:FEATURE_ID>1000158013</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832719.8</fme:EASTING>
<fme:NORTHING>820628.42</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820630.90007 832730.55195 0.00000 820618.67297 832715.21040 0.00000 820624.78110 832709.29205 0.00000 820638.39782 832723.05420 0.00000 820630.90007 832730.55195 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb187218e-8186-4846-8f33-478aea6c9d69">
<fme:FEATURE_ID>1000117085</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832588.8</fme:EASTING>
<fme:NORTHING>819723.29</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819724.91236 832592.91450 0.00000 819719.09500 832587.51670 0.00000 819721.62639 832584.67450 0.00000 819727.49884 832590.07169 0.00000 819724.91236 832592.91450 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3a3c217c-577f-4849-9f4e-c1b56ea0eb58">
<fme:FEATURE_ID>1000116807</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833584.79</fme:EASTING>
<fme:NORTHING>820767.89</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820703.80000 833584.02000 0.00000 820703.15000 833577.88000 0.00000 820749.37000 833522.32000 0.00000 820755.90000 833521.80000 0.00000 820831.93945 833585.51172 0.00000 820832.63086 833591.94141 0.00000 820786.21094 833647.17969 0.00000 820779.93945 833647.92187 0.00000 820703.80000 833584.02000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id44a0fb34-86a5-4fdc-88a1-d90690b1a9d7">
<fme:FEATURE_ID>1000116926</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832796</fme:EASTING>
<fme:NORTHING>820194.42</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820205.56956 832779.58242 0.00000 820197.00669 832815.97088 0.00000 820190.41533 832814.62111 0.00000 820189.92481 832817.31154 0.00000 820182.90309 832815.68047 0.00000 820190.61446 832783.96039 0.00000 820193.38996 832772.54359 0.00000 820199.59983 832774.19651 0.00000 820198.95445 832777.72451 0.00000 820205.56956 832779.58242 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3acef8c2-5da9-4c8a-bd32-46cad408d760">
<fme:FEATURE_ID>1310090811</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833242.75</fme:EASTING>
<fme:NORTHING>821008.99</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820999.86329 833290.65868 0.00000 820996.86397 833294.90772 0.00000 820993.22594 833294.90772 0.00000 820992.61916 833285.73195 0.00000 820990.04916 833285.73927 0.00000 820989.58791 833268.84621 0.00000 820991.65332 833263.06947 0.00000 820966.42858 833197.74744 0.00000 820970.73631 833190.59553 0.00000 820981.78269 833197.47471 0.00000 820987.00822 833211.43151 0.00000 820985.28842 833212.09297 0.00000 820982.85602 833212.94493 0.00000 820986.26915 833222.54932 0.00000 820988.92645 833221.61799 0.00000 820990.64625 833220.89038 0.00000 820994.61501 833231.67217 0.00000 820992.82906 833232.33363 0.00000 820990.47603 833233.18559 0.00000 820993.57166 833241.83749 0.00000 820997.85616 833240.73417 0.00000 821000.00000 833240.21133 0.00000 821000.00000 833251.53289 0.00000 820995.31792 833252.87063 0.00000 820998.57230 833261.60190 0.00000 820995.55604 833262.79253 0.00000 820995.55604 833270.01567 0.00000 820999.92168 833269.93629 0.00000 821000.00000 833274.40083 0.00000 821000.00000 833282.16023 0.00000 820999.60417 833282.16007 0.00000 820999.86329 833290.65868 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5da40bda-f799-479d-a307-53752ef35735">
<fme:FEATURE_ID>1210080952</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831525.23</fme:EASTING>
<fme:NORTHING>820243.76</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820238.40773 831516.83437 0.00000 820246.59367 831516.59218 0.00000 820246.98554 831522.98257 0.00000 820252.11221 831527.55088 0.00000 820247.70925 831532.49198 0.00000 820238.91938 831532.96374 0.00000 820238.40773 831516.83437 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb12581a5-b262-4008-8aa0-08e9b7bbd91f">
<fme:FEATURE_ID>1000117026</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832512.84</fme:EASTING>
<fme:NORTHING>819951.23</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819950.07361 832517.00487 0.00000 819946.91669 832512.94075 0.00000 819952.31740 832508.68261 0.00000 819955.57585 832512.72110 0.00000 819950.07361 832517.00487 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id244a7cc3-f3af-4daa-bccf-7b99b8540d0e">
<fme:FEATURE_ID>1000117021</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831876.97</fme:EASTING>
<fme:NORTHING>819973.09</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819970.28830 831878.16157 0.00000 819970.04673 831876.97420 0.00000 819970.28830 831875.78683 0.00000 819970.93679 831874.82542 0.00000 819971.94720 831874.15664 0.00000 819973.08557 831873.93536 0.00000 819974.27294 831874.17693 0.00000 819975.23435 831874.82542 0.00000 819975.88284 831875.78683 0.00000 819976.12441 831876.97420 0.00000 819975.88284 831878.16157 0.00000 819975.23435 831879.12298 0.00000 819974.22394 831879.79176 0.00000 819973.08557 831880.01304 0.00000 819971.89820 831879.77147 0.00000 819970.93679 831879.12298 0.00000 819970.28830 831878.16157 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id67a17707-4245-4b0a-b3d0-f24327589184">
<fme:FEATURE_ID>1000116860</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831700.88</fme:EASTING>
<fme:NORTHING>820353.17</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820354.54154 831714.68029 0.00000 820352.02839 831710.55527 0.00000 820354.14901 831709.28290 0.00000 820346.17548 831696.38953 0.00000 820344.05486 831697.61949 0.00000 820341.43766 831693.43832 0.00000 820350.66439 831687.84661 0.00000 820355.50519 831695.69815 0.00000 820358.75456 831700.96846 0.00000 820363.72567 831709.03136 0.00000 820354.54154 831714.68029 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id460d6138-f460-4f7d-ab6e-6798af51140e">
<fme:FEATURE_ID>1310097906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>5</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832249.49</fme:EASTING>
<fme:NORTHING>819821.21</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819813.30397 832251.24119 0.00000 819813.16018 832250.00000 0.00000 819813.88291 832248.66390 0.00000 819815.07928 832247.91507 0.00000 819826.62125 832245.85798 0.00000 819827.98097 832246.23640 0.00000 819828.95406 832247.25872 0.00000 819829.26496 832248.63544 0.00000 819828.83505 832250.00000 0.00000 819827.24046 832251.08790 0.00000 819815.83194 832253.10894 0.00000 819814.71626 832252.86026 0.00000 819813.83884 832252.20013 0.00000 819813.30397 832251.24119 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb7a7344a-6bb1-4a3b-b5fb-fe6c4100fa67">
<fme:FEATURE_ID>1000117086</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832270.79</fme:EASTING>
<fme:NORTHING>819707.85</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250726</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819699.86132 832272.16457 0.00000 819699.82840 832271.47819 0.00000 819700.00625 832270.84806 0.00000 819700.35376 832270.27745 0.00000 819700.75158 832269.88989 0.00000 819700.94675 832269.75791 0.00000 819700.96277 832269.74708 0.00000 819701.00883 832269.71594 0.00000 819701.19481 832269.66179 0.00000 819702.35937 832269.32272 0.00000 819703.16737 832269.17936 0.00000 819704.31467 832268.97581 0.00000 819705.42197 832268.77935 0.00000 819707.56821 832268.39857 0.00000 819709.76608 832268.00862 0.00000 819709.95292 832267.97548 0.00000 819711.88477 832267.63273 0.00000 819713.30986 832267.37989 0.00000 819713.88558 832267.41576 0.00000 819714.08563 832267.42822 0.00000 819714.17474 832267.47146 0.00000 819714.54943 832267.65327 0.00000 819715.05347 832267.89783 0.00000 819715.26350 832268.18572 0.00000 819715.78529 832268.90094 0.00000 819715.92367 832269.43871 0.00000 819715.94132 832269.90692 0.00000 819715.87151 832270.35399 0.00000 819715.60306 832270.99697 0.00000 819715.49372 832271.15369 0.00000 819714.16932 832272.07623 0.00000 819713.83954 832272.13720 0.00000 819712.97109 832272.29778 0.00000 819712.35808 832272.41112 0.00000 819711.15671 832272.63325 0.00000 819710.60049 832272.73609 0.00000 819709.01580 832273.02909 0.00000 819708.48480 832273.12727 0.00000 819708.01094 832273.21489 0.00000 819706.56555 832273.48213 0.00000 819704.69384 832273.82820 0.00000 819702.91727 832274.15668 0.00000 819702.15111 832274.25773 0.00000 819701.51697 832274.14864 0.00000 819701.35814 832274.07769 0.00000 819701.27242 832274.03940 0.00000 819700.34830 832273.35546 0.00000 819699.86703 832272.28362 0.00000 819699.86132 832272.16457 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id243b4388-71ca-4f7e-afbc-8380911e29d0">
<fme:FEATURE_ID>1000116966</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832141.45</fme:EASTING>
<fme:NORTHING>820120.33</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820119.26666 832149.53423 0.00000 820116.43376 832134.29533 0.00000 820121.39066 832133.37393 0.00000 820124.22346 832148.61273 0.00000 820119.26666 832149.53423 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide4dfefeb-a94d-448c-87a8-3f9382fc62c6">
<fme:FEATURE_ID>1210077727</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833445.43</fme:EASTING>
<fme:NORTHING>820945.34</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820968.34439 833469.46236 0.00000 820942.92128 833460.47591 0.00000 820942.64324 833460.37763 0.00000 820944.67110 833454.46694 0.00000 820938.05271 833450.29699 0.00000 820928.83359 833454.29371 0.00000 820923.87908 833456.44162 0.00000 820920.76490 833457.79170 0.00000 820914.96832 833444.72750 0.00000 820928.55415 833439.18447 0.00000 820937.35542 833413.87702 0.00000 820952.81617 833419.44540 0.00000 820944.01281 833443.83890 0.00000 820977.25025 833455.41918 0.00000 820971.79040 833470.58741 0.00000 820971.76069 833470.66994 0.00000 820968.34439 833469.46236 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id31d3dc3d-41ad-46c7-a49d-6bb943d8ed44">
<fme:FEATURE_ID>1000117000</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831864.48</fme:EASTING>
<fme:NORTHING>820013.7</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820016.62317 831867.51489 0.00000 820010.45723 831865.17490 0.00000 820010.91221 831862.74603 0.00000 820015.45186 831861.94565 0.00000 820016.62317 831867.51489 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4cfe5845-081b-49a1-a1dd-766cc9447f00">
<fme:FEATURE_ID>1000116993</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832262.58</fme:EASTING>
<fme:NORTHING>820011.23</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820002.85190 832295.23160 0.00000 819991.61790 832234.73420 0.00000 820013.22326 832230.71975 0.00000 820015.27960 832230.76524 0.00000 820017.12400 832231.35590 0.00000 820018.26424 832232.04780 0.00000 820019.25161 832232.94444 0.00000 820020.04988 832234.01291 0.00000 820020.67083 832235.32828 0.00000 820023.49494 832250.00000 0.00000 820030.93540 832290.01710 0.00000 820002.85190 832295.23160 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id82f72a4b-1331-4e7b-a6c0-c1b8a6c06c42">
<fme:FEATURE_ID>1000116883</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831770.85</fme:EASTING>
<fme:NORTHING>820291.21</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820306.52245 831763.50467 0.00000 820301.47362 831767.00124 0.00000 820303.52217 831769.89020 0.00000 820288.11213 831780.71244 0.00000 820285.94203 831777.75321 0.00000 820278.49584 831782.91453 0.00000 820276.76306 831780.36890 0.00000 820274.14838 831776.52767 0.00000 820302.12479 831757.24519 0.00000 820306.52245 831763.50467 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idef1e335a-8966-43dc-9ab4-2066a8e2e1a5">
<fme:FEATURE_ID>1000116921</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831187.55</fme:EASTING>
<fme:NORTHING>820215.21</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820215.57963 831193.15428 0.00000 820212.20136 831182.81778 0.00000 820214.84693 831181.95313 0.00000 820218.22520 831192.28963 0.00000 820215.57963 831193.15428 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id11ed3729-7a01-457d-9a2d-ca5d079ad92b">
<fme:FEATURE_ID>1000117093</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832705.75</fme:EASTING>
<fme:NORTHING>819619.45</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819618.22520 832708.68359 0.00000 819616.84387 832703.93128 0.00000 819620.66549 832702.80519 0.00000 819622.04716 832707.58845 0.00000 819618.22520 832708.68359 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida3f9a5c5-cc8e-4568-8fd2-f8031e927adf">
<fme:FEATURE_ID>1000117044</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832422.81</fme:EASTING>
<fme:NORTHING>819906.44</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819908.55125 832425.43093 0.00000 819903.69964 832424.80404 0.00000 819904.32546 832420.19868 0.00000 819909.17702 832420.80013 0.00000 819908.55125 832425.43093 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide1320950-81d1-4e42-a921-dae9b20a75bc">
<fme:FEATURE_ID>1000116986</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831903.86</fme:EASTING>
<fme:NORTHING>820053.29</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820049.23977 831910.21856 0.00000 820046.32574 831904.54494 0.00000 820056.84597 831897.62609 0.00000 820060.56840 831903.00226 0.00000 820049.23977 831910.21856 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id716b8d28-930b-4027-8b24-ee52c8832aef">
<fme:FEATURE_ID>1210077731</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833484.37</fme:EASTING>
<fme:NORTHING>820903.06</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820929.26700 833495.46100 0.00000 820928.59800 833496.56500 0.00000 820930.91600 833509.29400 0.00000 820923.32519 833510.49773 0.00000 820922.74956 833507.26714 0.00000 820922.01400 833503.13900 0.00000 820919.43251 833503.52597 0.00000 820914.83537 833499.98716 0.00000 820904.31816 833493.47178 0.00000 820905.74923 833491.07753 0.00000 820892.53095 833483.26546 0.00000 820897.30185 833475.65733 0.00000 820914.95443 833486.32140 0.00000 820911.97786 833490.89870 0.00000 820917.95746 833493.70329 0.00000 820921.66163 833490.42245 0.00000 820918.36840 833486.60231 0.00000 820930.50900 833476.81800 0.00000 820939.22500 833487.17700 0.00000 820929.26700 833495.46100 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd434d3e0-cdd2-4b64-a9a1-04c0b8aacf87">
<fme:FEATURE_ID>1000116824</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833681.52</fme:EASTING>
<fme:NORTHING>820614.97</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820613.27314 833695.75222 0.00000 820602.92812 833687.09476 0.00000 820602.60812 833683.88476 0.00000 820615.05812 833668.90476 0.00000 820618.24812 833668.65476 0.00000 820628.62794 833677.27496 0.00000 820613.27314 833695.75222 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf821c11c-a7d9-428c-bead-aafa0dd6db76">
<fme:FEATURE_ID>1000116790</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832704.38</fme:EASTING>
<fme:NORTHING>820929.41</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820930.58000 832709.45000 0.00000 820924.31000 832705.54000 0.00000 820928.23000 832699.31000 0.00000 820934.50000 832703.22000 0.00000 820930.58000 832709.45000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide1973760-6eaa-457d-a498-461aa34d8141">
<fme:FEATURE_ID>1000117005</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832364.78</fme:EASTING>
<fme:NORTHING>820001.75</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819998.20170 832370.65785 0.00000 819991.73231 832372.01823 0.00000 819989.97179 832362.11340 0.00000 820011.70976 832357.55134 0.00000 820012.01514 832358.29028 0.00000 820012.05350 832359.17180 0.00000 820013.51487 832367.43780 0.00000 819998.20170 832370.65785 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1ce364a5-d436-4ed7-b7b2-5df472cb5809">
<fme:FEATURE_ID>1000117062</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832529.5</fme:EASTING>
<fme:NORTHING>819835.06</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819832.34946 832535.01529 0.00000 819829.01001 832528.56067 0.00000 819837.76167 832523.99028 0.00000 819841.10113 832530.44490 0.00000 819832.34946 832535.01529 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id91cf8451-8e72-442d-bb84-a922a1c1f1d6">
<fme:FEATURE_ID>1000116885</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833115.56</fme:EASTING>
<fme:NORTHING>820292.71</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820287.73523 833117.25389 0.00000 820290.97564 833113.63052 0.00000 820293.82249 833110.44723 0.00000 820297.66084 833113.77495 0.00000 820291.64834 833120.69745 0.00000 820287.73523 833117.25389 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb7c56286-adb4-4b9a-81ef-10c5b2785ed7">
<fme:FEATURE_ID>1000117080</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832749.08</fme:EASTING>
<fme:NORTHING>819742.23</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819745.09318 832756.60315 0.00000 819735.16264 832745.11513 0.00000 819739.34034 832741.53312 0.00000 819749.32223 832753.07145 0.00000 819745.09318 832756.60315 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd6424e83-32d2-40a9-b9f3-130af87bf4ee">
<fme:FEATURE_ID>1000116806</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832341.49</fme:EASTING>
<fme:NORTHING>820810.08</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820786.65557 832344.12115 0.00000 820786.50862 832341.65711 0.00000 820786.62014 832339.19121 0.00000 820786.90971 832337.15439 0.00000 820787.48987 832334.75512 0.00000 820788.16291 832332.81102 0.00000 820789.19038 832330.56661 0.00000 820790.44691 832328.44194 0.00000 820791.91873 832326.46032 0.00000 820793.29812 832324.93396 0.00000 820795.12113 832323.26971 0.00000 820796.76651 832322.03472 0.00000 820798.87367 832320.74905 0.00000 820800.72454 832319.85083 0.00000 820802.64667 832319.11741 0.00000 820805.02665 832318.46262 0.00000 820807.46206 832318.06028 0.00000 820809.92619 832317.91482 0.00000 820812.39202 832318.02783 0.00000 820814.83251 832318.39806 0.00000 820817.22091 832319.02146 0.00000 820819.15253 832319.72951 0.00000 820821.37802 832320.79735 0.00000 820823.13897 832321.86109 0.00000 820824.80047 832323.07431 0.00000 820826.64524 832324.71441 0.00000 820828.30839 832326.53842 0.00000 820829.54239 832328.18455 0.00000 820830.62816 832329.93200 0.00000 820831.72388 832332.14390 0.00000 820832.58229 832334.45824 0.00000 820833.19399 832336.84967 0.00000 820833.51036 832338.88250 0.00000 820833.65434 832341.34671 0.00000 820833.53984 832343.81247 0.00000 820833.24781 832345.84894 0.00000 820832.66475 832348.24751 0.00000 820831.98937 832350.19079 0.00000 820830.95919 832352.43397 0.00000 820829.92528 832354.21260 0.00000 820828.48587 832356.21788 0.00000 820826.84465 832358.06166 0.00000 820825.01964 832359.72370 0.00000 820823.03083 832361.18580 0.00000 820821.26405 832362.23983 0.00000 820819.03272 832363.29542 0.00000 820816.70325 832364.11189 0.00000 820814.70545 832364.60308 0.00000 820812.67242 832364.91822 0.00000 820810.20812 832365.06071 0.00000 820807.79908 832364.95031 0.00000 820805.35814 832364.58302 0.00000 820803.36246 832364.08325 0.00000 820801.03651 832363.25679 0.00000 820798.80974 832362.19164 0.00000 820797.04750 832361.13003 0.00000 820795.06499 832359.65941 0.00000 820793.53780 832358.28094 0.00000 820791.87245 832356.45893 0.00000 820790.63646 832354.81430 0.00000 820789.34952 832352.70791 0.00000 820788.45019 832350.85759 0.00000 820787.58898 832348.54428 0.00000 820786.97439 832346.15360 0.00000 820786.65557 832344.12115 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idff831c7b-85ab-424c-a00a-112215f2742c">
<fme:FEATURE_ID>1000117022</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832805.24</fme:EASTING>
<fme:NORTHING>819962.4</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819959.26189 832815.10779 0.00000 819956.64354 832813.81578 0.00000 819965.44347 832795.45903 0.00000 819968.16341 832796.75084 0.00000 819959.26189 832815.10779 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id76da1a4a-c4fe-49b8-b48c-86f51fe8db72">
<fme:FEATURE_ID>1000116849</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832942.26</fme:EASTING>
<fme:NORTHING>820400.67</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820400.00000 832953.64953 0.00000 820383.80267 832937.58615 0.00000 820395.86299 832925.39032 0.00000 820417.55317 832947.02930 0.00000 820405.49397 832959.09807 0.00000 820400.00000 832953.64953 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idec7cd128-c829-4b91-b79d-5cafae8a33d1">
<fme:FEATURE_ID>1000117032</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831692.51</fme:EASTING>
<fme:NORTHING>819939.21</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819939.65415 831695.60834 0.00000 819936.02996 831692.95372 0.00000 819938.79105 831689.40986 0.00000 819942.38403 831692.06891 0.00000 819939.65415 831695.60834 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id811e9767-065d-4e83-8975-291b652e88c5">
<fme:FEATURE_ID>1000116945</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831928.09</fme:EASTING>
<fme:NORTHING>820152.49</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820153.23517 831931.15524 0.00000 820149.34542 831928.60583 0.00000 820151.71533 831925.01016 0.00000 820155.66488 831927.58915 0.00000 820153.23517 831931.15524 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9371fe45-8586-4cdb-8b41-9eadfbc23538">
<fme:FEATURE_ID>1310097908</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832719.84</fme:EASTING>
<fme:NORTHING>820199.75</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820211.13561 832731.33011 0.00000 820183.81732 832717.83633 0.00000 820188.51369 832708.31132 0.00000 820215.69968 832721.93738 0.00000 820211.13561 832731.33011 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7d4e3fb9-1e43-4c03-a78b-ddd926cafd4a">
<fme:FEATURE_ID>1000116820</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832700.57</fme:EASTING>
<fme:NORTHING>820649.89</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820650.77351 832715.74203 0.00000 820634.87312 832699.86313 0.00000 820649.21296 832685.45297 0.00000 820664.80281 832701.18149 0.00000 820650.77351 832715.74203 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id26e88c00-548c-409d-a13e-559eeb0c9630">
<fme:FEATURE_ID>1000116822</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833693.3</fme:EASTING>
<fme:NORTHING>820640.4</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820637.10824 833685.19929 0.00000 820639.59675 833687.25786 0.00000 820638.55598 833688.44438 0.00000 820638.69979 833691.66730 0.00000 820641.85676 833694.22563 0.00000 820644.96614 833693.90531 0.00000 820646.13374 833692.66600 0.00000 820648.81568 833694.88242 0.00000 820644.40556 833700.37263 0.00000 820632.62627 833690.56403 0.00000 820637.10824 833685.19929 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2831793e-5d23-4b28-ba0e-34f5c07c39a2">
<fme:FEATURE_ID>1000117069</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832534.89</fme:EASTING>
<fme:NORTHING>819818.05</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819816.43658 832539.47245 0.00000 819813.42826 832533.52594 0.00000 819819.61787 832530.30874 0.00000 819822.70237 832536.25510 0.00000 819816.43658 832539.47245 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idabe07f0d-e310-48ef-b973-c728e353addd">
<fme:FEATURE_ID>1000116800</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832521.19</fme:EASTING>
<fme:NORTHING>820865.13</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820861.14519 832524.29036 0.00000 820862.20942 832522.49585 0.00000 820865.88250 832516.30231 0.00000 820869.17082 832518.26289 0.00000 820864.23688 832526.09507 0.00000 820861.14519 832524.29036 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc24c6c26-f3e4-49f9-b7f1-b45aad1fe3e8">
<fme:FEATURE_ID>1000116843</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832458.34</fme:EASTING>
<fme:NORTHING>820456.4</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820451.09670 832471.12055 0.00000 820443.68958 832463.02758 0.00000 820461.04230 832445.58394 0.00000 820469.30592 832454.01972 0.00000 820451.09670 832471.12055 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0858413a-3f8a-4ae3-b098-e9e26fe5e1d7">
<fme:FEATURE_ID>1000117042</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831625.29</fme:EASTING>
<fme:NORTHING>819911.45</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819922.39298 831616.29889 0.00000 819916.23620 831628.39200 0.00000 819921.20235 831631.22142 0.00000 819916.12234 831640.42894 0.00000 819898.65981 831630.74517 0.00000 819910.16920 831609.71075 0.00000 819922.39298 831616.29889 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida9cef085-12cf-4fe2-aef0-3295edecedcb">
<fme:FEATURE_ID>1210077729</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833522.57</fme:EASTING>
<fme:NORTHING>820971.64</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820993.09490 833520.24112 0.00000 820990.22211 833518.47242 0.00000 820978.71483 833535.70437 0.00000 820968.46822 833537.21544 0.00000 820967.61268 833532.72445 0.00000 820962.33423 833533.47852 0.00000 820951.61859 833526.33475 0.00000 820950.68898 833527.70609 0.00000 820948.82061 833530.46226 0.00000 820946.02264 833528.46465 0.00000 820947.82470 833525.85970 0.00000 820948.69493 833524.60173 0.00000 820944.19701 833521.61193 0.00000 820947.18681 833517.29921 0.00000 820944.86790 833515.58002 0.00000 820947.18200 833512.34900 0.00000 820963.72330 833523.71537 0.00000 820975.23270 833521.85006 0.00000 820988.51600 833502.15900 0.00000 820991.87412 833504.30616 0.00000 820990.39335 833506.72909 0.00000 820994.48117 833509.66597 0.00000 820991.66335 833513.99191 0.00000 820995.47336 833516.57161 0.00000 820993.09490 833520.24112 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide1cdbb1f-1529-4422-8d22-3e684c2aaa19">
<fme:FEATURE_ID>1210080690</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831574.43</fme:EASTING>
<fme:NORTHING>820292.31</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820293.82047 831578.13935 0.00000 820288.71825 831572.65340 0.00000 820290.79133 831570.72533 0.00000 820295.89355 831576.21128 0.00000 820293.82047 831578.13935 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8ec98fc8-c83d-4aa5-87dc-b70f475e9ee2">
<fme:FEATURE_ID>1000154532</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833740.99</fme:EASTING>
<fme:NORTHING>820626.87</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820615.25211 833747.88405 0.00000 820629.43879 833730.95456 0.00000 820631.50187 833728.49261 0.00000 820638.47414 833734.49470 0.00000 820624.99408 833750.00000 0.00000 820617.82892 833750.00000 0.00000 820615.25211 833747.88405 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb937455a-9fce-44ae-b15a-51f6d54b335c">
<fme:FEATURE_ID>1000117068</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832754.47</fme:EASTING>
<fme:NORTHING>819812.57</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819800.00000 832753.24546 0.00000 819796.85791 832750.50680 0.00000 819806.97619 832739.39455 0.00000 819828.24378 832758.42915 0.00000 819818.18554 832769.56423 0.00000 819800.00000 832753.24546 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide4de799c-28e4-401e-837c-3e1f413520cc">
<fme:FEATURE_ID>1000117092</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832686.47</fme:EASTING>
<fme:NORTHING>819627.05</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819618.54105 832696.74425 0.00000 819614.46023 832691.56213 0.00000 819635.04793 832675.37690 0.00000 819639.66530 832681.26676 0.00000 819619.19111 832697.56975 0.00000 819618.54105 832696.74425 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idfac32da0-15e1-487f-88e4-6316c10ed792">
<fme:FEATURE_ID>1210076243</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832505.57</fme:EASTING>
<fme:NORTHING>820770.11</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820765.49282 832531.81775 0.00000 820743.82211 832510.14703 0.00000 820774.74084 832479.36634 0.00000 820796.41155 832500.89902 0.00000 820765.49282 832531.81775 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide06eb609-cb5a-43b6-b2b5-f69549c5349c">
<fme:FEATURE_ID>1000117105</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832629.34</fme:EASTING>
<fme:NORTHING>820653.86</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820678.45800 832661.80200 0.00000 820614.61852 832596.25747 0.00000 820617.05484 832593.54701 0.00000 820627.63507 832604.31646 0.00000 820631.68049 832599.91410 0.00000 820686.44100 832653.83600 0.00000 820678.45800 832661.80200 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id92cb69ea-fd54-4399-9bea-f35ffe0527d5">
<fme:FEATURE_ID>1310091443</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831729.76</fme:EASTING>
<fme:NORTHING>819888.58</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819853.16529 831781.63018 0.00000 819838.77106 831761.61902 0.00000 819905.41500 831641.20634 0.00000 819928.44989 831767.94738 0.00000 819853.16529 831781.63018 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8b7fb925-27ad-4da6-bde3-5812f9477998">
<fme:FEATURE_ID>1000116929</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832209.45</fme:EASTING>
<fme:NORTHING>820188.89</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820183.41234 832218.96798 0.00000 820182.38978 832200.79426 0.00000 820194.35974 832199.92313 0.00000 820195.38231 832218.09685 0.00000 820183.41234 832218.96798 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="iddd92d753-bb9a-40c0-943e-3091821473cc">
<fme:FEATURE_ID>1000117031</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832500.48</fme:EASTING>
<fme:NORTHING>819941.56</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819940.34846 832504.58406 0.00000 819937.29326 832500.59607 0.00000 819942.71946 832496.38875 0.00000 819945.85079 832500.35117 0.00000 819940.34846 832504.58406 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2e3b459f-0287-4747-8a86-49a6235ae951">
<fme:FEATURE_ID>1000117074</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832805.72</fme:EASTING>
<fme:NORTHING>819771.68</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819767.54071 832819.69647 0.00000 819757.10866 832809.66683 0.00000 819767.58618 832798.07806 0.00000 819771.47556 832801.41181 0.00000 819779.36016 832792.89221 0.00000 819780.15391 832791.96617 0.00000 819787.16539 832798.05160 0.00000 819767.54071 832819.69647 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd4099b4f-937a-4ff4-b261-7dcd4687481a">
<fme:FEATURE_ID>1000117009</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831827.12</fme:EASTING>
<fme:NORTHING>819997.79</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819990.39688 831832.67100 0.00000 819989.59164 831830.63002 0.00000 819989.12372 831828.76773 0.00000 819988.86861 831826.58853 0.00000 819988.91628 831824.39497 0.00000 819989.26582 831822.22891 0.00000 819989.81420 831820.38870 0.00000 819987.36370 831807.01910 0.00000 820000.86490 831804.47250 0.00000 820008.84480 831847.05890 0.00000 819995.20080 831849.60830 0.00000 819992.80760 831836.32510 0.00000 819991.47573 831834.58151 0.00000 819990.39688 831832.67100 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id726542c6-ebdc-4cd4-8bd5-7a89c4faa9a0">
<fme:FEATURE_ID>1000117113</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832732.92</fme:EASTING>
<fme:NORTHING>820278.8</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820289.26000 832732.08000 0.00000 820286.04000 832737.62000 0.00000 820301.49000 832753.09000 0.00000 820273.20000 832781.11000 0.00000 820257.87000 832765.76000 0.00000 820262.44000 832761.17000 0.00000 820256.16000 832754.88000 0.00000 820263.24000 832722.36000 0.00000 820277.49000 832684.41000 0.00000 820303.52000 832694.29000 0.00000 820289.26000 832732.08000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2a147c4b-0e7b-4709-af07-e77ac9e0c035">
<fme:FEATURE_ID>1000116795</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832472.08</fme:EASTING>
<fme:NORTHING>820893.35</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820895.31041 832479.35801 0.00000 820886.22876 832473.79323 0.00000 820886.61000 832473.40100 0.00000 820895.48000 832463.03200 0.00000 820896.62245 832466.76077 0.00000 820896.70188 832467.16330 0.00000 820897.72966 832472.37143 0.00000 820898.01829 832473.83406 0.00000 820897.84797 832475.01371 0.00000 820897.44635 832476.15653 0.00000 820895.31041 832479.35801 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide6b77777-59d3-4639-992c-c2806a44ac96">
<fme:FEATURE_ID>1000116816</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833614.28</fme:EASTING>
<fme:NORTHING>820705.05</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820701.71622 833606.27640 0.00000 820704.29415 833608.40997 0.00000 820703.79543 833609.23108 0.00000 820704.08543 833612.50108 0.00000 820704.90543 833613.38108 0.00000 820706.94543 833615.09108 0.00000 820710.38543 833614.76108 0.00000 820711.04042 833613.99338 0.00000 820713.57731 833616.09298 0.00000 820709.11543 833621.44108 0.00000 820697.30543 833611.64108 0.00000 820701.71622 833606.27640 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8d800a69-591e-48ed-a45f-91f56f53404b">
<fme:FEATURE_ID>1000117025</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832782.67</fme:EASTING>
<fme:NORTHING>819953.36</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819953.70213 832791.18378 0.00000 819945.57298 832789.87732 0.00000 819946.98458 832781.76396 0.00000 819948.30885 832774.15254 0.00000 819961.46820 832776.41554 0.00000 819959.27082 832789.62664 0.00000 819954.07821 832788.81750 0.00000 819953.70213 832791.18378 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6a3898c3-2345-444b-8bf4-8b735f40641f">
<fme:FEATURE_ID>1310090810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833216.67</fme:EASTING>
<fme:NORTHING>820978.57</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820999.86329 833290.65868 0.00000 820996.86397 833294.90772 0.00000 820993.22594 833294.90772 0.00000 820990.11708 833288.22697 0.00000 820990.04916 833285.73927 0.00000 820989.58791 833268.84621 0.00000 820988.79416 833264.14984 0.00000 820980.06289 833243.04928 0.00000 820964.28363 833201.30858 0.00000 820966.42858 833197.74744 0.00000 820970.73631 833190.59553 0.00000 820981.78269 833197.47471 0.00000 820987.00822 833211.43151 0.00000 820985.28842 833212.09297 0.00000 820988.92645 833221.61799 0.00000 820990.64625 833220.89038 0.00000 820994.61501 833231.67217 0.00000 820992.82906 833232.33363 0.00000 820995.54105 833239.74198 0.00000 820997.85616 833240.73417 0.00000 821000.00000 833240.21133 0.00000 821000.00000 833251.53289 0.00000 821000.00000 833254.23621 0.00000 820999.70824 833254.55868 0.00000 820999.44366 833256.67535 0.00000 821000.00000 833258.13310 0.00000 821000.00000 833274.40083 0.00000 821000.00000 833282.16023 0.00000 821000.00000 833290.46501 0.00000 820999.86329 833290.65868 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id568dd7cf-4562-4bcc-a3b2-f8e11897dbae">
<fme:FEATURE_ID>1000116940</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832763.62</fme:EASTING>
<fme:NORTHING>820164.09</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820164.29055 832766.86690 0.00000 820161.09647 832764.78727 0.00000 820163.83836 832760.39354 0.00000 820167.11291 832762.43355 0.00000 820164.29055 832766.86690 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf80faa5f-dcee-41b0-aede-0ae34d336843">
<fme:FEATURE_ID>1000116786</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832785.32</fme:EASTING>
<fme:NORTHING>820968.8</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820966.68880 832793.33276 0.00000 820962.45546 832790.75307 0.00000 820970.78985 832777.32544 0.00000 820975.15548 832780.03743 0.00000 820966.68880 832793.33276 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id24a631ce-089f-4c62-a7ab-f53385fae393">
<fme:FEATURE_ID>1000157983</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832163.7</fme:EASTING>
<fme:NORTHING>820978.97</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820974.74023 832168.18945 0.00000 820972.90039 832162.51953 0.00000 820983.23047 832159.25977 0.00000 820985.06055 832164.82031 0.00000 820974.74023 832168.18945 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9f265d22-d0ff-4894-b9a6-dab21033dc9b">
<fme:FEATURE_ID>1000117096</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RUI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831728.02</fme:EASTING>
<fme:NORTHING>820154.04</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820156.18828 831735.89617 0.00000 820146.36367 831725.37166 0.00000 820151.69696 831720.00485 0.00000 820161.91926 831730.93219 0.00000 820161.32044 831731.27358 0.00000 820156.18828 831735.89617 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf92949ec-a714-483c-9d45-1e8f6fe28197">
<fme:FEATURE_ID>1210046819</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832453.6</fme:EASTING>
<fme:NORTHING>820508.17</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820510.20595 832461.67788 0.00000 820500.09793 832451.64258 0.00000 820506.27909 832445.53413 0.00000 820516.16896 832455.56944 0.00000 820510.20595 832461.67788 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id587f3e47-c572-4be3-bb80-de470ba31871">
<fme:FEATURE_ID>1000116839</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832504.83</fme:EASTING>
<fme:NORTHING>820465.81</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250726</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820465.63490 832536.03850 0.00000 820434.45370 832505.32540 0.00000 820466.26950 832473.59960 0.00000 820497.02930 832504.38090 0.00000 820465.63490 832536.03850 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0990d4c6-9573-45ab-8c53-588ce0189219">
<fme:FEATURE_ID>1000117036</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831639.23</fme:EASTING>
<fme:NORTHING>819935.13</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819933.50469 831643.84362 0.00000 819931.72803 831642.74279 0.00000 819936.76201 831634.61828 0.00000 819938.53867 831635.71911 0.00000 819933.50469 831643.84362 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9bd0b2a8-5f3e-45ae-9ee4-b43ff9a225b6">
<fme:FEATURE_ID>1310096947</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832781.18</fme:EASTING>
<fme:NORTHING>821012.14</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820998.32134 832788.43766 0.00000 821000.00000 832785.74006 0.00000 821000.00000 832789.50530 0.00000 820998.32134 832788.43766 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9c199e58-4ef9-4f46-a933-bb4a48124b42">
<fme:FEATURE_ID>1000117012</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832616.21</fme:EASTING>
<fme:NORTHING>819994.53</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819988.49777 832621.48141 0.00000 819988.07198 832611.56157 0.00000 820000.51407 832610.90242 0.00000 820000.99081 832620.89848 0.00000 819988.49777 832621.48141 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id386f62cd-e06e-495e-9efe-8eca8974b74b">
<fme:FEATURE_ID>1000117098</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832791.26</fme:EASTING>
<fme:NORTHING>820979.7</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820978.90686 832778.97889 0.00000 820993.99736 832788.41678 0.00000 820987.22992 832799.04562 0.00000 820977.44356 832792.92503 0.00000 820969.99121 832804.54087 0.00000 820964.64844 832801.19940 0.00000 820966.51055 832798.29746 0.00000 820978.90686 832778.97889 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ideecd1029-4fbd-4ecb-9e1d-c44c31512535">
<fme:FEATURE_ID>1000116935</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831746.59</fme:EASTING>
<fme:NORTHING>820171.28</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820168.66942 831746.39513 0.00000 820167.49012 831742.65409 0.00000 820172.08636 831741.16253 0.00000 820175.10297 831750.50430 0.00000 820170.43675 831752.00159 0.00000 820168.66942 831746.39513 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb6bbba53-503d-4338-bb7d-94db5c5d75cd">
<fme:FEATURE_ID>1000116995</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832867.47</fme:EASTING>
<fme:NORTHING>820022.69</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820024.50817 832872.63322 0.00000 820018.52310 832863.82139 0.00000 820020.79918 832862.27783 0.00000 820026.86098 832871.03821 0.00000 820024.50817 832872.63322 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf5922a71-4fc4-44b9-8b1a-cd263a03842c">
<fme:FEATURE_ID>1420007878</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831353.88</fme:EASTING>
<fme:NORTHING>819909.52</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250726</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819893.30287 831372.77270 0.00000 819886.49193 831363.77964 0.00000 819887.32920 831363.14553 0.00000 819925.82456 831334.94544 0.00000 819932.49207 831344.04712 0.00000 819893.99671 831372.24722 0.00000 819893.30287 831372.77270 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf262da09-5114-4d83-b5be-fe8d01fc1461">
<fme:FEATURE_ID>1000116833</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832480.49</fme:EASTING>
<fme:NORTHING>820490.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820502.20300 832497.73697 0.00000 820473.50033 832468.85436 0.00000 820479.27971 832463.18942 0.00000 820508.20138 832491.63225 0.00000 820502.20300 832497.73697 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idee032460-e0bf-4fa3-ad20-30392460cb8a">
<fme:FEATURE_ID>1000116975</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832908.95</fme:EASTING>
<fme:NORTHING>820093.57</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820087.54951 832921.23730 0.00000 820081.51849 832915.49957 0.00000 820099.59032 832896.66478 0.00000 820105.62130 832902.37707 0.00000 820087.54951 832921.23730 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3c1bc113-9839-4e20-b17e-226d6862eae2">
<fme:FEATURE_ID>1000116841</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832151.59</fme:EASTING>
<fme:NORTHING>820482.89</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820483.18578 832154.89055 0.00000 820479.71272 832150.65139 0.00000 820482.55938 832148.32287 0.00000 820486.07143 832152.46749 0.00000 820483.18578 832154.89055 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf03d065f-8f89-469b-8ff4-07351f15ccd5">
<fme:FEATURE_ID>1000116946</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832944.31</fme:EASTING>
<fme:NORTHING>820129.08</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820109.69400 832969.31400 0.00000 820102.95500 832961.91300 0.00000 820148.75200 832919.21300 0.00000 820155.32500 832926.41200 0.00000 820109.69400 832969.31400 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id02662ac3-5b65-4bee-aa48-45fde6f83ff9">
<fme:FEATURE_ID>1000117090</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831830.72</fme:EASTING>
<fme:NORTHING>819657.68</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819649.74165 831832.65692 0.00000 819649.58222 831831.70371 0.00000 819649.72563 831830.92447 0.00000 819650.07550 831830.26261 0.00000 819650.63864 831829.70523 0.00000 819651.30407 831829.36220 0.00000 819663.32468 831827.13584 0.00000 819664.22621 831827.33499 0.00000 819664.96482 831827.81293 0.00000 819665.49604 831828.51421 0.00000 819665.75609 831829.35465 0.00000 819665.71377 831830.23339 0.00000 819665.37416 831831.04496 0.00000 819664.77802 831831.69195 0.00000 819663.99690 831832.09670 0.00000 819652.04338 831834.30941 0.00000 819651.10081 831834.09590 0.00000 819650.27542 831833.51413 0.00000 819649.74165 831832.65692 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9d0a7e64-25de-431e-9a11-8e98ed1d4af6">
<fme:FEATURE_ID>1000116960</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831926.48</fme:EASTING>
<fme:NORTHING>820121.49</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820124.00690 831934.97549 0.00000 820112.77551 831927.23526 0.00000 820119.13331 831917.89639 0.00000 820130.14848 831925.89715 0.00000 820124.00690 831934.97549 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1446e1ec-c815-4c73-b223-20645fb44631">
<fme:FEATURE_ID>1000116917</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831505.54</fme:EASTING>
<fme:NORTHING>820217.5</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820214.74502 831508.42830 0.00000 820213.86657 831504.58773 0.00000 820216.25736 831503.40673 0.00000 820220.09385 831502.58754 0.00000 820221.15926 831506.98085 0.00000 820218.52814 831507.57459 0.00000 820214.74502 831508.42830 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idcdb8e432-73ca-473b-884e-5496ca4e42f1">
<fme:FEATURE_ID>1310090821</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833393.63</fme:EASTING>
<fme:NORTHING>820876.98</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820912.50662 833412.21401 0.00000 820905.59874 833411.03446 0.00000 820905.28207 833412.88900 0.00000 820904.07723 833412.71803 0.00000 820900.81875 833412.19141 0.00000 820892.62176 833410.86665 0.00000 820893.32820 833406.49551 0.00000 820890.87338 833406.09878 0.00000 820890.41085 833408.96069 0.00000 820883.79705 833407.89180 0.00000 820884.84764 833401.39123 0.00000 820880.31775 833406.74820 0.00000 820877.26404 833404.16596 0.00000 820878.81390 833402.33313 0.00000 820870.29532 833395.34940 0.00000 820868.10686 833398.01881 0.00000 820853.71272 833386.21816 0.00000 820852.20594 833387.80494 0.00000 820845.48517 833382.17250 0.00000 820857.04315 833368.28937 0.00000 820863.71198 833372.59265 0.00000 820860.87218 833376.34718 0.00000 820883.17526 833394.89484 0.00000 820881.64974 833396.72924 0.00000 820885.71361 833399.62428 0.00000 820890.60841 833399.32662 0.00000 820910.29686 833402.79694 0.00000 820914.13157 833405.34590 0.00000 820913.13938 833411.36519 0.00000 820912.50662 833412.21401 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbcf28034-6901-416f-b5f1-69d7a99ceaf0">
<fme:FEATURE_ID>1000117097</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RUI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831738.74</fme:EASTING>
<fme:NORTHING>820121.58</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820102.18357 831745.44257 0.00000 820096.41322 831739.16517 0.00000 820114.62156 831722.75396 0.00000 820119.80543 831728.55113 0.00000 820125.31880 831723.64278 0.00000 820143.25364 831743.29678 0.00000 820141.87562 831744.08044 0.00000 820127.60290 831757.24198 0.00000 820110.27584 831738.08090 0.00000 820102.18357 831745.44257 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4ec1f86c-26d4-4843-8a84-074a2ace89a9">
<fme:FEATURE_ID>1000116785</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832487.34</fme:EASTING>
<fme:NORTHING>820983.47</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820982.54342 832493.31674 0.00000 820978.70455 832491.04185 0.00000 820984.38121 832481.37379 0.00000 820988.23065 832483.64846 0.00000 820982.54342 832493.31674 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id312d97fa-e558-44b6-a4a5-014cca71caae">
<fme:FEATURE_ID>1000116979</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831925.28</fme:EASTING>
<fme:NORTHING>820083.96</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820083.25375 831928.44060 0.00000 820080.83771 831924.56234 0.00000 820084.67665 831922.15606 0.00000 820087.09245 831925.94361 0.00000 820083.25375 831928.44060 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7f881bef-648e-4bbf-bb72-be52c84257cf">
<fme:FEATURE_ID>1310090996</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833433.92</fme:EASTING>
<fme:NORTHING>820845.96</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820881.60819 833422.35106 0.00000 820857.13419 833451.71987 0.00000 820873.00922 833465.34594 0.00000 820871.54951 833467.65432 0.00000 820861.63211 833483.33764 0.00000 820818.77125 833447.69545 0.00000 820811.36118 833441.53339 0.00000 820817.84348 833433.59588 0.00000 820809.64138 833426.71670 0.00000 820831.12677 833401.21953 0.00000 820839.15063 833391.69743 0.00000 820841.52374 833388.88121 0.00000 820847.75167 833394.08143 0.00000 820881.60819 833422.35106 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
<gml:interior>
<gml:LinearRing>
<gml:posList>820839.57591 833420.44008 0.00000 820828.78089 833433.37823 0.00000 820836.75809 833440.00605 0.00000 820838.34560 833439.92668 0.00000 820847.94999 833428.57603 0.00000 820849.14062 833428.49665 0.00000 820850.01374 833429.05228 0.00000 820851.28375 833428.89353 0.00000 820853.50625 833426.07571 0.00000 820853.34750 833424.92477 0.00000 820849.69624 833421.74977 0.00000 820847.98968 833422.38477 0.00000 820846.44186 833421.27351 0.00000 820845.44967 833422.74195 0.00000 820844.53686 833423.09914 0.00000 820843.50498 833422.70227 0.00000 820840.68716 833420.44008 0.00000 820839.57591 833420.44008 0.00000</gml:posList>
</gml:LinearRing>
</gml:interior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id59cd055f-72f3-408d-9c0e-f11670069565">
<fme:FEATURE_ID>1210047326</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833094.13</fme:EASTING>
<fme:NORTHING>820214.72</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820215.43845 833098.35627 0.00000 820211.06861 833091.89934 0.00000 820214.13402 833089.94269 0.00000 820218.30820 833096.39963 0.00000 820215.43845 833098.35627 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1385d281-4f73-42af-8857-a180716f5b8f">
<fme:FEATURE_ID>1000116914</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831755.66</fme:EASTING>
<fme:NORTHING>820223.55</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820227.45057 831762.15185 0.00000 820216.06038 831754.19748 0.00000 820219.61778 831749.19575 0.00000 820231.03289 831757.04829 0.00000 820230.36669 831757.99739 0.00000 820227.45057 831762.15185 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id49d7c9ab-15dd-4c5d-8c95-182300c5c4ab">
<fme:FEATURE_ID>1000116813</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832628.39</fme:EASTING>
<fme:NORTHING>820732.18</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820712.88351 832654.49625 0.00000 820706.11158 832647.57316 0.00000 820751.58234 832602.27996 0.00000 820758.36587 832608.99919 0.00000 820712.88351 832654.49625 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2029be47-ebdf-4017-b59d-b7d7aa48cf99">
<fme:FEATURE_ID>1000117028</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832506.62</fme:EASTING>
<fme:NORTHING>819946.35</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819945.23640 832510.78170 0.00000 819942.02864 832506.69224 0.00000 819947.48019 832502.45944 0.00000 819950.66260 832506.57438 0.00000 819945.23640 832510.78170 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida1625768-f2fd-48cb-be4e-9bebba2115fc">
<fme:FEATURE_ID>1310090820</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833396.28</fme:EASTING>
<fme:NORTHING>820879.03</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820910.42740 833415.00321 0.00000 820903.87895 833413.94488 0.00000 820904.07723 833412.71803 0.00000 820900.81875 833412.19141 0.00000 820900.15267 833416.31284 0.00000 820893.10168 833415.17328 0.00000 820889.78986 833419.30270 0.00000 820852.20594 833387.80494 0.00000 820845.48517 833382.17250 0.00000 820857.04315 833368.28937 0.00000 820863.71198 833372.59265 0.00000 820866.83051 833374.60498 0.00000 820867.63096 833378.82137 0.00000 820887.60704 833395.35786 0.00000 820902.88676 833397.87141 0.00000 820910.29686 833402.79694 0.00000 820914.13157 833405.34590 0.00000 820913.13938 833411.36519 0.00000 820912.50662 833412.21401 0.00000 820910.42740 833415.00321 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id97d16838-d514-478c-a483-83d8645eac24">
<fme:FEATURE_ID>1210080951</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831607.09</fme:EASTING>
<fme:NORTHING>820323.62</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820318.89059 831607.19666 0.00000 820322.40515 831604.49071 0.00000 820325.05588 831602.54896 0.00000 820328.33548 831606.96256 0.00000 820322.26592 831611.65627 0.00000 820318.89059 831607.19666 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idfb9bbb81-7e20-4825-84d6-2d91f3c2f583">
<fme:FEATURE_ID>1000116931</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832966.7</fme:EASTING>
<fme:NORTHING>820159.32</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820135.49500 832995.92600 0.00000 820128.34700 832988.46600 0.00000 820183.06400 832937.50500 0.00000 820190.23700 832945.05800 0.00000 820135.49500 832995.92600 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id80c93c91-5023-46f0-859f-4d87070fbb8c">
<fme:FEATURE_ID>1310094375</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832502.31</fme:EASTING>
<fme:NORTHING>820821.26</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240315</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820811.52984 832531.87587 0.00000 820798.51231 832523.72669 0.00000 820803.37841 832516.02736 0.00000 820822.37747 832485.96636 0.00000 820830.68571 832472.82075 0.00000 820844.02074 832481.28744 0.00000 820835.45387 832494.62609 0.00000 820816.43006 832524.24622 0.00000 820811.52984 832531.87587 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id351a2260-b575-4c1e-9c97-81a7822d7e6a">
<fme:FEATURE_ID>1000117041</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831601.29</fme:EASTING>
<fme:NORTHING>819915.75</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819914.88077 831593.65099 0.00000 819919.77233 831596.23543 0.00000 819922.53541 831597.69530 0.00000 819916.57993 831608.91086 0.00000 819908.97534 831604.94315 0.00000 819914.88077 831593.65099 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id752ac078-4c9e-41a9-bcc8-31a59ea0ff64">
<fme:FEATURE_ID>1000117122</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831394.71</fme:EASTING>
<fme:NORTHING>820078.53</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820090.20300 831389.33000 0.00000 820083.35872 831394.24353 0.00000 820085.38496 831397.05429 0.00000 820073.29957 831405.61374 0.00000 820067.00700 831396.78400 0.00000 820078.12900 831388.97900 0.00000 820085.90507 831383.48304 0.00000 820090.20300 831389.33000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb9c4a097-2532-474d-b950-87051d1d8555">
<fme:FEATURE_ID>1000117053</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832706</fme:EASTING>
<fme:NORTHING>819874.65</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819876.31088 832710.37383 0.00000 819870.18500 832704.88133 0.00000 819873.04779 832701.64539 0.00000 819879.09117 832707.11482 0.00000 819876.31088 832710.37383 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idcb8a647b-7a12-4f15-afcb-0fa0b9ef765a">
<fme:FEATURE_ID>1210058425</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832299.47</fme:EASTING>
<fme:NORTHING>820714.48</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820719.17378 832306.73026 0.00000 820706.92703 832294.39002 0.00000 820709.54466 832292.14634 0.00000 820721.97838 832304.29961 0.00000 820719.17378 832306.73026 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5064a005-574e-4ed2-a9bf-2500b1e0291a">
<fme:FEATURE_ID>1000117083</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831815.13</fme:EASTING>
<fme:NORTHING>819729.84</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819726.56060 831816.81880 0.00000 819726.15250 831814.74470 0.00000 819727.37549 831814.10180 0.00000 819728.98182 831813.58351 0.00000 819730.50337 831813.38202 0.00000 819732.03696 831813.44373 0.00000 819733.53740 831813.76680 0.00000 819733.75280 831815.17150 0.00000 819731.98093 831816.20895 0.00000 819729.39616 831816.92058 0.00000 819727.97439 831816.98095 0.00000 819726.56060 831816.81880 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3dd9dd76-16c3-4dab-8be5-cf2facc221e3">
<fme:FEATURE_ID>1000116910</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833023.93</fme:EASTING>
<fme:NORTHING>820210.12</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820225.68727 833046.53784 0.00000 820223.20172 833048.90410 0.00000 820221.75305 833047.38000 0.00000 820217.20240 833051.63564 0.00000 820222.72997 833057.51899 0.00000 820219.53245 833060.49937 0.00000 820221.66911 833062.78562 0.00000 820216.03674 833068.05247 0.00000 820197.22915 833047.95949 0.00000 820205.97938 833039.69026 0.00000 820213.57332 833047.77298 0.00000 820220.66367 833041.19352 0.00000 820209.89108 833029.73319 0.00000 820202.67943 833036.46309 0.00000 820193.46141 833026.66879 0.00000 820190.20470 833029.71132 0.00000 820175.58808 833014.08777 0.00000 820186.52225 833003.83077 0.00000 820201.18523 833019.45293 0.00000 820210.85613 833010.41804 0.00000 820190.97255 832989.33274 0.00000 820202.33228 832978.68943 0.00000 820222.00754 833000.00000 0.00000 820215.97776 833005.63323 0.00000 820222.06644 833012.10254 0.00000 820225.20748 833015.43995 0.00000 820217.78856 833022.36327 0.00000 820222.21444 833027.01692 0.00000 820227.00807 833022.51334 0.00000 820233.60873 833029.43783 0.00000 820223.85936 833038.57915 0.00000 820228.48579 833043.48212 0.00000 820240.52210 833032.13174 0.00000 820247.05598 833039.04628 0.00000 820231.93298 833053.18785 0.00000 820225.68727 833046.53784 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id755e97e4-fab4-42ec-a881-5d25463a8bd4">
<fme:FEATURE_ID>1000116857</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833131.26</fme:EASTING>
<fme:NORTHING>820372.02</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820380.48546 833133.54293 0.00000 820357.27558 833149.03659 0.00000 820349.83688 833137.32232 0.00000 820372.92368 833121.78613 0.00000 820369.82599 833117.19301 0.00000 820378.70141 833111.63349 0.00000 820393.28457 833133.54293 0.00000 820384.46604 833139.36071 0.00000 820380.48546 833133.54293 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd69ba997-f7ca-411f-82ea-5df94e1d912e">
<fme:FEATURE_ID>1000116881</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832489.75</fme:EASTING>
<fme:NORTHING>820293.53</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820289.77700 832503.29700 0.00000 820280.21900 832493.72500 0.00000 820297.30800 832476.33300 0.00000 820306.89800 832485.51400 0.00000 820289.77700 832503.29700 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7010718d-78dd-492b-acf8-e08b6046ed64">
<fme:FEATURE_ID>1000116952</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831938.31</fme:EASTING>
<fme:NORTHING>820139.33</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820138.72243 831945.94450 0.00000 820132.36640 831942.00981 0.00000 820140.05295 831930.57380 0.00000 820143.30310 831932.75938 0.00000 820146.24339 831934.73659 0.00000 820138.72243 831945.94450 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1bc44642-486c-49ff-aba2-9dd3b366fbff">
<fme:FEATURE_ID>1000116875</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832522.64</fme:EASTING>
<fme:NORTHING>820311.12</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820308.07422 832531.91073 0.00000 820300.87919 832524.46922 0.00000 820306.45395 832518.76058 0.00000 820308.94747 832521.24870 0.00000 820316.75237 832513.37361 0.00000 820321.68806 832518.07014 0.00000 820316.81247 832523.01039 0.00000 820308.07422 832531.91073 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id10f28ebb-5e5a-49d0-89e1-7b168b6f7036">
<fme:FEATURE_ID>1000117055</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832752.57</fme:EASTING>
<fme:NORTHING>819864.12</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819864.68632 832760.59024 0.00000 819853.69012 832750.50635 0.00000 819860.61264 832742.81818 0.00000 819875.18978 832755.91515 0.00000 819870.47682 832760.96062 0.00000 819867.06789 832757.91484 0.00000 819864.68632 832760.59024 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id64ac686c-f703-4859-b762-b9b0393ab88f">
<fme:FEATURE_ID>1000116911</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832891.4</fme:EASTING>
<fme:NORTHING>820222.64</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820228.70045 832903.31955 0.00000 820202.25518 832889.38580 0.00000 820207.99848 832878.48685 0.00000 820229.81169 832889.86745 0.00000 820232.13920 832885.36026 0.00000 820238.46435 832888.73629 0.00000 820244.01218 832891.69742 0.00000 820241.45661 832896.45944 0.00000 820237.09696 832900.76699 0.00000 820231.53878 832897.80505 0.00000 820228.70045 832903.31955 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id531d7491-f58c-4c60-a222-1c4356c65870">
<fme:FEATURE_ID>1000116828</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832407.83</fme:EASTING>
<fme:NORTHING>820551.58</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820553.89900 832417.29400 0.00000 820542.12771 832405.23406 0.00000 820548.35058 832399.12118 0.00000 820549.10700 832398.30600 0.00000 820561.08900 832410.43700 0.00000 820553.89900 832417.29400 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6abd5a54-d56d-4204-a85a-b3aef187cd10">
<fme:FEATURE_ID>1000117116</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832822.26</fme:EASTING>
<fme:NORTHING>820239.47</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820248.11430 832833.35377 0.00000 820233.46459 832837.45633 0.00000 820234.27234 832810.76903 0.00000 820235.65773 832805.32261 0.00000 820240.93857 832804.17295 0.00000 820248.11430 832833.35377 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd8459181-47c4-49da-a7de-902c2eb3940d">
<fme:FEATURE_ID>1000116922</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832838.9</fme:EASTING>
<fme:NORTHING>820206.2</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820217.48783 832821.03935 0.00000 820208.05352 832860.24358 0.00000 820201.20945 832858.58788 0.00000 820200.59258 832861.12535 0.00000 820194.68679 832859.57537 0.00000 820205.27898 832815.21968 0.00000 820211.86905 832816.97587 0.00000 820211.32860 832819.41206 0.00000 820217.48783 832821.03935 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd3671948-838a-4fc8-9314-fe0c360f12b2">
<fme:FEATURE_ID>1000116973</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831921.09</fme:EASTING>
<fme:NORTHING>820104.34</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820105.54721 831924.02729 0.00000 820101.16328 831921.38457 0.00000 820103.10353 831918.16703 0.00000 820107.54165 831920.78229 0.00000 820105.54721 831924.02729 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide295c8e1-7b8d-48d7-a36b-db129c69f358">
<fme:FEATURE_ID>1310090818</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833333.85</fme:EASTING>
<fme:NORTHING>820932.29</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820952.26390 833338.84878 0.00000 820939.72463 833341.20447 0.00000 820938.94932 833341.35012 0.00000 820937.42796 833342.40846 0.00000 820936.93186 833344.22747 0.00000 820939.19832 833356.49950 0.00000 820939.64385 833358.91188 0.00000 820938.88317 833369.49523 0.00000 820935.77431 833379.81400 0.00000 820927.84309 833390.87819 0.00000 820926.48080 833392.77861 0.00000 820923.20658 833392.77861 0.00000 820914.73989 833387.71844 0.00000 820913.08624 833385.70099 0.00000 820913.29471 833384.61290 0.00000 820920.39537 833371.61190 0.00000 820921.55293 833367.37856 0.00000 820922.77663 833353.58713 0.00000 820918.08026 833327.32718 0.00000 820916.36047 833326.76494 0.00000 820915.56672 833325.40894 0.00000 820916.75735 833320.41492 0.00000 820916.39354 833319.32352 0.00000 820914.60760 833317.96752 0.00000 820914.17765 833316.71075 0.00000 820915.07062 833312.41126 0.00000 820914.54146 833311.25371 0.00000 820913.05317 833310.06308 0.00000 820912.88781 833308.70709 0.00000 820913.78078 833304.40760 0.00000 820913.21854 833303.34926 0.00000 820911.63103 833302.09249 0.00000 820911.33338 833300.70343 0.00000 820912.32557 833296.99925 0.00000 820910.44867 833286.63620 0.00000 820912.33900 833283.61716 0.00000 820917.04228 833276.10555 0.00000 820924.51450 833282.27567 0.00000 820929.13340 833286.08968 0.00000 820931.75539 833288.25476 0.00000 820933.02539 833295.13394 0.00000 820928.70786 833295.93102 0.00000 820929.85779 833302.15982 0.00000 820930.89277 833307.76596 0.00000 820932.53350 833307.46306 0.00000 820934.88684 833320.21030 0.00000 820933.04210 833320.55087 0.00000 820934.25386 833327.11458 0.00000 820948.07228 833324.56349 0.00000 820947.64438 833322.24566 0.00000 820968.00076 833318.48756 0.00000 820973.69399 833323.08180 0.00000 820975.59418 833324.61519 0.00000 820972.58318 833328.75382 0.00000 820967.29286 833336.02537 0.00000 820961.84830 833337.04821 0.00000 820952.26390 833338.84878 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida90cab58-b083-48c8-863c-f21f64cba388">
<fme:FEATURE_ID>1210020526</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833716.32</fme:EASTING>
<fme:NORTHING>820617.86</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820609.62596 833720.23357 0.00000 820620.06729 833707.68436 0.00000 820626.09683 833712.69639 0.00000 820615.51858 833724.87856 0.00000 820609.62596 833720.23357 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2739e4ac-ec09-4a19-b8c1-3c35360e6f40">
<fme:FEATURE_ID>1000116797</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832485.13</fme:EASTING>
<fme:NORTHING>820884.76</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820873.98137 832490.05864 0.00000 820876.49343 832486.00363 0.00000 820886.22876 832473.79323 0.00000 820895.31041 832479.35801 0.00000 820884.55300 832496.59800 0.00000 820873.98137 832490.05864 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0a719294-1252-48f6-942d-7e98fd1a2b99">
<fme:FEATURE_ID>1000116978</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831791.48</fme:EASTING>
<fme:NORTHING>820087.24</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820084.35903 831795.49314 0.00000 820082.46267 831790.33742 0.00000 820084.39183 831789.62636 0.00000 820090.21541 831787.47990 0.00000 820091.96651 831792.60825 0.00000 820084.35903 831795.49314 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0b7321ca-8a9e-4e63-a01b-0cbb9292f8a3">
<fme:FEATURE_ID>1000117014</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832569.93</fme:EASTING>
<fme:NORTHING>819986.11</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819983.28684 832580.12972 0.00000 819976.31614 832573.73246 0.00000 819988.80829 832559.76940 0.00000 819995.95671 832566.14088 0.00000 819983.28684 832580.12972 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida1206a0e-e453-4bd7-a7aa-59dc5df146f4">
<fme:FEATURE_ID>1000117058</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832514.87</fme:EASTING>
<fme:NORTHING>819860.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819858.62644 832519.59977 0.00000 819855.77109 832513.95821 0.00000 819863.12763 832510.15367 0.00000 819866.00827 832515.74431 0.00000 819858.62644 832519.59977 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id348ef8cf-3742-4840-8d29-8e63c3efde4d">
<fme:FEATURE_ID>1000116965</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832031.92</fme:EASTING>
<fme:NORTHING>820121.22</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820121.20519 832036.85066 0.00000 820116.64416 832033.71969 0.00000 820121.26135 832026.98330 0.00000 820125.77146 832030.08910 0.00000 820121.20519 832036.85066 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id47fefd04-46f7-4b8a-877d-28e6becb2d77">
<fme:FEATURE_ID>1000116985</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831851.93</fme:EASTING>
<fme:NORTHING>820055.67</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820061.08519 831854.20707 0.00000 820058.12786 831854.25387 0.00000 820059.44311 831882.43408 0.00000 820050.44712 831882.55575 0.00000 820048.07215 831870.18133 0.00000 820048.10581 831854.39694 0.00000 820051.80039 831854.34289 0.00000 820049.46942 831836.81362 0.00000 820053.86755 831836.69422 0.00000 820053.58760 831822.02134 0.00000 820063.32542 831821.82196 0.00000 820063.46928 831836.67325 0.00000 820061.08519 831854.20707 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb0e93ebf-21e1-454b-8260-a1b4d4bb4a43">
<fme:FEATURE_ID>1000158007</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832750.76</fme:EASTING>
<fme:NORTHING>820653.21</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820657.38697 832756.02886 0.00000 820653.93290 832759.48310 0.00000 820644.41500 832749.98600 0.00000 820652.36571 832742.10801 0.00000 820662.05950 832751.35610 0.00000 820657.38697 832756.02886 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide0912954-b8d9-4afc-87a2-93c35f9c051c">
<fme:FEATURE_ID>1000116976</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832138.36</fme:EASTING>
<fme:NORTHING>820095.67</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820095.06170 832153.99430 0.00000 820089.49190 832124.00260 0.00000 820096.29498 832122.74707 0.00000 820101.83544 832152.74563 0.00000 820095.06170 832153.99430 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8fb03b0c-0b8a-4ae1-acbf-2cb6dc47ce8c">
<fme:FEATURE_ID>1000116913</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832761.49</fme:EASTING>
<fme:NORTHING>820224.67</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820219.48600 832782.89481 0.00000 820213.22523 832781.29247 0.00000 820223.43690 832739.74641 0.00000 820235.94952 832742.95933 0.00000 820226.56739 832781.70656 0.00000 820220.12816 832780.38286 0.00000 820219.48600 832782.89481 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9e184599-7cec-4438-89f4-b141ab4ee16e">
<fme:FEATURE_ID>1000116808</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832394.95</fme:EASTING>
<fme:NORTHING>820813.74</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820815.31600 832399.22300 0.00000 820810.54800 832394.22600 0.00000 820814.37600 832390.65600 0.00000 820815.67200 832392.05900 0.00000 820813.35800 832394.29800 0.00000 820816.84900 832397.78000 0.00000 820815.31600 832399.22300 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id985ef89b-8283-4b3f-90d5-b9fa2400e527">
<fme:FEATURE_ID>1000154631</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833851.33</fme:EASTING>
<fme:NORTHING>820791.25</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820886.99841 833750.00000 0.00000 820876.85919 833750.00000 0.00000 820884.02331 833743.17283 0.00000 820888.75248 833747.74284 0.00000 820886.99841 833750.00000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id55b054bd-dc75-44e0-a5a4-705d01c4126b">
<fme:FEATURE_ID>1000117101</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832067.91</fme:EASTING>
<fme:NORTHING>820798.54</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820801.88321 832086.58624 0.00000 820790.32177 832051.46918 0.00000 820795.72558 832049.93683 0.00000 820806.64454 832084.85468 0.00000 820801.88321 832086.58624 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd08a6b10-54b6-43cb-b305-e35de1677581">
<fme:FEATURE_ID>1000117008</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832180.34</fme:EASTING>
<fme:NORTHING>820007.04</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820005.91311 832187.74885 0.00000 820003.38896 832174.02367 0.00000 820003.44779 832173.15866 0.00000 820003.82944 832172.34248 0.00000 820004.44253 832171.74145 0.00000 820005.26613 832171.37609 0.00000 820006.16597 832171.33027 0.00000 820007.02243 832171.61008 0.00000 820007.72164 832172.17834 0.00000 820008.15598 832172.91892 0.00000 820010.70691 832186.72000 0.00000 820010.63446 832187.49235 0.00000 820010.30332 832188.24082 0.00000 820009.78050 832188.81392 0.00000 820009.10613 832189.19732 0.00000 820008.12996 832189.35389 0.00000 820007.20950 832189.13466 0.00000 820006.40871 832188.55487 0.00000 820005.91311 832187.74885 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id54374ecd-66b9-4b9c-95ef-1eda32fefc1e">
<fme:FEATURE_ID>1000116844</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833065.15</fme:EASTING>
<fme:NORTHING>820459.83</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820494.84445 833078.43513 0.00000 820487.86399 833087.39867 0.00000 820483.58562 833084.10810 0.00000 820480.32827 833088.50920 0.00000 820462.79781 833075.10355 0.00000 820466.28804 833070.74077 0.00000 820461.94711 833067.58435 0.00000 820455.90168 833075.58334 0.00000 820452.95951 833073.53175 0.00000 820426.04224 833052.98202 0.00000 820423.34082 833050.88711 0.00000 820432.54129 833038.91908 0.00000 820435.15996 833041.09074 0.00000 820461.98491 833061.60037 0.00000 820464.81880 833063.85562 0.00000 820465.44026 833062.96241 0.00000 820468.74706 833058.44565 0.00000 820473.03052 833061.85655 0.00000 820474.37902 833060.03211 0.00000 820492.06813 833073.43776 0.00000 820490.64031 833075.18287 0.00000 820494.84445 833078.43513 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd13c34b0-5c9d-4eb8-8e97-ec1250fcbf6d">
<fme:FEATURE_ID>1000116936</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832770.22</fme:EASTING>
<fme:NORTHING>820169.94</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820170.24034 832775.06715 0.00000 820164.61976 832771.21131 0.00000 820166.59490 832768.30776 0.00000 820167.99375 832769.29717 0.00000 820170.67797 832765.37479 0.00000 820174.87431 832768.24126 0.00000 820170.24034 832775.06715 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id684c4bf9-a27a-4d7b-9022-0d888e2a4b0c">
<fme:FEATURE_ID>1000116925</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832253.03</fme:EASTING>
<fme:NORTHING>820196.46</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820189.22816 832264.49418 0.00000 820185.99467 832242.81779 0.00000 820201.96354 832240.93038 0.00000 820203.47949 832251.91948 0.00000 820206.71298 832251.44044 0.00000 820208.23864 832261.95944 0.00000 820189.22816 832264.49418 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id035ec3fc-9b9a-433c-8020-c049eb6a440c">
<fme:FEATURE_ID>1000116837</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833026.79</fme:EASTING>
<fme:NORTHING>820493.35</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820492.73487 833034.44492 0.00000 820485.67947 833027.47846 0.00000 820493.94169 833019.11788 0.00000 820501.01537 833026.13182 0.00000 820492.73487 833034.44492 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idfcf96cc4-1397-4f2c-b14d-2a0994af566d">
<fme:FEATURE_ID>1000116964</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830958.8</fme:EASTING>
<fme:NORTHING>820115.2</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820113.01416 830973.67137 0.00000 820103.86070 830968.66654 0.00000 820107.69843 830961.64762 0.00000 820117.38632 830943.92918 0.00000 820126.53978 830948.93401 0.00000 820113.01416 830973.67137 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd993998a-ff2d-4efc-9169-39fece6c006a">
<fme:FEATURE_ID>1000117038</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831752.05</fme:EASTING>
<fme:NORTHING>819929.1</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819927.54612 831752.32840 0.00000 819927.35358 831750.60535 0.00000 819927.42710 831748.69164 0.00000 819929.51531 831748.35230 0.00000 819930.26443 831750.14513 0.00000 819930.66379 831751.75735 0.00000 819930.84251 831753.56198 0.00000 819930.76824 831755.37390 0.00000 819928.69308 831755.80460 0.00000 819928.03072 831754.21900 0.00000 819927.54612 831752.32840 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3e7996f0-e032-4d21-9986-2dc9894cd8cf">
<fme:FEATURE_ID>1000116894</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832617.84</fme:EASTING>
<fme:NORTHING>820262.78</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820254.85129 832615.51117 0.00000 820257.07841 832611.51284 0.00000 820262.16403 832614.42860 0.00000 820264.46730 832610.40468 0.00000 820271.15057 832614.26947 0.00000 820264.37202 832626.27923 0.00000 820255.44680 832621.18307 0.00000 820257.72472 832617.18465 0.00000 820254.85129 832615.51117 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id17b5c1ce-7fde-412c-8405-4df8a2cc30a0">
<fme:FEATURE_ID>1000116972</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832136.3</fme:EASTING>
<fme:NORTHING>820106.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820106.75259 832151.83919 0.00000 820101.21194 832121.83963 0.00000 820107.11230 832120.75070 0.00000 820107.19098 832121.17672 0.00000 820112.65306 832150.75150 0.00000 820106.75259 832151.83919 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide70dccff-9c9f-4967-a45c-d9fa77504fe3">
<fme:FEATURE_ID>1000117016</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832050.64</fme:EASTING>
<fme:NORTHING>819982.92</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819981.39400 832056.25340 0.00000 819979.36362 832045.00257 0.00000 819979.58772 832044.05934 0.00000 819980.17980 832043.23741 0.00000 819981.04506 832042.71068 0.00000 819982.04709 832042.56217 0.00000 819982.78305 832042.71168 0.00000 819983.44360 832043.06899 0.00000 819983.97150 832043.60313 0.00000 819984.33528 832044.30981 0.00000 819986.47287 832056.34188 0.00000 819986.23756 832057.28209 0.00000 819985.66738 832058.06584 0.00000 819984.84526 832058.57914 0.00000 819983.89076 832058.74735 0.00000 819982.94270 832058.54599 0.00000 819982.13895 832058.00437 0.00000 819981.59642 832057.20123 0.00000 819981.39400 832056.25340 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id78ad8e43-5ab4-477e-8752-382d82aa7d58">
<fme:FEATURE_ID>1000116893</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831793.34</fme:EASTING>
<fme:NORTHING>820267.87</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820264.89613 831801.02785 0.00000 820259.33925 831792.84026 0.00000 820269.42554 831786.05772 0.00000 820271.91987 831789.81860 0.00000 820273.95870 831788.40072 0.00000 820276.91328 831793.01275 0.00000 820274.92005 831794.34218 0.00000 820264.89613 831801.02785 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id80447820-54bc-44d3-ab47-f8d444b79feb">
<fme:FEATURE_ID>1000116835</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832419.86</fme:EASTING>
<fme:NORTHING>820500.83</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820498.53500 832425.10100 0.00000 820495.67400 832422.17200 0.00000 820503.16000 832414.59900 0.00000 820505.96100 832417.57300 0.00000 820498.53500 832425.10100 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5bb7fae3-6bc8-493d-832a-d28b6bc14a2d">
<fme:FEATURE_ID>1210076254</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832717.03</fme:EASTING>
<fme:NORTHING>820692.67</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820691.52382 832720.07232 0.00000 820689.64928 832715.87336 0.00000 820693.77327 832713.99882 0.00000 820695.72279 832718.12281 0.00000 820691.52382 832720.07232 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2e2d35e0-79ff-43ec-b9db-a4cf86ec846a">
<fme:FEATURE_ID>1000116948</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831920.06</fme:EASTING>
<fme:NORTHING>820150.33</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820150.17201 831923.41939 0.00000 820147.35527 831921.29204 0.00000 820150.45327 831916.77137 0.00000 820153.31354 831918.67547 0.00000 820150.17201 831923.41939 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id367c90c0-5e44-4acb-949e-dfad78f4aa5b">
<fme:FEATURE_ID>1000116897</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833011.09</fme:EASTING>
<fme:NORTHING>820247.9</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820252.61163 833027.39128 0.00000 820232.98858 833006.80506 0.00000 820237.85265 833002.18056 0.00000 820235.10301 832999.22054 0.00000 820239.38308 832995.21254 0.00000 820241.84933 832997.93271 0.00000 820244.15015 832995.93141 0.00000 820247.23504 832999.36841 0.00000 820263.83168 833016.80239 0.00000 820252.61163 833027.39128 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3576db96-97a5-46ba-be64-76be56da915b">
<fme:FEATURE_ID>1000116848</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832551.59</fme:EASTING>
<fme:NORTHING>820412.12</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820421.91790 832574.25615 0.00000 820389.64009 832541.31704 0.00000 820402.08159 832528.97204 0.00000 820434.59043 832561.55735 0.00000 820421.91790 832574.25615 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8f2c5f57-a3ac-4265-a44c-62d9519cac80">
<fme:FEATURE_ID>1000116939</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831934.65</fme:EASTING>
<fme:NORTHING>820162.24</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820166.42755 831939.81394 0.00000 820155.81474 831932.73639 0.00000 820158.12517 831929.52992 0.00000 820168.59679 831936.52272 0.00000 820166.42755 831939.81394 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6d50f3d9-f822-443f-b756-7c72ca7c7bdb">
<fme:FEATURE_ID>1000117117</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831086.18</fme:EASTING>
<fme:NORTHING>820226.4</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820224.67100 831097.91800 0.00000 820218.16700 831077.63200 0.00000 820228.08600 831074.44300 0.00000 820234.67800 831094.66400 0.00000 820224.67100 831097.91800 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idad1bae44-fd23-46e9-adb4-50de1470c687">
<fme:FEATURE_ID>1000116924</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832914.63</fme:EASTING>
<fme:NORTHING>820204.11</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820194.62116 832920.02923 0.00000 820193.16465 832915.58014 0.00000 820213.72345 832909.25742 0.00000 820215.10356 832913.60489 0.00000 820194.62116 832920.02923 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id727025e9-5156-412b-b89c-ba81973ad761">
<fme:FEATURE_ID>1210020521</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832003.76</fme:EASTING>
<fme:NORTHING>820528.61</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820530.64707 832015.55816 0.00000 820518.06244 831998.38317 0.00000 820526.62593 831991.96098 0.00000 820539.14191 832009.21114 0.00000 820530.64707 832015.55816 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id593ff8ae-2355-4301-8574-ef2434f0abd4">
<fme:FEATURE_ID>1000116997</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832593.41</fme:EASTING>
<fme:NORTHING>820018.11</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820016.43584 832597.61977 0.00000 820013.71213 832594.31797 0.00000 820019.74605 832589.21921 0.00000 820022.52050 832592.49548 0.00000 820016.43584 832597.61977 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd83c3659-a7c4-4f73-a5f2-14760fdc18c8">
<fme:FEATURE_ID>1000116863</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831979.28</fme:EASTING>
<fme:NORTHING>820341.35</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820354.92876 831976.25704 0.00000 820353.90841 831974.83092 0.00000 820350.19539 831977.54466 0.00000 820351.67865 831979.59560 0.00000 820347.50290 831982.53748 0.00000 820346.06939 831980.56750 0.00000 820341.26116 831984.03703 0.00000 820342.66210 831985.95883 0.00000 820340.72234 831987.34180 0.00000 820342.95195 831990.40099 0.00000 820341.18360 831991.71840 0.00000 820337.53964 831986.79442 0.00000 820332.75951 831990.28808 0.00000 820336.40118 831995.28126 0.00000 820334.59860 831996.62417 0.00000 820325.32765 831983.77391 0.00000 820351.22024 831964.82523 0.00000 820357.99637 831973.98791 0.00000 820354.92876 831976.25704 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idaa1457ad-b2b8-4fe1-a54c-a7902d7a2485">
<fme:FEATURE_ID>1000116791</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832717.58</fme:EASTING>
<fme:NORTHING>820923.23</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820921.02876 832724.80283 0.00000 820917.71980 832722.74899 0.00000 820925.42844 832710.34991 0.00000 820928.73740 832712.40375 0.00000 820921.02876 832724.80283 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3c04d978-0993-4186-93bc-bfa28874c311">
<fme:FEATURE_ID>1000117007</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832589.27</fme:EASTING>
<fme:NORTHING>820005.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820005.81738 832594.50115 0.00000 820000.69758 832589.89333 0.00000 820005.99143 832583.99063 0.00000 820011.04466 832588.71208 0.00000 820005.81738 832594.50115 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idaa981cd1-410d-4d73-8f5a-c02e779077b8">
<fme:FEATURE_ID>1000117110</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832934.22</fme:EASTING>
<fme:NORTHING>820323.25</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820351.07372 832892.97650 0.00000 820365.35000 832907.25849 0.00000 820296.87000 832975.57000 0.00000 820291.84000 832970.54000 0.00000 820286.19000 832948.63000 0.00000 820296.65000 832938.20000 0.00000 820301.23959 832942.80279 0.00000 820351.07372 832892.97650 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb199ec7b-5b1d-4c0f-ad9a-9eb82073395a">
<fme:FEATURE_ID>1000154486</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832696.26</fme:EASTING>
<fme:NORTHING>820977.79</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820991.74023 832738.94922 0.00000 820936.31055 832704.43945 0.00000 820971.28906 832647.52930 0.00000 821000.00000 832679.78906 0.00000 821000.00000 832726.18945 0.00000 820991.74023 832738.94922 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id85495652-bc08-4ae5-82f7-5d8172351ec6">
<fme:FEATURE_ID>1210046817</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832387.69</fme:EASTING>
<fme:NORTHING>820559.18</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820561.39450 832392.24650 0.00000 820554.61861 832385.35208 0.00000 820556.87333 832383.14860 0.00000 820563.73003 832389.90779 0.00000 820561.39450 832392.24650 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf913804e-164a-4f5f-b73d-45ea709727b2">
<fme:FEATURE_ID>1310097903</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833405.44</fme:EASTING>
<fme:NORTHING>820752.39</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820765.10878 833423.90612 0.00000 820761.47076 833420.66497 0.00000 820758.73431 833424.00150 0.00000 820731.26270 833401.00954 0.00000 820738.05508 833393.01596 0.00000 820734.61549 833390.10554 0.00000 820740.53931 833382.70616 0.00000 820767.96638 833405.60696 0.00000 820765.10878 833408.82484 0.00000 820776.22131 833418.01913 0.00000 820770.79734 833424.43529 0.00000 820767.29160 833421.32643 0.00000 820765.10878 833423.90612 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8a1ef91b-63cc-4489-8d4e-40ad4caf594b">
<fme:FEATURE_ID>1000117059</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832702.77</fme:EASTING>
<fme:NORTHING>819849.3</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819844.50650 832705.07906 0.00000 819842.74801 832703.42382 0.00000 819844.19729 832701.82945 0.00000 819846.91104 832704.19416 0.00000 819853.32491 832697.30096 0.00000 819855.47048 832699.10415 0.00000 819847.36825 832707.77277 0.00000 819844.50650 832705.07906 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb94f8a7c-acc2-485d-b8a4-299d209194be">
<fme:FEATURE_ID>1000117065</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832826.37</fme:EASTING>
<fme:NORTHING>819816.23</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819824.44935 832839.90611 0.00000 819801.90956 832819.62768 0.00000 819808.01530 832812.79897 0.00000 819830.58069 832833.17908 0.00000 819824.44935 832839.90611 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idaf977907-bd25-46c2-b4ea-2b6b0dccea65">
<fme:FEATURE_ID>1000158077</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831629.74</fme:EASTING>
<fme:NORTHING>819926.73</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819931.25860 831634.90600 0.00000 819919.91860 831628.58740 0.00000 819922.21020 831624.56830 0.00000 819933.55030 831630.88690 0.00000 819931.25860 831634.90600 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb049b970-b7f3-4a0f-b630-018ffe6abcf9">
<fme:FEATURE_ID>1000116886</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833074.64</fme:EASTING>
<fme:NORTHING>820274.45</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820278.85343 833076.43358 0.00000 820274.28591 833080.55732 0.00000 820276.24354 833082.74238 0.00000 820270.63564 833087.80796 0.00000 820266.38989 833083.08214 0.00000 820262.96422 833086.13680 0.00000 820254.49811 833076.68515 0.00000 820275.35664 833058.05174 0.00000 820295.64465 833080.56283 0.00000 820288.36196 833087.10485 0.00000 820278.85343 833076.43358 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2968f059-065a-43b6-a67e-757f2fc02b3f">
<fme:FEATURE_ID>1000116943</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831977.84</fme:EASTING>
<fme:NORTHING>820155.69</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820154.18800 831984.86100 0.00000 820148.51500 831977.57500 0.00000 820157.20100 831970.81200 0.00000 820162.87400 831978.09800 0.00000 820154.18800 831984.86100 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idfab03bac-2f5f-4cfa-a1f8-2ea3ac10b2f9">
<fme:FEATURE_ID>1000116818</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833612.44</fme:EASTING>
<fme:NORTHING>820672.33</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820662.92579 833635.20613 0.00000 820653.10885 833627.03799 0.00000 820652.85689 833624.30984 0.00000 820680.24122 833591.25842 0.00000 820683.12863 833590.85593 0.00000 820692.98073 833599.14999 0.00000 820662.92579 833635.20613 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0fc8be74-dd8e-434f-a9c4-acc6b26f8d76">
<fme:FEATURE_ID>1000117095</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832717.37</fme:EASTING>
<fme:NORTHING>820666.2</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820662.40543 832727.53667 0.00000 820656.07894 832721.34062 0.00000 820670.16679 832707.12233 0.00000 820676.23240 832713.44882 0.00000 820662.40543 832727.53667 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id88bd40e7-93cc-4bdb-bca1-b16b03859122">
<fme:FEATURE_ID>1000154487</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832753.51</fme:EASTING>
<fme:NORTHING>821013.96</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240617</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820998.32134 832788.43766 0.00000 820997.13000 832790.37600 0.00000 820993.99736 832788.41678 0.00000 820978.90686 832778.97889 0.00000 820976.20537 832777.29064 0.00000 821000.00000 832739.19162 0.00000 821000.00000 832785.70644 0.00000 820998.32134 832788.43766 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc63e9603-0cb8-4674-bb13-d862db1d0762">
<fme:FEATURE_ID>1000116992</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831815.72</fme:EASTING>
<fme:NORTHING>820033.73</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820031.77547 831828.77071 0.00000 820029.25917 831801.58421 0.00000 820031.82533 831801.48423 0.00000 820032.07152 831804.16639 0.00000 820035.95624 831803.84212 0.00000 820038.20200 831828.19361 0.00000 820031.77547 831828.77071 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="iddfe9ca95-8c42-4a94-b97c-ae43d15d662b">
<fme:FEATURE_ID>1000116814</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833686.55</fme:EASTING>
<fme:NORTHING>820683.04</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820721.14546 833713.28553 0.00000 820714.60937 833721.12109 0.00000 820705.59961 833713.62109 0.00000 820700.34961 833720.01953 0.00000 820682.01991 833704.74175 0.00000 820687.14062 833698.21875 0.00000 820680.24501 833692.51872 0.00000 820671.03906 833684.78125 0.00000 820665.87342 833691.28367 0.00000 820647.19922 833675.71875 0.00000 820652.43627 833669.37820 0.00000 820650.42969 833667.96094 0.00000 820643.43000 833661.82000 0.00000 820650.19000 833653.72000 0.00000 820654.52540 833657.46637 0.00000 820657.12000 833654.45000 0.00000 820661.55589 833658.33699 0.00000 820664.66914 833654.56775 0.00000 820717.79000 833699.14000 0.00000 820714.96000 833702.58000 0.00000 820719.53000 833706.42000 0.00000 820717.11000 833709.85000 0.00000 820721.14546 833713.28553 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id595b5063-9a2a-4303-ae41-065ea348bb21">
<fme:FEATURE_ID>1000116870</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833177.85</fme:EASTING>
<fme:NORTHING>820323.58</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820327.18658 833179.12733 0.00000 820324.62484 833182.63903 0.00000 820329.21638 833186.05468 0.00000 820326.76491 833189.40135 0.00000 820312.68420 833178.93742 0.00000 820321.32249 833167.21201 0.00000 820335.36456 833177.68366 0.00000 820331.72030 833182.60341 0.00000 820327.18658 833179.12733 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id11a5f114-0460-4c14-9721-1293e4bc49d3">
<fme:FEATURE_ID>1000116823</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832577.94</fme:EASTING>
<fme:NORTHING>820636.3</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820635.90113 832581.22690 0.00000 820631.91600 832577.17600 0.00000 820633.10400 832575.83100 0.00000 820635.39000 832578.13600 0.00000 820638.64600 832574.86700 0.00000 820640.38002 832576.62696 0.00000 820635.90113 832581.22690 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide0095913-c38f-4eaf-8eb0-2401f62d8233">
<fme:FEATURE_ID>1000116951</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831693.91</fme:EASTING>
<fme:NORTHING>820140.96</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820141.86336 831700.21977 0.00000 820134.97650 831691.65499 0.00000 820140.02195 831687.60726 0.00000 820146.96260 831696.13947 0.00000 820141.86336 831700.21977 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id352be682-b4d3-499f-af10-3a7037d61e16">
<fme:FEATURE_ID>1000117066</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832819.17</fme:EASTING>
<fme:NORTHING>819825.06</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819825.53366 832823.80338 0.00000 819820.44559 832819.18417 0.00000 819824.57516 832814.54680 0.00000 819829.66313 832819.11513 0.00000 819825.53366 832823.80338 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idaa96796e-6441-4f01-939e-f3ef3df30bf9">
<fme:FEATURE_ID>1000117114</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831185.98</fme:EASTING>
<fme:NORTHING>820271.1</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820268.13687 831198.90645 0.00000 820260.60804 831177.27401 0.00000 820274.41617 831173.12013 0.00000 820281.33581 831194.93209 0.00000 820268.13687 831198.90645 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7ea58b41-3b06-42f7-9fdc-e02a10bfeef3">
<fme:FEATURE_ID>1000116981</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831904.58</fme:EASTING>
<fme:NORTHING>820072.96</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820071.84090 831911.25054 0.00000 820066.61031 831902.28593 0.00000 820070.50412 831899.98310 0.00000 820073.98165 831897.92648 0.00000 820079.35743 831906.82462 0.00000 820071.84090 831911.25054 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ideeb99897-f5d7-4715-b659-17c2d7fdb779">
<fme:FEATURE_ID>1000117115</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831073.39</fme:EASTING>
<fme:NORTHING>820251.61</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820241.68417 831089.68582 0.00000 820234.48991 831065.42884 0.00000 820261.53682 831057.10124 0.00000 820268.73107 831081.35816 0.00000 820241.68417 831089.68582 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id17bed183-fa82-4824-92dc-2e93221f253f">
<fme:FEATURE_ID>1000116903</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831249.43</fme:EASTING>
<fme:NORTHING>820237.32</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820253.87865 831269.64559 0.00000 820241.17578 831273.49458 0.00000 820241.19897 831274.75856 0.00000 820240.70418 831275.84064 0.00000 820239.56226 831276.80728 0.00000 820238.48987 831277.34083 0.00000 820237.03555 831277.70070 0.00000 820235.54228 831277.59152 0.00000 820234.13765 831277.09647 0.00000 820233.60761 831276.38191 0.00000 820233.51127 831275.79289 0.00000 820233.74031 831274.92406 0.00000 820234.21954 831274.16672 0.00000 820234.93835 831273.58444 0.00000 820222.74203 831233.36167 0.00000 820221.17433 831231.72022 0.00000 820220.28399 831229.82756 0.00000 820220.05307 831228.65151 0.00000 820220.03917 831227.45333 0.00000 820220.38737 831226.63430 0.00000 820221.08546 831226.07873 0.00000 820221.96194 831225.91082 0.00000 820222.52139 831226.10540 0.00000 820223.20673 831226.67873 0.00000 820223.88712 831227.66584 0.00000 820239.44641 831222.89736 0.00000 820253.87865 831269.64559 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id54c14011-cf6d-471c-9db9-29f3632156eb">
<fme:FEATURE_ID>1000117035</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832418.91</fme:EASTING>
<fme:NORTHING>819933.89</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819934.19628 832423.60246 0.00000 819929.21030 832419.21107 0.00000 819933.61927 832414.26797 0.00000 819938.55421 832418.53227 0.00000 819934.19628 832423.60246 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id88b040e7-87cf-401c-a146-fa80e81bdc8a">
<fme:FEATURE_ID>1210013998</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>US</fme:DATALEVEL>
<fme:EASTING>831371.23</fme:EASTING>
<fme:NORTHING>820221.19</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820230.17169 831378.60211 0.00000 820222.50110 831383.07910 0.00000 820211.87909 831365.57507 0.00000 820221.82810 831359.78010 0.00000 820225.94513 831366.14612 0.00000 820223.47325 831367.67774 0.00000 820230.17169 831378.60211 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8413dfe5-09f2-4491-989d-8f11755da2dd">
<fme:FEATURE_ID>1310097909</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832826.62</fme:EASTING>
<fme:NORTHING>820187.09</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820189.33225 832836.18238 0.00000 820184.36401 832834.96673 0.00000 820185.21915 832830.40315 0.00000 820185.66941 832827.96937 0.00000 820178.39335 832826.24957 0.00000 820180.37773 832818.44435 0.00000 820194.40068 832822.08238 0.00000 820193.93766 832824.59592 0.00000 820191.22413 832836.62179 0.00000 820189.33225 832836.18238 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb51dc8d6-5674-4b03-9940-45bcbf8665e4">
<fme:FEATURE_ID>1000117084</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832683.13</fme:EASTING>
<fme:NORTHING>819725.73</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819722.51397 832685.59168 0.00000 819722.46832 832680.66144 0.00000 819728.95066 832680.66144 0.00000 819728.99413 832685.59154 0.00000 819722.51397 832685.59168 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf38d638b-3066-4be7-89d8-7a619cd77be8">
<fme:FEATURE_ID>1000116880</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832511.42</fme:EASTING>
<fme:NORTHING>820299.48</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820295.67400 832524.68500 0.00000 820286.30800 832515.72700 0.00000 820303.22600 832498.08000 0.00000 820312.63500 832507.27300 0.00000 820295.67400 832524.68500 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id05c860ce-4bf2-4b8e-afd7-c528fc5cd178">
<fme:FEATURE_ID>1000117111</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831449.09</fme:EASTING>
<fme:NORTHING>820351.49</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820352.36744 831437.58455 0.00000 820358.54772 831458.21415 0.00000 820350.60994 831460.59217 0.00000 820344.42966 831439.96258 0.00000 820352.36744 831437.58455 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idcc3a11e2-fd80-4563-98f1-d8bcc0ec503f">
<fme:FEATURE_ID>1000116999</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831138.13</fme:EASTING>
<fme:NORTHING>820016.89</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820016.35114 831141.52395 0.00000 820014.32394 831140.40885 0.00000 820017.43885 831134.74605 0.00000 820019.46605 831135.86114 0.00000 820016.35114 831141.52395 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8ac2124c-f91a-4683-952a-7f8a3bdda13e">
<fme:FEATURE_ID>1000116812</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832276</fme:EASTING>
<fme:NORTHING>820754.9</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820729.01796 832270.72296 0.00000 820728.72814 832268.54933 0.00000 820729.40438 832266.42400 0.00000 820730.85347 832264.78171 0.00000 820733.26861 832263.91226 0.00000 820760.65636 832263.86395 0.00000 820760.65636 832274.10416 0.00000 820765.77647 832279.12766 0.00000 820776.28365 832279.41645 0.00000 820776.22672 832292.96553 0.00000 820766.38600 832293.21800 0.00000 820747.46967 832274.10416 0.00000 820733.79995 832274.10416 0.00000 820731.91613 832273.71774 0.00000 820730.12892 832272.46187 0.00000 820729.01796 832270.72296 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6a68ca9f-cdd5-45da-ae07-09794cdb4a79">
<fme:FEATURE_ID>1000117076</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832826.91</fme:EASTING>
<fme:NORTHING>819762.73</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819759.62689 832829.85338 0.00000 819757.18804 832827.44687 0.00000 819760.22078 832824.16140 0.00000 819762.90305 832821.25560 0.00000 819764.67576 832822.85634 0.00000 819768.31379 832826.09749 0.00000 819762.51359 832832.70180 0.00000 819759.62689 832829.85338 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id91372c68-0859-48b2-9e13-404842e410f3">
<fme:FEATURE_ID>1000117017</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832384.54</fme:EASTING>
<fme:NORTHING>819981.11</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819980.01704 832388.85436 0.00000 819978.60296 832380.81644 0.00000 819982.16760 832380.25162 0.00000 819983.64350 832388.17550 0.00000 819980.01704 832388.85436 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbddee711-e19b-410c-9c4b-3dd356dfb80f">
<fme:FEATURE_ID>1000116908</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832901.16</fme:EASTING>
<fme:NORTHING>820244.92</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820243.55601 832904.90126 0.00000 820241.26640 832902.94681 0.00000 820241.31109 832899.89401 0.00000 820243.59161 832897.29486 0.00000 820246.28382 832897.36604 0.00000 820248.54855 832899.57493 0.00000 820248.52945 832902.72944 0.00000 820247.42449 832903.78019 0.00000 820246.19738 832904.94710 0.00000 820243.55601 832904.90126 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id283bd26e-fe8d-4bf0-91b3-4a0bf30230fe">
<fme:FEATURE_ID>1210046809</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832514.08</fme:EASTING>
<fme:NORTHING>820839.92</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820830.19098 832543.70271 0.00000 820817.31296 832535.41005 0.00000 820822.10904 832527.79946 0.00000 820840.82737 832498.09650 0.00000 820849.31645 832484.62571 0.00000 820862.58116 832492.97111 0.00000 820853.96010 832506.47398 0.00000 820835.02691 832536.12837 0.00000 820830.19098 832543.70271 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0e18b7e5-c895-4184-bd57-899f9996167b">
<fme:FEATURE_ID>1000116915</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831802.85</fme:EASTING>
<fme:NORTHING>820223.65</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820223.30725 831806.92824 0.00000 820219.65636 831802.14814 0.00000 820224.00527 831798.77950 0.00000 820227.65302 831803.53590 0.00000 820223.30725 831806.92824 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idcfb61fe9-2e95-41ac-9bd5-bbd4b2789d17">
<fme:FEATURE_ID>1000117088</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832648.11</fme:EASTING>
<fme:NORTHING>819676.09</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819670.24548 832657.60223 0.00000 819665.51546 832651.39495 0.00000 819681.88654 832638.63646 0.00000 819686.69381 832644.82869 0.00000 819670.24548 832657.60223 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id118b15d8-3a7e-4bc0-84bc-47acd0f02398">
<fme:FEATURE_ID>1000116834</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833032.81</fme:EASTING>
<fme:NORTHING>820504</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820504.37153 833037.52968 0.00000 820499.27577 833032.43963 0.00000 820503.63555 833028.01557 0.00000 820508.74035 833033.31596 0.00000 820504.37153 833037.52968 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idba4cb90d-067c-4c09-b88a-de3644ffbb63">
<fme:FEATURE_ID>1000116977</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832039.55</fme:EASTING>
<fme:NORTHING>820085.4</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820098.28710 832039.68330 0.00000 820085.94830 832054.43610 0.00000 820086.83474 832059.17589 0.00000 820086.78507 832059.77404 0.00000 820086.52544 832060.31518 0.00000 820085.75652 832060.89504 0.00000 820084.82297 832060.95550 0.00000 820083.98568 832060.47968 0.00000 820083.55986 832059.64670 0.00000 820083.24720 832057.98690 0.00000 820077.50980 832059.06760 0.00000 820072.87840 832034.29670 0.00000 820074.16270 832029.19300 0.00000 820077.87610 832027.05770 0.00000 820097.10530 832023.50280 0.00000 820099.73870 832037.65380 0.00000 820098.28710 832039.68330 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0901d768-4f1f-4e70-ae85-091a08662880">
<fme:FEATURE_ID>1000117048</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832457.21</fme:EASTING>
<fme:NORTHING>819891.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819892.42039 832461.55687 0.00000 819887.86282 832455.48580 0.00000 819891.26055 832452.85940 0.00000 819895.91965 832458.90484 0.00000 819895.05884 832459.55723 0.00000 819892.42039 832461.55687 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5851ac1a-af8f-4ffc-97a2-d5af84b47acd">
<fme:FEATURE_ID>1000116906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832867.72</fme:EASTING>
<fme:NORTHING>820246.45</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820244.37462 832870.44181 0.00000 820243.39484 832866.27962 0.00000 820248.48880 832865.02047 0.00000 820249.53756 832869.12030 0.00000 820244.37462 832870.44181 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id07c2d7a4-657b-4d2c-8799-f2d72dd74410">
<fme:FEATURE_ID>1000116819</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831880.98</fme:EASTING>
<fme:NORTHING>820670.81</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820680.12442 831880.70453 0.00000 820671.30601 831883.52142 0.00000 820672.87852 831888.44424 0.00000 820666.44504 831890.49930 0.00000 820662.57636 831877.93090 0.00000 820677.69569 831873.10129 0.00000 820680.12442 831880.70453 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idef34c534-f030-4b41-8844-05d3ee69c9d3">
<fme:FEATURE_ID>1000116796</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832781.17</fme:EASTING>
<fme:NORTHING>820890.15</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820885.91340 832790.78130 0.00000 820883.36897 832789.19199 0.00000 820894.38811 832771.55069 0.00000 820896.93254 832773.13999 0.00000 820885.91340 832790.78130 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbda88f6d-c253-4e69-a43a-0b5ca4be848b">
<fme:FEATURE_ID>1000117079</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832577.25</fme:EASTING>
<fme:NORTHING>819744.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819741.70384 832583.24796 0.00000 819738.28352 832576.55522 0.00000 819747.80854 832571.15771 0.00000 819751.54085 832578.08666 0.00000 819741.70384 832583.24796 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6ecb0c6a-49e1-4935-bc64-8adb9c633b58">
<fme:FEATURE_ID>1000116996</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832559.84</fme:EASTING>
<fme:NORTHING>820014.87</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820022.47404 832568.83867 0.00000 820003.12993 832559.28481 0.00000 820007.30346 832550.83176 0.00000 820026.62227 832560.43654 0.00000 820022.47404 832568.83867 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id95acb562-8c66-4c88-bfea-c91899337e2f">
<fme:FEATURE_ID>1000116971</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832457.61</fme:EASTING>
<fme:NORTHING>820111.45</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820111.52177 832460.68139 0.00000 820108.43802 832458.59658 0.00000 820111.31343 832454.48672 0.00000 820114.49194 832456.73795 0.00000 820111.52177 832460.68139 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id02e48581-acf5-4bf1-bb52-81a6905ac41f">
<fme:FEATURE_ID>1000116895</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831750.29</fme:EASTING>
<fme:NORTHING>820261.46</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820261.96183 831753.68151 0.00000 820258.78063 831752.44483 0.00000 820260.93646 831746.89649 0.00000 820264.14537 831748.16089 0.00000 820261.96183 831753.68151 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd4bb33aa-2b5e-4d2a-a177-f4a8821040b6">
<fme:FEATURE_ID>1000116871</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831813.13</fme:EASTING>
<fme:NORTHING>820316.41</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820306.33063 831828.20929 0.00000 820298.67250 831816.72550 0.00000 820326.57619 831798.08855 0.00000 820334.16326 831809.44038 0.00000 820306.33063 831828.20929 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id965b6718-48fa-43bc-a193-3d80f3261c80">
<fme:FEATURE_ID>1000116974</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832237.17</fme:EASTING>
<fme:NORTHING>820078.98</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820059.22240 832261.61470 0.00000 820051.78550 832221.44050 0.00000 820098.70220 832212.73710 0.00000 820106.20830 832252.88350 0.00000 820059.22240 832261.61470 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1a08343a-4f8d-46c9-bfcb-a36395d969b3">
<fme:FEATURE_ID>1000117039</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832483.1</fme:EASTING>
<fme:NORTHING>819924.81</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819927.18569 832487.41285 0.00000 819920.80895 832486.05112 0.00000 819922.41992 832478.77298 0.00000 819928.82215 832480.18554 0.00000 819927.18569 832487.41285 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id96a74775-bdba-4ca7-a4c6-b4145299623f">
<fme:FEATURE_ID>1000117034</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832493.13</fme:EASTING>
<fme:NORTHING>819935.83</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819935.68926 832498.48775 0.00000 819930.57226 832492.03616 0.00000 819936.02370 832487.75249 0.00000 819941.06472 832494.30596 0.00000 819935.68926 832498.48775 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id127bd8c9-3ba5-4520-902a-7b193f531897">
<fme:FEATURE_ID>1000116879</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832670.72</fme:EASTING>
<fme:NORTHING>820300.12</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820293.69781 832669.75258 0.00000 820307.15362 832656.10907 0.00000 820314.63481 832663.63714 0.00000 820293.02758 832685.26463 0.00000 820285.54800 832678.01608 0.00000 820293.69781 832669.75258 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id28d39eef-316f-49b4-a33e-4326f616a318">
<fme:FEATURE_ID>1210046810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832517.09</fme:EASTING>
<fme:NORTHING>820838</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820835.02691 832536.12837 0.00000 820822.10904 832527.79946 0.00000 820840.82737 832498.09650 0.00000 820853.96010 832506.47398 0.00000 820835.02691 832536.12837 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5ccc8fa4-bbab-47aa-85a7-6a9d584b44a0">
<fme:FEATURE_ID>1000116827</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832563.75</fme:EASTING>
<fme:NORTHING>820553.15</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820590.42046 832551.00850 0.00000 820576.84148 832563.50653 0.00000 820589.24021 832575.93004 0.00000 820559.65257 832605.35375 0.00000 820510.62201 832555.83277 0.00000 820539.85784 832526.44914 0.00000 820560.54684 832547.17932 0.00000 820573.62134 832534.50171 0.00000 820590.42046 832551.00850 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4bb0e1b2-cb80-4a8f-aa83-91d51e225161">
<fme:FEATURE_ID>1000116928</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831764.52</fme:EASTING>
<fme:NORTHING>820192.49</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820194.72940 831769.22351 0.00000 820189.35494 831768.66601 0.00000 820189.79129 831764.20794 0.00000 820190.22162 831759.81123 0.00000 820195.65543 831760.39754 0.00000 820194.72940 831769.22351 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1b66d46e-a677-4a43-b48a-79b9d966a81b">
<fme:FEATURE_ID>1210046807</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832601.58</fme:EASTING>
<fme:NORTHING>820673.46</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820697.67343 832612.48112 0.00000 820689.27155 832620.98935 0.00000 820691.93037 832623.64818 0.00000 820687.46355 832628.11500 0.00000 820646.94310 832587.48819 0.00000 820651.51627 832583.12772 0.00000 820654.17509 832585.68019 0.00000 820662.47062 832577.27831 0.00000 820697.67343 832612.48112 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida0b7c013-2b47-472f-b6e9-8688704be1be">
<fme:FEATURE_ID>1000116919</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831727.97</fme:EASTING>
<fme:NORTHING>820216.18</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820215.14760 831731.01592 0.00000 820213.08260 831727.35387 0.00000 820217.21028 831724.91846 0.00000 820219.26824 831728.59151 0.00000 820215.14760 831731.01592 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf3b4aea6-241c-4100-babc-97fd0bfa7f18">
<fme:FEATURE_ID>1000116918</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832937.31</fme:EASTING>
<fme:NORTHING>820204.2</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820218.18023 832930.64214 0.00000 820208.13432 832933.76608 0.00000 820212.96444 832948.84233 0.00000 820217.00003 832947.58811 0.00000 820218.20145 832951.47802 0.00000 820199.80026 832957.23696 0.00000 820192.33806 832934.05061 0.00000 820188.25188 832935.40668 0.00000 820186.25844 832929.15243 0.00000 820216.58857 832919.60572 0.00000 820219.98727 832930.08021 0.00000 820218.18023 832930.64214 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3ff1a2d3-0bbd-44cf-b0c9-b065dc1a4ec4">
<fme:FEATURE_ID>1000117050</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832722.29</fme:EASTING>
<fme:NORTHING>819884.02</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819883.53676 832727.23813 0.00000 819879.09451 832723.27596 0.00000 819884.53227 832717.36724 0.00000 819888.93322 832721.25018 0.00000 819886.46635 832723.98744 0.00000 819883.53676 832727.23813 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id28112214-d13e-433b-bd1b-67870ff041e5">
<fme:FEATURE_ID>1000116954</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830925.31</fme:EASTING>
<fme:NORTHING>820135.84</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820133.88954 830935.20183 0.00000 820128.51641 830932.28290 0.00000 820137.81786 830915.44126 0.00000 820143.18211 830918.22405 0.00000 820133.88954 830935.20183 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id48148349-4dc7-409a-9a30-07290ee9e519">
<fme:FEATURE_ID>1000116953</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832225.46</fme:EASTING>
<fme:NORTHING>820134.97</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820144.53004 832245.03377 0.00000 820132.60593 832247.29989 0.00000 820125.16011 832207.13023 0.00000 820138.97265 832204.48642 0.00000 820140.07741 832210.48138 0.00000 820140.80713 832214.44116 0.00000 820138.72985 832214.79187 0.00000 820141.72552 832230.41114 0.00000 820144.53004 832245.03377 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6af911d0-10ce-4c95-9cd3-a4596ef3d1f6">
<fme:FEATURE_ID>1000116991</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832911.89</fme:EASTING>
<fme:NORTHING>820033.42</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820039.39174 832918.16659 0.00000 820024.72272 832910.36160 0.00000 820026.31651 832907.38243 0.00000 820029.82211 832909.21430 0.00000 820031.19076 832906.58421 0.00000 820039.40245 832910.99368 0.00000 820037.94475 832913.58247 0.00000 820041.01093 832915.18738 0.00000 820039.39174 832918.16659 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4c921a4f-d539-44d9-9003-2fbd7fef2465">
<fme:FEATURE_ID>1000116990</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832030.5</fme:EASTING>
<fme:NORTHING>820045.07</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820043.30490 832033.30029 0.00000 820041.57198 832031.32654 0.00000 820046.60449 832026.23504 0.00000 820047.75262 832032.40695 0.00000 820043.30490 832033.30029 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbcb27a2d-561d-4b45-a510-20cf49e8bd8f">
<fme:FEATURE_ID>1000155265</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833540.72</fme:EASTING>
<fme:NORTHING>820756.51</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820784.85623 833674.89039 0.00000 820713.57731 833616.09298 0.00000 820711.04042 833613.99338 0.00000 820710.38543 833614.76108 0.00000 820706.94543 833615.09108 0.00000 820704.90543 833613.38108 0.00000 820704.08543 833612.50108 0.00000 820703.79543 833609.23108 0.00000 820704.29415 833608.40997 0.00000 820701.71622 833606.27640 0.00000 820692.98073 833599.14999 0.00000 820662.92579 833635.20613 0.00000 820757.43471 833714.90251 0.00000 820728.02161 833750.00000 0.00000 820715.21762 833750.00000 0.00000 820648.81568 833694.88242 0.00000 820646.13374 833692.66600 0.00000 820644.96614 833693.90531 0.00000 820641.85676 833694.22563 0.00000 820638.69979 833691.66730 0.00000 820638.55598 833688.44438 0.00000 820639.59675 833687.25786 0.00000 820637.10824 833685.19929 0.00000 820628.62794 833677.27496 0.00000 820613.27314 833695.75222 0.00000 820620.13248 833701.53243 0.00000 820617.39062 833705.03125 0.00000 820620.21094 833707.51172 0.00000 820620.06729 833707.68436 0.00000 820609.62596 833720.23357 0.00000 820584.85937 833750.00000 0.00000 820514.74023 833750.00000 0.00000 820520.01979 833741.32266 0.00000 820558.45945 833695.85088 0.00000 820564.82825 833687.91991 0.00000 820577.94572 833672.23666 0.00000 820582.31055 833675.82812 0.00000 820585.07031 833673.00000 0.00000 820591.83008 833678.26172 0.00000 820778.10317 833454.31232 0.00000 820788.66202 833463.12116 0.00000 820799.19876 833471.91156 0.00000 820791.06343 833481.76211 0.00000 820773.45058 833503.18606 0.00000 820768.64703 833509.02901 0.00000 820855.59697 833581.25774 0.00000 820857.53333 833582.81335 0.00000 820862.88086 833587.10937 0.00000 820854.93949 833596.74289 0.00000 820788.22679 833677.67073 0.00000 820784.85623 833674.89039 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9ce04457-f8d6-4a59-af51-caca5523fb23">
<fme:FEATURE_ID>1210013989</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832470.24</fme:EASTING>
<fme:NORTHING>820561.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820550.02221 832466.07026 0.00000 820534.96891 832450.97163 0.00000 820542.96390 832443.85092 0.00000 820588.49380 832489.18522 0.00000 820581.18655 832497.00585 0.00000 820550.14177 832465.95070 0.00000 820550.07485 832466.01762 0.00000 820550.02221 832466.07026 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5ec14333-1fab-4f21-acc3-1b8e0725a41f">
<fme:FEATURE_ID>1000116809</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833485.49</fme:EASTING>
<fme:NORTHING>820777.91</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820758.22000 833500.51000 0.00000 820758.07000 833497.09000 0.00000 820774.60834 833477.17947 0.00000 820785.57930 833463.63930 0.00000 820788.66202 833463.12116 0.00000 820799.19876 833471.91156 0.00000 820768.64703 833509.02901 0.00000 820758.22000 833500.51000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id58df8340-478a-4406-a0ee-6863631e9750">
<fme:FEATURE_ID>1000117102</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832572.62</fme:EASTING>
<fme:NORTHING>820787.28</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820784.39104 832608.35673 0.00000 820765.09984 832596.65642 0.00000 820768.27292 832591.72198 0.00000 820761.89524 832587.82451 0.00000 820765.99918 832581.08061 0.00000 820782.09124 832554.63694 0.00000 820769.92640 832547.43252 0.00000 820774.41439 832540.22810 0.00000 820786.52792 832547.28323 0.00000 820790.24050 832541.17294 0.00000 820815.75123 832556.64473 0.00000 820784.39104 832608.35673 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3795a948-12df-41d0-9769-6255b5835381">
<fme:FEATURE_ID>1000117018</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832768.25</fme:EASTING>
<fme:NORTHING>819972.4</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819982.86409 832770.42093 0.00000 819961.85926 832768.96207 0.00000 819962.08182 832766.03651 0.00000 819983.11231 832767.62250 0.00000 819982.86409 832770.42093 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5392bdee-430b-47f3-a4dd-74435f232774">
<fme:FEATURE_ID>1000117129</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831709.31</fme:EASTING>
<fme:NORTHING>819953.67</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819951.38409 831716.90227 0.00000 819950.59120 831716.37260 0.00000 819948.86180 831707.00490 0.00000 819947.87700 831707.15990 0.00000 819947.36870 831704.72090 0.00000 819957.32670 831703.05440 0.00000 819959.42336 831714.32776 0.00000 819957.14283 831714.02324 0.00000 819954.95305 831714.39760 0.00000 819952.96832 831715.39566 0.00000 819951.38409 831716.90227 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8355ac4c-6b1c-4a66-a1a0-904c93e75d15">
<fme:FEATURE_ID>1210001849</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>US</fme:DATALEVEL>
<fme:EASTING>830681.42</fme:EASTING>
<fme:NORTHING>820383.79</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820381.75000 830689.87500 0.00000 820370.93750 830680.93750 0.00000 820380.93750 830668.87500 0.00000 820391.68750 830677.81250 0.00000 820392.18750 830678.25000 0.00000 820396.62500 830681.93750 0.00000 820386.68750 830693.93750 0.00000 820382.18750 830690.25000 0.00000 820381.75000 830689.87500 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id291d2dd8-6a9f-46e2-94f4-c9f1e117d20b">
<fme:FEATURE_ID>1000116821</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832657.37</fme:EASTING>
<fme:NORTHING>820619.19</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820586.83735 832649.59904 0.00000 820599.98206 832636.76117 0.00000 820610.54929 832647.40551 0.00000 820627.93312 832630.42746 0.00000 820632.75520 832635.28575 0.00000 820628.51496 832639.40685 0.00000 820648.82551 832659.62755 0.00000 820623.00520 832685.34630 0.00000 820586.83735 832649.59904 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3e4f0669-8440-412d-996f-158c3325aca5">
<fme:FEATURE_ID>1000116874</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831415.32</fme:EASTING>
<fme:NORTHING>820311.95</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820317.83984 831432.50977 0.00000 820299.32031 831406.28906 0.00000 820304.97070 831402.42969 0.00000 820307.74023 831406.34961 0.00000 820313.21094 831402.55078 0.00000 820319.53906 831411.77930 0.00000 820314.33984 831415.63086 0.00000 820323.36914 831428.66016 0.00000 820317.83984 831432.50977 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id920da8e4-b982-47ee-a577-a78531fc7756">
<fme:FEATURE_ID>1000116792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832387.22</fme:EASTING>
<fme:NORTHING>820912.35</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820914.23501 832389.53968 0.00000 820902.63200 832398.55100 0.00000 820898.87800 832393.57000 0.00000 820922.60471 832375.81297 0.00000 820925.98151 832380.41691 0.00000 820925.56101 832380.74349 0.00000 820914.23501 832389.53968 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf434b966-eb4a-46c3-b698-7b8690a87df0">
<fme:FEATURE_ID>1000116967</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832894.57</fme:EASTING>
<fme:NORTHING>820118.67</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820115.07067 832897.91258 0.00000 820113.01167 832895.94578 0.00000 820114.74801 832894.13490 0.00000 820118.98129 832889.73322 0.00000 820123.89273 832894.45552 0.00000 820119.60927 832898.94117 0.00000 820116.79162 832896.16090 0.00000 820115.07067 832897.91258 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id50b0f106-a3f5-499f-b219-c74998192940">
<fme:FEATURE_ID>1000117131</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831944.75</fme:EASTING>
<fme:NORTHING>820043.72</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820054.50420 831984.13610 0.00000 820047.20206 831985.42459 0.00000 820032.38258 831905.42509 0.00000 820039.62580 831904.04500 0.00000 820045.02560 831933.15080 0.00000 820046.37883 831935.14683 0.00000 820047.49720 831937.18205 0.00000 820048.45658 831939.39451 0.00000 820049.17790 831941.60190 0.00000 820049.87210 831944.95760 0.00000 820050.04837 831947.50132 0.00000 820049.97196 831950.04999 0.00000 820049.64361 831952.57859 0.00000 820049.09140 831954.97460 0.00000 820054.50420 831984.13610 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8e701cc7-5e4f-4876-967a-d585608f7d36">
<fme:FEATURE_ID>1210046823</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832564.59</fme:EASTING>
<fme:NORTHING>820288.06</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820295.59028 832593.49330 0.00000 820265.85414 832574.33737 0.00000 820270.82482 832565.36904 0.00000 820263.26547 832561.07395 0.00000 820277.55091 832536.79815 0.00000 820315.34768 832558.61719 0.00000 820295.59028 832593.49330 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb8ab66a6-7d2c-4e21-8a8b-ba69910d1c68">
<fme:FEATURE_ID>1000116987</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832189.46</fme:EASTING>
<fme:NORTHING>820046.31</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820056.40575 832200.13835 0.00000 820052.58010 832200.84500 0.00000 820053.10440 832203.69330 0.00000 820044.18380 832205.37310 0.00000 820043.70520 832202.50380 0.00000 820040.87216 832203.07580 0.00000 820039.67450 832196.80180 0.00000 820036.30321 832178.77796 0.00000 820039.17400 832178.29330 0.00000 820038.63710 832175.43080 0.00000 820047.58960 832173.71450 0.00000 820048.09200 832176.57060 0.00000 820051.90313 832175.87461 0.00000 820056.40575 832200.13835 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id12c71863-0c76-4a7d-8752-f721c0adc8c9">
<fme:FEATURE_ID>1000116900</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832959.17</fme:EASTING>
<fme:NORTHING>820252.05</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820261.48282 832966.78619 0.00000 820245.67144 832972.20948 0.00000 820244.06143 832967.20102 0.00000 820248.85816 832965.56375 0.00000 820243.87292 832949.11407 0.00000 820254.35495 832945.68521 0.00000 820261.48282 832966.78619 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id47250f1d-3f5e-42eb-bca5-1b5d2ff76b6e">
<fme:FEATURE_ID>1000116838</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832550.66</fme:EASTING>
<fme:NORTHING>820489.13</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820485.51953 832561.82031 0.00000 820478.31055 832554.07031 0.00000 820492.39062 832539.69922 0.00000 820500.17969 832547.01953 0.00000 820485.51953 832561.82031 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5b60f111-1bbf-4875-9020-d26ede2aac0f">
<fme:FEATURE_ID>1210058451</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832629.07</fme:EASTING>
<fme:NORTHING>820732.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820712.88351 832654.49625 0.00000 820706.11158 832647.57316 0.00000 820751.58234 832602.27996 0.00000 820758.36587 832608.99919 0.00000 820759.85537 832610.41566 0.00000 820714.30677 832655.86633 0.00000 820712.88351 832654.49625 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id31ea561e-c6d7-4000-a7c6-3b82eea6f2f6">
<fme:FEATURE_ID>1000117037</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832465.21</fme:EASTING>
<fme:NORTHING>819933.43</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819934.08354 832469.64459 0.00000 819929.27183 832463.47225 0.00000 819932.82182 832460.79469 0.00000 819937.55735 832466.96717 0.00000 819934.08354 832469.64459 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1904c62d-c8fd-408b-a780-451a6b11d12d">
<fme:FEATURE_ID>1000117063</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832737.77</fme:EASTING>
<fme:NORTHING>819818.79</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819831.34417 832753.86099 0.00000 819830.06561 832755.27157 0.00000 819801.78461 832729.60311 0.00000 819809.18242 832721.32203 0.00000 819833.95247 832743.71625 0.00000 819830.50648 832747.36030 0.00000 819834.24602 832750.65953 0.00000 819831.34417 832753.86099 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1e7883fc-c51f-42f0-a4f6-dfaed12c9ed6">
<fme:FEATURE_ID>1000116890</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831918.14</fme:EASTING>
<fme:NORTHING>820267.53</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820272.01816 831932.48479 0.00000 820253.66233 831912.40934 0.00000 820263.07163 831903.81799 0.00000 820281.37879 831923.83533 0.00000 820272.01816 831932.48479 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idcb823747-a973-4949-a63c-a6ffd0272a92">
<fme:FEATURE_ID>1000116882</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831848.09</fme:EASTING>
<fme:NORTHING>820303.43</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820302.84196 831851.60517 0.00000 820300.12503 831846.78426 0.00000 820303.92681 831844.55636 0.00000 820306.77366 831849.39369 0.00000 820302.84196 831851.60517 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idfc2202dc-a886-4149-b19e-f00b0bf515be">
<fme:FEATURE_ID>1210061343</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833746.6</fme:EASTING>
<fme:NORTHING>820611.34</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820615.25211 833747.88405 0.00000 820613.72521 833750.00000 0.00000 820603.17975 833750.00000 0.00000 820623.36017 833725.80096 0.00000 820629.43879 833730.95456 0.00000 820615.25211 833747.88405 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida7ff11f5-4ee2-4946-a638-6d4730108fc6">
<fme:FEATURE_ID>1000117075</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832559.53</fme:EASTING>
<fme:NORTHING>819772.28</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819770.40244 832564.40376 0.00000 819767.28384 832558.29756 0.00000 819774.08491 832554.64743 0.00000 819777.30538 832560.77793 0.00000 819770.40244 832564.40376 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id63474fc0-596a-45a7-9a94-682263de4c9c">
<fme:FEATURE_ID>1000117081</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832757.26</fme:EASTING>
<fme:NORTHING>819734.85</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819735.51125 832765.43411 0.00000 819726.89105 832755.30502 0.00000 819734.13943 832749.11987 0.00000 819742.83472 832759.14639 0.00000 819735.51125 832765.43411 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0d423e3e-dd2b-490f-a91c-71b453adf6fe">
<fme:FEATURE_ID>1000116817</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831659.8</fme:EASTING>
<fme:NORTHING>820693.57</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820702.15982 831659.91638 0.00000 820697.27598 831661.18497 0.00000 820698.63278 831665.81300 0.00000 820689.02294 831668.61547 0.00000 820685.32023 831655.98323 0.00000 820699.61882 831651.65636 0.00000 820702.15982 831659.91638 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7f3f40ff-a2d3-4618-9220-9700c3bdd994">
<fme:FEATURE_ID>1000158046</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831193.39</fme:EASTING>
<fme:NORTHING>820247.45</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820260.60804 831177.27401 0.00000 820268.13687 831198.90645 0.00000 820234.03185 831209.39691 0.00000 820226.85403 831187.98938 0.00000 820260.60804 831177.27401 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4df24641-545b-4cc4-ba90-28f2a8b38408">
<fme:FEATURE_ID>1000117004</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831134.88</fme:EASTING>
<fme:NORTHING>820010.94</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820010.42425 831138.26456 0.00000 820008.36448 831137.13570 0.00000 820011.45568 831131.49536 0.00000 820013.51545 831132.62422 0.00000 820010.42425 831138.26456 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5fc12f7b-7512-4884-8361-7e5adda309fb">
<fme:FEATURE_ID>1000116892</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833023.95</fme:EASTING>
<fme:NORTHING>820273.7</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820269.61292 833025.16865 0.00000 820269.45314 833023.54811 0.00000 820269.94687 833021.91989 0.00000 820271.03755 833020.61402 0.00000 820272.48023 833019.85881 0.00000 820274.17484 833019.70665 0.00000 820275.72898 833020.19276 0.00000 820277.03486 833021.28344 0.00000 820277.79006 833022.72612 0.00000 820277.94984 833024.34666 0.00000 820277.45611 833025.97488 0.00000 820276.36543 833027.28075 0.00000 820274.92275 833028.03596 0.00000 820273.30222 833028.19574 0.00000 820271.67399 833027.70201 0.00000 820270.36812 833026.61133 0.00000 820269.61292 833025.16865 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id26239d19-51e7-40c9-a186-c21cf5057606">
<fme:FEATURE_ID>1000116840</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830688</fme:EASTING>
<fme:NORTHING>820480.54</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820482.75000 830700.53000 0.00000 820467.88000 830687.88000 0.00000 820478.17154 830675.50086 0.00000 820493.26434 830688.06747 0.00000 820482.75000 830700.53000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2ea9fb47-fbe1-43f6-aae3-dbe5d3b68a93">
<fme:FEATURE_ID>1000116855</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831724.72</fme:EASTING>
<fme:NORTHING>820372.17</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820376.92275 831737.50264 0.00000 820373.41456 831734.18540 0.00000 820375.10237 831732.40498 0.00000 820364.01165 831722.05106 0.00000 820362.34416 831723.75732 0.00000 820359.06536 831720.70915 0.00000 820366.31054 831712.87689 0.00000 820384.35053 831729.61592 0.00000 820379.89421 831734.34758 0.00000 820378.36456 831735.97174 0.00000 820376.92275 831737.50264 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id70c4057e-639f-4354-9a03-328e1e33b3cd">
<fme:FEATURE_ID>1000116803</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832333.53</fme:EASTING>
<fme:NORTHING>820858.28</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820856.25236 832336.35738 0.00000 820855.09666 832332.11165 0.00000 820860.30707 832330.69335 0.00000 820861.46272 832334.93888 0.00000 820856.25236 832336.35738 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id50de6d52-d499-4260-98ef-2235ae131c61">
<fme:FEATURE_ID>1000116830</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832578.56</fme:EASTING>
<fme:NORTHING>820518.99</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820518.21094 832583.61914 0.00000 820513.93945 832579.27930 0.00000 820519.85937 832573.51953 0.00000 820524.00000 832577.81055 0.00000 820518.21094 832583.61914 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id54cee26d-2d38-416c-b768-a7eb16e11595">
<fme:FEATURE_ID>1310090997</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833437.41</fme:EASTING>
<fme:NORTHING>820852.06</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820857.13419 833451.71987 0.00000 820853.03314 833456.61467 0.00000 820871.54951 833467.65432 0.00000 820861.63211 833483.33764 0.00000 820818.77125 833447.69545 0.00000 820828.29455 833436.24172 0.00000 820840.20082 833446.29590 0.00000 820858.72169 833424.33544 0.00000 820831.12677 833401.21953 0.00000 820839.15063 833391.69743 0.00000 820842.51593 833394.50361 0.00000 820847.75167 833394.08143 0.00000 820881.60819 833422.35106 0.00000 820857.13419 833451.71987 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id64ed22c8-5225-441b-9ac8-69dab9f0d068">
<fme:FEATURE_ID>1000117011</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832033.28</fme:EASTING>
<fme:NORTHING>820002.04</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819999.29100 832034.53990 0.00000 819999.00577 832033.36706 0.00000 819999.18312 832032.22554 0.00000 819999.81075 832031.19453 0.00000 820000.79133 832030.49070 0.00000 820001.96897 832030.22597 0.00000 820003.10722 832030.42320 0.00000 820004.12713 832031.06871 0.00000 820004.81961 832032.05637 0.00000 820005.08544 832033.22869 0.00000 820004.89347 832034.36303 0.00000 820004.25668 832035.38259 0.00000 820003.27359 832036.07435 0.00000 820002.15148 832036.32827 0.00000 820000.96635 832036.12715 0.00000 819999.95264 832035.48108 0.00000 819999.29100 832034.53990 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide6f89d7c-f108-493a-a4e7-057451e7c4f2">
<fme:FEATURE_ID>1000116899</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832632.17</fme:EASTING>
<fme:NORTHING>820255.94</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820259.79600 832636.03300 0.00000 820250.47000 832632.84800 0.00000 820252.05100 832628.26400 0.00000 820261.50100 832631.58300 0.00000 820259.79600 832636.03300 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd15ecbc6-f2d3-4e14-abd1-796749c7e360">
<fme:FEATURE_ID>1000154483</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832522.72</fme:EASTING>
<fme:NORTHING>820949.19</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820895.59752 832513.26983 0.00000 820887.52300 832508.46600 0.00000 820901.98703 832485.56768 0.00000 820909.76741 832490.69782 0.00000 820917.66500 832478.30700 0.00000 820946.93600 832496.10600 0.00000 821000.00000 832529.54963 0.00000 821000.00000 832548.23261 0.00000 820992.88200 832559.81500 0.00000 820986.27500 832569.98000 0.00000 820895.59752 832513.26983 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6979e65a-1681-4518-a212-977aa5ca07cb">
<fme:FEATURE_ID>1000117023</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831724.83</fme:EASTING>
<fme:NORTHING>819957.9</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819951.38409 831716.90227 0.00000 819952.96832 831715.39566 0.00000 819954.95305 831714.39760 0.00000 819957.14283 831714.02324 0.00000 819959.42336 831714.32776 0.00000 819961.26044 831715.14902 0.00000 819962.86786 831716.48752 0.00000 819963.98524 831718.10000 0.00000 819964.67400 831720.07510 0.00000 819966.01737 831727.80898 0.00000 819965.84412 831729.75936 0.00000 819965.17262 831731.59868 0.00000 819964.46936 831732.70087 0.00000 819963.68139 831733.57516 0.00000 819962.65796 831734.38880 0.00000 819961.62852 831734.95937 0.00000 819960.39615 831735.39602 0.00000 819958.06034 831735.62210 0.00000 819956.76710 831735.42990 0.00000 819954.93832 831734.73022 0.00000 819953.35255 831733.58159 0.00000 819952.11758 831732.06211 0.00000 819951.31734 831730.27503 0.00000 819949.90190 831722.86661 0.00000 819949.78372 831721.56202 0.00000 819949.87256 831720.38615 0.00000 819950.18542 831719.11412 0.00000 819950.71435 831717.91572 0.00000 819951.38409 831716.90227 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide50376fd-e7d1-41a2-ac66-1ad264e44dbd">
<fme:FEATURE_ID>1000117047</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832495.01</fme:EASTING>
<fme:NORTHING>819897.29</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819895.20777 832496.79651 0.00000 819893.19348 832493.14883 0.00000 819897.96267 832490.59618 0.00000 819901.35254 832496.89836 0.00000 819896.65948 832499.42543 0.00000 819895.20777 832496.79651 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc66cfdf8-2827-471a-9f37-489fded8e135">
<fme:FEATURE_ID>1000116801</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832349.97</fme:EASTING>
<fme:NORTHING>820860.03</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820855.82313 832352.34612 0.00000 820855.24951 832350.65095 0.00000 820855.33304 832348.86332 0.00000 820855.75189 832347.74209 0.00000 820856.24069 832346.98795 0.00000 820857.59084 832345.81333 0.00000 820859.27618 832345.21146 0.00000 820860.47247 832345.17294 0.00000 820861.35577 832345.33859 0.00000 820862.95524 832346.14127 0.00000 820863.80956 832346.97956 0.00000 820864.30003 832347.73262 0.00000 820864.82472 832349.44356 0.00000 820864.84074 832350.34211 0.00000 820864.60325 832351.51522 0.00000 820863.72874 832353.07658 0.00000 820862.34541 832354.21193 0.00000 820860.64348 832354.76515 0.00000 820859.44657 832354.76929 0.00000 820858.56840 832354.57834 0.00000 820856.99264 832353.73005 0.00000 820855.82313 832352.34612 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5c961dc8-675e-40c7-98f9-f98172d0efb4">
<fme:FEATURE_ID>1000116887</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833114.18</fme:EASTING>
<fme:NORTHING>820287.9</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820287.73523 833117.25389 0.00000 820284.83581 833114.70238 0.00000 820288.03242 833111.11380 0.00000 820290.97564 833113.63052 0.00000 820287.73523 833117.25389 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida97e8ac5-b967-4725-8745-fc24946e7f8a">
<fme:FEATURE_ID>1000116889</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830977.36</fme:EASTING>
<fme:NORTHING>820276.12</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820271.83008 830987.16992 0.00000 820267.09961 830971.72070 0.00000 820280.24023 830967.55078 0.00000 820285.28906 830982.89062 0.00000 820271.83008 830987.16992 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4548311a-4c39-4a6b-b74d-e33a5d78d31a">
<fme:FEATURE_ID>1210047278</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832534.64</fme:EASTING>
<fme:NORTHING>820512.24</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820511.75967 832530.71227 0.00000 820516.19036 832535.08122 0.00000 820512.78387 832538.55165 0.00000 820508.24801 832534.22714 0.00000 820511.75967 832530.71227 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida67ea98c-5591-4b94-ba24-ddbd53ce4449">
<fme:FEATURE_ID>1310090819</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833333.31</fme:EASTING>
<fme:NORTHING>820932.15</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820972.58318 833328.75382 0.00000 820968.64423 833329.43459 0.00000 820969.21455 833332.73451 0.00000 820961.39603 833334.08578 0.00000 820961.84830 833337.04821 0.00000 820952.26390 833338.84878 0.00000 820947.84793 833335.44858 0.00000 820942.55626 833336.44077 0.00000 820939.72463 833341.20447 0.00000 820938.94932 833341.35012 0.00000 820934.10140 833342.26087 0.00000 820935.92025 833351.94253 0.00000 820935.47864 833355.95383 0.00000 820939.19832 833356.49950 0.00000 820939.64385 833358.91188 0.00000 820938.88317 833369.49523 0.00000 820934.08704 833369.15051 0.00000 820933.75157 833373.81784 0.00000 820931.77446 833377.84814 0.00000 820935.77431 833379.81400 0.00000 820927.84309 833390.87819 0.00000 820925.19294 833389.35754 0.00000 820923.20658 833392.77861 0.00000 820914.73989 833387.71844 0.00000 820924.23382 833370.83667 0.00000 820925.82133 833352.05122 0.00000 820912.33900 833283.61716 0.00000 820917.04228 833276.10555 0.00000 820924.51450 833282.27567 0.00000 820925.36536 833286.69327 0.00000 820929.13340 833286.08968 0.00000 820931.75539 833288.25476 0.00000 820933.02539 833295.13394 0.00000 820928.70786 833295.93102 0.00000 820929.85779 833302.15982 0.00000 820926.56957 833302.76688 0.00000 820927.58865 833308.28687 0.00000 820930.89277 833307.76596 0.00000 820932.53350 833307.46306 0.00000 820934.88684 833320.21030 0.00000 820933.04210 833320.55087 0.00000 820930.56432 833321.00831 0.00000 820932.10575 833329.35765 0.00000 820939.07080 833329.34419 0.00000 820951.66500 833326.96293 0.00000 820951.36859 833325.39529 0.00000 820965.83964 833322.50249 0.00000 820966.26297 833324.46041 0.00000 820973.69399 833323.08180 0.00000 820975.59418 833324.61519 0.00000 820972.58318 833328.75382 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8fd06f6a-432e-40f5-a87d-6eed39a3b48f">
<fme:FEATURE_ID>1310097923</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832780.28</fme:EASTING>
<fme:NORTHING>819801.63</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819797.88095 832793.05277 0.00000 819789.65454 832785.49589 0.00000 819805.39802 832767.49167 0.00000 819813.60012 832775.09846 0.00000 819797.88095 832793.05277 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc3aec177-a80d-4813-95b4-d855a9628be5">
<fme:FEATURE_ID>1000117013</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832510.23</fme:EASTING>
<fme:NORTHING>819996.99</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819997.09928 832514.32251 0.00000 819993.07635 832508.93726 0.00000 819996.90554 832506.18287 0.00000 820000.87748 832511.46646 0.00000 820000.00000 832512.12978 0.00000 819997.09928 832514.32251 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id555a0a31-f78f-4ddc-b1f4-854e3f7712f5">
<fme:FEATURE_ID>1000116944</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832324.92</fme:EASTING>
<fme:NORTHING>820148.81</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820152.22865 832332.23172 0.00000 820141.86795 832329.04188 0.00000 820145.29510 832317.63474 0.00000 820155.81136 832320.80304 0.00000 820152.22865 832332.23172 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id08195c1f-3f71-40af-9aae-01497c1774ae">
<fme:FEATURE_ID>1000116878</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833006.49</fme:EASTING>
<fme:NORTHING>820284.62</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820276.47793 833012.10055 0.00000 820271.39432 833006.20693 0.00000 820274.59028 833003.40792 0.00000 820270.68271 832998.91498 0.00000 820268.46926 833000.89623 0.00000 820256.12829 832986.94613 0.00000 820265.56993 832978.60764 0.00000 820282.39481 832997.50910 0.00000 820294.28566 833011.25672 0.00000 820296.91180 833008.98227 0.00000 820298.69103 833011.01453 0.00000 820301.40512 833008.69893 0.00000 820303.98454 833011.66949 0.00000 820315.25785 833024.65227 0.00000 820308.81520 833030.30118 0.00000 820302.89451 833023.73955 0.00000 820299.26453 833026.89347 0.00000 820294.76715 833021.89821 0.00000 820290.83149 833025.31998 0.00000 820278.07594 833010.72647 0.00000 820276.47793 833012.10055 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9971e5fb-695a-43c8-beba-bad2d52e64e3">
<fme:FEATURE_ID>1000116847</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832486.47</fme:EASTING>
<fme:NORTHING>820431.18</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820428.88236 832496.37142 0.00000 820421.01838 832489.11673 0.00000 820433.36799 832476.43704 0.00000 820433.46050 832476.34206 0.00000 820441.25356 832484.30639 0.00000 820428.88236 832496.37142 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="iddc2c1b12-163f-440a-9728-488713f09411">
<fme:FEATURE_ID>1000116787</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832470.41</fme:EASTING>
<fme:NORTHING>820961.57</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820963.58800 832485.96000 0.00000 820946.85500 832475.80800 0.00000 820959.55900 832454.86900 0.00000 820976.29200 832465.02100 0.00000 820963.58800 832485.96000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id80c3c24c-9885-4968-ab1b-2be5d47534ee">
<fme:FEATURE_ID>1000116920</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831794.24</fme:EASTING>
<fme:NORTHING>820214.35</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820214.79301 831798.58234 0.00000 820210.35234 831792.76748 0.00000 820213.91639 831789.89812 0.00000 820218.34748 831795.70871 0.00000 820214.79301 831798.58234 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2ca4e843-ab1e-42f4-baad-d96424c6e0a7">
<fme:FEATURE_ID>1000116898</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831771.92</fme:EASTING>
<fme:NORTHING>820256.61</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820257.47649 831779.60162 0.00000 820250.29622 831775.74617 0.00000 820254.39337 831767.90420 0.00000 820252.74402 831767.03716 0.00000 820254.33009 831764.07951 0.00000 820257.86949 831766.02020 0.00000 820263.25916 831768.85511 0.00000 820257.47649 831779.60162 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5bdec99a-a961-4ef4-b849-dcad8b06e9e2">
<fme:FEATURE_ID>1000117089</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832708.8</fme:EASTING>
<fme:NORTHING>819682.03</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819682.17787 832712.89312 0.00000 819678.27691 832710.52220 0.00000 819681.83429 832704.68132 0.00000 819685.82429 832707.18045 0.00000 819682.17787 832712.89312 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1ef3b0bb-4836-40a9-8cfb-012e856995b2">
<fme:FEATURE_ID>1000116853</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832951.73</fme:EASTING>
<fme:NORTHING>820368.87</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820375.71665 832974.11006 0.00000 820345.59421 832943.84699 0.00000 820359.93245 832929.58153 0.00000 820373.47067 832943.35016 0.00000 820375.71005 832941.22760 0.00000 820391.93552 832957.62237 0.00000 820375.71665 832974.11006 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide1041369-3914-464a-88bf-ca016cc89cac">
<fme:FEATURE_ID>1000116916</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831807.06</fme:EASTING>
<fme:NORTHING>820209.01</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820212.08514 831822.87769 0.00000 820194.47899 831799.97581 0.00000 820205.89333 831791.22428 0.00000 820213.57368 831801.20793 0.00000 820223.55051 831814.17677 0.00000 820212.08514 831822.87769 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id61eb0f98-ec19-4053-87f8-28634d37835b">
<fme:FEATURE_ID>1000116896</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831819.34</fme:EASTING>
<fme:NORTHING>820253.98</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820259.96169 831828.24055 0.00000 820243.97120 831815.53354 0.00000 820248.04559 831810.40629 0.00000 820260.15903 831820.12754 0.00000 820264.02453 831823.22967 0.00000 820259.96169 831828.24055 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id17ca7a48-1be8-4405-adc3-d480c7af6356">
<fme:FEATURE_ID>1210013997</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831324.45</fme:EASTING>
<fme:NORTHING>820249.37</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820234.24928 831298.58475 0.00000 820229.43008 831283.09438 0.00000 820235.74445 831281.42838 0.00000 820245.79052 831310.47462 0.00000 820258.02052 831339.08407 0.00000 820274.18158 831362.23371 0.00000 820268.83893 831366.31187 0.00000 820251.91996 831342.10933 0.00000 820245.33703 831328.20513 0.00000 820238.15691 831309.68420 0.00000 820234.24928 831298.58475 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5755da60-1607-44de-a94e-90bc6756d4e0">
<fme:FEATURE_ID>1000117091</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832283.23</fme:EASTING>
<fme:NORTHING>819638.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819634.99413 832284.11225 0.00000 819634.97015 832283.46133 0.00000 819635.26850 832282.90550 0.00000 819636.75482 832282.31870 0.00000 819639.65711 832281.72090 0.00000 819642.39300 832281.75640 0.00000 819642.76908 832281.96302 0.00000 819642.99382 832282.31143 0.00000 819643.02699 832282.73924 0.00000 819642.84935 832283.12984 0.00000 819641.85672 832283.69767 0.00000 819640.36403 832284.26655 0.00000 819638.36312 832284.72613 0.00000 819636.08685 832284.86629 0.00000 819635.46534 832284.75081 0.00000 819634.99413 832284.11225 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id537e9e15-f40b-47c2-af48-2c961891472a">
<fme:FEATURE_ID>1310097924</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832769.48</fme:EASTING>
<fme:NORTHING>819788.18</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819785.72551 832781.88663 0.00000 819776.28147 832773.21122 0.00000 819790.31674 832757.17290 0.00000 819800.23863 832765.70573 0.00000 819785.72551 832781.88663 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbef6391b-9eec-4a33-a684-aca65308e3e1">
<fme:FEATURE_ID>1000117051</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832821.8</fme:EASTING>
<fme:NORTHING>819878.4</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819881.60296 832827.31909 0.00000 819872.41922 832819.47773 0.00000 819875.10449 832816.24203 0.00000 819884.41530 832824.13402 0.00000 819881.60296 832827.31909 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0291dc67-5f0c-4946-8516-e3b95c66b74d">
<fme:FEATURE_ID>1000116829</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832429.11</fme:EASTING>
<fme:NORTHING>820527.89</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820525.05458 832440.43411 0.00000 820516.58136 832431.96088 0.00000 820530.67322 832417.76848 0.00000 820539.20614 832426.30140 0.00000 820525.05458 832440.43411 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0e19ecc8-5fe4-4197-8883-9b76bfb87807">
<fme:FEATURE_ID>1210058432</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832572.16</fme:EASTING>
<fme:NORTHING>820709.87</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820735.51794 832590.72517 0.00000 820733.09700 832588.38360 0.00000 820730.00137 832592.03485 0.00000 820726.50886 832595.09080 0.00000 820728.49324 832597.94831 0.00000 820725.15949 832600.28987 0.00000 820722.85760 832597.23393 0.00000 820718.05540 832599.13893 0.00000 820712.89602 832600.17081 0.00000 820707.69695 832600.25018 0.00000 820702.06131 832599.17862 0.00000 820696.62412 832596.87674 0.00000 820691.90129 832593.62236 0.00000 820688.09128 832589.69329 0.00000 820685.39253 832585.40703 0.00000 820683.20971 832580.00952 0.00000 820682.25721 832574.81045 0.00000 820682.33658 832569.33356 0.00000 820683.48752 832563.89636 0.00000 820685.23378 832559.68948 0.00000 820680.33622 832556.80824 0.00000 820682.98938 832552.59039 0.00000 820687.64943 832555.68575 0.00000 820688.67906 832554.42408 0.00000 820692.23607 832550.94069 0.00000 820692.78568 832550.44745 0.00000 820689.75835 832545.68536 0.00000 820694.21431 832542.86213 0.00000 820697.24163 832547.55618 0.00000 820703.13789 832545.32714 0.00000 820709.21635 832544.40963 0.00000 820714.60669 832544.75370 0.00000 820720.18817 832546.35933 0.00000 820725.42559 832548.95892 0.00000 820730.05133 832552.82009 0.00000 820733.49197 832557.10177 0.00000 820736.01511 832562.03335 0.00000 820737.39136 832566.54441 0.00000 820738.01826 832570.76231 0.00000 820737.74044 832575.96138 0.00000 820737.22723 832578.24600 0.00000 820736.51013 832581.43827 0.00000 820735.12107 832584.93078 0.00000 820738.09764 832587.90735 0.00000 820735.51794 832590.72517 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6b811edd-6545-40f8-a565-7d3fd27f46ed">
<fme:FEATURE_ID>1000116927</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832907.36</fme:EASTING>
<fme:NORTHING>820201.89</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820199.73722 832907.30668 0.00000 820199.21032 832905.67364 0.00000 820203.04107 832904.41489 0.00000 820204.59233 832909.07827 0.00000 820200.69604 832910.27840 0.00000 820199.73722 832907.30668 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3011c597-a6d4-4e90-a2e4-3d5046ad964f">
<fme:FEATURE_ID>1210058403</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831656.01</fme:EASTING>
<fme:NORTHING>820370.05</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820383.34540 831684.27632 0.00000 820353.28373 831643.96117 0.00000 820357.38219 831640.80307 0.00000 820346.35738 831625.99468 0.00000 820351.18604 831622.35665 0.00000 820392.87042 831677.05318 0.00000 820383.34540 831684.27632 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4dc95995-e261-48b1-ae48-b18d86344f43">
<fme:FEATURE_ID>1000117073</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832836.37</fme:EASTING>
<fme:NORTHING>819787.37</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819785.54433 832843.77786 0.00000 819780.02999 832839.18888 0.00000 819789.22139 832828.94815 0.00000 819794.71033 832833.53741 0.00000 819785.54433 832843.77786 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id03209d4a-abd2-4d36-8133-c9545e77cd5c">
<fme:FEATURE_ID>1000117078</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832820.27</fme:EASTING>
<fme:NORTHING>819758.28</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819760.22078 832824.16140 0.00000 819754.72905 832822.72191 0.00000 819756.43133 832816.33302 0.00000 819761.77857 832817.80940 0.00000 819760.22078 832824.16140 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7024a3bc-b5a2-49c6-942d-35953f62827f">
<fme:FEATURE_ID>1000116998</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832837.99</fme:EASTING>
<fme:NORTHING>820012.38</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820008.56488 832843.08508 0.00000 820003.05852 832834.96219 0.00000 820007.95316 832831.72209 0.00000 820006.37387 832829.38514 0.00000 820010.75746 832826.43125 0.00000 820022.49733 832843.67292 0.00000 820017.76128 832846.83684 0.00000 820016.23298 832844.60154 0.00000 820011.66812 832847.66293 0.00000 820008.56488 832843.08508 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6b1b5197-d134-4a07-99de-cf467122fcfc">
<fme:FEATURE_ID>1000116941</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832303.39</fme:EASTING>
<fme:NORTHING>820155.41</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820157.65343 832315.05045 0.00000 820147.02780 832311.86749 0.00000 820153.07855 832291.72780 0.00000 820163.85962 832295.01860 0.00000 820157.65343 832315.05045 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf67e4c0d-deb4-4a7c-8ef6-d01d0b86be32">
<fme:FEATURE_ID>1000157995</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832439.47</fme:EASTING>
<fme:NORTHING>820855.02</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820849.13568 832447.74905 0.00000 820845.49572 832443.95448 0.00000 820854.37842 832435.28726 0.00000 820859.79605 832430.00106 0.00000 820864.57568 832434.81923 0.00000 820850.31002 832448.97327 0.00000 820849.13568 832447.74905 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc191af11-1ca5-4e88-a3bb-2d30e7f6ac87">
<fme:FEATURE_ID>1000154605</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833760.75</fme:EASTING>
<fme:NORTHING>820815.15</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820835.32400 833742.86300 0.00000 820829.01597 833750.00000 0.00000 820816.97377 833750.00000 0.00000 820820.24404 833746.40402 0.00000 820821.96544 833747.94928 0.00000 820830.45700 833738.49400 0.00000 820831.57323 833739.49601 0.00000 820829.90320 833741.35640 0.00000 820832.53775 833743.72137 0.00000 820834.20777 833741.86099 0.00000 820835.32400 833742.86300 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id504d1099-c0ab-4ed7-aa3b-36e1e7c2a73f">
<fme:FEATURE_ID>1000116930</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832232.48</fme:EASTING>
<fme:NORTHING>820187.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820184.63717 832240.73649 0.00000 820183.73821 832224.75960 0.00000 820191.21944 832224.21515 0.00000 820192.11840 832240.19204 0.00000 820184.63717 832240.73649 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide8d708d3-472a-436f-83fe-4f8cf9236f90">
<fme:FEATURE_ID>1000116859</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832894.78</fme:EASTING>
<fme:NORTHING>820360.4</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820365.35000 832907.25849 0.00000 820351.07372 832892.97650 0.00000 820347.92849 832889.83000 0.00000 820355.46000 832882.30150 0.00000 820372.88151 832899.72999 0.00000 820365.35000 832907.25849 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8e76945c-a8b7-425c-a6f1-75d5788e8281">
<fme:FEATURE_ID>1000117046</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832491.36</fme:EASTING>
<fme:NORTHING>819904.01</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819903.35661 832495.82625 0.00000 819899.96664 832489.47319 0.00000 819904.63420 832486.89529 0.00000 819908.07496 832493.24826 0.00000 819903.35661 832495.82625 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id10b523d2-33d6-42a9-8c18-0ef5f8a0d602">
<fme:FEATURE_ID>1210020525</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832293.79</fme:EASTING>
<fme:NORTHING>820754.47</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820754.88014 832297.00376 0.00000 820750.56353 832292.21558 0.00000 820753.09300 832289.94000 0.00000 820758.49027 832295.27718 0.00000 820756.51036 832297.03999 0.00000 820754.88014 832297.00376 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc461f6cf-a7b1-4841-89a1-6bd8a43bef33">
<fme:FEATURE_ID>1000116912</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832974.4</fme:EASTING>
<fme:NORTHING>820225.56</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820238.27923 832984.05283 0.00000 820231.85973 832989.60480 0.00000 820223.57256 832980.25224 0.00000 820216.44062 832972.67228 0.00000 820211.00162 832966.62895 0.00000 820217.35661 832960.81584 0.00000 820219.54083 832960.86255 0.00000 820223.76645 832965.73882 0.00000 820224.80593 832964.84647 0.00000 820226.96491 832964.96954 0.00000 820228.54271 832966.56921 0.00000 820228.36971 832968.96083 0.00000 820227.48235 832969.72570 0.00000 820230.35868 832972.97643 0.00000 820231.49961 832972.00756 0.00000 820233.42991 832972.08020 0.00000 820235.26254 832974.11184 0.00000 820235.13983 832976.24897 0.00000 820234.20193 832977.14114 0.00000 820238.47803 832981.86468 0.00000 820238.27923 832984.05283 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id40346c18-48da-4d8e-b661-3aeb281cd811">
<fme:FEATURE_ID>1000116867</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832500.04</fme:EASTING>
<fme:NORTHING>820339.19</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820339.30599 832503.35908 0.00000 820335.89518 832499.32102 0.00000 820339.06402 832496.74578 0.00000 820342.47472 832500.73296 0.00000 820339.30599 832503.35908 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id50f896fc-dcc8-43cb-9058-f3c194e69f85">
<fme:FEATURE_ID>1000116854</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832921.64</fme:EASTING>
<fme:NORTHING>820379.84</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820379.48661 832933.65772 0.00000 820367.78110 832921.83486 0.00000 820380.05645 832909.58926 0.00000 820391.96508 832921.53797 0.00000 820379.48661 832933.65772 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idacadb47d-1ea4-4b4d-9e5c-5883a11b3576">
<fme:FEATURE_ID>1000116937</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832909.6</fme:EASTING>
<fme:NORTHING>820168.18</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820168.78950 832913.96441 0.00000 820164.44605 832907.19958 0.00000 820167.49680 832905.23312 0.00000 820171.92910 832911.93836 0.00000 820168.78950 832913.96441 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc7e814ad-893d-4b19-ae14-f8060ff29c47">
<fme:FEATURE_ID>1420017698</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831581.63</fme:EASTING>
<fme:NORTHING>819920.47</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260731</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819919.77233 831596.23543 0.00000 819914.88077 831593.65099 0.00000 819912.29444 831592.97610 0.00000 819906.15965 831572.09920 0.00000 819926.74400 831566.54100 0.00000 819934.75500 831591.02400 0.00000 819919.77233 831596.23543 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide1723fdb-beb0-41ec-a8a6-14b0408d8a58">
<fme:FEATURE_ID>1000116956</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832025.96</fme:EASTING>
<fme:NORTHING>820131.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820131.84639 832031.02559 0.00000 820127.13296 832027.89537 0.00000 820131.95193 832020.85282 0.00000 820136.61503 832024.08501 0.00000 820131.84639 832031.02559 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc6173ba3-a50f-427f-b77c-020152b221a3">
<fme:FEATURE_ID>1000116955</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832003.18</fme:EASTING>
<fme:NORTHING>820132.35</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820133.92521 832008.10238 0.00000 820127.19457 832002.66789 0.00000 820130.80643 831998.25063 0.00000 820137.51191 832003.73611 0.00000 820133.92521 832008.10238 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1bb7cb55-0279-4f85-8afb-2022c21a10c0">
<fme:FEATURE_ID>1000116861</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832018.71</fme:EASTING>
<fme:NORTHING>820343.83</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820360.97296 832019.30617 0.00000 820330.31788 832029.89863 0.00000 820326.19304 832017.85011 0.00000 820329.17866 832016.86839 0.00000 820330.07986 832019.53434 0.00000 820334.77177 832017.90948 0.00000 820332.76942 832012.02635 0.00000 820335.47735 832011.09044 0.00000 820337.54856 832016.99667 0.00000 820345.52777 832014.27830 0.00000 820343.56779 832008.30474 0.00000 820345.56051 832007.63046 0.00000 820346.87282 832011.57569 0.00000 820350.30558 832010.44393 0.00000 820350.95016 832012.40765 0.00000 820355.39147 832010.91791 0.00000 820353.36519 832004.98958 0.00000 820355.69110 832004.20255 0.00000 820360.97296 832019.30617 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida3e088d9-8ca4-4c53-a7be-32d6c4cf15e5">
<fme:FEATURE_ID>1000117006</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832817.62</fme:EASTING>
<fme:NORTHING>820010.84</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820011.21482 832823.21617 0.00000 820008.49917 832822.70857 0.00000 820010.50035 832811.98270 0.00000 820013.16478 832812.49040 0.00000 820011.21482 832823.21617 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1484c569-ecc2-4df0-b50b-d1c028165d7a">
<fme:FEATURE_ID>1000116932</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832840.64</fme:EASTING>
<fme:NORTHING>820185.64</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820184.36401 832834.96673 0.00000 820189.33225 832836.18238 0.00000 820186.99167 832846.30739 0.00000 820181.87155 832844.98946 0.00000 820184.36401 832834.96673 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3d1e6a9a-50e8-4b39-9ac2-59be4f425fc4">
<fme:FEATURE_ID>1000116949</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831994.91</fme:EASTING>
<fme:NORTHING>820145.6</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820146.41002 831999.97949 0.00000 820140.49181 831994.46471 0.00000 820144.76312 831989.84077 0.00000 820150.73201 831995.32986 0.00000 820149.69313 831996.44750 0.00000 820146.41002 831999.97949 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1b55070a-a73f-4ec6-9099-8b8fb48f860b">
<fme:FEATURE_ID>1210013996</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830650.19</fme:EASTING>
<fme:NORTHING>820424.65</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:Ring>
<gml:curveMember>
<gml:LineString>
<gml:posList>820428.21008 830644.16589 0.00000 820428.40966 830644.28855 0.00000 820428.60502 830644.41781 0.00000 820428.79595 830644.55354 0.00000 820428.98223 830644.69559 0.00000 820429.16366 830644.84378 0.00000 820429.34002 830644.99797 0.00000 820429.51112 830645.15797 0.00000 820429.67678 830645.32360 0.00000 820429.83680 830645.49469 0.00000 820429.99101 830645.67103 0.00000 820430.13923 830645.85243 0.00000 820430.28129 830646.03870 0.00000 820430.41705 830646.22961 0.00000 820430.54634 830646.42496 0.00000 820430.66902 830646.62452 0.00000 820430.78495 830646.82808 0.00000 820430.89401 830647.03540 0.00000 820430.99608 830647.24626 0.00000 820431.09102 830647.46041 0.00000 820431.17875 830647.67762 0.00000 820431.25917 830647.89764 0.00000 820431.33217 830648.12023 0.00000 820431.39769 830648.34514 0.00000 820431.45564 830648.57212 0.00000 820431.50597 830648.80091 0.00000 820431.54861 830649.03125 0.00000 820431.58352 830649.26289 0.00000 820431.61067 830649.49557 0.00000 820431.63001 830649.72903 0.00000 820431.64153 830649.96300 0.00000 820431.64521 830650.19723 0.00000 820431.64105 830650.43145 0.00000 820431.62906 830650.66540 0.00000 820431.60925 830650.89882 0.00000 820431.58164 830651.13145 0.00000 820431.54626 830651.36302 0.00000 820431.50315 830651.59328 0.00000 820431.45236 830651.82196 0.00000 820431.39395 830652.04882 0.00000 820431.32797 830652.27360 0.00000 820431.25452 830652.49604 0.00000 820431.17366 830652.71590 0.00000 820431.08549 830652.93293 0.00000 820430.99011 830653.14689 0.00000 820430.88762 830653.35754 0.00000 820430.77815 830653.56464 0.00000 820430.66180 830653.76797 0.00000 820430.53872 830653.96728 0.00000 820430.40903 830654.16237 0.00000 820430.27289 830654.35300 0.00000 820430.13045 830654.53898 0.00000 820429.98186 830654.72008 0.00000 820429.82730 830654.89612 0.00000 820429.66693 830655.06688 0.00000 820429.50094 830655.23218 0.00000 820429.32951 830655.39183 0.00000 820429.15284 830655.54566 0.00000 820428.97112 830655.69349 0.00000 820428.78455 830655.83515 0.00000 820428.59335 830655.97050 0.00000 820428.39772 830656.09937 0.00000 820428.19790 830656.22162 0.00000 820427.99409 830656.33712 0.00000 820427.78653 830656.44573 0.00000 820427.57546 830656.54734 0.00000 820427.36110 830656.64183 0.00000 820427.14371 830656.72909 0.00000 820426.92351 830656.80903 0.00000 820426.70076 830656.88156 0.00000 820426.47571 830656.94659 0.00000 820426.24861 830657.00406 0.00000 820426.01972 830657.05390 0.00000 820425.78928 830657.09605 0.00000 820425.55757 830657.13046 0.00000 820425.32483 830657.15710 0.00000 820425.09133 830657.17594 0.00000 820424.85733 830657.18696 0.00000 820424.62310 830657.19014 0.00000 820424.38888 830657.18548 0.00000 820424.15496 830657.17299 0.00000 820423.92158 830657.15267 0.00000 820423.68902 830657.12456 0.00000 820423.45753 830657.08868 0.00000 820423.22736 830657.04508 0.00000 820422.99879 830656.99380 0.00000 820422.77205 830656.93490 0.00000 820422.54742 830656.86845 0.00000 820422.32513 830656.79451 0.00000 820422.10545 830656.71318 0.00000 820421.88861 830656.62455 0.00000 820421.67485 830656.52871 0.00000 820421.46442 830656.42577 0.00000 820421.25755 830656.31585 0.00000 820421.05448 830656.19907 0.00000 820420.85543 830656.07555 0.00000 820420.66062 830655.94545 0.00000 820420.47028 830655.80890 0.00000</gml:posList>
</gml:LineString>
</gml:curveMember>
<gml:curveMember>
<gml:LineString>
<gml:posList>820420.47028 830655.80890 0.00000 820420.28514 830655.66647 0.00000 820420.10485 830655.51793 0.00000 820419.92962 830655.36347 0.00000 820419.75964 830655.20325 0.00000 820419.59510 830655.03744 0.00000 820419.43618 830654.86623 0.00000 820419.28307 830654.68982 0.00000 820419.13592 830654.50840 0.00000 820418.99492 830654.32217 0.00000 820418.86020 830654.13134 0.00000 820418.73193 830653.93611 0.00000 820418.61024 830653.73672 0.00000 820418.49527 830653.53338 0.00000 820418.38715 830653.32632 0.00000 820418.28600 830653.11576 0.00000 820418.19193 830652.90195 0.00000 820418.10505 830652.68511 0.00000 820418.02545 830652.46550 0.00000 820417.95322 830652.24336 0.00000 820417.88844 830652.01893 0.00000 820417.83119 830651.79246 0.00000 820417.78153 830651.56421 0.00000 820417.73951 830651.33442 0.00000 820417.70518 830651.10337 0.00000 820417.67858 830650.87130 0.00000 820417.65974 830650.63846 0.00000 820417.64867 830650.40513 0.00000 820417.64540 830650.17157 0.00000 820417.64992 830649.93802 0.00000 820417.66223 830649.70475 0.00000 820417.68232 830649.47202 0.00000 820417.71017 830649.24010 0.00000 820417.74573 830649.00923 0.00000 820417.78898 830648.77967 0.00000 820417.83986 830648.55169 0.00000 820417.89833 830648.32553 0.00000 820417.96430 830648.10145 0.00000 820418.03772 830647.87969 0.00000 820418.11849 830647.66051 0.00000 820418.20653 830647.44415 0.00000 820418.30174 830647.23084 0.00000 820418.40402 830647.02083 0.00000 820418.51325 830646.81434 0.00000 820418.62930 830646.61162 0.00000 820418.75205 830646.41288 0.00000 820418.88137 830646.21835 0.00000 820419.01711 830646.02824 0.00000 820419.15911 830645.84277 0.00000 820419.30722 830645.66214 0.00000 820419.46128 830645.48655 0.00000 820419.62111 830645.31620 0.00000 820419.78653 830645.15127 0.00000 820419.95737 830644.99196 0.00000 820420.13342 830644.83843 0.00000 820420.31450 830644.69087 0.00000 820420.50040 830644.54943 0.00000 820420.69092 830644.41427 0.00000 820420.88585 830644.28554 0.00000 820421.08495 830644.16339 0.00000 820421.28803 830644.04795 0.00000 820421.49484 830643.93935 0.00000 820421.70516 830643.83771 0.00000 820421.91875 830643.74314 0.00000 820422.13539 830643.65576 0.00000 820422.35481 830643.57565 0.00000 820422.57679 830643.50290 0.00000 820422.80107 830643.43760 0.00000 820423.02740 830643.37983 0.00000 820423.25554 830643.32963 0.00000 820423.48522 830643.28708 0.00000 820423.71620 830643.25221 0.00000 820423.94821 830643.22507 0.00000 820424.18099 830643.20569 0.00000 820424.41430 830643.19408 0.00000 820424.64786 830643.19027 0.00000 820424.88142 830643.19425 0.00000 820425.11471 830643.20602 0.00000 820425.34749 830643.22556 0.00000 820425.57948 830643.25287 0.00000 820425.81043 830643.28790 0.00000 820426.04008 830643.33061 0.00000 820426.26818 830643.38097 0.00000 820426.49448 830643.43890 0.00000 820426.71871 830643.50436 0.00000 820426.94064 830643.57726 0.00000 820427.16001 830643.65752 0.00000 820427.37657 830643.74506 0.00000 820427.59010 830643.83977 0.00000 820427.80035 830643.94156 0.00000 820428.00709 830644.05031 0.00000 820428.21008 830644.16589 0.00000</gml:posList>
</gml:LineString>
</gml:curveMember>
</gml:Ring>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id11a63c0f-471c-43d2-a89d-47f28e38a0eb">
<fme:FEATURE_ID>1000116888</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831942.02</fme:EASTING>
<fme:NORTHING>820283.51</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820283.83021 831945.43754 0.00000 820280.16709 831941.56016 0.00000 820283.19232 831938.61975 0.00000 820286.83600 831942.45997 0.00000 820283.83021 831945.43754 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idca50a47c-38fb-4695-8bbf-340125474e11">
<fme:FEATURE_ID>1000116876</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831687.49</fme:EASTING>
<fme:NORTHING>820307.15</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820320.26366 831684.18819 0.00000 820319.95267 831688.23276 0.00000 820317.71191 831688.07798 0.00000 820317.59914 831689.99918 0.00000 820305.45637 831689.34871 0.00000 820305.00758 831696.78844 0.00000 820297.36225 831696.28058 0.00000 820298.20889 831682.01141 0.00000 820311.82452 831682.62899 0.00000 820311.78851 831680.39155 0.00000 820318.13962 831680.79165 0.00000 820317.94836 831684.04987 0.00000 820320.26366 831684.18819 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc16ef784-8e2a-417d-8848-7244f67f4142">
<fme:FEATURE_ID>1000117054</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832769.23</fme:EASTING>
<fme:NORTHING>819861.66</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819872.20172 832785.04540 0.00000 819844.80280 832760.42511 0.00000 819851.16231 832753.39244 0.00000 819878.56148 832778.13991 0.00000 819872.20172 832785.04540 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id604142d9-b831-4cb7-9942-51ef8a7abc5b">
<fme:FEATURE_ID>1000116868</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832607.08</fme:EASTING>
<fme:NORTHING>820327.06</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820317.52381 832618.86484 0.00000 820315.35662 832616.68138 0.00000 820329.50464 832594.40339 0.00000 820339.78800 832600.77216 0.00000 820319.64459 832621.01378 0.00000 820317.52381 832618.86484 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbd80c632-a78f-4e5d-b125-2caf2722b715">
<fme:FEATURE_ID>1000116810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832423.14</fme:EASTING>
<fme:NORTHING>820666.58</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820573.09130 832505.12839 0.00000 820581.18655 832497.00585 0.00000 820588.49380 832489.18522 0.00000 820542.96390 832443.85092 0.00000 820552.44385 832434.39047 0.00000 820550.26713 832432.12668 0.00000 820553.04526 832429.34855 0.00000 820555.28594 832431.55422 0.00000 820564.55274 832422.30648 0.00000 820573.85539 832413.02296 0.00000 820571.84327 832410.94594 0.00000 820574.38321 832408.39507 0.00000 820576.51811 832410.36571 0.00000 820579.22860 832407.66080 0.00000 820581.25204 832405.64153 0.00000 820594.88952 832392.03210 0.00000 820592.84801 832389.85076 0.00000 820595.39285 832387.29497 0.00000 820597.49974 832389.42724 0.00000 820621.57999 832365.39651 0.00000 820619.34748 832363.23719 0.00000 820622.20700 832360.36536 0.00000 820622.25689 832360.31577 0.00000 820624.54867 832362.43394 0.00000 820642.76383 832344.25624 0.00000 820640.67183 832342.01210 0.00000 820643.28675 832339.41298 0.00000 820645.52701 832341.49874 0.00000 820663.54818 832323.51463 0.00000 820661.40539 832321.40382 0.00000 820664.05279 832318.77242 0.00000 820666.20969 832320.85860 0.00000 820684.85142 832302.25520 0.00000 820682.79845 832300.14002 0.00000 820685.55577 832297.39936 0.00000 820687.51942 832299.59269 0.00000 820697.19100 832289.94100 0.00000 820703.43590 832296.25335 0.00000 820718.56630 832311.54714 0.00000 820720.12331 832313.12096 0.00000 820727.74800 832320.82800 0.00000 820736.96841 832312.30716 0.00000 820741.29700 832308.30700 0.00000 820754.91398 832321.82566 0.00000 820763.44839 832330.29845 0.00000 820775.72503 832342.48645 0.00000 820776.06100 832342.82000 0.00000 820774.47106 832344.42942 0.00000 820770.08826 832348.86591 0.00000 820762.75500 832356.28900 0.00000 820796.02416 832388.65484 0.00000 820786.65458 832398.01307 0.00000 820788.98131 832400.33979 0.00000 820786.12380 832403.15761 0.00000 820783.87576 832400.78852 0.00000 820765.15359 832419.48800 0.00000 820767.51033 832421.77109 0.00000 820764.77188 832424.43015 0.00000 820762.44306 832422.19524 0.00000 820744.35724 832440.25914 0.00000 820746.68758 832442.54092 0.00000 820744.06820 832445.23968 0.00000 820741.70644 832442.90672 0.00000 820723.41378 832461.17721 0.00000 820725.65316 832463.41659 0.00000 820722.87503 832466.11534 0.00000 820720.72921 832463.85853 0.00000 820711.43615 832473.14033 0.00000 820704.79208 832479.77635 0.00000 820696.52900 832488.02941 0.00000 820698.82435 832490.32477 0.00000 820696.20497 832492.86477 0.00000 820693.90036 832490.65487 0.00000 820675.45972 832509.07316 0.00000 820677.86931 832511.35918 0.00000 820675.17056 832513.97856 0.00000 820672.91792 832511.61187 0.00000 820670.09880 832514.42758 0.00000 820667.74499 832516.77854 0.00000 820663.05243 832521.46541 0.00000 820659.43578 832525.07768 0.00000 820654.09225 832530.41473 0.00000 820656.27927 832532.71110 0.00000 820653.50114 832535.48923 0.00000 820651.24475 832533.25878 0.00000 820638.23026 832546.25750 0.00000 820640.84178 832548.78263 0.00000 820623.64414 832565.98028 0.00000 820620.97893 832563.48792 0.00000 820615.40335 832569.05674 0.00000 820575.51055 832528.56555 0.00000 820579.96341 832523.94953 0.00000 820575.47478 832519.61255 0.00000 820572.68593 832516.91792 0.00000 820578.68494 832510.72223 0.00000 820573.09130 832505.12839 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id193eeafa-2191-430b-8312-bd7b088fa330">
<fme:FEATURE_ID>1000116852</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832518.52</fme:EASTING>
<fme:NORTHING>820390.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820379.90969 832528.26778 0.00000 820377.47041 832525.99000 0.00000 820398.53607 832505.06113 0.00000 820404.28125 832510.94310 0.00000 820383.72300 832531.84626 0.00000 820379.90969 832528.26778 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd5cb09a1-c518-4edb-a6c4-21ba111c2174">
<fme:FEATURE_ID>1000117001</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832375.36</fme:EASTING>
<fme:NORTHING>820007.02</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819998.20170 832370.65785 0.00000 820013.51487 832367.43780 0.00000 820015.78197 832380.26133 0.00000 820000.44990 832383.12210 0.00000 819998.20170 832370.65785 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idaef5916f-5ec3-46ba-a872-aa0314fcb051">
<fme:FEATURE_ID>1210069627</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833888.69</fme:EASTING>
<fme:NORTHING>820880.38</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820945.00533 833750.00000 0.00000 820930.36623 833750.00000 0.00000 820945.79151 833729.95945 0.00000 820961.10146 833709.64064 0.00000 821000.00000 833743.77247 0.00000 821000.00000 833750.00000 0.00000 820945.00533 833750.00000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida4144e75-07ba-4ac7-8925-5d1e73db0ee8">
<fme:FEATURE_ID>1000116825</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831392.68</fme:EASTING>
<fme:NORTHING>820608.88</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820617.65039 831392.44922 0.00000 820612.27930 831394.15039 0.00000 820613.61914 831398.85937 0.00000 820604.44922 831401.83008 0.00000 820600.52930 831388.99023 0.00000 820615.17969 831384.40039 0.00000 820617.65039 831392.44922 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9bf95bae-1522-4f97-8fa4-5e15884d3fcc">
<fme:FEATURE_ID>1000116982</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832932.92</fme:EASTING>
<fme:NORTHING>820063.98</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820074.71927 832944.32051 0.00000 820049.46613 832926.89643 0.00000 820053.21361 832921.52201 0.00000 820078.49215 832938.94604 0.00000 820074.71927 832944.32051 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id859165d0-9d36-49b0-981a-bc5a0414755f">
<fme:FEATURE_ID>1000116891</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832521.61</fme:EASTING>
<fme:NORTHING>820271</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820278.32605 832529.58152 0.00000 820260.45005 832519.31294 0.00000 820263.68977 832513.63364 0.00000 820281.56582 832523.92766 0.00000 820278.61749 832529.07292 0.00000 820278.32605 832529.58152 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide493467a-1361-423c-8dd9-c456309fde70">
<fme:FEATURE_ID>1000116873</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831682.47</fme:EASTING>
<fme:NORTHING>820321.92</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820320.26366 831684.18819 0.00000 820318.91265 831682.77933 0.00000 820320.47006 831680.69704 0.00000 820322.87704 831679.48686 0.00000 820324.44488 831681.14429 0.00000 820323.83690 831683.69439 0.00000 820321.93634 831685.73582 0.00000 820320.26366 831684.18819 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc94eb78c-2c32-4884-ae11-9e32e6502f6a">
<fme:FEATURE_ID>1210058454</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832531.25</fme:EASTING>
<fme:NORTHING>820686.64</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820688.95268 832535.99539 0.00000 820682.02827 832528.77317 0.00000 820684.38108 832526.50971 0.00000 820691.24592 832533.74682 0.00000 820688.95268 832535.99539 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idc38cdfdc-9efc-4121-9a94-002a732d4062">
<fme:FEATURE_ID>1210080689</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831557.59</fme:EASTING>
<fme:NORTHING>820290.26</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820295.53418 831570.51526 0.00000 820273.58503 831555.00806 0.00000 820277.36023 831550.06839 0.00000 820279.00452 831551.32452 0.00000 820288.38145 831542.16219 0.00000 820300.78321 831557.74987 0.00000 820303.92458 831565.62258 0.00000 820303.04570 831568.87798 0.00000 820301.53619 831570.41796 0.00000 820298.83500 831571.35135 0.00000 820295.53418 831570.51526 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id023d78aa-71d0-439e-9589-b2303f904c80">
<fme:FEATURE_ID>1000117040</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832501.04</fme:EASTING>
<fme:NORTHING>819921.87</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819925.29562 832503.27442 0.00000 819917.71119 832501.42235 0.00000 819918.44488 832498.81471 0.00000 819925.99712 832500.63466 0.00000 819925.29562 832503.27442 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4ad94294-9c2d-48ff-b58d-01bc5b646c8e">
<fme:FEATURE_ID>1000116815</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832492.13</fme:EASTING>
<fme:NORTHING>820716.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820717.99820 832495.65942 0.00000 820713.38769 832491.25026 0.00000 820715.79266 832488.58392 0.00000 820720.36300 832493.04898 0.00000 820717.99820 832495.65942 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide343e314-8c46-4c0a-9466-ca946645b98e">
<fme:FEATURE_ID>1310094376</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832505.17</fme:EASTING>
<fme:NORTHING>820819.43</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240315</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820816.43006 832524.24622 0.00000 820803.37841 832516.02736 0.00000 820822.37747 832485.96636 0.00000 820835.45387 832494.62609 0.00000 820816.43006 832524.24622 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd71de1b1-ca68-49b7-b397-558be078564f">
<fme:FEATURE_ID>1000116856</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832575.47</fme:EASTING>
<fme:NORTHING>820361.14</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820350.18103 832595.23090 0.00000 820340.23572 832588.77568 0.00000 820342.85481 832584.56878 0.00000 820358.11959 832559.01583 0.00000 820361.50948 832554.21349 0.00000 820362.39534 832553.41907 0.00000 820363.24067 832553.12286 0.00000 820364.13640 832553.12347 0.00000 820366.63949 832554.08361 0.00000 820370.49038 832556.89773 0.00000 820382.81103 832569.38178 0.00000 820355.47726 832597.54578 0.00000 820352.92989 832596.54812 0.00000 820350.18103 832595.23090 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8e45fc01-9ad5-43e5-8b0e-4e5af4b22e7d">
<fme:FEATURE_ID>1210046813</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832417.1</fme:EASTING>
<fme:NORTHING>820881.81</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820886.60011 832422.44031 0.00000 820876.30281 832421.48650 0.00000 820877.19765 832411.60981 0.00000 820887.25452 832412.81558 0.00000 820886.60011 832422.44031 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idab942c03-e32a-4b4f-b94a-e0a56e40af90">
<fme:FEATURE_ID>1210013987</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832482.33</fme:EASTING>
<fme:NORTHING>820549.69</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820564.55628 832513.69218 0.00000 820518.18094 832467.80927 0.00000 820534.96891 832450.97163 0.00000 820550.07485 832466.01762 0.00000 820581.18655 832497.00585 0.00000 820573.09130 832505.12839 0.00000 820564.55628 832513.69218 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd48dbaf6-9c79-4d48-9429-9af16c56922a">
<fme:FEATURE_ID>1000117010</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832594.65</fme:EASTING>
<fme:NORTHING>820001.03</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820000.69758 832589.89333 0.00000 820005.81738 832594.50115 0.00000 820001.40575 832599.42843 0.00000 819996.21601 832594.73217 0.00000 820000.69758 832589.89333 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id0cc9827a-2dcd-4c96-8c4b-6e46f243c01a">
<fme:FEATURE_ID>1310097907</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832892.94</fme:EASTING>
<fme:NORTHING>820294.26</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820290.76322 832904.96437 0.00000 820282.16425 832896.69613 0.00000 820297.84084 832880.75495 0.00000 820306.24138 832889.48622 0.00000 820290.76322 832904.96437 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide5e6b232-7041-4579-baa7-951b03112dee">
<fme:FEATURE_ID>1000117119</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832324.03</fme:EASTING>
<fme:NORTHING>820111.76</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820120.12200 832319.48600 0.00000 820114.93500 832320.46000 0.00000 820117.74387 832336.56471 0.00000 820107.97470 832338.38771 0.00000 820104.08332 832314.24880 0.00000 820118.82331 832311.50373 0.00000 820120.12200 832319.48600 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2d287036-1c2f-46c0-9fa0-23b419bb29bc">
<fme:FEATURE_ID>1000116959</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831973</fme:EASTING>
<fme:NORTHING>820126.06</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820124.08124 831977.45602 0.00000 820121.21436 831972.66372 0.00000 820128.05340 831968.56947 0.00000 820130.92012 831973.30263 0.00000 820124.08124 831977.45602 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide01111d9-ac1f-460e-8ca3-effffe3b5baa">
<fme:FEATURE_ID>1000117061</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832808</fme:EASTING>
<fme:NORTHING>819833.86</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819838.83796 832822.98866 0.00000 819818.46027 832804.51188 0.00000 819828.82249 832793.02010 0.00000 819849.27631 832811.47130 0.00000 819838.83796 832822.98866 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf88a67fd-2390-4b36-aff9-115720e2b76c">
<fme:FEATURE_ID>1000116968</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832906.35</fme:EASTING>
<fme:NORTHING>820114.44</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820118.24947 832914.76908 0.00000 820106.13046 832901.58968 0.00000 820109.53571 832897.92582 0.00000 820122.72564 832909.99503 0.00000 820118.24947 832914.76908 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6b4e6153-5ae0-42d4-93b4-48dead24148b">
<fme:FEATURE_ID>1000116923</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832899.64</fme:EASTING>
<fme:NORTHING>820207.99</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820214.17266 832905.28804 0.00000 820199.78292 832897.70916 0.00000 820201.78184 832893.99121 0.00000 820216.19698 832901.57004 0.00000 820214.17266 832905.28804 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8a3b6219-f76e-4284-ae63-f47c2703ba6a">
<fme:FEATURE_ID>1000116970</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832292.33</fme:EASTING>
<fme:NORTHING>820082.61</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820053.01570 832316.65630 0.00000 820046.25850 832280.19870 0.00000 820097.44500 832270.70936 0.00000 820112.25706 832268.11125 0.00000 820118.97830 832304.46220 0.00000 820053.01570 832316.65630 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbede23bd-8147-48ba-8026-1adbb5c88d8b">
<fme:FEATURE_ID>1000117087</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832617.01</fme:EASTING>
<fme:NORTHING>819705.49</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819705.09147 832624.82854 0.00000 819698.38427 832620.50260 0.00000 819705.80977 832609.24742 0.00000 819712.63211 832613.43821 0.00000 819705.09147 832624.82854 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd4497591-5f33-4a0a-a78a-e255d04ff2f3">
<fme:FEATURE_ID>1000116789</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832394.94</fme:EASTING>
<fme:NORTHING>820928.68</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820914.23501 832389.53968 0.00000 820925.56101 832380.74349 0.00000 820925.98151 832380.41691 0.00000 820943.18941 832403.69412 0.00000 820935.42000 832409.93100 0.00000 820926.66200 832398.55000 0.00000 820923.07200 832401.20300 0.00000 820914.23501 832389.53968 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id53f048a5-3af4-447f-8e2c-521cd2ad529e">
<fme:FEATURE_ID>1210080688</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831507</fme:EASTING>
<fme:NORTHING>820240.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820246.59367 831516.59218 0.00000 820238.40773 831516.83437 0.00000 820238.22478 831511.06725 0.00000 820237.75075 831509.18470 0.00000 820232.67080 831501.86959 0.00000 820240.72686 831496.31836 0.00000 820247.27334 831505.83897 0.00000 820245.98648 831506.69057 0.00000 820246.59367 831516.59218 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf8ec756a-ca04-49d8-86a4-cf70ac2ac471">
<fme:FEATURE_ID>1000117033</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832254.57</fme:EASTING>
<fme:NORTHING>819934.23</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819930.77840 832267.02790 0.00000 819926.61028 832244.41596 0.00000 819927.34600 832244.00400 0.00000 819937.66386 832242.07989 0.00000 819941.89110 832264.99540 0.00000 819930.77840 832267.02790 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd09a4959-85a4-49de-ac80-26f703233d12">
<fme:FEATURE_ID>1000116845</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832944.57</fme:EASTING>
<fme:NORTHING>820441.12</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820438.40259 832954.83526 0.00000 820430.89614 832947.37418 0.00000 820443.82524 832934.29639 0.00000 820451.33147 832941.78288 0.00000 820438.40259 832954.83526 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9d3588a3-0675-4ea3-a6cc-da07d8b999e4">
<fme:FEATURE_ID>1000117030</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832476.74</fme:EASTING>
<fme:NORTHING>819942.87</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819944.38610 832481.08282 0.00000 819939.01424 832473.93703 0.00000 819941.25021 832472.37847 0.00000 819946.72388 832479.41446 0.00000 819944.38610 832481.08282 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id97b15210-7d44-4fee-8020-4bf6fe61ef5a">
<fme:FEATURE_ID>1000117043</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832487.57</fme:EASTING>
<fme:NORTHING>819910.95</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819910.38337 832491.97207 0.00000 819906.96805 832485.64450 0.00000 819911.50884 832483.16859 0.00000 819914.92415 832489.49616 0.00000 819910.38337 832491.97207 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2d9601a8-5e4d-4999-9430-c7bd67511f1d">
<fme:FEATURE_ID>1210080687</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831599.98</fme:EASTING>
<fme:NORTHING>820309.74</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820318.89059 831607.19666 0.00000 820310.79139 831613.43243 0.00000 820297.05451 831595.58966 0.00000 820308.74892 831586.48215 0.00000 820322.40515 831604.49071 0.00000 820318.89059 831607.19666 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf426368b-cbdb-4be3-8e26-b4c750a3e84f">
<fme:FEATURE_ID>1000158006</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832687.56</fme:EASTING>
<fme:NORTHING>820661.78</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820666.80352 832699.01931 0.00000 820651.31069 832683.32658 0.00000 820658.07112 832676.65226 0.00000 820667.87167 832686.57927 0.00000 820670.86133 832694.93497 0.00000 820666.80352 832699.01931 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id697b70a8-3f46-4dbf-b8f7-d57030c8a874">
<fme:FEATURE_ID>1000158027</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831443.6</fme:EASTING>
<fme:NORTHING>820369.82</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820358.54772 831458.21415 0.00000 820352.36744 831437.58455 0.00000 820381.08380 831428.98161 0.00000 820387.26408 831449.61121 0.00000 820358.54772 831458.21415 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb49c1b1a-6154-4403-a07a-3627e2bce17a">
<fme:FEATURE_ID>1000117027</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832823.26</fme:EASTING>
<fme:NORTHING>819948.03</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819955.40189 832824.63079 0.00000 819950.74240 832825.15894 0.00000 819951.37800 832830.69897 0.00000 819943.15080 832831.68241 0.00000 819941.62262 832817.56674 0.00000 819954.36986 832816.11619 0.00000 819955.40189 832824.63079 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf0e9ac66-a093-4604-8c07-770c75d39057">
<fme:FEATURE_ID>1000117015</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832551.03</fme:EASTING>
<fme:NORTHING>819984.91</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819985.14508 832553.87979 0.00000 819981.01725 832548.95709 0.00000 819983.54070 832546.80961 0.00000 819988.86200 832553.23460 0.00000 819986.19949 832555.17627 0.00000 819985.14508 832553.87979 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id958cf130-9a2f-4e80-8085-73190e0d48bb">
<fme:FEATURE_ID>1000157986</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832746.85</fme:EASTING>
<fme:NORTHING>820928.47</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820923.12067 832785.17276 0.00000 820896.37474 832768.37017 0.00000 820933.64766 832708.60800 0.00000 820960.63749 832725.35917 0.00000 820923.12067 832785.17276 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd723ce88-cb80-41eb-b744-4f9c4b1bc2bc">
<fme:FEATURE_ID>1000116836</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832576.32</fme:EASTING>
<fme:NORTHING>820499.8</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820499.87393 832580.01233 0.00000 820496.17740 832576.23937 0.00000 820499.61686 832572.63976 0.00000 820503.47603 832576.36155 0.00000 820499.87393 832580.01233 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id56cf0b89-4805-4d40-9eca-75f1cfbb9a17">
<fme:FEATURE_ID>1210047327</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832291.59</fme:EASTING>
<fme:NORTHING>820851.02</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820851.63322 832294.89913 0.00000 820847.76519 832290.51480 0.00000 820850.40082 832288.29821 0.00000 820854.26570 832292.61740 0.00000 820851.63322 832294.89913 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbb9074e1-097f-4bf4-b805-4f2d2af56662">
<fme:FEATURE_ID>1000117049</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832755.18</fme:EASTING>
<fme:NORTHING>819889.49</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819887.50670 832757.70537 0.00000 819887.02220 832753.19777 0.00000 819891.46617 832752.62894 0.00000 819891.92289 832757.22060 0.00000 819887.50670 832757.70537 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id10872f0b-2211-4c0b-ad8a-5552415d7ef1">
<fme:FEATURE_ID>1000116831</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833052.82</fme:EASTING>
<fme:NORTHING>820507.93</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820506.29484 833068.64900 0.00000 820495.06471 833061.73200 0.00000 820510.56754 833035.86580 0.00000 820520.20907 833045.22711 0.00000 820506.29484 833068.64900 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7cf4b7ee-fdfd-48ad-b3b4-834fb50d31f8">
<fme:FEATURE_ID>1000117019</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831766.38</fme:EASTING>
<fme:NORTHING>819966.13</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819977.62120 831783.10280 0.00000 819961.82210 831786.02690 0.00000 819958.90250 831770.23700 0.00000 819959.39560 831770.14200 0.00000 819958.46490 831765.31030 0.00000 819957.99290 831765.40120 0.00000 819955.07360 831749.58780 0.00000 819970.86450 831746.64870 0.00000 819973.78670 831762.45840 0.00000 819968.58240 831763.46090 0.00000 819969.47920 831768.30830 0.00000 819974.68350 831767.30580 0.00000 819977.62120 831783.10280 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide299a2cc-acfe-4aee-9c9f-8f7327955d0b">
<fme:FEATURE_ID>1420015898</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833566.91</fme:EASTING>
<fme:NORTHING>820928.7</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260422</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820953.06879 833588.62828 0.00000 820943.01460 833587.96682 0.00000 820942.71695 833593.15928 0.00000 820935.44089 833592.72933 0.00000 820935.17631 833597.88871 0.00000 820916.59591 833596.89652 0.00000 820917.19122 833587.56994 0.00000 820903.18386 833586.78642 0.00000 820903.67996 833577.98901 0.00000 820897.91628 833577.74330 0.00000 820899.61778 833541.68515 0.00000 820923.44356 833542.98161 0.00000 820923.56262 833540.56067 0.00000 820948.82983 833541.80866 0.00000 820948.36206 833553.23423 0.00000 820963.44334 833553.86924 0.00000 820962.36230 833575.49830 0.00000 820953.92869 833574.96914 0.00000 820953.06879 833588.62828 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4ece5187-d79f-413a-87cc-3a5c286da654">
<fme:FEATURE_ID>1310097904</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831161.44</fme:EASTING>
<fme:NORTHING>820065.68</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250726</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820060.71841 831141.92081 0.00000 820071.03718 831148.27083 0.00000 820080.36376 831155.61303 0.00000 820083.10214 831157.64251 0.00000 820069.13211 831181.77256 0.00000 820056.03521 831174.23192 0.00000 820058.86261 831169.00717 0.00000 820048.28297 831162.69065 0.00000 820060.71841 831141.92081 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida281086f-9699-4fd8-9296-4a42ccaef96d">
<fme:FEATURE_ID>1000116933</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831950.26</fme:EASTING>
<fme:NORTHING>820163.78</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820165.04401 831962.79781 0.00000 820160.11742 831959.50283 0.00000 820161.57402 831957.32154 0.00000 820144.73934 831946.07478 0.00000 820149.25504 831939.36432 0.00000 820166.04767 831950.62213 0.00000 820171.82231 831941.97444 0.00000 820181.96257 831948.71456 0.00000 820176.58645 831956.83587 0.00000 820171.34630 831953.37284 0.00000 820165.04401 831962.79781 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9b4a2bb0-30c1-40bb-b60f-7d2574a8a120">
<fme:FEATURE_ID>1310097905</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831621.34</fme:EASTING>
<fme:NORTHING>820322.99</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820318.72936 831631.86674 0.00000 820311.57230 831622.32399 0.00000 820327.39317 831610.77224 0.00000 820334.29911 831620.44055 0.00000 820318.72936 831631.86674 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id54e2a679-b53c-453e-b99e-028b065a66ff">
<fme:FEATURE_ID>1000116799</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832180.08</fme:EASTING>
<fme:NORTHING>820866.47</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820862.00000 832182.83000 0.00000 820861.23000 832180.33000 0.00000 820870.96000 832177.34000 0.00000 820871.75000 832179.79000 0.00000 820862.00000 832182.83000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id2882750f-d9c3-493f-8a6c-8a315759b69e">
<fme:FEATURE_ID>1000116872</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833024.77</fme:EASTING>
<fme:NORTHING>820325.09</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820326.26288 833028.06695 0.00000 820321.48521 833025.15373 0.00000 820323.95856 833021.41496 0.00000 820328.71098 833024.48753 0.00000 820326.26288 833028.06695 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id71796b3a-6929-4c73-8ca3-a5313e0cf6b5">
<fme:FEATURE_ID>1000116988</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832894.4</fme:EASTING>
<fme:NORTHING>820050.87</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820052.15368 832899.98001 0.00000 820046.59858 832890.73244 0.00000 820049.64208 832888.81869 0.00000 820055.12115 832898.14272 0.00000 820052.15368 832899.98001 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id798caa3e-dafa-4aa4-9d1c-20ea4dc03dfb">
<fme:FEATURE_ID>1000117045</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832268.68</fme:EASTING>
<fme:NORTHING>819900.37</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819898.10105 832283.88564 0.00000 819892.76407 832255.42998 0.00000 819902.77820 832253.52230 0.00000 819907.85261 832282.18181 0.00000 819898.10105 832283.88564 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8624ab9d-965f-498e-8ce6-4f7550bc2a5c">
<fme:FEATURE_ID>1000116798</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832490.8</fme:EASTING>
<fme:NORTHING>820870.06</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820873.98137 832490.05864 0.00000 820868.98852 832498.11822 0.00000 820863.97900 832495.04823 0.00000 820867.67817 832487.80974 0.00000 820873.17514 832483.88250 0.00000 820876.49343 832486.00363 0.00000 820873.98137 832490.05864 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id46ed13f2-e5ef-4899-ae69-9b1b9863ede3">
<fme:FEATURE_ID>1000116850</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832618.4</fme:EASTING>
<fme:NORTHING>820370.43</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820359.60246 832661.25942 0.00000 820322.41007 832623.78779 0.00000 820339.81282 832605.72082 0.00000 820344.61738 832610.43473 0.00000 820349.58407 832605.36237 0.00000 820354.75545 832610.31212 0.00000 820388.96101 832575.36710 0.00000 820416.97017 832604.15183 0.00000 820386.57458 832634.17461 0.00000 820359.60246 832661.25942 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9bff35eb-6aab-4d49-9ab1-68329910845c">
<fme:FEATURE_ID>1000116804</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832418.69</fme:EASTING>
<fme:NORTHING>820833.69</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820840.62900 832444.36600 0.00000 820808.07600 832411.55000 0.00000 820826.75800 832393.01800 0.00000 820859.31100 832425.83400 0.00000 820852.03827 832433.04834 0.00000 820840.62900 832444.36600 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb6cee36b-3bc7-4858-a4db-f5942cefce6f">
<fme:FEATURE_ID>1000117002</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832907.54</fme:EASTING>
<fme:NORTHING>820010.49</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820011.59881 832913.00763 0.00000 820005.31950 832909.73893 0.00000 820009.41782 832902.07459 0.00000 820015.64630 832905.31796 0.00000 820011.59881 832913.00763 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idd77462f9-74ca-445a-94ff-c18c3f371fdb">
<fme:FEATURE_ID>1000116938</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832274.8</fme:EASTING>
<fme:NORTHING>820164</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820168.34805 832279.44175 0.00000 820157.76460 832276.13048 0.00000 820159.61801 832270.21279 0.00000 820170.18944 832273.35846 0.00000 820168.34805 832279.44175 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id67bbfe7e-5ba8-490d-a281-33e1be294e79">
<fme:FEATURE_ID>1000117020</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832531.42</fme:EASTING>
<fme:NORTHING>819963.79</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819969.43189 832546.70522 0.00000 819950.28686 832522.14285 0.00000 819958.02042 832516.12517 0.00000 819977.29212 832540.53468 0.00000 819969.43189 832546.70522 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id40cef1ab-358b-44c7-8267-c7f4c1fb9800">
<fme:FEATURE_ID>1000116994</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832850.87</fme:EASTING>
<fme:NORTHING>820026.9</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820027.05898 832856.70619 0.00000 820024.17231 832845.77277 0.00000 820026.79423 832845.07044 0.00000 820029.60075 832856.08445 0.00000 820027.05898 832856.70619 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id850db59e-cdbd-425d-87cf-734e68f2b1c5">
<fme:FEATURE_ID>1000117003</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832583.87</fme:EASTING>
<fme:NORTHING>820010.76</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820011.04466 832588.71208 0.00000 820005.99143 832583.99063 0.00000 820010.36864 832579.07650 0.00000 820015.57035 832583.63075 0.00000 820011.04466 832588.71208 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide86cda91-3380-49bb-8b08-295e7277f913">
<fme:FEATURE_ID>1000116802</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832522.83</fme:EASTING>
<fme:NORTHING>820855.47</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820861.14519 832524.29036 0.00000 820859.47290 832527.11016 0.00000 820855.05182 832524.34158 0.00000 820853.01043 832527.60425 0.00000 820848.99095 832525.13930 0.00000 820853.92758 832517.27099 0.00000 820862.20942 832522.49585 0.00000 820861.14519 832524.29036 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide53e79cc-2fe5-4c20-ab77-6df0565b02b7">
<fme:FEATURE_ID>1000116907</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832853.56</fme:EASTING>
<fme:NORTHING>820244.49</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820241.09348 832857.46075 0.00000 820239.71949 832851.70046 0.00000 820248.00610 832849.71967 0.00000 820249.22758 832855.35381 0.00000 820241.09348 832857.46075 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idbf079ba3-9686-4745-9b95-29c530e4ab51">
<fme:FEATURE_ID>1210046818</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832517.71</fme:EASTING>
<fme:NORTHING>820522.75</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820516.19036 832535.08122 0.00000 820511.75967 832530.71227 0.00000 820505.34695 832524.38891 0.00000 820517.99497 832511.75929 0.00000 820529.14368 832500.39648 0.00000 820540.28345 832511.20122 0.00000 820528.36900 832522.67400 0.00000 820516.19036 832535.08122 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8314418d-1a6f-42b8-b628-e856701d02c3">
<fme:FEATURE_ID>1000116947</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832831.07</fme:EASTING>
<fme:NORTHING>820145.21</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820145.44859 832839.66774 0.00000 820137.07606 832828.22175 0.00000 820144.83525 832822.56999 0.00000 820153.35533 832833.54207 0.00000 820149.50646 832836.68347 0.00000 820145.44859 832839.66774 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb0113d20-0e25-4084-bb27-1a3dee7a6116">
<fme:FEATURE_ID>1000117029</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831706.79</fme:EASTING>
<fme:NORTHING>819943.41</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819947.36870 831704.72090 0.00000 819947.87700 831707.15990 0.00000 819948.47500 831709.19530 0.00000 819946.32026 831709.96392 0.00000 819944.16294 831710.47181 0.00000 819941.96300 831710.74058 0.00000 819939.67540 831710.76380 0.00000 819938.48910 831704.37190 0.00000 819940.64561 831703.59185 0.00000 819942.80572 831703.07255 0.00000 819945.00962 831702.79218 0.00000 819947.30260 831702.75690 0.00000 819947.36870 831704.72090 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id8522099b-012e-45f2-bd99-c36c5e015c3c">
<fme:FEATURE_ID>1000116904</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832933.95</fme:EASTING>
<fme:NORTHING>820243.29</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820240.89840 832947.56795 0.00000 820233.13170 832924.50937 0.00000 820245.59819 832920.30332 0.00000 820253.51219 832943.34641 0.00000 820240.89840 832947.56795 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idaf7256d0-14ab-4b04-8bb2-2cb5079e4288">
<fme:FEATURE_ID>1000116864</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833159.97</fme:EASTING>
<fme:NORTHING>820342.96</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820348.17412 833162.29869 0.00000 820344.39201 833164.51461 0.00000 820346.94504 833168.82871 0.00000 820342.37747 833171.43049 0.00000 820336.94246 833162.02150 0.00000 820335.01392 833163.13187 0.00000 820331.74122 833157.40466 0.00000 820345.46946 833149.58633 0.00000 820354.14492 833164.63266 0.00000 820350.63943 833166.64486 0.00000 820348.17412 833162.29869 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7176c35d-3639-43c9-9981-546fb34c54dd">
<fme:FEATURE_ID>1000116969</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832921</fme:EASTING>
<fme:NORTHING>820105.32</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820098.52749 832931.91377 0.00000 820091.01082 832924.76674 0.00000 820106.92782 832907.97128 0.00000 820120.06394 832920.38056 0.00000 820112.90578 832927.89407 0.00000 820109.08807 832924.25815 0.00000 820100.22275 832933.52566 0.00000 820098.52749 832931.91377 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf4a6c73d-eedc-40d0-a2fb-e16d775e4c37">
<fme:FEATURE_ID>1000116980</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832160.43</fme:EASTING>
<fme:NORTHING>820069.57</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820066.77160 832187.02220 0.00000 820057.41410 832136.63140 0.00000 820060.47640 832136.06270 0.00000 820059.92265 832133.08051 0.00000 820071.54750 832130.89820 0.00000 820078.83000 832170.13310 0.00000 820082.00020 832187.31770 0.00000 820070.40410 832189.42973 0.00000 820069.85000 832186.45666 0.00000 820066.77160 832187.02220 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id14804b7a-329c-490e-8c0a-0fe0f5104bb3">
<fme:FEATURE_ID>1000116963</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832176.97</fme:EASTING>
<fme:NORTHING>820116.55</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820111.41040 832191.61670 0.00000 820106.08130 832162.84170 0.00000 820121.28870 832160.02590 0.00000 820126.58840 832188.80150 0.00000 820123.68100 832189.34440 0.00000 820123.62886 832191.24500 0.00000 820122.88667 832192.90645 0.00000 820121.57614 832194.16889 0.00000 820119.88812 832194.84849 0.00000 820117.98690 832194.82957 0.00000 820116.31274 832194.11653 0.00000 820115.02758 832192.82826 0.00000 820114.30210 832191.07080 0.00000 820111.41040 832191.61670 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id404b7f4a-dd7d-4d8c-8581-d80841b8f247">
<fme:FEATURE_ID>1000117071</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832546.29</fme:EASTING>
<fme:NORTHING>819795.77</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819793.97625 832550.19043 0.00000 819791.52713 832545.48288 0.00000 819797.44538 832542.35869 0.00000 819800.07170 832547.11099 0.00000 819793.97625 832550.19043 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3354fcd7-5b68-4377-9522-3d9f7296fa9a">
<fme:FEATURE_ID>1210014004</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831405.3</fme:EASTING>
<fme:NORTHING>820176.21</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250726</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820166.23600 831418.14700 0.00000 820160.13500 831407.95200 0.00000 820186.02600 831392.34100 0.00000 820192.17896 831402.92990 0.00000 820166.23600 831418.14700 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3b393a6d-cf40-4a30-bf3d-03139fae5ef6">
<fme:FEATURE_ID>1210046792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833039.81</fme:EASTING>
<fme:NORTHING>820462.28</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820467.26847 833051.68033 0.00000 820450.34268 833034.71589 0.00000 820457.33621 833027.97667 0.00000 820474.19076 833044.85694 0.00000 820467.26847 833051.68033 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id408142f5-ca8d-46b5-8af2-de48c16f3911">
<fme:FEATURE_ID>1000154489</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833133.3</fme:EASTING>
<fme:NORTHING>821003.71</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>821000.00000 833139.68244 0.00000 820997.82271 833138.31650 0.00000 821000.00000 833134.87505 0.00000 821000.00000 833139.68244 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide13ee050-926b-4177-b8d2-dbade1e00b7e">
<fme:FEATURE_ID>1000116958</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832834.75</fme:EASTING>
<fme:NORTHING>820128.25</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820129.82843 832839.77420 0.00000 820124.02107 832831.56838 0.00000 820126.65889 832829.73164 0.00000 820132.46620 832837.91201 0.00000 820129.82843 832839.77420 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id70fecc61-22b6-4ffb-b2e3-0b2d04838ac9">
<fme:FEATURE_ID>1000158072</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832376.21</fme:EASTING>
<fme:NORTHING>819974.8</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819980.01704 832388.85436 0.00000 819971.67789 832390.41543 0.00000 819967.26760 832365.77580 0.00000 819979.06880 832363.61460 0.00000 819982.16760 832380.25162 0.00000 819978.60296 832380.81644 0.00000 819980.01704 832388.85436 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id7e181d15-354d-4160-9124-c3b236a225b3">
<fme:FEATURE_ID>1000116788</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832829.84</fme:EASTING>
<fme:NORTHING>820939.25</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820941.30000 832834.17000 0.00000 820934.48000 832829.87000 0.00000 820937.15000 832825.54000 0.00000 820944.03844 832829.77904 0.00000 820941.30000 832834.17000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id6d64078b-357a-4ee0-9790-be5dbd409670">
<fme:FEATURE_ID>1000116905</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832638.92</fme:EASTING>
<fme:NORTHING>820249.28</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820251.34871 832642.17871 0.00000 820245.60476 832640.28182 0.00000 820246.39936 832637.96770 0.00000 820247.19563 832635.64873 0.00000 820252.96504 832637.57101 0.00000 820251.34871 832642.17871 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id9f86c6a5-cb6a-46f9-b46f-ec9e999b1103">
<fme:FEATURE_ID>1000117112</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832650.92</fme:EASTING>
<fme:NORTHING>820315.77</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820307.15362 832656.10907 0.00000 820293.69781 832669.75258 0.00000 820288.31582 832664.24227 0.00000 820290.56478 832657.69382 0.00000 820301.00758 832642.71666 0.00000 820315.22758 832628.28666 0.00000 820342.65000 832655.31000 0.00000 820328.43000 832669.74000 0.00000 820310.85362 832652.41941 0.00000 820307.15362 832656.10907 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3c56e9cc-2d6d-43ff-b4e3-0fab9191d609">
<fme:FEATURE_ID>1000117060</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832717.16</fme:EASTING>
<fme:NORTHING>819847.1</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819850.59251 832722.62296 0.00000 819841.33197 832714.09494 0.00000 819843.53620 832711.67423 0.00000 819852.89837 832720.22749 0.00000 819850.59251 832722.62296 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ida1935dce-6acd-40c5-9165-5351e8821117">
<fme:FEATURE_ID>1310097922</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832845.89</fme:EASTING>
<fme:NORTHING>819853.64</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819861.50964 832844.61787 0.00000 819840.31647 832868.35104 0.00000 819858.33463 832884.46420 0.00000 819852.22275 832891.13171 0.00000 819832.84247 832873.83361 0.00000 819826.69626 832868.47275 0.00000 819860.39839 832830.80659 0.00000 819915.64350 832880.41606 0.00000 819909.37286 832887.40108 0.00000 819861.50964 832844.61787 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="ide4f98c1e-eebf-4841-b438-5c0e43c7ed47">
<fme:FEATURE_ID>1000116869</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832055.02</fme:EASTING>
<fme:NORTHING>820332.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820336.05528 832059.89066 0.00000 820327.17299 832056.44773 0.00000 820329.66028 832050.10501 0.00000 820338.65179 832053.67951 0.00000 820336.05528 832059.89066 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id789d32c4-4db2-44e5-bdea-08215ab6ae0f">
<fme:FEATURE_ID>1000117024</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831650.74</fme:EASTING>
<fme:NORTHING>819958.88</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>819959.32277 831653.87149 0.00000 819955.72109 831651.02143 0.00000 819958.45810 831647.59271 0.00000 819962.03188 831650.46314 0.00000 819959.32277 831653.87149 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id4884a133-9a9b-4e3b-a962-ff43bae4e3be">
<fme:FEATURE_ID>1000116866</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833059.74</fme:EASTING>
<fme:NORTHING>820326.33</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820352.01199 833070.19045 0.00000 820344.48517 833076.85482 0.00000 820346.83730 833079.52056 0.00000 820341.66261 833084.14642 0.00000 820326.53057 833067.28949 0.00000 820313.44248 833078.72413 0.00000 820286.85891 833049.33987 0.00000 820301.69893 833036.00697 0.00000 820307.69947 833042.76569 0.00000 820311.40479 833039.42789 0.00000 820319.46428 833048.45099 0.00000 820326.79783 833041.88327 0.00000 820334.92198 833051.41371 0.00000 820343.12616 833043.92312 0.00000 820368.63371 833072.30736 0.00000 820360.32285 833079.59897 0.00000 820352.01199 833070.19045 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf4c501cc-f98b-4521-b2fb-f0b5ce439181">
<fme:FEATURE_ID>1000116832</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832569.74</fme:EASTING>
<fme:NORTHING>820509.97</fme:NORTHING>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820510.71094 832576.41992 0.00000 820503.25000 832568.91016 0.00000 820507.93945 832564.59961 0.00000 820509.39062 832563.05078 0.00000 820516.55078 832570.44922 0.00000 820510.71094 832576.41992 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id003791d8-137d-4986-9201-9d58092e6680">
<fme:FEATURE_ID>1000116793</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832139.89</fme:EASTING>
<fme:NORTHING>820888.37</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820860.02773 832157.75578 0.00000 820854.27000 832150.70000 0.00000 820854.93087 832141.57033 0.00000 820853.52000 832137.09000 0.00000 820916.54645 832117.47482 0.00000 820924.33000 832142.23000 0.00000 820877.76084 832156.87233 0.00000 820861.38000 832162.05000 0.00000 820860.02773 832157.75578 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
</gml:FeatureCollection>
