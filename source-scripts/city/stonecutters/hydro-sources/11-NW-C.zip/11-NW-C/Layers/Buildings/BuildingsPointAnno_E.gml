<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingsPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820299.99222 832341.18037</gml:lowerCorner>
<gml:upperCorner>820994.33646 833432.61616</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id52813ea7-ae24-487a-b6d6-aa2f52d24292">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>West Kowloon
Refuse Transfer
Station</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>57.4499921496349</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000591</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832526.34529545</fme:EASTING>
<fme:NORTHING>820945.07424868</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007180</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820945.06035 832526.36708</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id602f483a-d9cd-49d0-8db1-715c50046c15">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pumping
Station</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000750</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832341.180375</fme:EASTING>
<fme:NORTHING>820807.184845</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027100</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820807.17193 832341.18037</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idceefb41f-f71a-47cf-9d87-2b4c7fcd2d4a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Diving Base</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-44.243734586351</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001258</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832753.84042</fme:EASTING>
<fme:NORTHING>820670.67863</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027609</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820670.67863 832753.84042</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id8183d2ac-c742-4a43-bccd-e85816163c56">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Sedimentation Tanks</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210020189</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832461.038</fme:EASTING>
<fme:NORTHING>820615.514</fme:NORTHING>
<fme:LINKFEATURE_ID>1210181339</fme:LINKFEATURE_ID>
<fme:ST_CODE>79186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820615.51401 832461.03766</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id5f2962da-b934-48eb-afa0-3123d110453d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030157</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833206.179</fme:EASTING>
<fme:NORTHING>820976.53</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206936</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820976.52996 833206.17900</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id78dfa80f-3d54-44da-9b91-190a24765244">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030158</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833229.674</fme:EASTING>
<fme:NORTHING>820985.208</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206937</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820985.20831 833229.67404</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida0a4a82f-f0df-4f97-ab10-8af4cb84d42a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030159</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833248.589</fme:EASTING>
<fme:NORTHING>820992.299</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206938</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820992.29916 833248.58903</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0e10d2d0-b6d5-4e3b-b8c0-ea1f7bf4402e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030161</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833278.357</fme:EASTING>
<fme:NORTHING>820994.336</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206940</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820994.33646 833278.35748</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id5f775e7e-06b9-4ee4-a99b-1e67caa44d95">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030162</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833292.727</fme:EASTING>
<fme:NORTHING>820922.19</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207033</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820922.18992 833292.72742</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id1749a359-1efe-4d56-9216-4032b004932c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030163</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833315.349</fme:EASTING>
<fme:NORTHING>820926.291</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207034</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820926.29097 833315.34935</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida37f64ee-886b-4518-b4b9-1c572c6bb00a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030164</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833337.201</fme:EASTING>
<fme:NORTHING>820929.731</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207035</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820929.73057 833337.20121</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id7671a603-24bc-4832-903e-f4e4ea5cc2f2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030165</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833331.91</fme:EASTING>
<fme:NORTHING>820956.057</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207036</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820956.05666 833331.90953</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idcac11122-682c-49bc-a3ba-c0f56ff66279">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030166</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833362.445</fme:EASTING>
<fme:NORTHING>820931.847</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207037</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820931.84723 833362.44528</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idd9da07b6-2930-4646-aa9a-ce1646fbdcf5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030167</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833382.421</fme:EASTING>
<fme:NORTHING>820925.365</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207038</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820925.36493 833382.42136</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id84c12352-fbce-4a3a-b7f3-f972729cdc4d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;FNT name="Microsoft YaHei" size="5.00"&gt;2&lt;/FNT&gt;</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030180</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833406.262</fme:EASTING>
<fme:NORTHING>820899.126</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207032</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820899.12588 833406.26197</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide1c7615b-7a01-4595-87b2-2031fc4dcec7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;FNT name="Microsoft YaHei" size="5.00"&gt;1A&lt;/FNT&gt;</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030181</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833379.825</fme:EASTING>
<fme:NORTHING>820857.586</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207039</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820857.58621 833379.82478</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id873f3495-1e68-4d5f-85ec-c379af9f650c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;FNT name="Microsoft YaHei" size="5.00"&gt;1B&lt;/FNT&gt;</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030182</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833393.446</fme:EASTING>
<fme:NORTHING>820875.578</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207031</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820875.57790 833393.44567</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id6ba6d390-f75b-4912-ba5e-58bc998ec497">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Townplace
West Kowloon</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.2320044820303</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030217</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833432.641</fme:EASTING>
<fme:NORTHING>820846.5</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207190</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820846.47081 833432.61616</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id033207e6-3260-4e0e-a68c-32f60824009a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PG</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>44.1449042141663</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002551</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832921.919</fme:EASTING>
<fme:NORTHING>820379.835</fme:NORTHING>
<fme:LINKFEATURE_ID>1210026763</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820379.83527 832921.91859</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idec43249b-6267-48af-a71f-c402de168815">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>G</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002553</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833026.326</fme:EASTING>
<fme:NORTHING>820493.659</fme:NORTHING>
<fme:LINKFEATURE_ID>1210026880</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820493.65854 833026.32596</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id2cce4295-492e-4930-b778-6098520ff65e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.72522256207958</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002585</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832618.484</fme:EASTING>
<fme:NORTHING>820373.001</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028372</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820373.00080 832618.48356</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ided858756-10d6-476a-96cf-ac21900519c5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002544</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832551.853</fme:EASTING>
<fme:NORTHING>820411.747</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028255</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820411.74676 832551.85266</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id3e622deb-62e8-4c5f-a6e7-6e88ce0d34ab">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>M</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-46.8881597964901</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002548</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832518.914</fme:EASTING>
<fme:NORTHING>820390.702</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027016</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820390.70246 832518.91404</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id583dd68b-fe6a-47f8-862d-2862702494bf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>H</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>45.0000451171248</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002564</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832701.238</fme:EASTING>
<fme:NORTHING>820649.056</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027991</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820649.05581 832701.23765</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idae50096e-6dcf-44b6-9bfb-9da103a5ec50">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PB</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-38.6597972540108</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002584</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832604.45</fme:EASTING>
<fme:NORTHING>820329.164</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027761</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820329.16426 832604.45028</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id970f3fde-1f48-44de-b53f-c499cf56de38">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PH</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-44.9999999915967</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002550</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832944.539</fme:EASTING>
<fme:NORTHING>820440.972</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027868</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820440.97233 832944.53948</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0b5f38ef-e363-4f8d-9c7e-e19c0244ae77">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PC</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.0000000029485</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002586</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832671.087</fme:EASTING>
<fme:NORTHING>820299.992</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007475</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820299.99222 832671.08678</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id3fc50198-cec6-4d59-aeb5-39df1c71627c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>F</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>42.7093207756049</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002552</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832948.312</fme:EASTING>
<fme:NORTHING>820407.169</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028503</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820407.16866 832948.31201</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id5c97f8f6-eb19-4764-965c-101860edc9ab">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>45</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002587</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832894.595</fme:EASTING>
<fme:NORTHING>820360.191</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027136</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820360.19135 832894.59538</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id7182a946-4df6-4f5a-8782-3c06be6ffb32">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PM</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>45.0000637007286</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002545</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832480.079</fme:EASTING>
<fme:NORTHING>820490.814</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027009</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820490.81357 832480.07934</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id06d7cafc-61cf-424a-a625-9631dff24df7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PK</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-30.3508850895711</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002554</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833053.695</fme:EASTING>
<fme:NORTHING>820507.629</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028497</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820507.62856 833053.69510</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idb80230ee-eaf7-4e0a-b469-b3eed32ab8c3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>L</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-44.9999430152526</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002546</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832486.847</fme:EASTING>
<fme:NORTHING>820430.881</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028133</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820430.88075 832486.84680</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idbb089a4f-2671-4a19-9484-ed4c41e75451">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>PN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.0000000076105</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002547</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832458.499</fme:EASTING>
<fme:NORTHING>820456.318</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027494</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820456.31819 832458.49893</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id050da6d1-cea6-41e1-a0e4-3e2b4ac76395">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Swallow
Block</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002549</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832503.668</fme:EASTING>
<fme:NORTHING>820466.52</fme:NORTHING>
<fme:LINKFEATURE_ID>1210026878</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820466.48165 832503.66756</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idbab94c27-af12-455a-834b-5c4450ea2efb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>E</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>44.9999999975285</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002588</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832953.478</fme:EASTING>
<fme:NORTHING>820369.386</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007476</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820369.38556 832953.47845</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
