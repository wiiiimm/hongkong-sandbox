<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingsPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>819897.85238 831720.43583</gml:lowerCorner>
<gml:upperCorner>821011.73949 833739.08967</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5d5084a6-6d65-4b40-8323-680510d8516e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>潛水基地</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-44.6245679232487</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000983</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832761.661</fme:EASTING>
<fme:NORTHING>820679.389</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027609</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820679.27185 832762.08391</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id8f2bb945-b6dc-49fc-b6b6-5a951e562a7f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002872</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832325.58531555</fme:EASTING>
<fme:NORTHING>820819.91866296</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027100</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820822.78504 832339.62178</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id63313c49-df65-40b3-8d6d-c738bcce9071">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>珠江集團
船廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-34.7348369135768</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002951</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832724.42464973</fme:EASTING>
<fme:NORTHING>821017.8557641</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003484</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821011.73949 832746.49876</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="iddcf57d32-b29a-461f-a5d5-c46d80700dc6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>污水泵房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>36.142043486395</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004822</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832410.909</fme:EASTING>
<fme:NORTHING>820921.158</fme:NORTHING>
<fme:LINKFEATURE_ID>1210026722</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820921.40376 832410.88264</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf1e53cea-2f6c-44eb-900d-2145764bb9fe">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西九龍廢物轉運站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>57.6525566760263</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005755</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832492.18289917</fme:EASTING>
<fme:NORTHING>820921.36708127</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007180</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820955.90122 832510.66163</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb339f2d6-ff8f-4e07-87be-14d4c493786e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西北九龍基本
污水處理廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>44.672598222061</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006709</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832565.91</fme:EASTING>
<fme:NORTHING>820550.77</fme:NORTHING>
<fme:LINKFEATURE_ID>1210171143</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820551.16015 832565.52448</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb2c27a9b-c583-4fba-99b4-f0bb03b52545">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.000013389537</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007644</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832433.344</fme:EASTING>
<fme:NORTHING>820523.821</fme:NORTHING>
<fme:LINKFEATURE_ID>1210028118</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820523.91328 832433.55400</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc61bbade-4ee7-4b87-8b88-e182654cb69d">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>副食品批發市場
市場辦事處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.1300158646786</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210016912</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833683.991</fme:EASTING>
<fme:NORTHING>820685.706</fme:NORTHING>
<fme:LINKFEATURE_ID>1210026995</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820686.06547 833683.56047</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id37d28695-fb9f-480d-8c48-4ec443904988">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>沉澱池</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210016913</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832460.062</fme:EASTING>
<fme:NORTHING>820626.793</fme:NORTHING>
<fme:LINKFEATURE_ID>1210181339</fme:LINKFEATURE_ID>
<fme:ST_CODE>79186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820627.00703 832460.42829</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id60e038bb-40d8-4bfe-a3c4-c877afbda8b4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>彗鑽</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210024188</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833739.12</fme:EASTING>
<fme:NORTHING>820951.917</fme:NORTHING>
<fme:LINKFEATURE_ID>1210195749</fme:LINKFEATURE_ID>
<fme:ST_CODE>82620</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820952.13064 833739.08967</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id1e4a9eee-0b2f-4d9a-baca-ddee7bf032bd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>凱碧</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210024629</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833395.846</fme:EASTING>
<fme:NORTHING>820992.235</fme:NORTHING>
<fme:LINKFEATURE_ID>1210196916</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820992.44839 833395.91704</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id6ea9bbb3-0444-41de-a4c7-c16b2487c3af">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>凱葶</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210024631</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833527.94</fme:EASTING>
<fme:NORTHING>820974.322</fme:NORTHING>
<fme:LINKFEATURE_ID>1210196919</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820974.53607 833527.82091</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id57fe1055-8a52-4d6b-b690-6727f7f740c0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>凱旭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210024632</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833493.742</fme:EASTING>
<fme:NORTHING>820924.766</fme:NORTHING>
<fme:LINKFEATURE_ID>1210196918</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820924.97951 833493.89245</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id95344d11-dfc7-45fc-86a8-c67e6302ce42">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>凱曈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210024633</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833440.654</fme:EASTING>
<fme:NORTHING>820938.313</fme:NORTHING>
<fme:LINKFEATURE_ID>1210196917</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820938.52620 833440.60967</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id4a5df3b1-cac5-4808-810b-67c72b8f88f0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>本舍</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.529333431576</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028288</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>833441.99</fme:EASTING>
<fme:NORTHING>820857.44</fme:NORTHING>
<fme:LINKFEATURE_ID>1310207190</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820857.60495 833442.12640</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id45879ef3-95bb-4374-a731-ece0e354c1ea">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>駐香港部隊展覽中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029708</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>831719.85</fme:EASTING>
<fme:NORTHING>819897.639</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206355</fme:LINKFEATURE_ID>
<fme:ST_CODE>79187</fme:ST_CODE>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819897.85238 831720.43583</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc428d6fb-6b4b-424f-b7b7-193687d07878">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>電力供應
及控制樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420003520</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832292.575</fme:EASTING>
<fme:NORTHING>820811.987</fme:NORTHING>
<fme:LINKFEATURE_ID>1210026980</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820812.54708 832292.57479</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb748ef44-c19c-49f4-be26-c890f96641de">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海測樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.2534004601972</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420003561</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832576.657</fme:EASTING>
<fme:NORTHING>820359.696</fme:NORTHING>
<fme:LINKFEATURE_ID>1210027269</fme:LINKFEATURE_ID>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820359.81720 832576.86919</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id24777928-28fe-414b-8c49-7372391b89c1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>倉務大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-44.3703928934354</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420003521</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>832517.584</fme:EASTING>
<fme:NORTHING>820523.01</fme:NORTHING>
<fme:LINKFEATURE_ID>1210171144</fme:LINKFEATURE_ID>
<fme:ST_CODE>79186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820522.93495 832517.96697</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
