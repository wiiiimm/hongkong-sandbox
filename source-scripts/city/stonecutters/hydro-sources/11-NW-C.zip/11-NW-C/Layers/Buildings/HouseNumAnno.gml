<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HouseNumAnno.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820929.84454 833358.64576</gml:lowerCorner>
<gml:upperCorner>820946.55383 833534.37286</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HouseNumAnno gml:id="idb7783521-b9a1-4799-80bd-563a1156b9fc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>8</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-37.4362339872928</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310015307</fme:FEATURE_ID>
<fme:FEATURECODE>HSN</fme:FEATURECODE>
<fme:EASTING>833358.646</fme:EASTING>
<fme:NORTHING>820946.554</fme:NORTHING>
<fme:ADDR_ID/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820946.55383 833358.64576</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HouseNumAnno>
</gml:featureMember>
<gml:featureMember>
<fme:HouseNumAnno gml:id="id820551ce-d16f-4a7d-b28e-c2ad69a2131b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.5490356253686</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420001680</fme:FEATURE_ID>
<fme:FEATURECODE>HSN</fme:FEATURECODE>
<fme:EASTING>833534.373</fme:EASTING>
<fme:NORTHING>820929.845</fme:NORTHING>
<fme:ADDR_ID/>
<fme:ST_CODE>14468</fme:ST_CODE>
<fme:LINKFEATURE_ID>1420003841</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820929.84454 833534.37286</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HouseNumAnno>
</gml:featureMember>
</gml:FeatureCollection>
