<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingsPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>819889.00000 830682.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>820998.00000 833748.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide3f45963-2123-4070-a968-1eba074dfcd7">
<fme:FEATURE_ID>1310206355</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310091443</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831730</fme:EASTING>
<fme:NORTHING>819889</fme:NORTHING>
<fme:ENGLISHNAME>PLA Hong Kong Garrison Exhibition Center</fme:ENGLISHNAME>
<fme:CHINESENAME>駐香港部隊展覽中心</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79187</fme:ST_CODE>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819889.00000 831730.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6045cd6d-34f7-44ab-b9c6-e48b895f4a57">
<fme:FEATURE_ID>1210067416</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000117120</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831416</fme:EASTING>
<fme:NORTHING>820099</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108657033</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13841</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820099.00000 831416.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id60e27006-ebe2-4c6d-8257-fc58855d2f7f">
<fme:FEATURE_ID>1210010043</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116964</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830958</fme:EASTING>
<fme:NORTHING>820114</fme:NORTHING>
<fme:ENGLISHNAME>Stonecutters Island Public Cargo Working Area Administration Office</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲公眾貨物裝卸區辦事處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>70942</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820114.00000 830958.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id28ab84f9-89c0-4976-b106-ae5540c2f9e7">
<fme:FEATURE_ID>1210007615</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116954</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830924</fme:EASTING>
<fme:NORTHING>820135</fme:NORTHING>
<fme:ENGLISHNAME>Public Cargo Working Area Sub-Station</fme:ENGLISHNAME>
<fme:CHINESENAME>公眾貨物裝卸區變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>70942</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820135.00000 830924.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id41fb3752-0560-4185-8351-71cdf6035c76">
<fme:FEATURE_ID>1210000694</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116903</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831252</fme:EASTING>
<fme:NORTHING>820236</fme:NORTHING>
<fme:ENGLISHNAME>Modern Terminals Limited</fme:ENGLISHNAME>
<fme:CHINESENAME>現代貨箱碼頭有限公司</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820236.00000 831252.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id55e0d01b-3b0c-4247-a3e5-c4ad19889536">
<fme:FEATURE_ID>1210010404</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116907</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832854</fme:EASTING>
<fme:NORTHING>820244</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PE</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＥ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820244.00000 832854.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7691243e-0b5b-4081-bb26-d4b833428f49">
<fme:FEATURE_ID>1210028398</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116906</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832867</fme:EASTING>
<fme:NORTHING>820246</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PF</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＦ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820246.00000 832867.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5b46bd65-7f1d-4c7e-9a4f-77f97b0fdd49">
<fme:FEATURE_ID>1210007475</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116879</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832671</fme:EASTING>
<fme:NORTHING>820299</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PC</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＣ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820299.00000 832671.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id91fe092a-e9c9-4ba7-8c42-91320a1b8fa2">
<fme:FEATURE_ID>1210027761</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116868</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832605</fme:EASTING>
<fme:NORTHING>820328</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PB</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＢ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820328.00000 832605.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id30ae4e45-5375-4f3f-817b-c1fba1090b7e">
<fme:FEATURE_ID>1210027136</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116859</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832895</fme:EASTING>
<fme:NORTHING>820360</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block D</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢Ｄ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820360.00000 832895.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0819af38-9aa4-4815-9bca-a40b9512a74d">
<fme:FEATURE_ID>1210027269</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116856</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832573</fme:EASTING>
<fme:NORTHING>820361</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Hydro Building</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢海測樓</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820361.00000 832573.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id38a4f32f-f4b1-4ce7-973c-9af5e755a9d4">
<fme:FEATURE_ID>1210028372</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116850</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832617</fme:EASTING>
<fme:NORTHING>820371</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block B</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢Ｂ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820371.00000 832617.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id48a9d295-7dad-4ec7-8b23-9d4999c84227">
<fme:FEATURE_ID>1210007476</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116853</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832954</fme:EASTING>
<fme:NORTHING>820372</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block E</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢Ｅ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820372.00000 832954.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7639a972-3765-492b-bd27-d6af87a92765">
<fme:FEATURE_ID>1210026763</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116854</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832921</fme:EASTING>
<fme:NORTHING>820378</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PG</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＧ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820378.00000 832921.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9ef23f8d-383a-41a0-b2f2-55ee127f2d12">
<fme:FEATURE_ID>1210027016</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116852</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832524</fme:EASTING>
<fme:NORTHING>820384</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block M</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢Ｍ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820384.00000 832524.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6f640059-e9ba-4812-963a-412f17f38658">
<fme:FEATURE_ID>1210000615</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210001849</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830682</fme:EASTING>
<fme:NORTHING>820385</fme:NORTHING>
<fme:ENGLISHNAME>Substation "A"</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820385.00000 830682.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id54eef37d-542c-4023-afcc-8b4c98aabf95">
<fme:FEATURE_ID>1210028503</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116849</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832938</fme:EASTING>
<fme:NORTHING>820392</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block F</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢Ｆ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820392.00000 832938.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfb661cf5-62d6-4c39-9dd1-4acad009fc2c">
<fme:FEATURE_ID>1210028255</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116848</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832548</fme:EASTING>
<fme:NORTHING>820411</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block A</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢Ａ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820411.00000 832548.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc168bb70-4873-41e7-abd8-22f8dcf21eb8">
<fme:FEATURE_ID>1210028369</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116851</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832524</fme:EASTING>
<fme:NORTHING>820412</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PA</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＡ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820412.00000 832524.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idedad1276-4df9-462a-881e-25d5401add24">
<fme:FEATURE_ID>1210028133</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116847</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832487</fme:EASTING>
<fme:NORTHING>820432</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Hong Lau</fme:ENGLISHNAME>
<fme:CHINESENAME>海康樓</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820432.00000 832487.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc820ccb8-56d1-49e7-be78-f3367e1cc02b">
<fme:FEATURE_ID>1210027868</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116845</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832945</fme:EASTING>
<fme:NORTHING>820440</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PH</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＨ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820440.00000 832945.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6d8b15ca-5390-4d7a-880d-1612933feaad">
<fme:FEATURE_ID>1210027494</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116843</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832459</fme:EASTING>
<fme:NORTHING>820454</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PN</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＮ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820454.00000 832459.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id59e486d3-29f7-40b9-9e10-40fc428ae2b2">
<fme:FEATURE_ID>1210026878</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116839</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832504</fme:EASTING>
<fme:NORTHING>820460</fme:NORTHING>
<fme:ENGLISHNAME>Swallow Block</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820460.00000 832504.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idde3bd93f-7e45-402f-bc00-33e66c32245c">
<fme:FEATURE_ID>1210000614</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116840</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830688</fme:EASTING>
<fme:NORTHING>820481</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Chung Marine Traffic Control Station</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌海上交通控制站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820481.00000 830688.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id099338a5-af59-4429-93e1-96541395cd71">
<fme:FEATURE_ID>1210026880</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116837</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833028</fme:EASTING>
<fme:NORTHING>820493</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block G</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢Ｇ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820493.00000 833028.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id16c6eadc-24b1-41be-8c3f-1746193896d2">
<fme:FEATURE_ID>1210027009</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116833</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832485</fme:EASTING>
<fme:NORTHING>820496</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PM</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＭ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820496.00000 832485.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id53fd75d5-0546-45eb-b8f0-b0024db4c93b">
<fme:FEATURE_ID>1210026752</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116834</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833031</fme:EASTING>
<fme:NORTHING>820503</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PJ</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＪ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820503.00000 833031.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbf9ed5fc-d910-426a-86f3-5b15df6a82d4">
<fme:FEATURE_ID>1210028497</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116831</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833050</fme:EASTING>
<fme:NORTHING>820508</fme:NORTHING>
<fme:ENGLISHNAME>Government Dockyard Block PK</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢ＰＫ座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820508.00000 833050.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id37762fe3-175f-4b38-99ac-dd36548a794c">
<fme:FEATURE_ID>1210171144</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210046818</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832518</fme:EASTING>
<fme:NORTHING>820522</fme:NORTHING>
<fme:ENGLISHNAME>Storage Building</fme:ENGLISHNAME>
<fme:CHINESENAME>倉務大樓</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820522.00000 832518.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6ed0f76a-7ea2-4193-8d32-15d7630559ec">
<fme:FEATURE_ID>1210028118</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116829</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832429</fme:EASTING>
<fme:NORTHING>820526</fme:NORTHING>
<fme:ENGLISHNAME>N W Kowloon Pumping Station</fme:ENGLISHNAME>
<fme:CHINESENAME>西北九龍抽水站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820526.00000 832429.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1eb46648-a1c2-4b92-923d-5f307e2459df">
<fme:FEATURE_ID>1210171143</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116827</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832557</fme:EASTING>
<fme:NORTHING>820555</fme:NORTHING>
<fme:ENGLISHNAME>NWK Preliminary Treatment Works</fme:ENGLISHNAME>
<fme:CHINESENAME>西北九龍基本污水處理廠</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820555.00000 832557.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf806ff63-2b8e-485b-9ad7-bd89b90b2e7d">
<fme:FEATURE_ID>1210163123</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000155265</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833712</fme:EASTING>
<fme:NORTHING>820583</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID>1109620132</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13893</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820583.00000 833712.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1035e172-fa1c-4b88-8b7f-0aa97ea6d934">
<fme:FEATURE_ID>1210192149</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210020523</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831991</fme:EASTING>
<fme:NORTHING>820592</fme:NORTHING>
<fme:ENGLISHNAME>Container Port Road South Temporary Storage Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路臨時倉變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820592.00000 831991.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1401fe64-2b2c-4b15-93fd-d8a3f68760c3">
<fme:FEATURE_ID>1210026872</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000117106</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832625</fme:EASTING>
<fme:NORTHING>820598</fme:NORTHING>
<fme:ENGLISHNAME>Swift Block</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820598.00000 832625.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7a05e072-a963-4d5a-89f4-4d51594b0195">
<fme:FEATURE_ID>1210181339</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116810</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832495</fme:EASTING>
<fme:NORTHING>820610</fme:NORTHING>
<fme:ENGLISHNAME>Stonecutters Island Sewage Treatment Works Sedimentation Tanks</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲污水處理廠沉澱池</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820610.00000 832495.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9fc3f86a-3ddb-43f1-b3a0-669ddceac538">
<fme:FEATURE_ID>1210077442</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116824</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833682</fme:EASTING>
<fme:NORTHING>820615</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID>1109620125</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13893</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820615.00000 833682.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0d3587b6-6158-40dd-8fee-0b1a963e6fe3">
<fme:FEATURE_ID>1210026745</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116824</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833682</fme:EASTING>
<fme:NORTHING>820615</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Wholesale Fish Market</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣魚類批發市場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820615.00000 833682.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9d756bc1-0bd3-4d4b-bdae-0d90db425b5c">
<fme:FEATURE_ID>1210028591</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116821</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832660</fme:EASTING>
<fme:NORTHING>820621</fme:NORTHING>
<fme:ENGLISHNAME>Hong Kong Police Small Boat Division</fme:ENGLISHNAME>
<fme:CHINESENAME>香港警察小艇分區</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820621.00000 832660.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id58305290-5926-4a06-bedf-2fc5da02117e">
<fme:FEATURE_ID>1210027991</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116820</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832702</fme:EASTING>
<fme:NORTHING>820650</fme:NORTHING>
<fme:ENGLISHNAME>Customs Marine Base</fme:ENGLISHNAME>
<fme:CHINESENAME>香港海關船隊基地</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820650.00000 832702.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6f8c285e-a337-4473-818f-f5df06975905">
<fme:FEATURE_ID>1210027856</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000117095</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832717</fme:EASTING>
<fme:NORTHING>820668</fme:NORTHING>
<fme:ENGLISHNAME>Typhoon Block</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820668.00000 832717.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5fb7d8fe-71ee-4706-a449-0c81a5a90c69">
<fme:FEATURE_ID>1210026995</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116814</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833676</fme:EASTING>
<fme:NORTHING>820678</fme:NORTHING>
<fme:ENGLISHNAME>AFCD Cheung Sha Wan Wholesale Food Market Market Office</fme:ENGLISHNAME>
<fme:CHINESENAME>漁農自然護理署長沙灣副食品批發市場市場辦事處</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820678.00000 833676.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4863f1e2-22e1-45e6-bae8-d5d15f4959fb">
<fme:FEATURE_ID>1210027609</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210013979</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832753</fme:EASTING>
<fme:NORTHING>820679</fme:NORTHING>
<fme:ENGLISHNAME>Fire Services Department Diving Base</fme:ENGLISHNAME>
<fme:CHINESENAME>消防處潛水基地</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820679.00000 832753.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf61343da-8de1-47a5-846b-0e01d3a5b58a">
<fme:FEATURE_ID>1210027721</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116810</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832412</fme:EASTING>
<fme:NORTHING>820689</fme:NORTHING>
<fme:ENGLISHNAME>Stonecutters Island Sewage Treatment Works Sedimentation Tanks</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲污水處理廠沉澱池</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820689.00000 832412.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1ed3934b-a6cc-4f46-94c4-5e7bfd0a63b6">
<fme:FEATURE_ID>1210028587</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116813</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832632</fme:EASTING>
<fme:NORTHING>820729</fme:NORTHING>
<fme:ENGLISHNAME>Stonecutters Island Sewage Treatment Works Chemical Dosing Facilities</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲污水處理廠化學劑調控設施</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820729.00000 832632.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7eabdbaf-66ec-4e11-9489-d727da9ade66">
<fme:FEATURE_ID>1210163101</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000155265</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833616</fme:EASTING>
<fme:NORTHING>820753</fme:NORTHING>
<fme:ENGLISHNAME>36</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID>1109620101</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13893</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820753.00000 833616.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8a3217a3-f45a-4680-ac97-20b132bd2d3b">
<fme:FEATURE_ID>1210027215</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116807</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833583</fme:EASTING>
<fme:NORTHING>820759</fme:NORTHING>
<fme:ENGLISHNAME>AFCD Cheung Sha Wan Wholesale Food Market Market Office</fme:ENGLISHNAME>
<fme:CHINESENAME>漁農自然護理署長沙灣副食品批發市場市場辦事處</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820759.00000 833583.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc7a9b47e-1306-4039-ba57-1768c1a546e6">
<fme:FEATURE_ID>1210027100</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116806</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832342</fme:EASTING>
<fme:NORTHING>820811</fme:NORTHING>
<fme:ENGLISHNAME>Stonecutters Island Sewage Treatment Works Main Pumping Station</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲污水處理廠主抽水站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820811.00000 832342.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id894b4aaf-db55-4be9-a21c-cd3ba3d08514">
<fme:FEATURE_ID>1210026980</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116805</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832294</fme:EASTING>
<fme:NORTHING>820815</fme:NORTHING>
<fme:ENGLISHNAME>Stonecutters Island Sewage Treatment Works Switchgear and Control Building</fme:ENGLISHNAME>
<fme:CHINESENAME>電力供應及控制樓</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820815.00000 832294.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide685dd53-3f23-4ac9-814e-1171b3a39ae9">
<fme:FEATURE_ID>1210028464</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116804</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832427</fme:EASTING>
<fme:NORTHING>820835</fme:NORTHING>
<fme:ENGLISHNAME>Stonecutters Island Sewage Treatment Works Administration Building</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲污水處理廠行政大樓</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820835.00000 832427.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id628966b4-9385-4406-8417-544c9ea7db55">
<fme:FEATURE_ID>1310207039</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090821</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833380</fme:EASTING>
<fme:NORTHING>820857</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria III Tower 1 (1A)</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩＩ第１座（１Ａ）</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820857.00000 833380.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7801270f-1dfd-4f68-9edb-b8408a0aefc2">
<fme:FEATURE_ID>1310207190</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090997</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833438.833</fme:EASTING>
<fme:NORTHING>820859.758</fme:NORTHING>
<fme:ENGLISHNAME>Townplace West Kowloon</fme:ENGLISHNAME>
<fme:CHINESENAME>本舍</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231228</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820859.75836 833438.83329 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0f4bb026-b3d3-4fac-84e8-f011f441ab71">
<fme:FEATURE_ID>1310207200</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090997</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833438.833</fme:EASTING>
<fme:NORTHING>820859.758</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID>1910088529</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14468</fme:ST_CODE>
<fme:LASTUPDATEDATE>20231228</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820859.75836 833438.83329 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8fe89990-982f-4708-994a-99ad0732fffe">
<fme:FEATURE_ID>1310207031</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090821</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833391.715</fme:EASTING>
<fme:NORTHING>820872.668</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria III Tower 1 (1B)</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩＩ第１座（１Ｂ）</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820872.66751 833391.71501 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id53c88c82-e5a0-473a-b7d5-f56a7952d95a">
<fme:FEATURE_ID>1210000546</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116794</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832173</fme:EASTING>
<fme:NORTHING>820895</fme:NORTHING>
<fme:ENGLISHNAME>Administration Building</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820895.00000 832173.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3bd5a195-9fc4-41e3-90fd-166306485f19">
<fme:FEATURE_ID>1310207032</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090821</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833406</fme:EASTING>
<fme:NORTHING>820899</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria III Tower 2</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩＩ第２座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820899.00000 833406.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0b3ebf05-2e32-42c3-b7f4-5fdd8db0c7d8">
<fme:FEATURE_ID>1210196918</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210077731</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833493</fme:EASTING>
<fme:NORTHING>820908</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Yuk House</fme:ENGLISHNAME>
<fme:CHINESENAME>凱旭閣</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82890</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820908.00000 833493.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id94d9d40e-2fe2-4e3a-88c7-9b753740db98">
<fme:FEATURE_ID>1310207033</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090819</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833292</fme:EASTING>
<fme:NORTHING>820921</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria II Tower 1</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩ第１座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820921.00000 833292.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id79bed0aa-1960-4b23-8e83-a85cb362eb0b">
<fme:FEATURE_ID>1210196917</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210077727</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833442</fme:EASTING>
<fme:NORTHING>820921</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Tung House</fme:ENGLISHNAME>
<fme:CHINESENAME>凱曈閣</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82890</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820921.00000 833442.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id440d2c37-63f0-46f2-a639-40a6f32267e1">
<fme:FEATURE_ID>1310207034</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090819</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833314</fme:EASTING>
<fme:NORTHING>820924</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria II Tower 2</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩ第２座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820924.00000 833314.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb192f4fc-846c-418a-9ff5-2b2d47277e6e">
<fme:FEATURE_ID>1210026722</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000116789</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832391</fme:EASTING>
<fme:NORTHING>820925</fme:NORTHING>
<fme:ENGLISHNAME>West Kowloon No.2 Sewage Pumping Station</fme:ENGLISHNAME>
<fme:CHINESENAME>西九龍二號污水泵房</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820925.00000 832391.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide413fab2-465b-4952-8954-53e8934d1e6b">
<fme:FEATURE_ID>1310207038</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090819</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833382</fme:EASTING>
<fme:NORTHING>820925</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria II Tower 6</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩ第６座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820925.00000 833382.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4e4b948d-8dc3-4b5b-b7b6-d279df361b59">
<fme:FEATURE_ID>1310207035</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090819</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833338</fme:EASTING>
<fme:NORTHING>820928</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria II Tower 3 (3A)</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩ第３座（３Ａ）</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820928.00000 833338.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id404f7d1f-a67d-40c6-ab62-660d344efe96">
<fme:FEATURE_ID>1420003841</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833579</fme:EASTING>
<fme:NORTHING>820930</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID>1910104543</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14468</fme:ST_CODE>
<fme:LASTUPDATEDATE>20260519</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820930.00000 833579.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb22a44f1-ef96-4b15-930f-0d21732934cb">
<fme:FEATURE_ID>1310207037</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090819</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833362</fme:EASTING>
<fme:NORTHING>820931</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria II Tower 5</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩ第５座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820931.00000 833362.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5a703f6c-549b-45f6-8e24-e067240162f7">
<fme:FEATURE_ID>1210195749</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210076562</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833748</fme:EASTING>
<fme:NORTHING>820940</fme:NORTHING>
<fme:ENGLISHNAME>Cullinan West Aster Sky Mansion</fme:ENGLISHNAME>
<fme:CHINESENAME>匯璽彗鑽匯</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82620</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820940.00000 833748.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id54a06337-23d4-423d-b0be-0258ed2645bb">
<fme:FEATURE_ID>1210196919</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210077729</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833520</fme:EASTING>
<fme:NORTHING>820952</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Ting House</fme:ENGLISHNAME>
<fme:CHINESENAME>凱葶閣</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82890</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820952.00000 833520.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfd01d6e5-5411-4579-b704-f986fd93a6a3">
<fme:FEATURE_ID>1310207036</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090819</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833331</fme:EASTING>
<fme:NORTHING>820953</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria II Tower 3 (3B)</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙ＩＩ第３座（３Ｂ）</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820953.00000 833331.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb012ec76-e62b-44bd-acf4-71eeb15a48bc">
<fme:FEATURE_ID>1210196916</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210077728</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833391</fme:EASTING>
<fme:NORTHING>820957</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Pik House</fme:ENGLISHNAME>
<fme:CHINESENAME>凱碧閣</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82890</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820957.00000 833391.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida8919bd7-2ff9-4269-ade1-b64236b189bb">
<fme:FEATURE_ID>1210074391</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154486</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832696</fme:EASTING>
<fme:NORTHING>820975</fme:NORTHING>
<fme:ENGLISHNAME>95</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID>1109619916</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820975.00000 832696.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc1ccf445-5ab3-4177-a9e1-997d56ace851">
<fme:FEATURE_ID>1210007306</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154486</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832696</fme:EASTING>
<fme:NORTHING>820975</fme:NORTHING>
<fme:ENGLISHNAME>Ocean Shipyard</fme:ENGLISHNAME>
<fme:CHINESENAME>海洋造船廠</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820975.00000 832696.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd37fca89-ea2c-4f92-b266-6a36bcf03676">
<fme:FEATURE_ID>1310206936</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090811</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833207</fme:EASTING>
<fme:NORTHING>820976</fme:NORTHING>
<fme:ENGLISHNAME>Grand VictoriaTower 1</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙Ｉ第１座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820976.00000 833207.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9fe62a6a-d4df-4ab4-b6c4-6d8362470372">
<fme:FEATURE_ID>1310206937</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090811</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833229</fme:EASTING>
<fme:NORTHING>820985</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria I Tower 2</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙Ｉ第２座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820985.00000 833229.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id84c72ba2-ee00-449b-b676-a20ef3f74064">
<fme:FEATURE_ID>1310206938</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090811</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833249</fme:EASTING>
<fme:NORTHING>820992</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria I Tower 3 (3A)</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙Ｉ第３座（３Ａ）</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820992.00000 833249.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide13958f7-1484-48ea-b335-0ae0f6018933">
<fme:FEATURE_ID>1210196920</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210077730</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833470</fme:EASTING>
<fme:NORTHING>820993</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Sha House</fme:ENGLISHNAME>
<fme:CHINESENAME>凱莎閣</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82890</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820993.00000 833470.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida197d7eb-ae8e-4ea5-90df-3b1667013282">
<fme:FEATURE_ID>1310206940</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090811</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833278</fme:EASTING>
<fme:NORTHING>820996</fme:NORTHING>
<fme:ENGLISHNAME>Grand Victoria I Tower 5</fme:ENGLISHNAME>
<fme:CHINESENAME>維港滙Ｉ第５座</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820996.00000 833278.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id238e9864-a0a2-4d55-aac2-d8e199cb9784">
<fme:FEATURE_ID>1310206946</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833230</fme:EASTING>
<fme:NORTHING>820998</fme:NORTHING>
<fme:ENGLISHNAME>6</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ADDR_ID>1910088302</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14468</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820998.00000 833230.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
</gml:FeatureCollection>
