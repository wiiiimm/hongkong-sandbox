<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>819412.89474 830252.26900 0.00000</gml:lowerCorner>
<gml:upperCorner>820971.72000 833727.50034 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPoint gml:id="id6309f8ac-b2fb-4e16-9658-152ec62c9a3e">
<fme:FEATURE_ID>1210035146</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831872.88</fme:EASTING>
<fme:NORTHING>819412.9</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819412.89474 831872.87589 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id13d45c81-3dc5-4647-b84f-8bd5ee94650c">
<fme:FEATURE_ID>1210035311</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831883.91</fme:EASTING>
<fme:NORTHING>819492.14</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819492.14412 831883.90695 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id79c38828-b3e2-4cd2-acb5-da185b08d14c">
<fme:FEATURE_ID>1210035310</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831977.67</fme:EASTING>
<fme:NORTHING>819506.08</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819506.07807 831977.67087 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id689bf84e-5c7d-4832-b79d-7a3849c1069f">
<fme:FEATURE_ID>1000986882</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831843</fme:EASTING>
<fme:NORTHING>819612.12</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819612.12299 831842.99699 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2f4ecdf3-0419-4f75-971e-d2642e5dbc24">
<fme:FEATURE_ID>1000986881</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832275.87</fme:EASTING>
<fme:NORTHING>819661.85</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819661.85154 832275.86602 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5d8bbd29-22b9-4b01-9dee-639bf2db384a">
<fme:FEATURE_ID>1000986880</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832255.42</fme:EASTING>
<fme:NORTHING>819764.91</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819764.90635 832255.42311 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id19a0e5b6-a71b-462b-a505-b84f33b41018">
<fme:FEATURE_ID>1210007881</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832887</fme:EASTING>
<fme:NORTHING>819771</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819771.00000 832887.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idabfbf256-2c84-4342-a923-23bd8e375090">
<fme:FEATURE_ID>1000986865</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831600.36</fme:EASTING>
<fme:NORTHING>819908.98</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819908.97909 831600.36006 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8aabf0e5-49a9-41c6-a8f8-9c12fea78532">
<fme:FEATURE_ID>1210037631</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831641.36</fme:EASTING>
<fme:NORTHING>819921.73</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819921.72706 831641.35710 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id26cf39da-3516-4fef-8968-4e98bdce1658">
<fme:FEATURE_ID>1310057540</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831322</fme:EASTING>
<fme:NORTHING>820049</fme:NORTHING>
<fme:ENGLISHNAME>NGONG WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>昂運路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820049.00000 831322.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcb872e6d-23c8-4de7-85f6-72d24be8a89c">
<fme:FEATURE_ID>1000986887</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832779.86</fme:EASTING>
<fme:NORTHING>820059.47</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820059.46974 832779.86178 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id57b08769-022f-413f-b08e-244ccc2d15f6">
<fme:FEATURE_ID>1210040160</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831047.11</fme:EASTING>
<fme:NORTHING>820107.39</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH (STT 3861)</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路 (STT 3861)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820107.38764 831047.10673 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id94527ef3-989e-4193-8a8c-877afdb968fd">
<fme:FEATURE_ID>1000986864</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830938.57</fme:EASTING>
<fme:NORTHING>820129.94</fme:NORTHING>
<fme:ENGLISHNAME>Public Cargo Working Area Sub-Station</fme:ENGLISHNAME>
<fme:CHINESENAME>公眾貨物裝卸區變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820129.93672 830938.57421 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6d7064ee-5b26-4574-8f07-80f0eeb18ba6">
<fme:FEATURE_ID>1420001957</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830845.7</fme:EASTING>
<fme:NORTHING>820209.81</fme:NORTHING>
<fme:ENGLISHNAME>Container Port Road South</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820209.80799 830845.69766 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbb5fa9aa-ccb2-4c7d-a75f-bfd0c2d1c3c5">
<fme:FEATURE_ID>1210024520</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832846.8</fme:EASTING>
<fme:NORTHING>820242.96</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820242.95646 832846.80395 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id57b652db-410c-4869-a86a-8adc1bd8f03a">
<fme:FEATURE_ID>1210034717</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833258.46</fme:EASTING>
<fme:NORTHING>820257.52</fme:NORTHING>
<fme:ENGLISHNAME>Jetty</fme:ENGLISHNAME>
<fme:CHINESENAME>渡頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820257.51900 833258.45600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0934c4bd-d4df-49d0-9f45-8f240cb26bf1">
<fme:FEATURE_ID>1210033207</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830981.61</fme:EASTING>
<fme:NORTHING>820287.9</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820287.89993 830981.61404 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id159ccb8c-d68b-4e3b-a17c-8ee3c303978a">
<fme:FEATURE_ID>1210033192</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831428.8</fme:EASTING>
<fme:NORTHING>820308.71</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820308.70473 831428.80402 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0b460075-80fb-4764-9046-ee1e4915fd36">
<fme:FEATURE_ID>1210040253</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831640.05</fme:EASTING>
<fme:NORTHING>820352.6</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820352.59583 831640.05371 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2aa14922-1fc4-4517-b66e-c14043453727">
<fme:FEATURE_ID>1210008073</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832798</fme:EASTING>
<fme:NORTHING>820405</fme:NORTHING>
<fme:ENGLISHNAME>Jetty</fme:ENGLISHNAME>
<fme:CHINESENAME>渡頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820405.00000 832798.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2f403eca-da71-41bf-bde4-56aee4d3a3c4">
<fme:FEATURE_ID>1310055394</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832480.03</fme:EASTING>
<fme:NORTHING>820405.66</fme:NORTHING>
<fme:ENGLISHNAME>NGONG SHUNG ROAD near Hoi Hong Lau, Government Dockyard</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船路近政府船塢海康樓</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820405.65668 832480.02582 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcebad64e-94f1-4bea-aebc-92fb761dc196">
<fme:FEATURE_ID>1000986870</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832499.8</fme:EASTING>
<fme:NORTHING>820418.07</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820418.06929 832499.79814 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id07ae81ab-7ce5-46c7-86bd-099752d0091e">
<fme:FEATURE_ID>1210034773</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832648.01</fme:EASTING>
<fme:NORTHING>820437.68</fme:NORTHING>
<fme:ENGLISHNAME>Jetty</fme:ENGLISHNAME>
<fme:CHINESENAME>渡頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820437.67600 832648.01200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb99d3079-9bb2-4dab-b234-5e29e996b1b9">
<fme:FEATURE_ID>1210023969</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830680.58</fme:EASTING>
<fme:NORTHING>820486.54</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Chung Marine Traffic Control Station</fme:ENGLISHNAME>
<fme:CHINESENAME>葵涌海上交通控制站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820486.53565 830680.58086 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id907a4b45-ff3c-44da-9326-c8415bc064b1">
<fme:FEATURE_ID>1210008083</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833723</fme:EASTING>
<fme:NORTHING>820489</fme:NORTHING>
<fme:ENGLISHNAME>Fish Marketing Organization Pier No.1</fme:ENGLISHNAME>
<fme:CHINESENAME>魚類統營處1號碼頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820489.00000 833723.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3bb45905-4b0b-40fd-a41d-aa82c95c5978">
<fme:FEATURE_ID>1210008076</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833670</fme:EASTING>
<fme:NORTHING>820536</fme:NORTHING>
<fme:ENGLISHNAME>Fish Marketing Organization Pier No.2</fme:ENGLISHNAME>
<fme:CHINESENAME>魚類統營處2號碼頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820536.00000 833670.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcd2289df-d6be-4674-88f1-ec30697c3da7">
<fme:FEATURE_ID>1000986861</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832401.75</fme:EASTING>
<fme:NORTHING>820550.39</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820550.38658 832401.75012 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id648bf290-29ee-43d0-8c85-b133945274d8">
<fme:FEATURE_ID>1210015253</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833727.5</fme:EASTING>
<fme:NORTHING>820590.59</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Wholesale Fish Market</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣魚類批發市場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820590.58762 833727.50034 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0cf38b27-99b9-47ee-bc46-1a85bf1bcbe5">
<fme:FEATURE_ID>1210040234</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831502</fme:EASTING>
<fme:NORTHING>820592</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 8</fme:ENGLISHNAME>
<fme:CHINESENAME>八號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820592.00000 831502.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3ebc088b-028e-4892-8abf-55d606ce35d2">
<fme:FEATURE_ID>1210041273</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832003</fme:EASTING>
<fme:NORTHING>820592.15</fme:NORTHING>
<fme:ENGLISHNAME>Container Port Road South Temporary Storage Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路臨時倉變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820592.14768 832003.00252 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9950e041-418c-402b-b358-0f9c0e9f2e23">
<fme:FEATURE_ID>1210035141</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832946.17</fme:EASTING>
<fme:NORTHING>820592.79</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820592.79183 832946.17365 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idfd336ab3-1a12-405a-97bc-16d0707ec6c1">
<fme:FEATURE_ID>1210033196</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831406.59</fme:EASTING>
<fme:NORTHING>820603.65</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820603.64838 831406.58544 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1c7e9aff-4aa0-4dee-8ac5-4c31cc415a11">
<fme:FEATURE_ID>1210007893</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833621.66</fme:EASTING>
<fme:NORTHING>820604.08</fme:NORTHING>
<fme:ENGLISHNAME>Pond Fish Market Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>塘魚市場碼頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820604.07900 833621.66300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4c3ec489-94e9-4e18-907d-b1898834a3f1">
<fme:FEATURE_ID>1210020002</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832656.3</fme:EASTING>
<fme:NORTHING>820625.49</fme:NORTHING>
<fme:ENGLISHNAME>SMALL BOAT DIVISION</fme:ENGLISHNAME>
<fme:CHINESENAME>小艇分區</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820625.49251 832656.30124 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbd31e568-8607-43dd-9774-d8e5605f0ddc">
<fme:FEATURE_ID>1210035140</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832840.88</fme:EASTING>
<fme:NORTHING>820656</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820655.99509 832840.87536 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida8dba775-efed-4d78-8114-ef0a9ef7ddf7">
<fme:FEATURE_ID>1210008039</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833499</fme:EASTING>
<fme:NORTHING>820666.6</fme:NORTHING>
<fme:ENGLISHNAME>Vegetable and Poultry Market Pier No.1</fme:ENGLISHNAME>
<fme:CHINESENAME>蔬菜及家禽市場1號碼頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820666.59900 833499.00100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida6de5bd2-e6a3-442d-b19c-549f93bbccf2">
<fme:FEATURE_ID>1210033060</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831892.28</fme:EASTING>
<fme:NORTHING>820676.18</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820676.18250 831892.28159 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0c4b1429-ea49-474b-8ae9-12e63b13ee9c">
<fme:FEATURE_ID>1210033019</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831674.37</fme:EASTING>
<fme:NORTHING>820687.95</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820687.94522 831674.36753 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id74930732-8737-48eb-b631-65b7af8ec0fb">
<fme:FEATURE_ID>1210035096</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830252.27</fme:EASTING>
<fme:NORTHING>820729.86</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820729.85800 830252.26900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3b57b241-73b3-4dd4-8ab8-f0dc6fc799c0">
<fme:FEATURE_ID>1210008122</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833403.69</fme:EASTING>
<fme:NORTHING>820751.84</fme:NORTHING>
<fme:ENGLISHNAME>Vegetable and Poultry Market Pier No.2</fme:ENGLISHNAME>
<fme:CHINESENAME>蔬菜及家禽市場2號碼頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820751.84000 833403.68600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb1bb717c-be7b-4d5a-bb3a-fd8de6c9dae4">
<fme:FEATURE_ID>1210035099</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830276.33</fme:EASTING>
<fme:NORTHING>820759.38</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820759.38200 830276.32700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf44284f8-af84-48d7-a62c-923a571eb2b4">
<fme:FEATURE_ID>1210011448</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833588.75</fme:EASTING>
<fme:NORTHING>820787.78</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Sha Wan Wholesale Food Market</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣副食品批發市場</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820787.78429 833588.75127 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd8497b5e-a5d2-4fb1-836f-4c023ca8a3f1">
<fme:FEATURE_ID>1210007822</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832813</fme:EASTING>
<fme:NORTHING>820823</fme:NORTHING>
<fme:ENGLISHNAME>Jetty</fme:ENGLISHNAME>
<fme:CHINESENAME>渡頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820823.00000 832813.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id16d700c1-a6ec-44bd-9ace-ad57899a6cbf">
<fme:FEATURE_ID>1310065861</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833421.33</fme:EASTING>
<fme:NORTHING>820830.89</fme:NORTHING>
<fme:ENGLISHNAME>SOHO West</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241003</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820830.89000 833421.32800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id699e1778-8190-4362-9724-1e1b47209f2e">
<fme:FEATURE_ID>1420004974</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HTL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833468.31</fme:EASTING>
<fme:NORTHING>820857.73</fme:NORTHING>
<fme:ENGLISHNAME>TOWNPLACE WEST KOWLOON</fme:ENGLISHNAME>
<fme:CHINESENAME>TOWNPLACE WEST KOWLOON</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260422</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820857.73000 833468.30666 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4570bdd3-30df-4f7b-9204-960413afe60e">
<fme:FEATURE_ID>1000986856</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832501.13</fme:EASTING>
<fme:NORTHING>820901.37</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820901.37437 832501.12549 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id60947164-1ae6-4af9-b696-1c2620af9010">
<fme:FEATURE_ID>1420005292</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833567.34</fme:EASTING>
<fme:NORTHING>820938.09</fme:NORTHING>
<fme:ENGLISHNAME>Father Cucchiara Memorial School</fme:ENGLISHNAME>
<fme:CHINESENAME>郭怡雅神父紀念學校</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820938.09389 833567.34166 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id640c49f2-0ce6-417d-a72b-f7b756b35752">
<fme:FEATURE_ID>1210041231</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833398</fme:EASTING>
<fme:NORTHING>820939</fme:NORTHING>
<fme:ENGLISHNAME>Hoi Ying Estate</fme:ENGLISHNAME>
<fme:CHINESENAME>海盈邨</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820939.00000 833398.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8d6aa8ff-b3ee-450f-bdf9-ac5e17bd48d5">
<fme:FEATURE_ID>1210034747</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832876.99</fme:EASTING>
<fme:NORTHING>820971.72</fme:NORTHING>
<fme:ENGLISHNAME>Jetty</fme:ENGLISHNAME>
<fme:CHINESENAME>渡頭</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820971.72000 832876.99200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
</gml:FeatureCollection>
