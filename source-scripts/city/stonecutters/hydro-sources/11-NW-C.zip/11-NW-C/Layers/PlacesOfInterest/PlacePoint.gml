<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>819737.99701 830960.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>820985.00000 833582.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePoint gml:id="ideb03b598-24d6-4261-9e1c-0ee91d7f1432">
<fme:FEATURE_ID>1001283475</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832054</fme:EASTING>
<fme:NORTHING>819738</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Naval Base</fme:ENGLISHNAME>
<fme:CHINESENAME>海軍基地</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819737.99701 832054.00281 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id36aa9fb1-0c38-4709-8c9d-37ad72c50c56">
<fme:FEATURE_ID>1210006663</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831460</fme:EASTING>
<fme:NORTHING>819970</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Cargo Working Area</fme:ENGLISHNAME>
<fme:CHINESENAME>貨物裝卸區</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819970.00425 831460.00108 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id6689e300-4123-4ff7-911c-f42c3a470d22">
<fme:FEATURE_ID>1310014675</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830960</fme:EASTING>
<fme:NORTHING>820090</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Stonecutters Island Public Cargo Working Area</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲公眾貨物裝卸區</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820090.00000 830960.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id35ee63b9-16f6-4360-9c53-931cfeaa4d2e">
<fme:FEATURE_ID>1210006785</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REB</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832220</fme:EASTING>
<fme:NORTHING>820160</fme:NORTHING>
<fme:ST_CODE>79187</fme:ST_CODE>
<fme:ENGLISHNAME>NGONG SHUEN CHAU BARRACKS</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲軍營</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820160.00118 832219.99496 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id697c2e35-3b03-42af-a612-2afaf94063b8">
<fme:FEATURE_ID>1001278961</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831995</fme:EASTING>
<fme:NORTHING>820298</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Stonecutters Island</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820297.99732 831994.99459 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ida9513bc3-413f-44aa-8eed-2a44228d60a4">
<fme:FEATURE_ID>1001283384</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832593</fme:EASTING>
<fme:NORTHING>820437</fme:NORTHING>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:ENGLISHNAME>Government Dockyard</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820437.00046 832593.00326 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id00d11649-d850-4ced-9f66-32aae0294ed2">
<fme:FEATURE_ID>1210005077</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833030</fme:EASTING>
<fme:NORTHING>820510</fme:NORTHING>
<fme:ST_CODE>76097</fme:ST_CODE>
<fme:ENGLISHNAME>Government Dockyard Fuel and Oil Store</fme:ENGLISHNAME>
<fme:CHINESENAME>政府船塢燃油及滑油庫</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820509.99978 833029.99764 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0d488a6c-c832-4690-855b-5fb08c91b6d0">
<fme:FEATURE_ID>1210010559</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831985</fme:EASTING>
<fme:NORTHING>820555</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Customs and Excise Department Vehicle Detention Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>海關車輛扣押中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20251118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820554.99454 831985.00008 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf08f2bc7-41ac-4cb7-8ed9-7528b75cb731">
<fme:FEATURE_ID>1001283535</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832482</fme:EASTING>
<fme:NORTHING>820649</fme:NORTHING>
<fme:ST_CODE>79186</fme:ST_CODE>
<fme:ENGLISHNAME>Stonecutters Island Sewage Treatment Works</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲污水處理廠</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820649.00398 832481.99751 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id96962255-c1bc-4c67-918c-bd56b1665258">
<fme:FEATURE_ID>1420002409</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833582</fme:EASTING>
<fme:NORTHING>820930</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Father Cucchiara Memorial School</fme:ENGLISHNAME>
<fme:CHINESENAME>郭怡雅神父紀念學校</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20260625</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820930.00000 833582.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ida3ccb71d-3028-4279-8f2b-a0016edcf41c">
<fme:FEATURE_ID>1001283511</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832131</fme:EASTING>
<fme:NORTHING>820940</fme:NORTHING>
<fme:ST_CODE>76133</fme:ST_CODE>
<fme:ENGLISHNAME>COSCO-HIT Terminals (Hong Kong) Limited</fme:ENGLISHNAME>
<fme:CHINESENAME>中遠-國際貨櫃碼頭(香港)有限公司</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820939.99644 832131.00445 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id3f425696-9b6f-43e1-a14c-0616d6bf9613">
<fme:FEATURE_ID>1310015465</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833254</fme:EASTING>
<fme:NORTHING>820951</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Cheung Sha Wan Promenade</fme:ENGLISHNAME>
<fme:CHINESENAME>長沙灣海濱花園</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20231128</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820951.00000 833254.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id3d49c9f2-eab7-4ae1-b42a-79df8b769c60">
<fme:FEATURE_ID>1310012337</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833434</fme:EASTING>
<fme:NORTHING>820985</fme:NORTHING>
<fme:ST_CODE>82890</fme:ST_CODE>
<fme:ENGLISHNAME>Hoi Lok Court</fme:ENGLISHNAME>
<fme:CHINESENAME>凱樂苑</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820985.00000 833434.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
</gml:FeatureCollection>
