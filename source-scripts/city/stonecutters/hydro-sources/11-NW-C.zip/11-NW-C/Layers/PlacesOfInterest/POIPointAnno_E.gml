<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>819753.07303 831124.12187</gml:lowerCorner>
<gml:upperCorner>820961.29082 833708.84659</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idcc4ed1e4-ac89-458f-afae-9f0893e9c431">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pond Fish Market Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000949</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833555.146</fme:EASTING>
<fme:NORTHING>820574.655</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007893</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820574.65517 833555.14609</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idc4c0135d-6c6b-43a0-8ecc-31fcab55dcc0">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001126</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832902.50195061</fme:EASTING>
<fme:NORTHING>819753.07302704</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007881</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819753.07303 832902.50695</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id031946e3-c444-4ccc-ae1a-e86769251750">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Vegetable and Poultry Market
Pier No.1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001166</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833399.807</fme:EASTING>
<fme:NORTHING>820619.83</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008039</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820619.79079 833399.80706</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ideda0429c-ca8c-415f-b625-6f27aea641b9">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Vegetable and Poultry Market
Pier No.2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001169</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833304.216</fme:EASTING>
<fme:NORTHING>820700.586</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008122</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820700.54696 833304.21568</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idfcf2b988-8a42-46a3-bb9b-ec71e2cd19b8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Wholesale Fish
Market</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.3113720602552</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003562</fme:FEATURE_ID>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:EASTING>833708.871</fme:EASTING>
<fme:NORTHING>820566.3</fme:NORTHING>
<fme:LINKFEATURE_ID>1210015253</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820566.27049 833708.84659</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id7d957737-b328-4436-ae1b-4be0e4b74f50">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Wholesale Food Market</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003582</fme:FEATURE_ID>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:EASTING>833589.864</fme:EASTING>
<fme:NORTHING>820759.498</fme:NORTHING>
<fme:LINKFEATURE_ID>1210011448</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820759.49830 833589.86423</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id87b1112a-454f-4674-92e2-582c0af30e7d">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fish Marketing Organization
Pier No.2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007588</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833580.986</fme:EASTING>
<fme:NORTHING>820488.152</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008076</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820488.11280 833580.98587</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idc71bde1f-1984-40cc-9007-f7c3e56545cd">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fish Marketing Organization
Pier No.1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007589</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833642.96</fme:EASTING>
<fme:NORTHING>820436.125</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008083</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820436.08652 833642.95995</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ide5168933-d744-4d91-9cdd-a24af26405b5">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Jetty</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007590</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832852.849</fme:EASTING>
<fme:NORTHING>820787.245</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007822</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820787.24494 832852.84942</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id89b35b3a-a419-4736-a8e5-bdea09b6a01f">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Jetty</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-33.0000037625111</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210009775</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832873.316</fme:EASTING>
<fme:NORTHING>820961.291</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034747</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820961.29082 832873.31627</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id15d12a3f-a25e-45b3-aa8d-ddeb419e637c">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Jetty</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210009776</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833281.711</fme:EASTING>
<fme:NORTHING>820253.029</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034717</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820253.02884 833281.71116</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idd9227f7c-ece1-43e1-a7a0-52e577d32792">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Jetty</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210009777</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832652.953</fme:EASTING>
<fme:NORTHING>820451.645</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034773</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820451.64477 832652.95290</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id4448566b-741e-45b8-86f1-f61be81cca34">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Jetty</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012216</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832780.214</fme:EASTING>
<fme:NORTHING>820387.453</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008073</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820387.45334 832780.21353</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id7d29125d-2404-4ec1-98a2-1e90933ac0dc">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tollgate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-27.6499939490286</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310013396</fme:FEATURE_ID>
<fme:FEATURECODE>TOA</fme:FEATURECODE>
<fme:EASTING>831124.122</fme:EASTING>
<fme:NORTHING>819991.49</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231227</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819991.48962 831124.12187</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
