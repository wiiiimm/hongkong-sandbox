<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>819763.74936 830689.68698</gml:lowerCorner>
<gml:upperCorner>820978.35765 833720.02497</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idb28f49c3-1123-4f7a-a465-51732c511f4f">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>蔬菜及家禽市場2號碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001220</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833325.757</fme:EASTING>
<fme:NORTHING>820717.469</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008122</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820717.68251 833324.18885</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="ida43de73c-2611-48f5-8500-ac671e357964">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>蔬菜及家禽市場1號碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001298</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833421.662</fme:EASTING>
<fme:NORTHING>820636.189</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008039</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820636.40262 833420.46479</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idc3adc9d0-3bfb-4ace-9c79-2da7195fb1a6">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001361</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832901.5735177</fme:EASTING>
<fme:NORTHING>819763.7493629</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007881</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819763.74936 832901.57402</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id2374a2cd-9564-4f0d-8e0e-34e8f0b126ea">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>塘魚市場碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001443</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833580.839</fme:EASTING>
<fme:NORTHING>820586.739</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007893</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820586.95259 833580.16416</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id148de5ab-dcfe-41ab-b582-e82560fa2667">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>魚類批發市場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.2326378863979</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003505</fme:FEATURE_ID>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:EASTING>833719.309</fme:EASTING>
<fme:NORTHING>820578.41</fme:NORTHING>
<fme:LINKFEATURE_ID>1210015253</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820578.10180 833720.02497</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id9a131ee6-1a26-4ca4-981c-e9b6093e5846">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>副食品批發市場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003525</fme:FEATURE_ID>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:EASTING>833588.973</fme:EASTING>
<fme:NORTHING>820772.187</fme:NORTHING>
<fme:LINKFEATURE_ID>1210011448</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820772.40091 833589.29489</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id8e0d88bc-2784-4398-b2fa-80f118c7c17b">
<fme:AnnotationClassID>8</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海上交通
控制站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003526</fme:FEATURE_ID>
<fme:FEATURECODE>SGN</fme:FEATURECODE>
<fme:EASTING>830689.687</fme:EASTING>
<fme:NORTHING>820454.674</fme:NORTHING>
<fme:LINKFEATURE_ID>1210023969</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820455.23462 830689.68698</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idce836f7f-ca2f-47c0-ac04-9de3b60c8cee">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>魚類統營處2號碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008437</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833608.398</fme:EASTING>
<fme:NORTHING>820505.191</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008076</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820505.40456 833609.74964</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id9b09a81f-fa43-4e73-8f73-928aaaa85120">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>魚類統營處1號碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008438</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833670.332</fme:EASTING>
<fme:NORTHING>820452.272</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008083</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820452.48596 833671.31392</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idac0c7bbd-252e-4a47-934c-4678f91f0908">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渡頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008439</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832852.81</fme:EASTING>
<fme:NORTHING>820798.504</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007822</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820798.71784 832852.88970</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id41e4271e-4e06-4177-b744-8213141c5500">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>八號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011882</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>831571.193</fme:EASTING>
<fme:NORTHING>820583.216</fme:NORTHING>
<fme:LINKFEATURE_ID>1210040234</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820583.47235 831572.19320</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id3e460532-7cff-4dc7-8275-159c8c609b29">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渡頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.9999940146671</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011883</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832884.779</fme:EASTING>
<fme:NORTHING>820978.219</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034747</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820978.35765 832884.95959</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id642cec5d-9cce-45df-aa23-faa8feef9dcc">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渡頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011884</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>833281.489</fme:EASTING>
<fme:NORTHING>820264.568</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034717</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820264.78185 833281.56887</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="ide3b5bb03-dc13-4919-8772-01a57f9485fd">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渡頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011885</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832653.221</fme:EASTING>
<fme:NORTHING>820462.466</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034773</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820462.67983 832653.30012</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idf506a7d5-5b1c-49d2-9227-daf464ab4af1">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渡頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015751</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>832779.584</fme:EASTING>
<fme:NORTHING>820399.173</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008073</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820399.38619 832779.66296</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id663ab0a9-e1a8-4bfa-a9c1-5ab0085d360d">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>收費站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-27.5799901851281</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310017953</fme:FEATURE_ID>
<fme:FEATURECODE>TOA</fme:FEATURECODE>
<fme:EASTING>831126.326</fme:EASTING>
<fme:NORTHING>820002.119</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231227</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820002.36317 831126.31977</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id67a9dfe4-9839-44ee-bb8f-8dae2f524358">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>小艇分區</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>44.8976223678914</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002862</fme:FEATURE_ID>
<fme:FEATURECODE>GOF</fme:FEATURECODE>
<fme:EASTING>832663.039</fme:EASTING>
<fme:NORTHING>820613.64</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820613.97152 832663.06969</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
