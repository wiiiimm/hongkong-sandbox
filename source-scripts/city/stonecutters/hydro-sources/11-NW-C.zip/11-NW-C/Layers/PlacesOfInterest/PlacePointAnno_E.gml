<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>819538.02735 830694.93191</gml:lowerCorner>
<gml:upperCorner>820969.53438 833446.86070</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idfa26ce6f-b1ad-4fb0-b81f-22e4ba975531">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>STONECUTTERS ISLAND</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972042</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>832217.383</fme:EASTING>
<fme:NORTHING>820494.505</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME>Ngong Shuen Chau</fme:ALIAS_ENGLISHNAME>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278961</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820494.50474 832217.38334</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id687083a2-b5d1-44b9-9ea2-f2e50c27029e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Breakwater</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>11.4742961765506</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972044</fme:FEATURE_ID>
<fme:FEATURECODE>TYP</fme:FEATURECODE>
<fme:EASTING>832156.06584729</fme:EASTING>
<fme:NORTHING>819529.89653207</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819538.02735 832180.75206</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id4d0ec94b-7bdc-42a2-9e07-3d32ec0c220b">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stonecutters Island Public Cargo Working Area</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-28.9760855241016</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972049</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>830951.022</fme:EASTING>
<fme:NORTHING>820093.492</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70942</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310014675</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820093.49204 830951.02229</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id36e6815a-26ba-465c-a66e-8ec96ebe54bc">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Ngong Shuen Chau Barracks</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>8</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972048</fme:FEATURE_ID>
<fme:FEATURECODE>REB</fme:FEATURECODE>
<fme:EASTING>832043.295</fme:EASTING>
<fme:NORTHING>819966.353</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79187</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006785</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820206.94195 831990.47155</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id6ae2d953-b7e3-4b12-82b6-8f22fb99f2cc">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cargo Working Area</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972056</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>831411.606</fme:EASTING>
<fme:NORTHING>819971.787</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210006663</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819971.78684 831411.60610</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9fe1f115-4513-41d8-a6af-ec6ce8981e84">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Government
Dockyard</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.0000101348965</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972052</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832616.26358004</fme:EASTING>
<fme:NORTHING>820411.60670776</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820397.66813 832641.04260</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id6e28780a-12cd-4ebe-8ead-22fb74a1c272">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972053</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832675.50834416</fme:EASTING>
<fme:NORTHING>820308.87561342</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820311.93313 832708.22605</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id0d5296cc-1103-448a-bddb-4ca9e8393950">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Naval Base</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972047</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832046.937</fme:EASTING>
<fme:NORTHING>819712.002</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001283475</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819712.00214 832046.93731</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id34918ddf-ad04-4743-9661-7d3360abfa88">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Breakwater</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.4768517938036</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972043</fme:FEATURE_ID>
<fme:FEATURECODE>TYP</fme:FEATURECODE>
<fme:EASTING>832940.74143532</fme:EASTING>
<fme:NORTHING>820577.34712724</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820559.77265 832969.44641</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id24f06675-1a88-4bc5-b8bb-74e0ed80e110">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972051</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832876.54062924</fme:EASTING>
<fme:NORTHING>820292.92637739</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820292.92638 832876.54563</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idc77ad0ad-1ca5-4dc2-8aca-314d64584897">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>RAMBLER CHANNEL</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>11.0000000018626</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000972057</fme:FEATURE_ID>
<fme:FEATURECODE>BAY</fme:FEATURECODE>
<fme:EASTING>830584.82944506</fme:EASTING>
<fme:NORTHING>820771.46783127</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001281817</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820778.19439 830694.93191</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id143385eb-b04e-445f-acfd-2dd5a76f4727">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Stonecutters Island
Sewage Treatment Works</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007997</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>832402.703</fme:EASTING>
<fme:NORTHING>820693.101</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79186</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283535</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820693.05923 832402.70328</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id70a520de-408f-45a3-9d72-671504f7a970">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>(NGONG SHUEN CHAU)</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012820</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>832218.668</fme:EASTING>
<fme:NORTHING>820457.396</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME>Ngong Shuen Chau</fme:ALIAS_ENGLISHNAME>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278961</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820457.39575 832218.66774</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id34e1c9d2-4f4c-4908-9683-4808b9f7dee6">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hoi Lok Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210013939</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833446.861</fme:EASTING>
<fme:NORTHING>820969.534</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310012337</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820969.53438 833446.86070</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idb858c6a9-9d03-47a0-bb9d-945a56597cff">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cheung Sha Wan Promenade</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-32.0398101340266</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310016940</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>833290.412</fme:EASTING>
<fme:NORTHING>820895.338</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015465</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820895.33798 833290.41160</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id5bd55a88-b876-42bc-9d62-76fb1c86bc13">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Grand Victoria</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-33.8154308623581</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310016941</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>833285.342</fme:EASTING>
<fme:NORTHING>820952.491</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015452</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240229</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820952.49077 833285.34164</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
