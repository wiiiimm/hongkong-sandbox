<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820025.34000 830383.80900 0.00000</gml:lowerCorner>
<gml:upperCorner>820973.56700 833675.93900 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPoint gml:id="idb21ff593-e9c3-4dc2-8367-cc305d2e5ebd">
<fme:FEATURE_ID>1210016551</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831539.971</fme:EASTING>
<fme:NORTHING>820025.34</fme:NORTHING>
<fme:ENGLISHNAME>CHI NGONG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>志昂路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13842</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820025.34000 831539.97100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="iddeff78a3-4c22-46ea-8a99-03182924eb31">
<fme:FEATURE_ID>1210018152</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831346.372</fme:EASTING>
<fme:NORTHING>820091.152</fme:NORTHING>
<fme:ENGLISHNAME>NGONG WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>昂運路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13841</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820091.15200 831346.37200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id54d6273f-f46a-456c-8c6a-cc976a66fae8">
<fme:FEATURE_ID>1210016314</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831015.539</fme:EASTING>
<fme:NORTHING>820162.426</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820162.42600 831015.53900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id536bd3d8-db10-4cdb-959d-0d37279a0bd2">
<fme:FEATURE_ID>1210016552</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831586.068</fme:EASTING>
<fme:NORTHING>820374.73</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820374.73000 831586.06800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ide2870de7-8cd0-4ef6-8331-320d49022c54">
<fme:FEATURE_ID>1210018153</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>831845.017</fme:EASTING>
<fme:NORTHING>820531.433</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820531.43300 831845.01700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id3009e0c7-bdcb-4491-b74d-64335c758d6b">
<fme:FEATURE_ID>1210003245</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>830383.809</fme:EASTING>
<fme:NORTHING>820686.472</fme:NORTHING>
<fme:ENGLISHNAME>STONECUTTERS BRIDGE</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船洲大橋</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39537</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820686.47200 830383.80900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id3ccc8d99-c80e-4045-91f6-7c79f65a1869">
<fme:FEATURE_ID>1210016037</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832269.836</fme:EASTING>
<fme:NORTHING>820695.023</fme:NORTHING>
<fme:ENGLISHNAME>NGONG SHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13898</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820695.02300 832269.83600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id27c9099c-9964-42d5-baa2-33bbc1758f63">
<fme:FEATURE_ID>1210015953</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832340.059</fme:EASTING>
<fme:NORTHING>820884.759</fme:NORTHING>
<fme:ENGLISHNAME>NGONG SHUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>昂船路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13898</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820884.75900 832340.05900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idfe36c374-835f-4670-b9fc-dc69b9673445">
<fme:FEATURE_ID>1210028031</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833410.623</fme:EASTING>
<fme:NORTHING>820925.487</fme:NORTHING>
<fme:ENGLISHNAME>LAI YING STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>荔盈街</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14468</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820925.48705 833410.62265 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id14a59eef-7da2-408d-aaef-061ba426f957">
<fme:FEATURE_ID>1210016550</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832277.768</fme:EASTING>
<fme:NORTHING>820928.832</fme:NORTHING>
<fme:ENGLISHNAME>HING WAH STREET WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>興華街西</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820928.83200 832277.76800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ideeaa5152-cc98-4ba1-a658-39d1466e905e">
<fme:FEATURE_ID>1210016034</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832352.948</fme:EASTING>
<fme:NORTHING>820947.121</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820947.12100 832352.94800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idcc93d9a3-9bb4-4d1d-b82b-1c16f173e1bf">
<fme:FEATURE_ID>1210007594</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>833675.939</fme:EASTING>
<fme:NORTHING>820972.775</fme:NORTHING>
<fme:ENGLISHNAME>WEST KOWLOON HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>西九龍公路</fme:CHINESENAME>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13885</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820972.77500 833675.93900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7a6bcd2a-9898-4b68-8a7e-42c21f3ef996">
<fme:FEATURE_ID>1210018145</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>832197.989</fme:EASTING>
<fme:NORTHING>820973.567</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER PORT ROAD SOUTH</fme:ENGLISHNAME>
<fme:CHINESENAME>貨櫃碼頭南路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820973.56700 832197.98900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
</gml:FeatureCollection>
