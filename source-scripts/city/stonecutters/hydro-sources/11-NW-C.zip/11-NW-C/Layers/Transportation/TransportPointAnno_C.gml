<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820035.51050 830250.50352</gml:lowerCorner>
<gml:upperCorner>820991.51672 833688.41118</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id5b0b0439-44b4-4e0d-9b24-08e26f1cb44f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>志昂路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000663</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831502.14499611</fme:EASTING>
<fme:NORTHING>820102.01412896</fme:NORTHING>
<fme:ST_CODE>13842</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016551</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820089.66103 831510.45489</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id0cc1adf4-4e18-4904-a579-03deef3bc068">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨櫃碼頭南路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.1023341744919</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001739</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832187.24153075</fme:EASTING>
<fme:NORTHING>820981.60325839</fme:NORTHING>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018145</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820954.83398 832198.89872</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id02124d87-9d0c-42c5-80f7-8a2f75cd0378">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨櫃碼頭南路（地面）</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001295</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>830977.28621764</fme:EASTING>
<fme:NORTHING>820180.0553728</fme:NORTHING>
<fme:ST_CODE>10332</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016314</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820181.62334 830973.47209</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id4b495fc9-bac8-4a68-8369-92f9fe628eb3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西九龍公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003392</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833666.58495512</fme:EASTING>
<fme:NORTHING>820974.51706358</fme:NORTHING>
<fme:ST_CODE>13885</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007594</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820962.54979 833688.41118</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idff7583e1-c092-4c65-a0cf-77b173243294">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>昂船洲大橋</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.4173926108276</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002808</fme:FEATURE_ID>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:EASTING>830201.31538816</fme:EASTING>
<fme:NORTHING>820794.52939949</fme:NORTHING>
<fme:ST_CODE>39537</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003245</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820802.17778 830250.50352</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id316e0d8e-629f-4725-ae56-a96eadef6f50">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>昂船路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>15.3574892490687</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002603</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832323.99349012</fme:EASTING>
<fme:NORTHING>820881.75199946</fme:NORTHING>
<fme:ST_CODE>13898</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015953</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820887.18271 832343.76685</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id6dadc798-d8a1-4a11-aced-1d471153487e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>興華街西</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003606</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832586.27632168</fme:EASTING>
<fme:NORTHING>820990.94318565</fme:NORTHING>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015744</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820991.51672 832606.94191</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9ba31eee-d0f8-4b74-92e8-1d2e09d8a166">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青沙公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>37.763066732718</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003314</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831668.10140507</fme:EASTING>
<fme:NORTHING>820419.46489385</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016552</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820438.82276 831686.53788</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idf3a7eb24-b98d-4d1f-8042-cad1215cf1c0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>昂運路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>31.6808378514853</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002680</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831285.295</fme:EASTING>
<fme:NORTHING>820035.51</fme:NORTHING>
<fme:ST_CODE>13841</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018152</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820035.51050 831285.29486</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
