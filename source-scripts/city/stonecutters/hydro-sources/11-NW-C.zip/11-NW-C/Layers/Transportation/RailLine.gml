<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme RailLine.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820905.70672 833611.31874 0.00000</gml:lowerCorner>
<gml:upperCorner>821000.00000 833750.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:RailLine gml:id="idf4e0ebe5-3649-465e-b3d4-bf4f39050e54">
<fme:FEATURE_ID>1001146059</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>UG</fme:DATALEVEL>
<fme:DISPLAY>8</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 833707.91431 0.00000 820992.78500 833717.70300 0.00000 820967.66617 833750.00000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:RailLine>
</gml:featureMember>
<gml:featureMember>
<fme:RailLine gml:id="id9acdd9e9-ffa7-4786-bc61-c29f59b6a56c">
<fme:FEATURE_ID>1001146049</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MTR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>UG</fme:DATALEVEL>
<fme:DISPLAY>8</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820905.70672 833750.00000 0.00000 821000.00000 833611.31874 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:RailLine>
</gml:featureMember>
</gml:FeatureCollection>
