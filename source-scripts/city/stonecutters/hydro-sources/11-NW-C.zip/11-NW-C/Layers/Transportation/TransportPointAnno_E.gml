<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820016.49328 830426.51864</gml:lowerCorner>
<gml:upperCorner>820953.37174 833673.37321</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ida8179da2-7245-4cee-8ed1-65eff969517a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>WEST KOWLOON HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000425</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833616.91417401</fme:EASTING>
<fme:NORTHING>820988.5544499</fme:NORTHING>
<fme:ST_CODE>13885</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007594</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820953.37174 833673.37321</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc4f0c3d3-0f08-459e-940a-14e13ae26ed4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>NGONG SHUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000630</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832243.65344665</fme:EASTING>
<fme:NORTHING>820737.54372644</fme:NORTHING>
<fme:ST_CODE>13898</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016037</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820684.48056 832277.93269</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id760d3aeb-0005-46eb-accb-6ac24ab010c2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHI NGONG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001703</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831522.66854653</fme:EASTING>
<fme:NORTHING>820055.47179539</fme:NORTHING>
<fme:ST_CODE>13842</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016551</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820016.49328 831545.53675</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc8992723-7705-4ba8-975e-39e09271eaea">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HING WAH STREET WEST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>36.9683439373118</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001406</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832256.39940962</fme:EASTING>
<fme:NORTHING>820908.95978911</fme:NORTHING>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016550</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820950.61395 832306.65570</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ide4f51d51-4594-4fe9-b6bc-8a32e0259a56">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>NGONG WAN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>34.936253590289</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002540</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831354.07477796</fme:EASTING>
<fme:NORTHING>820082.21173061</fme:NORTHING>
<fme:ST_CODE>13841</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018152</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820111.50756 831396.01279</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idaabb26c7-a9ae-4174-9ba7-7c655f181d26">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>STONECUTTERS BRIDGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.644173514531</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002378</fme:FEATURE_ID>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:EASTING>830352.86535275</fme:EASTING>
<fme:NORTHING>820666.81471979</fme:NORTHING>
<fme:ST_CODE>39537</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003245</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820656.47731 830426.51864</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id7a20f047-6175-4d93-9891-752f6c14e93a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING SHA HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>36.9137488429462</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001823</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>831836.8157375</fme:EASTING>
<fme:NORTHING>820545.68802321</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210018153</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820594.10381 831894.14034</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc51590e3-caf5-472e-a1b1-ad5f8d132c6b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HING WAH STREET WEST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>36.9683439373118</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003727</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>832306.655695</fme:EASTING>
<fme:NORTHING>820950.613945</fme:NORTHING>
<fme:ST_CODE>13896</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016550</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820950.61395 832306.65570</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id71e5d969-87b7-4038-95d1-26b2177b7992">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LAI YING STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-35.7315930138549</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007662</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>833441.987</fme:EASTING>
<fme:NORTHING>820903.538</fme:NORTHING>
<fme:ST_CODE>14468</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210028031</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820903.53786 833441.98667</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
