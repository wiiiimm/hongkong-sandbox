<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyLineAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>819843.72604 830964.94827</gml:lowerCorner>
<gml:upperCorner>820934.92646 833452.13552</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id8f49b61b-82b6-4e84-9ad6-d63b60716533">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HWM</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>41.1214901717974</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832509</fme:FEATURE_ID>
<fme:FEATURECODE>HWM</fme:FEATURECODE>
<fme:EASTING>833044.56360545</fme:EASTING>
<fme:NORTHING>820152.06068892</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820164.13665 833052.81713</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="idf92a4f4a-f5c7-45b5-82d8-786f790e3047">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HWM</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.9710028019122</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832510</fme:FEATURE_ID>
<fme:FEATURECODE>HWM</fme:FEATURECODE>
<fme:EASTING>832467.69290561</fme:EASTING>
<fme:NORTHING>819853.59385398</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819845.96349 832480.17198</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id4e639a1e-1f50-4b5a-87fb-db30dbb0c917">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.6182442108293</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832517</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>831315.88181359</fme:EASTING>
<fme:NORTHING>820743.75031107</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820752.04627 831331.90338</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id55e5d225-71c9-4948-8207-1228b8a8f480">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>58.0419019624095</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832515</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>832581.87647037</fme:EASTING>
<fme:NORTHING>820918.22205748</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820934.92646 832588.69384</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id55eb23ff-9502-4249-9ba3-41ef28a2f4b2">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.4790468357711</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832512</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>833436.62564476</fme:EASTING>
<fme:NORTHING>820760.34023897</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820751.12302 833452.13552</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id61cce70b-07ee-41f1-945e-b2c0374b0599">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>^</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-142.187040700848</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001273199</fme:FEATURE_ID>
<fme:FEATURECODE>DAS</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820148.23794 832010.66741</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="ide85f8e0b-12c3-40b1-8a42-e5a4295e7b2d">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-28.4429282172186</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832516</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>830919.59653899</fme:EASTING>
<fme:NORTHING>820084.0388409</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820059.47332 830964.94827</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id3faf4b98-3d0e-4999-ab8a-b07417ed1e41">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>10.092577489818</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832511</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>832007.10471721</fme:EASTING>
<fme:NORTHING>819940.09044654</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819945.96761 832040.12366</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id388c5fc9-b212-4bcd-8426-cc23c2ed5726">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Floating Jetty</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832520</fme:FEATURE_ID>
<fme:FEATURECODE>JET</fme:FEATURECODE>
<fme:EASTING>832872.982</fme:EASTING>
<fme:NORTHING>820484.2</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820484.19976 832872.98194</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id035092d2-4f67-46c4-b069-b7cbdeaf40b7">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.0000144662603</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832513</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>832741.07913364</fme:EASTING>
<fme:NORTHING>820340.09823611</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820330.19885 832750.97852</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="ide1be7ab6-5c85-40e1-88e3-e28877e07d07">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>64.9163385813931</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832514</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>832911.42664223</fme:EASTING>
<fme:NORTHING>819826.32572809</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819843.72604 832916.19558</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id0dada90c-f4e6-49d2-a960-86a47da257f2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Floating Jetty</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>45.0000047607209</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000832521</fme:FEATURE_ID>
<fme:FEATURECODE>JET</fme:FEATURECODE>
<fme:EASTING>832704.15500503</fme:EASTING>
<fme:NORTHING>820477.39260433</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820502.36978 832724.80819</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id1c33d31f-673f-4d4c-a85f-5be7134a6846">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Slipways</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.9891362478695</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000300</fme:FEATURE_ID>
<fme:FEATURECODE>SLI</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20250726</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820897.35200 832860.07520</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
