<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityPolyAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>819974.41723 831512.58240</gml:lowerCorner>
<gml:upperCorner>820882.58351 833124.47778</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="id29c9efc2-1f62-4c98-bc0d-b3d3790b72a4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173745</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832510.65891333</fme:EASTING>
<fme:NORTHING>820879.71712871</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820882.58351 832514.83060</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="id9ce893b4-8974-4513-89d0-bca9baa0ecf7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>儲水缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173738</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832736.06664752</fme:EASTING>
<fme:NORTHING>819974.41723296</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819974.41723 832736.06715</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="ide5e42c8a-df27-4e67-a7b5-146e3512a0b9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173742</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832225.396095</fme:EASTING>
<fme:NORTHING>820717.56991545</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820720.43630 832229.56779</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="idfe08ed2c-b17b-400d-92c7-a67b5efa8289">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>儲水缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173735</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>831767.34457956</fme:EASTING>
<fme:NORTHING>820087.89035326</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820087.89035 831767.34508</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="idafc07fea-e2ea-433b-b42d-32e568dc6b8b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173744</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>833120.30608892</fme:EASTING>
<fme:NORTHING>820330.92824802</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820333.79463 833124.47778</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="id461bb990-abe6-4be3-b490-f26a27a15638">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173737</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>831508.41070586</fme:EASTING>
<fme:NORTHING>820260.74791762</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820263.61430 831512.58240</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="idc0dd1ccc-9e3a-4d8d-ae18-433814698ba8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>42.0750220511626</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173736</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832201.23383105</fme:EASTING>
<fme:NORTHING>820746.90382873</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820751.82692 832202.40957</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="id7d6300dc-6094-4475-9e53-b7f1de841fc5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>儲水缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173734</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832229.62267342</fme:EASTING>
<fme:NORTHING>820327.91719732</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820327.91720 832229.62317</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="idb763a29e-d44c-4e7d-a3fd-c4ab6f943c36">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>儲水缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173741</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832815.78301385</fme:EASTING>
<fme:NORTHING>820075.09028858</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820075.09029 832815.78351</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="id2ba86980-cf62-43da-8320-0fa3aa316b45">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-42.610353908332</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173739</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832447.374</fme:EASTING>
<fme:NORTHING>820784.063</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820784.38135 832447.34330</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="id099cf1f9-912b-423b-b33c-d6082b4f0cd5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-46.0000070341029</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173740</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832636.608</fme:EASTING>
<fme:NORTHING>820758.112</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820758.43137 832636.59669</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="idf3ea1f2e-4e6a-4bf2-8874-f70da11b841a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>鼓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173746</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832388.34553992</fme:EASTING>
<fme:NORTHING>819988.04817412</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819990.91455 832392.60543</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_C gml:id="id3005d67e-6f2a-4d3f-b682-858ecfdf3ab0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>儲水缸</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-73.4429149742925</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173743</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>832787.71004387</fme:EASTING>
<fme:NORTHING>820007.07181359</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819994.29470 832794.49902</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
