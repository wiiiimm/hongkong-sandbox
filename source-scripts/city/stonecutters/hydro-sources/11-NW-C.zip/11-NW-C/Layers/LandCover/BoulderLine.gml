<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BoulderLine.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>819539.69932 831506.25101 0.00000</gml:lowerCorner>
<gml:upperCorner>820542.69664 833321.67825 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BoulderLine gml:id="id175afb11-0916-4de2-a478-9878402c1b97">
<fme:FEATURE_ID>1000859279</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888009</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819896.11441 832381.75725 0.00000 819896.98685 832381.84430 0.00000 819897.94711 832382.16907 0.00000 819899.16641 832383.03664 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="iddbd1b2c0-4090-481c-aa07-f1ce519587c1">
<fme:FEATURE_ID>1000859214</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820185.74039 833293.68529 0.00000 820185.76960 833294.69676 0.00000 820186.45425 833296.50730 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idcf27ecc6-ce44-47f7-8999-190caaeb735c">
<fme:FEATURE_ID>1000859296</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819884.45455 832945.15624 0.00000 819885.05380 832947.62190 0.00000 819885.08763 832949.71784 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idbc4ca94f-0ee0-4159-98c1-531bd1e5f6f5">
<fme:FEATURE_ID>1000859209</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820190.93405 833301.66769 0.00000 820191.03489 833302.15899 0.00000 820190.88416 833302.58307 0.00000 820189.64227 833305.07599 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4c06f2dd-b191-4351-a6d4-a1d1fd866844">
<fme:FEATURE_ID>1000859264</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887554</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819931.65259 832626.19916 0.00000 819933.18664 832627.72307 0.00000 819934.25940 832629.44789 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5c7a23b6-569d-466e-a2bb-ea601dfd66b0">
<fme:FEATURE_ID>1000859361</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819662.03529 832784.17301 0.00000 819661.13915 832785.05946 0.00000 819660.75414 832785.99521 0.00000 819660.80001 832789.68058 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id158b86f3-7326-4b7c-bb3f-801b750185cc">
<fme:FEATURE_ID>1000859277</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888010</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819899.36460 832343.78519 0.00000 819898.73933 832345.17386 0.00000 819898.16465 832346.01184 0.00000 819896.57902 832347.47843 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idaa298bda-d093-4e3a-910e-d212bc3ca0ca">
<fme:FEATURE_ID>1000859336</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887542</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819689.64210 832552.54920 0.00000 819688.89539 832552.40656 0.00000 819687.29412 832551.60983 0.00000 819685.76990 832551.47272 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id822ec304-e4f3-499e-83e4-a2c8e9d207dc">
<fme:FEATURE_ID>1000859373</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887528</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819586.29537 832695.84575 0.00000 819584.88619 832698.41284 0.00000 819584.67950 832699.40643 0.00000 819584.74734 832700.59300 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7bc9eebb-609d-4b87-bb76-e87dfae5ff85">
<fme:FEATURE_ID>1000859282</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888011</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819893.33137 832374.06313 0.00000 819893.88364 832372.65617 0.00000 819893.83410 832371.51877 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd018cf4a-4458-42b4-87da-4bcc0f6441b0">
<fme:FEATURE_ID>1000859307</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819878.27288 832953.30629 0.00000 819879.23491 832954.08975 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id53c3d547-2467-4ae6-90f6-b9fc75b652cb">
<fme:FEATURE_ID>1000859184</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820243.03303 833230.82770 0.00000 820242.04468 833232.99005 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7f1be67c-bab2-4160-958f-929d5085699d">
<fme:FEATURE_ID>1000859275</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888010</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819900.61126 832342.56425 0.00000 819900.39406 832343.01994 0.00000 819900.05326 832345.01727 0.00000 819899.64771 832345.94899 0.00000 819898.86340 832347.09256 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id78aa02cf-9189-4033-b4e5-f87917f53296">
<fme:FEATURE_ID>1000859349</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819672.70258 832788.73622 0.00000 819672.38183 832789.53591 0.00000 819671.90458 832790.09304 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf52fd670-3b1d-4e8a-a16c-f9f42a58e7e6">
<fme:FEATURE_ID>1000859309</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819878.25598 832927.05220 0.00000 819877.14665 832928.75237 0.00000 819876.32966 832931.05614 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id40ee8506-782a-4707-9d41-df602822b93b">
<fme:FEATURE_ID>1000859215</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820184.19900 833301.34115 0.00000 820183.85692 833302.00941 0.00000 820183.89551 833302.58751 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd68fb7c4-09a8-43e2-915c-3f667cae2304">
<fme:FEATURE_ID>1000859211</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820190.27040 833298.21040 0.00000 820189.65278 833299.37748 0.00000 820189.25798 833301.64386 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3c116e16-d487-4de5-b4ef-7d5b14c4ea6f">
<fme:FEATURE_ID>1000859229</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887567</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820152.75078 831506.41060 0.00000 820151.03071 831506.25101 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf6a4bc2d-543a-4327-9fd2-aeb8c64457af">
<fme:FEATURE_ID>1000859206</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887574</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820198.18646 833309.34248 0.00000 820198.22752 833310.98874 0.00000 820198.97703 833312.69802 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id40b5b646-70db-4bb9-a481-46f1abfb5e3a">
<fme:FEATURE_ID>1000859329</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887542</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819696.09416 832554.97065 0.00000 819693.45900 832555.53364 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id00541766-4d87-4e1c-8ff4-a22a29c377c8">
<fme:FEATURE_ID>1000859357</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819665.13544 832788.98105 0.00000 819663.30932 832789.22998 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6fa16baf-9b2b-4230-b18e-7fbe8969805d">
<fme:FEATURE_ID>1000859261</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887554</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819934.38984 832632.77757 0.00000 819935.51192 832630.48524 0.00000 819936.10279 832628.62681 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7e9e0f33-47c7-43b3-bc8f-7db2ad9656db">
<fme:FEATURE_ID>1000859152</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882015</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820351.96136 833236.37994 0.00000 820350.45970 833237.40272 0.00000 820349.55114 833238.56868 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idccdb00d3-8ff0-40a3-94cf-3f57f11cf78c">
<fme:FEATURE_ID>1000859157</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882015</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820345.59292 833241.75042 0.00000 820345.63330 833242.12657 0.00000 820345.92479 833242.53407 0.00000 820346.26746 833242.69343 0.00000 820346.73645 833242.66468 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2cbf0af8-cb05-481a-b1e2-25e839bb4b54">
<fme:FEATURE_ID>1000859304</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819881.43802 832929.24120 0.00000 819880.45661 832931.01140 0.00000 819880.13531 832933.05644 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idef530699-d57f-46a2-be4f-e76ea7522c9a">
<fme:FEATURE_ID>1000859257</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887555</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819946.08944 832941.11228 0.00000 819946.21301 832937.85674 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id319d9e15-3e47-4736-b474-29ab4b4c1e78">
<fme:FEATURE_ID>1000859293</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888012</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819885.45933 832373.56947 0.00000 819886.59612 832375.83988 0.00000 819887.24581 832378.14417 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id84ac6094-cfe3-4f1e-9712-ce6ea4994482">
<fme:FEATURE_ID>1000859207</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887572</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820197.24536 833282.39146 0.00000 820196.74223 833282.85368 0.00000 820196.40548 833283.44844 0.00000 820196.00394 833285.29122 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id09c1815e-d101-4140-a319-16d1b6aa9842">
<fme:FEATURE_ID>1000859352</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819669.99115 832789.32551 0.00000 819669.40728 832790.12786 0.00000 819669.43034 832791.46823 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idbe10dc4a-3dae-44d6-a37a-71e87934cf29">
<fme:FEATURE_ID>1000859359</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819663.70469 832784.96265 0.00000 819662.72669 832786.11796 0.00000 819662.46371 832787.62152 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ida41a75f3-dbdd-4dc1-8800-5a62c6aa0e76">
<fme:FEATURE_ID>1000859210</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887572</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820189.27084 833281.63611 0.00000 820189.46390 833282.34372 0.00000 820191.20430 833285.14314 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2df393f5-e46c-4c16-b736-9bd8cd63145b">
<fme:FEATURE_ID>1000859369</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887529</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819588.71088 832715.05470 0.00000 819590.11025 832715.26828 0.00000 819589.07172 832715.53401 0.00000 819587.77423 832715.34475 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="iddf201af7-8b7c-404a-976e-a92c4343ba29">
<fme:FEATURE_ID>1000859089</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882032</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820536.28541 833023.71874 0.00000 820538.02580 833024.53455 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2f0135b4-213d-4030-aa9f-66fc56fe5c88">
<fme:FEATURE_ID>1000859395</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819565.70676 832708.22802 0.00000 819565.42726 832708.63636 0.00000 819565.31967 832709.98704 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id01564f8a-dcfd-4ad2-b2a6-520c03104ec4">
<fme:FEATURE_ID>1000859202</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887574</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820203.13014 833301.15060 0.00000 820202.34411 833302.34637 0.00000 820202.21928 833304.48229 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id181eb62e-0f5e-450f-9e9d-a887ec86a4e6">
<fme:FEATURE_ID>1000859280</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888009</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819895.74698 832392.34979 0.00000 819896.41759 832393.76857 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc0ed1d6f-5783-4403-bd8e-3d627f8ebd75">
<fme:FEATURE_ID>1000859401</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887522</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819545.39337 832735.11462 0.00000 819547.87805 832737.02048 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2f0054ea-a1a1-47e2-ace1-2f0d676fdba7">
<fme:FEATURE_ID>1000859350</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819670.86322 832783.45514 0.00000 819671.89481 832783.47066 0.00000 819672.04712 832783.82571 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7afa3f93-a1e9-4f86-b464-89185abc9baf">
<fme:FEATURE_ID>1000859228</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887567</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820157.48325 831506.84970 0.00000 820152.75078 831506.41060 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id201f0876-92c5-4ba5-8039-acd53c3e7e62">
<fme:FEATURE_ID>1000859183</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820243.15542 833226.14882 0.00000 820243.56259 833226.98755 0.00000 820243.61454 833228.15719 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8915d0f9-0c5b-4d66-a635-33b3f66db151">
<fme:FEATURE_ID>1000859377</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887528</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819579.85343 832689.71118 0.00000 819578.75664 832690.70297 0.00000 819578.07355 832691.84153 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6924f443-6cd1-4581-b102-4fd4d92e3e06">
<fme:FEATURE_ID>1000859381</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819574.68782 832711.29587 0.00000 819574.80945 832713.12560 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0189d5fb-a9f9-4677-9d69-7cafc53e77d0">
<fme:FEATURE_ID>1000859278</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888009</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819896.49915 832382.40589 0.00000 819897.34076 832382.97422 0.00000 819898.42869 832384.03875 0.00000 819899.55311 832385.96081 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb9d1a04b-f8d9-4a08-9ae7-80562b5213be">
<fme:FEATURE_ID>1000859147</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882017</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820362.77996 833237.84473 0.00000 820362.34983 833239.47232 0.00000 820362.32543 833240.51477 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id69c79936-fa94-4d1d-b5be-abe3da727a13">
<fme:FEATURE_ID>1000859182</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820245.49922 833233.57153 0.00000 820244.51745 833235.11584 0.00000 820244.08017 833236.80227 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id711e75e1-657f-4df4-abdc-8ecb15ae4091">
<fme:FEATURE_ID>1000859230</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887567</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820153.06409 831507.41768 0.00000 820148.36987 831507.58143 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7e1efc83-abc0-4976-9db5-431f50ed46a3">
<fme:FEATURE_ID>1000859263</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887554</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819932.93635 832632.38636 0.00000 819933.70762 832631.72840 0.00000 819934.28908 832630.89742 0.00000 819934.64345 832629.94672 0.00000 819934.74902 832629.00784 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id431b76ff-13cf-48ba-a48d-563b920a3d19">
<fme:FEATURE_ID>1000859285</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887548</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819890.16362 832963.72576 0.00000 819891.64295 832965.10337 0.00000 819892.16459 832965.97483 0.00000 819892.54132 832967.03394 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id531f62b2-68c2-4dde-818a-47909d9f4c8a">
<fme:FEATURE_ID>1000859204</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887574</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820200.29440 833309.56935 0.00000 820201.00529 833311.54797 0.00000 820201.92293 833312.87325 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2a34ba93-ec58-471f-8d3e-a336ccd8defd">
<fme:FEATURE_ID>1000859212</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820187.49030 833291.39491 0.00000 820188.55298 833292.65071 0.00000 820189.04806 833292.89505 0.00000 820189.44715 833292.89335 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3dd0a3e6-18a5-4de2-8b21-1bfc22f5d9f6">
<fme:FEATURE_ID>1000859271</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888008</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819901.67672 832364.31339 0.00000 819903.56022 832365.05701 0.00000 819904.86799 832366.02941 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idaaecf15c-3ee9-47c3-b79f-55ccf38468b9">
<fme:FEATURE_ID>1000859288</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819889.38069 832934.44612 0.00000 819890.55946 832936.09566 0.00000 819891.13404 832937.56798 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idadaa4f63-11d1-4777-bfaf-7587b31f6efa">
<fme:FEATURE_ID>1000859146</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882017</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820369.68518 833236.21124 0.00000 820367.19777 833237.33221 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9b30e288-ff57-441e-b5ce-5571dcd41dc2">
<fme:FEATURE_ID>1000859371</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887529</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819587.45535 832710.08937 0.00000 819587.64888 832710.54079 0.00000 819586.85359 832711.84371 0.00000 819586.66929 832712.53978 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0373cc75-3578-4651-b9b3-6749480411c1">
<fme:FEATURE_ID>1000859200</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887574</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820205.02906 833295.50418 0.00000 820204.81441 833293.94508 0.00000 820204.27885 833292.38862 0.00000 820203.97045 833291.99001 0.00000 820203.52707 833291.76792 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd47cc9bc-92f8-4f4a-9f28-6a55465e172a">
<fme:FEATURE_ID>1000859388</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819572.61513 832707.91360 0.00000 819572.20847 832708.20934 0.00000 819571.04653 832708.46489 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1ab3d9f7-e444-4f2d-bdd3-03c7d24b34a2">
<fme:FEATURE_ID>1000859397</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819561.14860 832709.44790 0.00000 819562.51123 832711.18556 0.00000 819563.51245 832711.93967 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0c218d35-c83c-4916-899e-533442f609a6">
<fme:FEATURE_ID>1000859208</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820195.45858 833298.61512 0.00000 820196.12380 833300.98607 0.00000 820196.42764 833302.70785 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide45daaaf-7970-4b17-a071-66f7d530b157">
<fme:FEATURE_ID>1000859281</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888010</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819895.29182 832356.11930 0.00000 819896.63726 832354.04955 0.00000 819897.09570 832352.59733 0.00000 819897.22166 832351.41947 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide53d19d4-daee-4e2f-acf8-e742abd15f5c">
<fme:FEATURE_ID>1000859379</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819578.11643 832708.70104 0.00000 819576.49900 832709.43088 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3d969f25-8f19-4542-bc8f-1ea4d1506c7c">
<fme:FEATURE_ID>1000859299</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888012</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819881.63665 832385.01474 0.00000 819884.21167 832384.50845 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id36636101-cd4e-4fb8-b9f0-8c65fe98ea97">
<fme:FEATURE_ID>1000859308</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888012</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819877.96662 832372.23905 0.00000 819877.77136 832373.55825 0.00000 819878.09967 832374.83363 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfe790b12-2bfe-4ef3-986f-9963a94c9c76">
<fme:FEATURE_ID>1000859222</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887569</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820170.48410 833319.03451 0.00000 820170.56028 833319.93859 0.00000 820171.07077 833321.67825 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4776a4b2-c00e-4d90-ba30-1e8d536682a2">
<fme:FEATURE_ID>1000859226</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887567</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820154.09068 831507.38187 0.00000 820153.06409 831507.41768 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idafd8cc0a-995b-4bf5-bc72-8b45e819e9ce">
<fme:FEATURE_ID>1000859392</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819569.55463 832711.72075 0.00000 819569.27725 832712.20369 0.00000 819568.48102 832712.74134 0.00000 819568.22461 832713.18495 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id993ceb45-fb87-4262-ab8d-429b0d343eaf">
<fme:FEATURE_ID>1000859186</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820241.50902 833230.62576 0.00000 820242.77547 833227.16632 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4c766e54-4d6a-4bef-a879-853dfe22f9d8">
<fme:FEATURE_ID>1000859276</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888008</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819898.56039 832366.34030 0.00000 819899.79772 832367.11496 0.00000 819901.06223 832367.43554 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idcca55a3e-2930-431d-91d5-2464aea2c415">
<fme:FEATURE_ID>1000859153</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882015</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820353.48469 833236.14972 0.00000 820352.13422 833238.14046 0.00000 820349.02038 833241.18795 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7c268091-1408-48c3-af93-8f98f8cb3221">
<fme:FEATURE_ID>1000859287</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888011</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819891.21327 832370.15497 0.00000 819889.69086 832370.66655 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idab50c2d7-e829-44b2-ac98-14d19004c306">
<fme:FEATURE_ID>1000859259</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887555</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819941.92770 832932.57279 0.00000 819942.25769 832933.77993 0.00000 819942.29369 832935.12177 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id27cd8086-ea77-45c5-b344-16179310a3b0">
<fme:FEATURE_ID>1000859298</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888013</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819883.05055 832350.89373 0.00000 819884.16296 832352.49981 0.00000 819884.59302 832353.42041 0.00000 819884.93508 832354.90367 0.00000 819884.91698 832356.27540 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id85d7c8d3-fce9-4a96-8a5b-7528a19f6d8f">
<fme:FEATURE_ID>1000859372</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887529</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819586.28138 832711.90815 0.00000 819586.93089 832710.90905 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0ecd2fda-417d-429d-b6ba-a89e2f113978">
<fme:FEATURE_ID>1000859305</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819879.23491 832954.08975 0.00000 819880.16260 832954.49862 0.00000 819881.22265 832954.68263 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id24366df1-0aaa-4b8f-b72b-4a40f88a766f">
<fme:FEATURE_ID>1000859310</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819870.14550 832933.17236 0.00000 819871.20520 832934.55581 0.00000 819872.28568 832936.48025 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7bfd7858-b962-4d19-8524-547fc407ac00">
<fme:FEATURE_ID>1000859260</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887555</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819937.88508 832937.74845 0.00000 819938.85831 832938.02963 0.00000 819939.87104 832938.04620 0.00000 819940.85287 832937.79702 0.00000 819941.74337 832937.29347 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfc0a2a63-b806-4654-b3bf-13f7fa0ae90b">
<fme:FEATURE_ID>1000859375</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888019</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819580.44029 832717.78110 0.00000 819579.62679 832718.66960 0.00000 819578.37579 832719.43138 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb564469c-1c9b-447c-b72e-e9bfaef5da1b">
<fme:FEATURE_ID>1000859284</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819890.27570 832930.39946 0.00000 819891.55663 832932.02886 0.00000 819892.51523 832933.64611 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id93646de7-0cb8-44f2-89d0-e049ff6d62c9">
<fme:FEATURE_ID>1000859335</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887542</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819687.74342 832550.78984 0.00000 819688.86773 832551.41328 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3b23165c-a763-4367-8d49-27832a4a8d10">
<fme:FEATURE_ID>1000859199</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887574</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820206.73595 833300.99468 0.00000 820204.55480 833303.74275 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1bb263d7-55ae-4921-b668-55e9931c998f">
<fme:FEATURE_ID>1000859294</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888013</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819885.16351 832352.58700 0.00000 819886.18523 832354.90536 0.00000 819886.44633 832356.40701 0.00000 819886.44345 832357.79852 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5f1e840d-9fad-4a26-861a-577ff1214f84">
<fme:FEATURE_ID>1000859353</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819672.04712 832783.82571 0.00000 819669.26873 832783.98132 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id643a625e-b760-4b77-9307-6581e39e8a55">
<fme:FEATURE_ID>1000859289</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819888.46090 832944.15885 0.00000 819888.47954 832945.67539 0.00000 819889.20715 832947.59055 0.00000 819889.47098 832950.03230 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide6cf1de3-1a8d-4980-9c09-24393a1eb358">
<fme:FEATURE_ID>1000859266</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887554</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819928.84012 832629.15853 0.00000 819929.30594 832629.22464 0.00000 819930.27657 832628.93248 0.00000 819931.15344 832628.42344 0.00000 819931.83116 832627.79314 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4243d0d1-624f-4de8-b305-19f2d7470df0">
<fme:FEATURE_ID>1000859297</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888012</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819884.18649 832376.04320 0.00000 819884.77199 832377.43205 0.00000 819884.71719 832378.44255 0.00000 819884.32005 832379.34936 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idab5a6d9b-8274-4954-9a4c-fe420ea258e7">
<fme:FEATURE_ID>1000859145</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882017</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820371.40977 833233.99769 0.00000 820370.88525 833234.85681 0.00000 820370.09064 833235.34642 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id66c0dd73-f5bd-4c55-abe4-754a853f1082">
<fme:FEATURE_ID>1000859272</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888008</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819901.67672 832364.31339 0.00000 819902.32124 832364.06634 0.00000 819903.33311 832364.12342 0.00000 819904.30355 832364.41616 0.00000 819905.11961 832364.88441 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3b260508-cb3d-4e21-8d1b-17a62a06c31f">
<fme:FEATURE_ID>1000859348</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819673.76632 832784.13552 0.00000 819672.04712 832783.82571 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4a8ff03d-a832-47eb-9f17-597e1980223f">
<fme:FEATURE_ID>1000859286</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887548</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819890.03242 832962.72134 0.00000 819892.17039 832964.08360 0.00000 819893.78224 832965.71438 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb70d9c3d-abae-408e-b178-e49dfbc05378">
<fme:FEATURE_ID>1000859087</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882032</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820539.14862 833022.35811 0.00000 820538.02580 833024.53455 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf11c0c09-f72c-4c45-9bf1-e7268e924e5e">
<fme:FEATURE_ID>1000859378</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819578.57715 832709.02659 0.00000 819577.91289 832709.38987 0.00000 819577.33757 832709.47254 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id378a1ab5-daf1-423c-bb5c-cb818eb01905">
<fme:FEATURE_ID>1000859084</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882032</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820540.30562 833027.66172 0.00000 820540.75113 833029.30055 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3d90221f-cb23-4791-894a-356da45f3ee7">
<fme:FEATURE_ID>1000859403</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887522</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819545.50818 832738.64888 0.00000 819540.16386 832737.71546 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfc2ac534-0417-45a5-84bb-b548040daf6c">
<fme:FEATURE_ID>1000859217</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820181.90682 833294.62993 0.00000 820182.04221 833295.61952 0.00000 820181.57957 833297.50381 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8f1c95da-1866-4eaf-9e8e-f362625d906b">
<fme:FEATURE_ID>1000859332</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887542</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819696.91290 832555.52116 0.00000 819694.64350 832555.74656 0.00000 819691.87569 832556.70623 0.00000 819690.17445 832557.09559 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfe850454-bec2-43cb-b1e4-cb3bb69c5081">
<fme:FEATURE_ID>1000859213</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887572</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820187.08923 833283.92651 0.00000 820187.41612 833285.22684 0.00000 820188.05642 833286.13770 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7568d8ca-230b-4e3f-ae72-07db9f256ae1">
<fme:FEATURE_ID>1000859283</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888011</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819892.48228 832369.89820 0.00000 819890.45385 832371.30094 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8e6b127b-7ef3-438b-a93b-e6b09e9ab1cb">
<fme:FEATURE_ID>1000859185</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820241.99671 833235.86346 0.00000 820241.94810 833236.34820 0.00000 820242.45462 833236.65129 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id319bea5a-0f4c-42da-857f-e87c5321af66">
<fme:FEATURE_ID>1000859195</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887574</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820212.11295 833294.42967 0.00000 820210.99274 833291.55755 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4e006508-7156-4db0-b7cd-a14b961fc1dc">
<fme:FEATURE_ID>1000859205</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887572</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820201.38795 833285.74387 0.00000 820199.61242 833287.80506 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4b16ab16-2aec-40e1-abca-df0f50b83b09">
<fme:FEATURE_ID>1000859358</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819666.17695 832791.27496 0.00000 819664.18523 832791.65977 0.00000 819662.62518 832791.66998 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf6773cba-2e6b-4ae5-88b4-da5d17ab24fd">
<fme:FEATURE_ID>1000859376</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887528</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819579.95519 832694.36403 0.00000 819579.06490 832694.84771 0.00000 819578.31180 832695.04329 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id59439278-e2a2-4c08-9b50-1af08dec1c90">
<fme:FEATURE_ID>1000859306</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819879.23491 832954.08975 0.00000 819880.78590 832953.85748 0.00000 819882.59239 832953.17992 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf4b2414f-0be3-4e07-9d5b-5ad3fb660af9">
<fme:FEATURE_ID>1000859367</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887529</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819588.63546 832710.95371 0.00000 819589.33239 832711.67800 0.00000 819589.56589 832712.41876 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id61f85a4e-5544-4f74-9e72-e21f5db5dd93">
<fme:FEATURE_ID>1000859386</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819572.72144 832708.34477 0.00000 819572.28870 832708.60388 0.00000 819571.78520 832708.66023 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idaf94c0f7-5cd4-41f6-8f4b-34b6f028c90f">
<fme:FEATURE_ID>1000859302</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819883.01732 832934.85483 0.00000 819882.28019 832936.75053 0.00000 819881.15365 832938.98365 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5d0a82f3-b8ed-4f07-beff-38592b83bf52">
<fme:FEATURE_ID>1000859382</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819574.37775 832713.13034 0.00000 819574.23880 832712.03831 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1375ccc1-d410-454d-9715-e4c199217d1f">
<fme:FEATURE_ID>1000859221</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887569</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820170.68137 833313.03382 0.00000 820171.51662 833314.99555 0.00000 820171.98064 833317.25327 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id43099862-13b0-41ee-974b-3433850144e4">
<fme:FEATURE_ID>1000859187</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820241.91839 833233.70216 0.00000 820241.57666 833233.81268 0.00000 820241.02454 833234.57495 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ida75908e0-320a-4a91-87b8-25c97c1851ab">
<fme:FEATURE_ID>1000859396</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888020</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819561.17646 832711.99075 0.00000 819563.04417 832713.24182 0.00000 819563.40445 832713.90864 0.00000 819563.56589 832714.84512 0.00000 819564.00465 832715.13864 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id72cfbfaa-5c86-4b57-aa25-6e67698a373e">
<fme:FEATURE_ID>1000859086</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882032</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820538.02580 833024.53455 0.00000 820539.66428 833025.30259 0.00000 820540.30562 833027.66172 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id061de278-334e-4305-8983-217cad6f4657">
<fme:FEATURE_ID>1000859303</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888012</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819880.52930 832384.13397 0.00000 819882.04106 832384.18745 0.00000 819883.00453 832383.87558 0.00000 819884.19910 832382.94604 0.00000 819884.84109 832381.83669 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd02c465d-9864-4bb5-8aea-ee7e98835200">
<fme:FEATURE_ID>1000859393</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888019</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819573.60616 832717.57638 0.00000 819571.52414 832717.16100 0.00000 819567.66278 832717.53990 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8ff9ba78-9510-43fd-a2d3-697454e37c64">
<fme:FEATURE_ID>1000859368</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887528</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819588.61734 832685.24076 0.00000 819588.47277 832686.23502 0.00000 819589.57443 832689.14670 0.00000 819589.56213 832690.34211 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idccd24a6a-7fd5-45ae-b928-d118d3364020">
<fme:FEATURE_ID>1000859404</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887522</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819543.52518 832733.83789 0.00000 819542.53413 832733.64102 0.00000 819541.61954 832733.78247 0.00000 819539.69932 832734.71918 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0c29da55-b20d-4839-afb3-70538c9666e0">
<fme:FEATURE_ID>1000859098</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882029</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820521.77096 833033.19556 0.00000 820520.83664 833034.35712 0.00000 820520.41029 833035.76980 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3bbd0e0b-ebe9-49e8-9e51-b07f9c6ee076">
<fme:FEATURE_ID>1000859274</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000888008</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>819900.16696 832364.13083 0.00000 819901.67672 832364.31339 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6d103dd3-7a71-440c-871f-56da49742436">
<fme:FEATURE_ID>1000859227</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887567</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820152.75078 831506.41060 0.00000 820153.06409 831507.41768 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6b87a412-6241-4f04-8cf4-9055145e80c9">
<fme:FEATURE_ID>1000859085</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882032</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820542.69664 833026.52183 0.00000 820540.30562 833027.66172 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfe100090-6cc9-4bee-9183-39ebf983bf0e">
<fme:FEATURE_ID>1000859223</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000887569</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820166.08401 833312.09744 0.00000 820166.16229 833314.23314 0.00000 820166.82420 833315.91062 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idca320504-f3ba-4dfe-b80e-d0c82e13540d">
<fme:FEATURE_ID>1000859144</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882017</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820373.31421 833233.99596 0.00000 820372.51563 833235.43872 0.00000 820371.03175 833237.02361 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
</gml:FeatureCollection>
