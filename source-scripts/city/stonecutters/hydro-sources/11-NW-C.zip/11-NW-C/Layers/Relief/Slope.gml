<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme Slope.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>819614.70697 831630.63168 0.00000</gml:lowerCorner>
<gml:upperCorner>820953.01102 833747.00280 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:Slope gml:id="id61e8cb10-fb69-4eab-a2b2-21461be4c5ee">
<fme:FEATURE_ID>1000317808</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832692.53848</fme:EASTING>
<fme:NORTHING>819614.70697</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.19</fme:SLOPESIZE>
<fme:SLOPEANGLE>399.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.438</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819614.70697 832692.53848 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0f1ddd9c-a2a2-4c47-b3af-7375a52676bf">
<fme:FEATURE_ID>1000317807</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832696.06812</fme:EASTING>
<fme:NORTHING>819617.48841</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.545</fme:SLOPESIZE>
<fme:SLOPEANGLE>395.94</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.509</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819617.48841 832696.06812 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idde027382-7739-4d96-8e0d-3d2a6eb68da6">
<fme:FEATURE_ID>1000317805</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832697.85556</fme:EASTING>
<fme:NORTHING>819619.13338</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.125</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.12</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.425</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819619.13338 832697.85556 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida9976cb4-bae3-4d42-bcce-7be0408072e7">
<fme:FEATURE_ID>1000317804</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832728.72266</fme:EASTING>
<fme:NORTHING>819619.64876</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.395</fme:SLOPESIZE>
<fme:SLOPEANGLE>399.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.279</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819619.64876 832728.72266 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3a2524ca-befd-4002-a085-5a11b228c47c">
<fme:FEATURE_ID>1000317802</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832731.067</fme:EASTING>
<fme:NORTHING>819621.52839</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>399.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.333</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819621.52839 832731.06700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide75f4a74-86e0-4cca-82d4-00547b0eacf6">
<fme:FEATURE_ID>1000317801</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832694.96461</fme:EASTING>
<fme:NORTHING>819623.01286</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.1</fme:SLOPESIZE>
<fme:SLOPEANGLE>127.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.22</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819623.01286 832694.96461 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfe545629-2e4e-4056-b758-658566dd95db">
<fme:FEATURE_ID>1000317800</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832733.10537</fme:EASTING>
<fme:NORTHING>819623.48081</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.39</fme:SLOPESIZE>
<fme:SLOPEANGLE>402.94</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.078</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819623.48081 832733.10537 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id003c51a4-aecf-4c59-bec9-739749f686c5">
<fme:FEATURE_ID>1000317799</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832735.67128</fme:EASTING>
<fme:NORTHING>819626.0232</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.55</fme:SLOPESIZE>
<fme:SLOPEANGLE>404.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.71</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819626.02320 832735.67128 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide4fb7d14-ce49-4aef-817e-3235f9121d5c">
<fme:FEATURE_ID>1000317798</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832692.33543</fme:EASTING>
<fme:NORTHING>819626.20951</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.61</fme:SLOPESIZE>
<fme:SLOPEANGLE>128.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.522</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819626.20951 832692.33543 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida0b17913-d69d-4322-84bc-516f64723dfe">
<fme:FEATURE_ID>1000317796</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832738.10557</fme:EASTING>
<fme:NORTHING>819628.97041</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.26</fme:SLOPESIZE>
<fme:SLOPEANGLE>408.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.252</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819628.97041 832738.10557 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd7a05019-548e-46a8-b13a-aadc2a8b8537">
<fme:FEATURE_ID>1000317795</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832689.93708</fme:EASTING>
<fme:NORTHING>819629.23091</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.16</fme:SLOPESIZE>
<fme:SLOPEANGLE>128</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.632</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819629.23091 832689.93708 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddcf39109-25df-49d8-8b52-2a2bce34cf5c">
<fme:FEATURE_ID>1210014922</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832703.3472</fme:EASTING>
<fme:NORTHING>819631.68629</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.265</fme:SLOPESIZE>
<fme:SLOPEANGLE>308.928</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.653</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819631.68629 832703.34720 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0deef28e-fb5e-44fa-886e-c7cb49f8ef0c">
<fme:FEATURE_ID>1000317792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832687.38425</fme:EASTING>
<fme:NORTHING>819632.42834</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>127.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.796</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819632.42834 832687.38425 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id95f5399e-8c4e-45b1-8bc4-6d03f9e2fe08">
<fme:FEATURE_ID>1210014920</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832694.2827</fme:EASTING>
<fme:NORTHING>819632.76689</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.289</fme:SLOPESIZE>
<fme:SLOPEANGLE>393.311</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.458</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819632.76689 832694.28270 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7c89b0a4-87ca-4fe1-bd39-6d418a1d4271">
<fme:FEATURE_ID>1000317789</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832685.0116</fme:EASTING>
<fme:NORTHING>819635.42464</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.275</fme:SLOPESIZE>
<fme:SLOPEANGLE>128.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.655</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819635.42464 832685.01160 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id85ec021d-46d0-47ce-aa91-6f4b1782fdd1">
<fme:FEATURE_ID>1000317788</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832675.82693</fme:EASTING>
<fme:NORTHING>819635.8067</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>218.2</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.533</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819635.80670 832675.82693 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8efd7742-87be-44e9-831a-7479487578e4">
<fme:FEATURE_ID>1210014927</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832698.83224</fme:EASTING>
<fme:NORTHING>819636.24441</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.681</fme:SLOPESIZE>
<fme:SLOPEANGLE>350.538</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.536</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819636.24441 832698.83224 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0c235231-d6d1-488a-ba31-04ba3d582c79">
<fme:FEATURE_ID>1000317786</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832678.77623</fme:EASTING>
<fme:NORTHING>819638.17551</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.655</fme:SLOPESIZE>
<fme:SLOPEANGLE>217.58</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.331</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819638.17551 832678.77623 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida79bdb94-a910-4a60-8d39-36b93edf37e0">
<fme:FEATURE_ID>1000317785</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832682.63896</fme:EASTING>
<fme:NORTHING>819638.42088</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.32</fme:SLOPESIZE>
<fme:SLOPEANGLE>128.42</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.664</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819638.42088 832682.63896 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide56e3741-c84a-427d-8e6c-9b17b23d973a">
<fme:FEATURE_ID>1000317784</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832681.24766</fme:EASTING>
<fme:NORTHING>819640.05648</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>189.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.332</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819640.05648 832681.24766 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id02b65f25-5a92-4f36-9174-437261e4004c">
<fme:FEATURE_ID>1000317775</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832665.3375</fme:EASTING>
<fme:NORTHING>819662.28247</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.545</fme:SLOPESIZE>
<fme:SLOPEANGLE>234.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.909</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819662.28247 832665.33750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id820bd425-3c6b-42d1-b7c2-63fd31ea06f2">
<fme:FEATURE_ID>1210014917</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832720.56962</fme:EASTING>
<fme:NORTHING>819662.70747</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.929</fme:SLOPESIZE>
<fme:SLOPEANGLE>363.495</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.386</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819662.70747 832720.56962 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8907f57e-7f94-468a-920f-fe6bb5ceb7e7">
<fme:FEATURE_ID>1210014919</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832702.7598</fme:EASTING>
<fme:NORTHING>819665.29083</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>85.061</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>17.012</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819665.29083 832702.75980 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide75d4a39-0d9c-4eb7-9331-88f800467a17">
<fme:FEATURE_ID>1000317774</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832666.21005</fme:EASTING>
<fme:NORTHING>819666.1777</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.93</fme:SLOPESIZE>
<fme:SLOPEANGLE>253.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.786</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819666.17770 832666.21005 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id75dbb965-dd42-465e-8e87-1f8561e1ecfc">
<fme:FEATURE_ID>1210014929</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832715.87812</fme:EASTING>
<fme:NORTHING>819666.51387</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.774</fme:SLOPESIZE>
<fme:SLOPEANGLE>359.119</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.355</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819666.51387 832715.87812 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb5761470-a6d6-439b-a41d-14133fc8895b">
<fme:FEATURE_ID>1000317823</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832718.49023</fme:EASTING>
<fme:NORTHING>819666.64796</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.62</fme:SLOPESIZE>
<fme:SLOPEANGLE>359.11</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.724</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819666.64796 832718.49023 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7877d489-a657-46b4-aade-09a50e47092e">
<fme:FEATURE_ID>1000317773</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832654.05625</fme:EASTING>
<fme:NORTHING>819667.14954</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.17</fme:SLOPESIZE>
<fme:SLOPEANGLE>397.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.034</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819667.14954 832654.05625 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4ea430c2-c719-4b0e-8320-0ef72c0769d8">
<fme:FEATURE_ID>1000317821</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832722.39518</fme:EASTING>
<fme:NORTHING>819667.68113</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.8</fme:SLOPESIZE>
<fme:SLOPEANGLE>405.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.56</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819667.68113 832722.39518 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9d007f00-c091-4136-a4d0-9000ddf28ebf">
<fme:FEATURE_ID>1210014923</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832711.19815</fme:EASTING>
<fme:NORTHING>819669.27524</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.789</fme:SLOPESIZE>
<fme:SLOPEANGLE>330.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.558</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819669.27524 832711.19815 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id69996183-7a11-406d-9b41-6ec403fd1706">
<fme:FEATURE_ID>1000317772</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832657.02033</fme:EASTING>
<fme:NORTHING>819669.32799</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.925</fme:SLOPESIZE>
<fme:SLOPEANGLE>399.96</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.185</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819669.32799 832657.02033 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd1744dff-4261-48e6-829c-43fe11e2de0c">
<fme:FEATURE_ID>1000317771</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832667.59733</fme:EASTING>
<fme:NORTHING>819669.5199</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.015</fme:SLOPESIZE>
<fme:SLOPEANGLE>251.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.803</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819669.51990 832667.59733 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id119362b2-b2d6-414d-a9c4-9465365e0935">
<fme:FEATURE_ID>1000317770</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832657.87534</fme:EASTING>
<fme:NORTHING>819670.20086</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.485</fme:SLOPESIZE>
<fme:SLOPEANGLE>91.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.097</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819670.20086 832657.87534 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb8bd1b1a-a0c8-4b55-8ba6-78c54d758bed">
<fme:FEATURE_ID>1000317819</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832724.50115</fme:EASTING>
<fme:NORTHING>819670.42165</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.83</fme:SLOPESIZE>
<fme:SLOPEANGLE>431.81</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.766</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819670.42165 832724.50115 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbae6be69-516c-4f27-a940-f127b280a07d">
<fme:FEATURE_ID>1210014926</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832707.17988</fme:EASTING>
<fme:NORTHING>819670.58896</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.818</fme:SLOPESIZE>
<fme:SLOPEANGLE>322.716</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.764</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819670.58896 832707.17988 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7c828036-0aa2-46bd-8b9d-281f475e384e">
<fme:FEATURE_ID>1210014925</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832717.99865</fme:EASTING>
<fme:NORTHING>819671.80097</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.685</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.681</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.537</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819671.80097 832717.99865 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcad478e0-e475-4cbe-83dc-64d7f16f80f4">
<fme:FEATURE_ID>1210014918</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832720.80813</fme:EASTING>
<fme:NORTHING>819672.28796</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.215</fme:SLOPESIZE>
<fme:SLOPEANGLE>408.545</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.843</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819672.28796 832720.80813 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id466588ae-ae7f-4c48-bd8c-6ade0f45378b">
<fme:FEATURE_ID>1000317769</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832656.14677</fme:EASTING>
<fme:NORTHING>819672.44224</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.59</fme:SLOPESIZE>
<fme:SLOPEANGLE>127.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.918</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819672.44224 832656.14677 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0466edc9-9503-4d5f-a26e-47544519d85d">
<fme:FEATURE_ID>1000317768</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832667.57967</fme:EASTING>
<fme:NORTHING>819673.4308</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.695</fme:SLOPESIZE>
<fme:SLOPEANGLE>289.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.139</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819673.43080 832667.57967 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb4777881-fced-4f53-b1a5-1492fdb3d223">
<fme:FEATURE_ID>1210014928</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832702.08245</fme:EASTING>
<fme:NORTHING>819673.96625</fme:NORTHING>
<fme:SYMBOL>185</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>5</fme:RULEID>
<fme:SLOPESIZE>125.084</fme:SLOPESIZE>
<fme:SLOPEANGLE>308.514</fme:SLOPEANGLE>
<fme:SLOPESIZE200>25.017</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819673.96625 832702.08245 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9c1f3e2c-11bd-4ff4-bf72-bede23d26e07">
<fme:FEATURE_ID>1000317814</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832724.86768</fme:EASTING>
<fme:NORTHING>819674.08277</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>90.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.075</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819674.08277 832724.86768 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1ed211a0-e03d-4fac-b897-71548565631d">
<fme:FEATURE_ID>1210014930</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832715.77536</fme:EASTING>
<fme:NORTHING>819674.45954</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.734</fme:SLOPESIZE>
<fme:SLOPEANGLE>304.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.747</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819674.45954 832715.77536 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id43bddcdf-36f5-40cc-b9fd-27c068c1d4fb">
<fme:FEATURE_ID>1000317767</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832653.61152</fme:EASTING>
<fme:NORTHING>819675.77325</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.72</fme:SLOPESIZE>
<fme:SLOPEANGLE>127.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.944</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819675.77325 832653.61152 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id41bb9769-bdfc-47ec-8524-0e81bfe10dc5">
<fme:FEATURE_ID>1000317766</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832665.0556</fme:EASTING>
<fme:NORTHING>819676.32385</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.95</fme:SLOPESIZE>
<fme:SLOPEANGLE>309.25</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.79</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819676.32385 832665.05560 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc253723b-aa60-4001-9b42-b117d70600ae">
<fme:FEATURE_ID>1000317811</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832725.6123</fme:EASTING>
<fme:NORTHING>819678.05281</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.43</fme:SLOPESIZE>
<fme:SLOPEANGLE>447.17</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.086</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819678.05281 832725.61230 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide1fa8ddd-0933-4573-975f-8e9a814305ef">
<fme:FEATURE_ID>1210014924</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832698.55671</fme:EASTING>
<fme:NORTHING>819678.75097</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>38.254</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.992</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.651</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819678.75097 832698.55671 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf707c86c-7f02-4169-977c-cb8c21c283d7">
<fme:FEATURE_ID>1000317765</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832651.07627</fme:EASTING>
<fme:NORTHING>819679.10426</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>127.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.97</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819679.10426 832651.07627 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf659c416-ca34-454f-8d59-541cc3be11fc">
<fme:FEATURE_ID>1000317764</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832662.1993</fme:EASTING>
<fme:NORTHING>819679.36559</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.05</fme:SLOPESIZE>
<fme:SLOPEANGLE>313.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.81</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819679.36559 832662.19930 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idaa2b1489-eab1-4f15-80a9-04395755d538">
<fme:FEATURE_ID>1210014921</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832637.86227</fme:EASTING>
<fme:NORTHING>819681.66448</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.858</fme:SLOPESIZE>
<fme:SLOPEANGLE>217.661</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.972</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819681.66448 832637.86227 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6483ee3b-e63a-4d31-9275-22690254d430">
<fme:FEATURE_ID>1000317763</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832659.32482</fme:EASTING>
<fme:NORTHING>819681.74685</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.345</fme:SLOPESIZE>
<fme:SLOPEANGLE>333.18</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.669</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819681.74685 832659.32482 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf8451313-a8a4-4c1e-9baf-cba6566cb52d">
<fme:FEATURE_ID>1000317810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832726.10348</fme:EASTING>
<fme:NORTHING>819681.94393</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.225</fme:SLOPESIZE>
<fme:SLOPEANGLE>90.19</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.845</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819681.94393 832726.10348 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id78768c3d-f7c1-4604-8073-382032534d6e">
<fme:FEATURE_ID>1000317762</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832648.54101</fme:EASTING>
<fme:NORTHING>819682.43527</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>128.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.996</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819682.43527 832648.54101 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id67135d29-f012-4058-8964-694b1f70501d">
<fme:FEATURE_ID>1000317761</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832655.85632</fme:EASTING>
<fme:NORTHING>819682.64859</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.985</fme:SLOPESIZE>
<fme:SLOPEANGLE>354.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.197</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819682.64859 832655.85632 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbc2f8632-dbfc-4279-8859-25c28329b22e">
<fme:FEATURE_ID>1000317760</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832640.84928</fme:EASTING>
<fme:NORTHING>819684.07178</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>216.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.099</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819684.07178 832640.84928 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4b8be370-1269-499a-9c85-282c99838763">
<fme:FEATURE_ID>1000317759</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832646.00571</fme:EASTING>
<fme:NORTHING>819685.76624</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.11</fme:SLOPESIZE>
<fme:SLOPEANGLE>128.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.022</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819685.76624 832646.00571 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb53bb7f1-2673-46f2-8161-a77735d26978">
<fme:FEATURE_ID>1000317809</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832726.23865</fme:EASTING>
<fme:NORTHING>819685.83111</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.7</fme:SLOPESIZE>
<fme:SLOPEANGLE>449.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.54</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819685.83111 832726.23865 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id38b11522-18b1-4249-9cfe-6066bd5489b2">
<fme:FEATURE_ID>1000317758</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832643.83628</fme:EASTING>
<fme:NORTHING>819686.47903</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.96</fme:SLOPESIZE>
<fme:SLOPEANGLE>216.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.192</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819686.47903 832643.83628 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida8241a79-0749-4861-8951-5b1f1a0d5d14">
<fme:FEATURE_ID>1000317757</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832644.79635</fme:EASTING>
<fme:NORTHING>819687.04829</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.975</fme:SLOPESIZE>
<fme:SLOPEANGLE>188.24</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.595</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819687.04829 832644.79635 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7204856e-9dd9-4c7b-95cd-d67547c2f428">
<fme:FEATURE_ID>1210015655</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832625.51</fme:EASTING>
<fme:NORTHING>819700.102</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>16.624</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.343</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.325</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819700.10186 832625.51039 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id42809d4c-8f74-4902-a5d8-019a9d073cbf">
<fme:FEATURE_ID>1000317755</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832629.02771</fme:EASTING>
<fme:NORTHING>819701.04722</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.025</fme:SLOPESIZE>
<fme:SLOPEANGLE>375.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.405</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819701.04722 832629.02771 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id336c49b0-2faa-4149-90ea-fab9ecaaa5c3">
<fme:FEATURE_ID>1000317754</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832628.32657</fme:EASTING>
<fme:NORTHING>819702.3602</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.97</fme:SLOPESIZE>
<fme:SLOPEANGLE>236.97</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.594</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819702.36020 832628.32657 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf7d2b453-dd85-4fbf-8a3b-6d87f0d78ef6">
<fme:FEATURE_ID>1000317753</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832631.96021</fme:EASTING>
<fme:NORTHING>819702.62851</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.46</fme:SLOPESIZE>
<fme:SLOPEANGLE>397.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.892</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819702.62851 832631.96021 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1e88de99-f1ba-48d6-9b38-3efe2d93e7ec">
<fme:FEATURE_ID>1210015654</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832635.058</fme:EASTING>
<fme:NORTHING>819704.59</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.822</fme:SLOPESIZE>
<fme:SLOPEANGLE>53.842</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.164</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819704.58970 832635.05827 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide97f04dc-b6c3-40ec-a897-512a120840c8">
<fme:FEATURE_ID>1000317751</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832606.57815</fme:EASTING>
<fme:NORTHING>819705.14455</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.3</fme:SLOPESIZE>
<fme:SLOPEANGLE>212.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.06</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819705.14455 832606.57815 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id55e580e8-03c8-4949-8203-1f591942b21f">
<fme:FEATURE_ID>1000317750</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832631.36865</fme:EASTING>
<fme:NORTHING>819705.54268</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.65</fme:SLOPESIZE>
<fme:SLOPEANGLE>276.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.53</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819705.54268 832631.36865 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0da7f109-a8ce-40ac-aa9e-40c75f670239">
<fme:FEATURE_ID>1000317749</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832601.20899</fme:EASTING>
<fme:NORTHING>819707.75249</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.07</fme:SLOPESIZE>
<fme:SLOPEANGLE>193.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.214</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819707.75249 832601.20899 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddf87e913-a037-4b43-a51b-956e8c817b19">
<fme:FEATURE_ID>1210015653</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832637.815</fme:EASTING>
<fme:NORTHING>819707.887</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.199</fme:SLOPESIZE>
<fme:SLOPEANGLE>60.255</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.24</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819707.88720 832637.81497 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id15ce8371-4f82-4a7a-a5f0-e35e2895bfc7">
<fme:FEATURE_ID>1000317748</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832609.15662</fme:EASTING>
<fme:NORTHING>819708.85527</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.54</fme:SLOPESIZE>
<fme:SLOPEANGLE>233.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.508</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819708.85527 832609.15662 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf74edf75-c1be-4b04-b908-da5f09e19171">
<fme:FEATURE_ID>1000317747</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832630.63983</fme:EASTING>
<fme:NORTHING>819709.36962</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.38</fme:SLOPESIZE>
<fme:SLOPEANGLE>296.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.476</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819709.36962 832630.63983 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id45b4d6d6-b37e-414c-8e33-32a6042ba931">
<fme:FEATURE_ID>1000317746</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832608.65497</fme:EASTING>
<fme:NORTHING>819712.83711</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.295</fme:SLOPESIZE>
<fme:SLOPEANGLE>91.92</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.859</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819712.83711 832608.65497 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id32f073df-fba0-465e-b486-ffcf72923cfa">
<fme:FEATURE_ID>1000317745</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832629.49438</fme:EASTING>
<fme:NORTHING>819714.08089</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.555</fme:SLOPESIZE>
<fme:SLOPEANGLE>308.44</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.311</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819714.08089 832629.49438 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5312ae57-9348-470c-bc49-5cda552eb03a">
<fme:FEATURE_ID>1210015656</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832607.681</fme:EASTING>
<fme:NORTHING>819714.969</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.888</fme:SLOPESIZE>
<fme:SLOPEANGLE>242.85</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.978</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819714.96940 832607.68093 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id29545055-e5d7-4bab-8cdc-5f8c92503c1f">
<fme:FEATURE_ID>1000317744</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832626.06023</fme:EASTING>
<fme:NORTHING>819716.48143</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.72</fme:SLOPESIZE>
<fme:SLOPEANGLE>328.12</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.144</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819716.48143 832626.06023 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idddf88a12-84d5-49b7-97e8-bc407306f481">
<fme:FEATURE_ID>1000317743</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832608.69012</fme:EASTING>
<fme:NORTHING>819716.57083</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.18</fme:SLOPESIZE>
<fme:SLOPEANGLE>413.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.636</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819716.57083 832608.69012 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id663b635d-9121-4173-a292-90ae2579eec1">
<fme:FEATURE_ID>1000317742</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832622.5808</fme:EASTING>
<fme:NORTHING>819718.37353</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.785</fme:SLOPESIZE>
<fme:SLOPEANGLE>330.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.957</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819718.37353 832622.58080 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0938ddd1-16ce-418e-be17-60d807d2e02c">
<fme:FEATURE_ID>1000317741</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832611.88838</fme:EASTING>
<fme:NORTHING>819719.42482</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.933</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819719.42482 832611.88838 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id721c16c3-656f-49c1-99a8-80cfb7295a73">
<fme:FEATURE_ID>1000317740</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832615.11207</fme:EASTING>
<fme:NORTHING>819719.96804</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.54</fme:SLOPESIZE>
<fme:SLOPEANGLE>362.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.108</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819719.96804 832615.11207 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6611a46a-d787-4877-b4f3-90fd4af17316">
<fme:FEATURE_ID>1000317739</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832618.61799</fme:EASTING>
<fme:NORTHING>819720.28574</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.6</fme:SLOPESIZE>
<fme:SLOPEANGLE>347.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.92</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819720.28574 832618.61799 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1c83faad-9bbf-4636-a818-3c6e6d1ba274">
<fme:FEATURE_ID>1000317843</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832677.70952</fme:EASTING>
<fme:NORTHING>819732.66542</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.01</fme:SLOPESIZE>
<fme:SLOPEANGLE>348.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.202</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819732.66542 832677.70952 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7f8de931-2c24-4458-b8fe-27860bef5d83">
<fme:FEATURE_ID>1000317842</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832680.09128</fme:EASTING>
<fme:NORTHING>819733.45334</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.755</fme:SLOPESIZE>
<fme:SLOPEANGLE>407.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.751</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819733.45334 832680.09128 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id37a598bc-0c4c-4ea8-8f8c-63e3355a5aba">
<fme:FEATURE_ID>1000317841</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832703.04317</fme:EASTING>
<fme:NORTHING>819734.54248</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.44</fme:SLOPESIZE>
<fme:SLOPEANGLE>310.21</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.688</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819734.54248 832703.04317 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf55994b9-882e-4096-a9e6-274bfc3d6ea2">
<fme:FEATURE_ID>1000317738</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832576.45997</fme:EASTING>
<fme:NORTHING>819735.90084</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>388.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.732</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819735.90084 832576.45997 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id488e96e0-0b7d-4645-a76c-26c235e305e5">
<fme:FEATURE_ID>1000317840</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832682.90224</fme:EASTING>
<fme:NORTHING>819736.8365</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.475</fme:SLOPESIZE>
<fme:SLOPEANGLE>405.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.095</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819736.83650 832682.90224 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0980f63c-9331-4425-b948-e04125bccd3e">
<fme:FEATURE_ID>1000317737</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832580.0381</fme:EASTING>
<fme:NORTHING>819737.74315</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.54</fme:SLOPESIZE>
<fme:SLOPEANGLE>387.11</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.708</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819737.74315 832580.03810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id22591eea-4e01-4bea-b41d-07f5fc9722cd">
<fme:FEATURE_ID>1000317839</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832700.61658</fme:EASTING>
<fme:NORTHING>819737.81755</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.055</fme:SLOPESIZE>
<fme:SLOPEANGLE>311.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.611</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819737.81755 832700.61658 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida0ec8d37-efb3-4f80-9922-a9bad9bf0285">
<fme:FEATURE_ID>1000317736</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832583.61623</fme:EASTING>
<fme:NORTHING>819739.58547</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.43</fme:SLOPESIZE>
<fme:SLOPEANGLE>385.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.686</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819739.58547 832583.61623 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7f6c15ef-f12c-4d05-be56-afb74d6e9fa2">
<fme:FEATURE_ID>1000317838</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832686.1245</fme:EASTING>
<fme:NORTHING>819739.81775</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.01</fme:SLOPESIZE>
<fme:SLOPEANGLE>391.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.402</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819739.81775 832686.12450 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id88e974f4-f316-4174-9efc-dea63dbee082">
<fme:FEATURE_ID>1000317837</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832697.96565</fme:EASTING>
<fme:NORTHING>819740.68377</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.265</fme:SLOPESIZE>
<fme:SLOPEANGLE>320.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.053</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819740.68377 832697.96565 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide1132c98-bde9-4e2a-9944-c64ac397b975">
<fme:FEATURE_ID>1000317735</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832593.58157</fme:EASTING>
<fme:NORTHING>819742.20875</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>266.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.775</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819742.20875 832593.58157 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id34aaa492-ada8-4b7c-a02f-55efcb24436f">
<fme:FEATURE_ID>1000317836</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832689.88329</fme:EASTING>
<fme:NORTHING>819742.57635</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.36</fme:SLOPESIZE>
<fme:SLOPEANGLE>376.17</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.872</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819742.57635 832689.88329 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idee6e7714-e087-483d-9b96-12db7a9a0357">
<fme:FEATURE_ID>1000317835</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832694.48203</fme:EASTING>
<fme:NORTHING>819742.95679</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.99</fme:SLOPESIZE>
<fme:SLOPEANGLE>354.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.798</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819742.95679 832694.48203 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida82e92a9-5ac1-42db-8be7-6d2736a6c317">
<fme:FEATURE_ID>1000317834</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832681.7081</fme:EASTING>
<fme:NORTHING>819745.9663</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.415</fme:SLOPESIZE>
<fme:SLOPEANGLE>163.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.683</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819745.96630 832681.70810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id63af5375-abe7-41da-842d-be714203577e">
<fme:FEATURE_ID>1000317833</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832685.49571</fme:EASTING>
<fme:NORTHING>819746.1093</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.585</fme:SLOPESIZE>
<fme:SLOPEANGLE>192.81</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.517</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819746.10930 832685.49571 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id65ddc661-89c7-41ef-b1dc-d2c9aa0caea9">
<fme:FEATURE_ID>1000317734</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832593.50799</fme:EASTING>
<fme:NORTHING>819746.57618</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.04</fme:SLOPESIZE>
<fme:SLOPEANGLE>291.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.208</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819746.57618 832593.50799 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2a15b105-2844-42a4-9cdc-9d052e837b08">
<fme:FEATURE_ID>1000317832</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832677.79726</fme:EASTING>
<fme:NORTHING>819747.77747</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>135.59</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.175</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819747.77747 832677.79726 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idee328468-bca0-4459-9235-989c32bfce5a">
<fme:FEATURE_ID>1000317831</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832688.21722</fme:EASTING>
<fme:NORTHING>819750.68508</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.78</fme:SLOPESIZE>
<fme:SLOPEANGLE>244.09</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.156</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819750.68508 832688.21722 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5920bdfa-3790-4f22-9c19-78f59d31e9d1">
<fme:FEATURE_ID>1000317733</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832593.68421</fme:EASTING>
<fme:NORTHING>819751.35274</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.715</fme:SLOPESIZE>
<fme:SLOPEANGLE>294.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.543</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819751.35274 832593.68421 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8458f99a-20d1-45bd-b8d0-103bafeea56d">
<fme:FEATURE_ID>1000317830</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832676.10169</fme:EASTING>
<fme:NORTHING>819751.64464</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.58</fme:SLOPESIZE>
<fme:SLOPEANGLE>105.43</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.716</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819751.64464 832676.10169 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4bab2483-3c77-44a6-adce-1b0c91faee76">
<fme:FEATURE_ID>1000317732</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832591.10539</fme:EASTING>
<fme:NORTHING>819754.60072</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.645</fme:SLOPESIZE>
<fme:SLOPEANGLE>293.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.129</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819754.60072 832591.10539 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd8e7646a-b122-481b-aa15-b0cd7e3d7ab2">
<fme:FEATURE_ID>1000317828</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832677.12572</fme:EASTING>
<fme:NORTHING>819755.64312</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.815</fme:SLOPESIZE>
<fme:SLOPEANGLE>433.92</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.963</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819755.64312 832677.12572 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id116a5fee-0b50-4bf8-ba8d-b3b1873dc338">
<fme:FEATURE_ID>1000317731</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832587.91121</fme:EASTING>
<fme:NORTHING>819757.60118</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.555</fme:SLOPESIZE>
<fme:SLOPEANGLE>294.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.311</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819757.60118 832587.91121 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6a44a7b2-07da-4955-b760-760eaa4ef2f5">
<fme:FEATURE_ID>1000317827</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832679.58486</fme:EASTING>
<fme:NORTHING>819758.64148</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.24</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.648</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819758.64148 832679.58486 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idae08dae6-221a-48e9-905e-f228457e4c53">
<fme:FEATURE_ID>1000317826</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832680.38286</fme:EASTING>
<fme:NORTHING>819760.07241</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.115</fme:SLOPESIZE>
<fme:SLOPEANGLE>108.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.423</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819760.07241 832680.38286 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida77853c2-ebdd-43f3-9bdb-b330d89bd690">
<fme:FEATURE_ID>1000318050</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832539.4839</fme:EASTING>
<fme:NORTHING>819854.73591</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.15</fme:SLOPESIZE>
<fme:SLOPEANGLE>293</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.03</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819854.73591 832539.48390 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb654b1c9-2ce7-4185-aec5-f4ca526cbbd2">
<fme:FEATURE_ID>1000318048</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832535.78659</fme:EASTING>
<fme:NORTHING>819859.19766</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.305</fme:SLOPESIZE>
<fme:SLOPEANGLE>321.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.661</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819859.19766 832535.78659 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id57741989-dbe5-48bd-84f4-165fb6ed9089">
<fme:FEATURE_ID>1000317629</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832666.80693</fme:EASTING>
<fme:NORTHING>819904.88476</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.955</fme:SLOPESIZE>
<fme:SLOPEANGLE>137.91</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.791</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819904.88476 832666.80693 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6e4601ce-54f5-4f3b-aed2-cd006fbc0e7d">
<fme:FEATURE_ID>1000317628</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832662.6079</fme:EASTING>
<fme:NORTHING>819905.76466</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.78</fme:SLOPESIZE>
<fme:SLOPEANGLE>127.01</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.156</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819905.76466 832662.60790 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcbeb04cb-f21a-47f5-886c-f9a7844ce722">
<fme:FEATURE_ID>1000317623</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832659.39677</fme:EASTING>
<fme:NORTHING>819908.77989</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.035</fme:SLOPESIZE>
<fme:SLOPEANGLE>103.9</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.207</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819908.77989 832659.39677 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5567b7f0-6187-4c76-97cd-b131cea0483f">
<fme:FEATURE_ID>1000317613</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832658.52325</fme:EASTING>
<fme:NORTHING>819913.1969</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.73</fme:SLOPESIZE>
<fme:SLOPEANGLE>440.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.146</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819913.19690 832658.52325 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0a4ba2d5-d083-4284-8de4-ae726aa6c931">
<fme:FEATURE_ID>1000317605</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832659.25152</fme:EASTING>
<fme:NORTHING>819918.04904</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.12</fme:SLOPESIZE>
<fme:SLOPEANGLE>421.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.024</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819918.04904 832659.25152 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id467ad633-f9d8-41a2-9f69-da44adffd2a0">
<fme:FEATURE_ID>1000317375</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832422.6928</fme:EASTING>
<fme:NORTHING>819918.23871</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.215</fme:SLOPESIZE>
<fme:SLOPEANGLE>205.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.243</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819918.23871 832422.69280 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id798eabf7-3f98-408c-829c-d44f481444a7">
<fme:FEATURE_ID>1000317373</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832416.86656</fme:EASTING>
<fme:NORTHING>819918.73427</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.035</fme:SLOPESIZE>
<fme:SLOPEANGLE>197.25</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.407</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819918.73427 832416.86656 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id089ee343-e9ea-4729-ae3b-d0b5cd16f4df">
<fme:FEATURE_ID>1000317372</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832427.80467</fme:EASTING>
<fme:NORTHING>819918.8336</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.76</fme:SLOPESIZE>
<fme:SLOPEANGLE>347.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.152</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819918.83360 832427.80467 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd6b68aba-0781-4616-999c-d27c5f6eca77">
<fme:FEATURE_ID>1000317371</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832428.38722</fme:EASTING>
<fme:NORTHING>819920.15532</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.11</fme:SLOPESIZE>
<fme:SLOPEANGLE>215.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.622</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819920.15532 832428.38722 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf7e7fb6d-6e25-4d46-b6f0-07b644084c1a">
<fme:FEATURE_ID>1000317369</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832432.21993</fme:EASTING>
<fme:NORTHING>819924.50583</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.705</fme:SLOPESIZE>
<fme:SLOPEANGLE>228.43</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.541</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819924.50583 832432.21993 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id469f258f-1df9-4f24-8763-9b1fa5fcf2b1">
<fme:FEATURE_ID>1210014689</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832666.49431</fme:EASTING>
<fme:NORTHING>819925.18644</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.339</fme:SLOPESIZE>
<fme:SLOPEANGLE>38.418</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.668</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819925.18644 832666.49431 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7030d100-d47a-4d25-ade4-39afc1297a7e">
<fme:FEATURE_ID>1000317595</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832670.32517</fme:EASTING>
<fme:NORTHING>819927.01195</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>381.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.099</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819927.01195 832670.32517 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id274a3553-56e0-43d8-818a-5d82f720d2b6">
<fme:FEATURE_ID>1000317594</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832678.74484</fme:EASTING>
<fme:NORTHING>819927.23308</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.43</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.286</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819927.23308 832678.74484 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd9724cb6-af01-4f47-b796-205dc3c63c39">
<fme:FEATURE_ID>1000317593</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832674.13953</fme:EASTING>
<fme:NORTHING>819927.73118</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.405</fme:SLOPESIZE>
<fme:SLOPEANGLE>365.73</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.081</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819927.73118 832674.13953 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id22f059d1-03a3-4f92-8d74-c9136e3728ba">
<fme:FEATURE_ID>1000317364</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832433.04922</fme:EASTING>
<fme:NORTHING>819929.78956</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.605</fme:SLOPESIZE>
<fme:SLOPEANGLE>230.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.321</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819929.78956 832433.04922 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2a52dfc9-d367-484f-b371-fa7eb24c804d">
<fme:FEATURE_ID>1000317580</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832714.30463</fme:EASTING>
<fme:NORTHING>819954.88871</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.835</fme:SLOPESIZE>
<fme:SLOPEANGLE>315.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.967</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819954.88871 832714.30463 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id57bd936d-c059-44c8-94e9-62c3924e614a">
<fme:FEATURE_ID>1000317571</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832715.00491</fme:EASTING>
<fme:NORTHING>819961.06138</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.945</fme:SLOPESIZE>
<fme:SLOPEANGLE>315.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.589</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819961.06138 832715.00491 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id428e7bef-f60d-4373-9c8a-d1d2d75d33f1">
<fme:FEATURE_ID>1000317566</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832706.19243</fme:EASTING>
<fme:NORTHING>819966.57887</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.155</fme:SLOPESIZE>
<fme:SLOPEANGLE>313.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.631</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819966.57887 832706.19243 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida313d86a-d369-4e3f-a23c-dabdc6f5d7f4">
<fme:FEATURE_ID>1000317562</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832713.56491</fme:EASTING>
<fme:NORTHING>819968.98179</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>34.285</fme:SLOPESIZE>
<fme:SLOPEANGLE>317.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.857</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819968.98179 832713.56491 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc3ed4856-1ff6-41c5-b353-27950b090a72">
<fme:FEATURE_ID>1000317117</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832451.46706</fme:EASTING>
<fme:NORTHING>819985.18387</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33</fme:SLOPESIZE>
<fme:SLOPEANGLE>279.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.6</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819985.18387 832451.46706 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8335cabc-7610-44b8-95ea-a2db4d56ffcb">
<fme:FEATURE_ID>1000317293</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832513.75862</fme:EASTING>
<fme:NORTHING>819985.24338</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.5</fme:SLOPESIZE>
<fme:SLOPEANGLE>378.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.3</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819985.24338 832513.75862 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5602cda5-5504-4eb5-a747-7c50ad7f0deb">
<fme:FEATURE_ID>1000317292</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832526.73157</fme:EASTING>
<fme:NORTHING>819985.44859</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.6</fme:SLOPESIZE>
<fme:SLOPEANGLE>397.58</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.52</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819985.44859 832526.73157 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8b2c5e4a-db9d-41ce-99c4-595d0e4c22a0">
<fme:FEATURE_ID>1000317291</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832508.59266</fme:EASTING>
<fme:NORTHING>819986.29902</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>49.5</fme:SLOPESIZE>
<fme:SLOPEANGLE>362.14</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.9</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819986.29902 832508.59266 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcadd4b10-8270-483f-ba67-cf1582eaa3e0">
<fme:FEATURE_ID>1000317287</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832486.94056</fme:EASTING>
<fme:NORTHING>819988.58946</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>35.465</fme:SLOPESIZE>
<fme:SLOPEANGLE>403.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.093</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819988.58946 832486.94056 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb0ac4b49-2615-411b-92ce-9a32c6492fba">
<fme:FEATURE_ID>1000317286</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832503.75455</fme:EASTING>
<fme:NORTHING>819988.85357</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.605</fme:SLOPESIZE>
<fme:SLOPEANGLE>355.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.321</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819988.85357 832503.75455 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd30685ac-fab8-4c3e-ad42-cf308bb07373">
<fme:FEATURE_ID>1000317285</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832529.29414</fme:EASTING>
<fme:NORTHING>819988.90762</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.145</fme:SLOPESIZE>
<fme:SLOPEANGLE>399.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.229</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819988.90762 832529.29414 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id49ee4d64-b4d2-4192-958b-fa6f459eae4f">
<fme:FEATURE_ID>1000317282</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832497.79755</fme:EASTING>
<fme:NORTHING>819991.17723</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.115</fme:SLOPESIZE>
<fme:SLOPEANGLE>367.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.423</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819991.17723 832497.79755 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id217a2c5c-5d98-495f-8a7a-0ce0e8f4cf63">
<fme:FEATURE_ID>1000317281</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832491.89585</fme:EASTING>
<fme:NORTHING>819991.24093</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.45</fme:SLOPESIZE>
<fme:SLOPEANGLE>386.2</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.49</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819991.24093 832491.89585 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id493eeb4a-cf49-42ba-b0f6-9e70a2a43dfd">
<fme:FEATURE_ID>1000317116</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832453.13354</fme:EASTING>
<fme:NORTHING>819991.56176</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.16</fme:SLOPESIZE>
<fme:SLOPEANGLE>279.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.232</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819991.56176 832453.13354 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6b55e811-06cf-47cb-b145-09b2846414b7">
<fme:FEATURE_ID>1000317280</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832531.70372</fme:EASTING>
<fme:NORTHING>819992.54409</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.615</fme:SLOPESIZE>
<fme:SLOPEANGLE>398.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.923</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819992.54409 832531.70372 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd64f11c9-84f8-4ba2-88fc-3e0068104f65">
<fme:FEATURE_ID>1000317276</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832534.57192</fme:EASTING>
<fme:NORTHING>819995.8006</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.745</fme:SLOPESIZE>
<fme:SLOPEANGLE>397.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.349</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819995.80060 832534.57192 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd2dbd26a-4393-4188-b07d-4646ac5b2b16">
<fme:FEATURE_ID>1000317115</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832454.39254</fme:EASTING>
<fme:NORTHING>819998.19275</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>48.605</fme:SLOPESIZE>
<fme:SLOPEANGLE>279.1</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.721</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819998.19275 832454.39254 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9d41170e-4758-431e-b38e-a8ca60e665cf">
<fme:FEATURE_ID>1000317272</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832636.19187</fme:EASTING>
<fme:NORTHING>819998.22493</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>34.505</fme:SLOPESIZE>
<fme:SLOPEANGLE>271.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.901</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819998.22493 832636.19187 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id09ad2fc5-1e16-4b53-95d9-6a9b7d751fd7">
<fme:FEATURE_ID>1000317267</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832636.15778</fme:EASTING>
<fme:NORTHING>820002.71962</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.02</fme:SLOPESIZE>
<fme:SLOPEANGLE>277.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.204</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820002.71962 832636.15778 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idca85b95b-8567-450d-9da5-614e9217298b">
<fme:FEATURE_ID>1000317114</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832455.49976</fme:EASTING>
<fme:NORTHING>820004.36627</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>54.48</fme:SLOPESIZE>
<fme:SLOPEANGLE>278.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.896</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820004.36627 832455.49976 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4bcff3bc-c086-41d3-b3ac-b76e51c3b2ef">
<fme:FEATURE_ID>1000317258</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832633.24932</fme:EASTING>
<fme:NORTHING>820007.13206</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.14</fme:SLOPESIZE>
<fme:SLOPEANGLE>290.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.828</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820007.13206 832633.24932 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id659ca9ac-8c9c-4b26-b858-b31b6275534b">
<fme:FEATURE_ID>1000317113</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832446.7145</fme:EASTING>
<fme:NORTHING>820008.99495</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>277.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.325</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820008.99495 832446.71450 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4b9bcf34-5d8f-4525-968e-65a27fa0242a">
<fme:FEATURE_ID>1000317112</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832444.18917</fme:EASTING>
<fme:NORTHING>820012.54498</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.26</fme:SLOPESIZE>
<fme:SLOPEANGLE>277.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.052</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820012.54498 832444.18917 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7d4012d4-0ff7-4b11-a6b8-365667df77f7">
<fme:FEATURE_ID>1000317111</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832442.29981</fme:EASTING>
<fme:NORTHING>820016.09635</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.205</fme:SLOPESIZE>
<fme:SLOPEANGLE>278.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.241</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820016.09635 832442.29981 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idec28e134-622b-4b08-858e-f78079337458">
<fme:FEATURE_ID>1000317110</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832441.27534</fme:EASTING>
<fme:NORTHING>820019.64957</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19</fme:SLOPESIZE>
<fme:SLOPEANGLE>278.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.8</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820019.64957 832441.27534 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddaee5651-c561-4702-beb6-2fc181d9f99f">
<fme:FEATURE_ID>1000317109</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832440.35257</fme:EASTING>
<fme:NORTHING>820023.2284</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.525</fme:SLOPESIZE>
<fme:SLOPEANGLE>278.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.705</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820023.22840 832440.35257 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id87e2da55-772b-4f3b-bfb2-7eba703c6f0e">
<fme:FEATURE_ID>1000317108</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832439.96397</fme:EASTING>
<fme:NORTHING>820026.83376</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.215</fme:SLOPESIZE>
<fme:SLOPEANGLE>278</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.043</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820026.83376 832439.96397 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id34e20e80-4d17-4f1c-93ba-265f877948d3">
<fme:FEATURE_ID>1000317107</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832439.1938</fme:EASTING>
<fme:NORTHING>820030.43832</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>278.21</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.77</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820030.43832 832439.19380 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7436464d-24b3-4bc3-a6a0-39fa140e61c2">
<fme:FEATURE_ID>1000317106</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832438.44886</fme:EASTING>
<fme:NORTHING>820034.14451</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.16</fme:SLOPESIZE>
<fme:SLOPEANGLE>278.44</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.032</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820034.14451 832438.44886 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ideec05c7c-cfc6-4ee1-9d86-38c10a8604f6">
<fme:FEATURE_ID>1000318073</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832864.37382</fme:EASTING>
<fme:NORTHING>820035.961</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.57</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.714</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820035.96100 832864.37382 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbe4e98df-b802-422e-a9aa-9886034321ce">
<fme:FEATURE_ID>1000316931</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831799.91011</fme:EASTING>
<fme:NORTHING>820036.86765</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.045</fme:SLOPESIZE>
<fme:SLOPEANGLE>420.8</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.209</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820036.86765 831799.91011 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id826e3787-45b7-4f7e-b6e5-e6d4ebc6e9aa">
<fme:FEATURE_ID>1000318072</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832868.08468</fme:EASTING>
<fme:NORTHING>820037.56868</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.395</fme:SLOPESIZE>
<fme:SLOPEANGLE>403.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.879</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820037.56868 832868.08468 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9c1a3eea-44b7-46ed-b041-46de28f52bb1">
<fme:FEATURE_ID>1000317105</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832437.67889</fme:EASTING>
<fme:NORTHING>820037.62208</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.05</fme:SLOPESIZE>
<fme:SLOPEANGLE>279.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.81</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820037.62208 832437.67889 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbbfe8014-c2c5-4f35-94e6-fbcdccdda262">
<fme:FEATURE_ID>1000318071</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832871.18302</fme:EASTING>
<fme:NORTHING>820040.24163</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.015</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.803</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820040.24163 832871.18302 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6c5cf2f1-121a-4447-af8d-c97aa1cb57e0">
<fme:FEATURE_ID>1000317104</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832436.95976</fme:EASTING>
<fme:NORTHING>820041.15055</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.615</fme:SLOPESIZE>
<fme:SLOPEANGLE>279.18</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.723</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820041.15055 832436.95976 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id10a0e5fa-1f1c-4c72-ac74-642b91973f96">
<fme:FEATURE_ID>1000316929</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831801.4611</fme:EASTING>
<fme:NORTHING>820042.43727</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.16</fme:SLOPESIZE>
<fme:SLOPEANGLE>381.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.832</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820042.43727 831801.46110 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8353a290-d6bc-450a-bb54-b494ac5b165a">
<fme:FEATURE_ID>1000317967</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832407.95541</fme:EASTING>
<fme:NORTHING>820042.47339</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.035</fme:SLOPESIZE>
<fme:SLOPEANGLE>285.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.407</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820042.47339 832407.95541 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb414571f-6139-4560-ad09-01b1df26f360">
<fme:FEATURE_ID>1000318070</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832874.15418</fme:EASTING>
<fme:NORTHING>820042.83811</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.91</fme:SLOPESIZE>
<fme:SLOPEANGLE>402.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.782</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820042.83811 832874.15418 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2651055a-56a1-4afd-8be6-5718d5497686">
<fme:FEATURE_ID>1000316928</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831822.33489</fme:EASTING>
<fme:NORTHING>820042.8587</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>363.92</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.975</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820042.85870 831822.33489 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1b8f78f4-ac39-4c34-9cb4-453c97dfcfa3">
<fme:FEATURE_ID>1000316927</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831806.10707</fme:EASTING>
<fme:NORTHING>820044.00704</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>364.91</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.282</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820044.00704 831806.10707 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id61605fb7-3f64-4d3b-a840-802f4001ed1e">
<fme:FEATURE_ID>1000317103</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832436.95264</fme:EASTING>
<fme:NORTHING>820044.80752</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.655</fme:SLOPESIZE>
<fme:SLOPEANGLE>281</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.331</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820044.80752 832436.95264 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id19b5035e-a55c-48e1-b3ad-9eceea6147da">
<fme:FEATURE_ID>1000316926</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831818.25626</fme:EASTING>
<fme:NORTHING>820045.10158</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.42</fme:SLOPESIZE>
<fme:SLOPEANGLE>365.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.684</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820045.10158 831818.25626 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd82b23da-9712-4856-95a6-e1aa3cc37acd">
<fme:FEATURE_ID>1000316925</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831810.16917</fme:EASTING>
<fme:NORTHING>820045.37105</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.78</fme:SLOPESIZE>
<fme:SLOPEANGLE>363.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.156</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820045.37105 831810.16917 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc775b754-8d16-45eb-8236-fe37c1c48a23">
<fme:FEATURE_ID>1000316924</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831814.02696</fme:EASTING>
<fme:NORTHING>820046.93739</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.635</fme:SLOPESIZE>
<fme:SLOPEANGLE>363.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.727</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820046.93739 831814.02696 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfae49b6c-cfda-4c83-8389-cfacccdf6974">
<fme:FEATURE_ID>1000317102</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832437.02145</fme:EASTING>
<fme:NORTHING>820048.64244</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>281.38</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.933</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820048.64244 832437.02145 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc6b3c520-0bbb-49d9-859c-6539758cb6c2">
<fme:FEATURE_ID>1000317966</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832408.10485</fme:EASTING>
<fme:NORTHING>820048.64725</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.94</fme:SLOPESIZE>
<fme:SLOPEANGLE>285.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.988</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820048.64725 832408.10485 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idba42d085-f5a2-46c5-aa22-df869d7baffa">
<fme:FEATURE_ID>1000317101</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832436.65765</fme:EASTING>
<fme:NORTHING>820052.57798</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.945</fme:SLOPESIZE>
<fme:SLOPEANGLE>281.84</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.389</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820052.57798 832436.65765 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id174fffb4-64ab-4d76-ad38-e4b3e33b7101">
<fme:FEATURE_ID>1000317965</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832407.95556</fme:EASTING>
<fme:NORTHING>820054.51209</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.405</fme:SLOPESIZE>
<fme:SLOPEANGLE>285.84</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.081</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820054.51209 832407.95556 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id498c590d-78fb-46dd-9a73-50159f4cf585">
<fme:FEATURE_ID>1000317100</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832436.62404</fme:EASTING>
<fme:NORTHING>820056.76823</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.7</fme:SLOPESIZE>
<fme:SLOPEANGLE>283.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.14</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820056.76823 832436.62404 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id446d9fdd-f562-43c6-8674-3fb390a07b5d">
<fme:FEATURE_ID>1000317423</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832771.3556</fme:EASTING>
<fme:NORTHING>820058.00944</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.975</fme:SLOPESIZE>
<fme:SLOPEANGLE>166.05</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.195</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820058.00944 832771.35560 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id262e30e2-cee2-4f87-a6ce-e688fbc96a61">
<fme:FEATURE_ID>1000317422</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832767.43687</fme:EASTING>
<fme:NORTHING>820058.68677</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.015</fme:SLOPESIZE>
<fme:SLOPEANGLE>167.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.203</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820058.68677 832767.43687 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbdbabe72-7df9-4631-a543-5ab0c65249ca">
<fme:FEATURE_ID>1000317421</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832763.54372</fme:EASTING>
<fme:NORTHING>820059.26258</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.105</fme:SLOPESIZE>
<fme:SLOPEANGLE>170.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.221</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820059.26258 832763.54372 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9d6c730e-ba5d-460d-a5f0-1d426e4bf1c7">
<fme:FEATURE_ID>1000317420</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832759.65071</fme:EASTING>
<fme:NORTHING>820059.78763</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.715</fme:SLOPESIZE>
<fme:SLOPEANGLE>170.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.143</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820059.78763 832759.65071 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8ac7ff29-6fc8-418f-969c-02d5083cfa33">
<fme:FEATURE_ID>1000316921</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831653.82702</fme:EASTING>
<fme:NORTHING>820059.95408</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.76</fme:SLOPESIZE>
<fme:SLOPEANGLE>378.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.352</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820059.95408 831653.82702 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcb80a08a-1341-4906-b855-2e98b5da9701">
<fme:FEATURE_ID>1000317419</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832755.78293</fme:EASTING>
<fme:NORTHING>820060.4143</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.565</fme:SLOPESIZE>
<fme:SLOPEANGLE>170.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.113</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820060.41430 832755.78293 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1d23920f-2d0d-4e51-81de-e37846497099">
<fme:FEATURE_ID>1000317964</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832408.55512</fme:EASTING>
<fme:NORTHING>820060.54041</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.06</fme:SLOPESIZE>
<fme:SLOPEANGLE>284.81</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.212</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820060.54041 832408.55512 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6ab973f1-be3f-446f-b591-94245855d34d">
<fme:FEATURE_ID>1000318136</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832784.47543</fme:EASTING>
<fme:NORTHING>820061.21147</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.745</fme:SLOPESIZE>
<fme:SLOPEANGLE>159.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.549</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820061.21147 832784.47543 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idff4ba8ed-052d-40f3-9b19-5f97159c6c7d">
<fme:FEATURE_ID>1000316920</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831657.25193</fme:EASTING>
<fme:NORTHING>820061.64553</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.835</fme:SLOPESIZE>
<fme:SLOPEANGLE>380.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.167</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820061.64553 831657.25193 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id68ea441c-56ee-474d-a936-17076d9bdf43">
<fme:FEATURE_ID>1000317418</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832751.65925</fme:EASTING>
<fme:NORTHING>820061.82764</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.97</fme:SLOPESIZE>
<fme:SLOPEANGLE>153.51</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.194</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820061.82764 832751.65925 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9c0a6251-085f-40c0-a090-2e66a439384e">
<fme:FEATURE_ID>1000318135</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832781.03881</fme:EASTING>
<fme:NORTHING>820062.49927</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.435</fme:SLOPESIZE>
<fme:SLOPEANGLE>162.2</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.687</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820062.49927 832781.03881 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id09ebda9c-64c9-43b3-b538-1b6516cbfe0e">
<fme:FEATURE_ID>1000317099</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832435.82355</fme:EASTING>
<fme:NORTHING>820062.86151</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>34.455</fme:SLOPESIZE>
<fme:SLOPEANGLE>289.03</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.891</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820062.86151 832435.82355 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id66e520c5-fd80-497a-9fce-86719d4f941b">
<fme:FEATURE_ID>1000316919</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831660.83143</fme:EASTING>
<fme:NORTHING>820062.90581</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.115</fme:SLOPESIZE>
<fme:SLOPEANGLE>378.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.023</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820062.90581 831660.83143 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5544da05-bcbf-47a2-866b-cd3beb87c0da">
<fme:FEATURE_ID>1000316918</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831813.13786</fme:EASTING>
<fme:NORTHING>820063.41881</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.34</fme:SLOPESIZE>
<fme:SLOPEANGLE>95.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.868</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820063.41881 831813.13786 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2671a6b0-5838-4adc-9d70-d1612f30ff19">
<fme:FEATURE_ID>1000318134</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832777.42451</fme:EASTING>
<fme:NORTHING>820063.58357</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.25</fme:SLOPESIZE>
<fme:SLOPEANGLE>162.11</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.85</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820063.58357 832777.42451 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id029942cf-79e9-49b7-979b-97d1a8bd4fa9">
<fme:FEATURE_ID>1000316917</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831664.53896</fme:EASTING>
<fme:NORTHING>820063.96346</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.14</fme:SLOPESIZE>
<fme:SLOPEANGLE>379.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.028</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820063.96346 831664.53896 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida3a620ad-3a8b-406b-8395-974e3504a178">
<fme:FEATURE_ID>1000317417</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832748.55108</fme:EASTING>
<fme:NORTHING>820064.28429</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.835</fme:SLOPESIZE>
<fme:SLOPEANGLE>146.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.167</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820064.28429 832748.55108 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9cce413f-146f-46a7-bfef-4f650cb3afcc">
<fme:FEATURE_ID>1000316916</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831888.11722</fme:EASTING>
<fme:NORTHING>820064.58464</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.61</fme:SLOPESIZE>
<fme:SLOPEANGLE>318.91</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.922</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820064.58464 831888.11722 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id856450d1-1d2a-42c7-aaaf-fc55865c809b">
<fme:FEATURE_ID>1000317416</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832773.35232</fme:EASTING>
<fme:NORTHING>820064.69233</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.345</fme:SLOPESIZE>
<fme:SLOPEANGLE>163.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.069</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820064.69233 832773.35232 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id86ce7b00-5116-40de-b1ae-e9cd16405597">
<fme:FEATURE_ID>1000316915</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831668.40042</fme:EASTING>
<fme:NORTHING>820064.71697</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.33</fme:SLOPESIZE>
<fme:SLOPEANGLE>379.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.666</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820064.71697 831668.40042 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1b0e71b3-b94a-40cb-ae00-2f3426e26179">
<fme:FEATURE_ID>1000316914</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831672.10887</fme:EASTING>
<fme:NORTHING>820065.5714</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>382.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.082</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820065.57140 831672.10887 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id10121586-192f-4335-bec3-fc831f9fe6e9">
<fme:FEATURE_ID>1000317415</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832769.66208</fme:EASTING>
<fme:NORTHING>820065.5987</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.575</fme:SLOPESIZE>
<fme:SLOPEANGLE>166.74</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.115</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820065.59870 832769.66208 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id62c4c360-b75e-4704-906e-f60217c6ff21">
<fme:FEATURE_ID>1000316913</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831770.15446</fme:EASTING>
<fme:NORTHING>820065.92355</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.255</fme:SLOPESIZE>
<fme:SLOPEANGLE>102.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.251</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820065.92355 831770.15446 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3de6243d-952c-47da-8600-799969286079">
<fme:FEATURE_ID>1000317414</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832766.0485</fme:EASTING>
<fme:NORTHING>820066.30208</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>170.24</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.675</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820066.30208 832766.04850 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc050611b-b583-44e3-80ac-c25221b44fdc">
<fme:FEATURE_ID>1000317413</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832745.5958</fme:EASTING>
<fme:NORTHING>820066.61433</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.455</fme:SLOPESIZE>
<fme:SLOPEANGLE>144.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.291</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820066.61433 832745.59580 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2aa32010-e2ac-4e5d-9e19-475efcf5ac38">
<fme:FEATURE_ID>1000317412</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832762.38442</fme:EASTING>
<fme:NORTHING>820066.82758</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.04</fme:SLOPESIZE>
<fme:SLOPEANGLE>171.01</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.808</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820066.82758 832762.38442 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc807c609-cc94-4c18-ba94-75e6861a471e">
<fme:FEATURE_ID>1000316911</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831811.59585</fme:EASTING>
<fme:NORTHING>820066.99365</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.585</fme:SLOPESIZE>
<fme:SLOPEANGLE>98.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.317</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820066.99365 831811.59585 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id58421e3d-495c-4cf5-a81c-83cc7cc45edd">
<fme:FEATURE_ID>1000316910</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831833.61429</fme:EASTING>
<fme:NORTHING>820067.31846</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.565</fme:SLOPESIZE>
<fme:SLOPEANGLE>423.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.913</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820067.31846 831833.61429 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id061e01b6-4c67-4e71-a0ac-c5eedd2d55ee">
<fme:FEATURE_ID>1000317411</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832758.23682</fme:EASTING>
<fme:NORTHING>820067.45369</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>160.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.082</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820067.45369 832758.23682 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4546d2cc-1560-45d8-9285-eca0b388d813">
<fme:FEATURE_ID>1000317963</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832408.70789</fme:EASTING>
<fme:NORTHING>820068.05665</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.64</fme:SLOPESIZE>
<fme:SLOPEANGLE>285.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.328</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820068.05665 832408.70789 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbef36bb2-d8d0-402a-bc36-d53e1a746322">
<fme:FEATURE_ID>1000317098</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832431.71735</fme:EASTING>
<fme:NORTHING>820068.31282</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.77</fme:SLOPESIZE>
<fme:SLOPEANGLE>296.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.954</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820068.31282 832431.71735 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id02f8bcdb-daba-4aed-8df2-9efbbbd9369a">
<fme:FEATURE_ID>1000317410</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832742.25967</fme:EASTING>
<fme:NORTHING>820068.5626</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.295</fme:SLOPESIZE>
<fme:SLOPEANGLE>147.84</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.659</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820068.56260 832742.25967 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2db32aae-1bc1-4659-a804-bd1ad37de1bc">
<fme:FEATURE_ID>1000317409</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832754.29102</fme:EASTING>
<fme:NORTHING>820068.96896</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.895</fme:SLOPESIZE>
<fme:SLOPEANGLE>149.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.179</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820068.96896 832754.29102 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcdc69d8b-94d4-42fb-a2a0-5deefe84748d">
<fme:FEATURE_ID>1000316909</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831674.35393</fme:EASTING>
<fme:NORTHING>820069.49299</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.675</fme:SLOPESIZE>
<fme:SLOPEANGLE>375.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.535</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820069.49299 831674.35393 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3b3b0c48-ad2f-48da-96f4-9cd8c26d5d76">
<fme:FEATURE_ID>1000316908</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831887.20395</fme:EASTING>
<fme:NORTHING>820069.68627</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.105</fme:SLOPESIZE>
<fme:SLOPEANGLE>329.85</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.421</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820069.68627 831887.20395 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfbdbdb20-bbbd-4dc3-bea1-932b454a4e1f">
<fme:FEATURE_ID>1000316907</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831769.32232</fme:EASTING>
<fme:NORTHING>820069.9587</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.605</fme:SLOPESIZE>
<fme:SLOPEANGLE>100.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.521</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820069.95870 831769.32232 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2fd19de3-52e5-48e9-a6bd-b7236ce07f45">
<fme:FEATURE_ID>1000317408</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832738.94945</fme:EASTING>
<fme:NORTHING>820070.257</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>153.09</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.726</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820070.25700 832738.94945 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ideaac7097-f37c-4e98-8a15-56389e84f853">
<fme:FEATURE_ID>1000316906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831660.15996</fme:EASTING>
<fme:NORTHING>820070.72643</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.13</fme:SLOPESIZE>
<fme:SLOPEANGLE>358.08</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.226</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820070.72643 831660.15996 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idace3f638-7e41-4ece-b84f-15552790b116">
<fme:FEATURE_ID>1000316905</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831809.08613</fme:EASTING>
<fme:NORTHING>820070.89445</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.995</fme:SLOPESIZE>
<fme:SLOPEANGLE>97.2</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.999</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820070.89445 831809.08613 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8bf6d80e-9df5-4c2d-a80e-bfcc6b90800a">
<fme:FEATURE_ID>1000316904</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831678.31213</fme:EASTING>
<fme:NORTHING>820071.33915</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.726</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820071.33915 831678.31213 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id958ecbfa-6e5f-4d93-82a9-bf39650f5d73">
<fme:FEATURE_ID>1000317097</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832428.30247</fme:EASTING>
<fme:NORTHING>820071.4546</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.185</fme:SLOPESIZE>
<fme:SLOPEANGLE>298.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.037</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820071.45460 832428.30247 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3260c683-9e0e-41c6-8411-712d30f182ef">
<fme:FEATURE_ID>1000316903</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831655.60498</fme:EASTING>
<fme:NORTHING>820071.49397</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>45.26</fme:SLOPESIZE>
<fme:SLOPEANGLE>334.71</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.052</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820071.49397 831655.60498 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb339bb9f-2d43-4f0f-9b46-5048f31f9bd6">
<fme:FEATURE_ID>1000316902</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831664.63052</fme:EASTING>
<fme:NORTHING>820071.73659</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.34</fme:SLOPESIZE>
<fme:SLOPEANGLE>380.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.068</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820071.73659 831664.63052 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0fccd76f-884e-47f3-a07e-c82409edd63f">
<fme:FEATURE_ID>1000317407</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832735.43598</fme:EASTING>
<fme:NORTHING>820071.82399</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.855</fme:SLOPESIZE>
<fme:SLOPEANGLE>156.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.771</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820071.82399 832735.43598 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id35fc445e-25fc-4a59-b91c-3844b2db84a6">
<fme:FEATURE_ID>1000317406</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832751.18197</fme:EASTING>
<fme:NORTHING>820071.88272</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.405</fme:SLOPESIZE>
<fme:SLOPEANGLE>137.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.681</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820071.88272 832751.18197 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5ec9a4ce-c5a4-490c-bfb2-280db4871db7">
<fme:FEATURE_ID>1000316901</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831883.63304</fme:EASTING>
<fme:NORTHING>820072.10919</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.985</fme:SLOPESIZE>
<fme:SLOPEANGLE>330.08</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.597</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820072.10919 831883.63304 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide6c3e265-2959-4034-9074-f35fb11b396c">
<fme:FEATURE_ID>1000316900</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831682.07017</fme:EASTING>
<fme:NORTHING>820072.47322</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.715</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.143</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820072.47322 831682.07017 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide0ab648d-e978-44f7-a7cf-8c03f0e50bf3">
<fme:FEATURE_ID>1000316899</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831819.24891</fme:EASTING>
<fme:NORTHING>820072.66612</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.165</fme:SLOPESIZE>
<fme:SLOPEANGLE>395.01</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.633</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820072.66612 831819.24891 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id37749542-4e03-49c9-871a-bc366eae9931">
<fme:FEATURE_ID>1000316898</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831668.69318</fme:EASTING>
<fme:NORTHING>820072.97359</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.215</fme:SLOPESIZE>
<fme:SLOPEANGLE>376.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.243</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820072.97359 831668.69318 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id81221cb1-b389-4038-b231-6d9ab444aea6">
<fme:FEATURE_ID>1000318069</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832699.01558</fme:EASTING>
<fme:NORTHING>820072.97593</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>186.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.675</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820072.97593 832699.01558 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id74ff9d0c-b267-4a83-b50a-5ff30184bbed">
<fme:FEATURE_ID>1000317405</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832732.02455</fme:EASTING>
<fme:NORTHING>820073.26423</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.945</fme:SLOPESIZE>
<fme:SLOPEANGLE>158.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.789</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820073.26423 832732.02455 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id590b00d1-cb92-4b6e-958f-4b150ba1d566">
<fme:FEATURE_ID>1000318068</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832702.30351</fme:EASTING>
<fme:NORTHING>820073.43192</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.9</fme:SLOPESIZE>
<fme:SLOPEANGLE>186.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.78</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820073.43192 832702.30351 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id39af1d77-8aac-4d02-a7f4-e17b0ea0ea86">
<fme:FEATURE_ID>1000316897</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831651.604</fme:EASTING>
<fme:NORTHING>820073.43236</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>40.385</fme:SLOPESIZE>
<fme:SLOPEANGLE>319.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.077</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820073.43236 831651.60400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8bcac41f-644d-482e-9f84-1becb293ed84">
<fme:FEATURE_ID>1000316896</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831685.90438</fme:EASTING>
<fme:NORTHING>820073.63303</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.295</fme:SLOPESIZE>
<fme:SLOPEANGLE>372.42</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.059</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820073.63303 831685.90438 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb9fc7eab-6589-4400-a47a-752b93ad7d5b">
<fme:FEATURE_ID>1000318067</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832705.61543</fme:EASTING>
<fme:NORTHING>820073.83991</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.92</fme:SLOPESIZE>
<fme:SLOPEANGLE>187.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.984</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820073.83991 832705.61543 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf8559e9f-1228-4964-a809-97a0ef8228be">
<fme:FEATURE_ID>1000316895</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831823.7949</fme:EASTING>
<fme:NORTHING>820073.85444</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.45</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.69</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820073.85444 831823.79490 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id991e6bb3-5e2e-4c40-ba7b-ab9bdaafafb4">
<fme:FEATURE_ID>1000316894</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831807.57143</fme:EASTING>
<fme:NORTHING>820074.06297</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.095</fme:SLOPESIZE>
<fme:SLOPEANGLE>94.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.019</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820074.06297 831807.57143 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb8621f6f-3093-40a1-a26e-996a92953bb8">
<fme:FEATURE_ID>1000316893</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831690.0964</fme:EASTING>
<fme:NORTHING>820074.38798</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.58</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.126</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820074.38798 831690.09640 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3913b5e0-069e-4ee7-9adc-f6eb41a2853c">
<fme:FEATURE_ID>1000317404</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832728.18098</fme:EASTING>
<fme:NORTHING>820074.52584</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.995</fme:SLOPESIZE>
<fme:SLOPEANGLE>161.51</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.799</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820074.52584 832728.18098 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id000c48e1-4cdd-42a7-bfee-3d4df2d5671e">
<fme:FEATURE_ID>1000316892</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831828.06181</fme:EASTING>
<fme:NORTHING>820074.91453</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.715</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.743</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820074.91453 831828.06181 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id05bb66a5-03de-4f08-a3a8-decfc9376b55">
<fme:FEATURE_ID>1000316891</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831694.23816</fme:EASTING>
<fme:NORTHING>820075.0157</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.93</fme:SLOPESIZE>
<fme:SLOPEANGLE>377.05</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.986</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.01570 831694.23816 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id51eef292-1d9b-4127-b099-29d3ef35b83c">
<fme:FEATURE_ID>1000317403</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832748.80992</fme:EASTING>
<fme:NORTHING>820075.15354</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.2</fme:SLOPESIZE>
<fme:SLOPEANGLE>131.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.24</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.15354 832748.80992 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8047823f-8090-471e-88fc-fff7d7575e22">
<fme:FEATURE_ID>1000318066</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832708.20737</fme:EASTING>
<fme:NORTHING>820075.15988</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>187.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.725</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.15988 832708.20737 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2251985a-dc03-433e-af6a-db9e7e52f276">
<fme:FEATURE_ID>1000317096</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832426.76892</fme:EASTING>
<fme:NORTHING>820075.1845</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.615</fme:SLOPESIZE>
<fme:SLOPEANGLE>301.97</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.923</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.18450 832426.76892 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd25b419d-f11b-4b08-ab57-0942797e3534">
<fme:FEATURE_ID>1000316890</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831831.92541</fme:EASTING>
<fme:NORTHING>820075.21083</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.325</fme:SLOPESIZE>
<fme:SLOPEANGLE>395.94</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.665</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.21083 831831.92541 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8735d02f-f4d6-4f3d-b3c4-7b46060ad2e3">
<fme:FEATURE_ID>1000316889</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831768.28093</fme:EASTING>
<fme:NORTHING>820075.26297</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.685</fme:SLOPESIZE>
<fme:SLOPEANGLE>90.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.737</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.26297 831768.28093 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id155bc2a7-f13e-48e1-a223-2b85198fbd08">
<fme:FEATURE_ID>1000316888</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831879.85468</fme:EASTING>
<fme:NORTHING>820075.42023</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.485</fme:SLOPESIZE>
<fme:SLOPEANGLE>334.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.097</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.42023 831879.85468 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida7df8d10-7a23-4fab-9278-cc8cfc60d2f9">
<fme:FEATURE_ID>1000317402</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832724.49045</fme:EASTING>
<fme:NORTHING>820075.55917</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.545</fme:SLOPESIZE>
<fme:SLOPEANGLE>166.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.709</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.55917 832724.49045 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9afb4c89-732d-444b-911b-06145c31f7ba">
<fme:FEATURE_ID>1000317962</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832406.46646</fme:EASTING>
<fme:NORTHING>820075.83496</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>43.16</fme:SLOPESIZE>
<fme:SLOPEANGLE>291.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.632</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820075.83496 832406.46646 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idff52bf9c-1b53-45ab-95a5-e19a1273874f">
<fme:FEATURE_ID>1000316887</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831697.81841</fme:EASTING>
<fme:NORTHING>820076.09818</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.39</fme:SLOPESIZE>
<fme:SLOPEANGLE>383.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.678</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820076.09818 831697.81841 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id16843177-3d84-4d23-91fe-cd5937301e85">
<fme:FEATURE_ID>1000316886</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831835.91214</fme:EASTING>
<fme:NORTHING>820076.3713</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.22</fme:SLOPESIZE>
<fme:SLOPEANGLE>388.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.844</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820076.37130 831835.91214 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb751f61d-a922-4256-8502-82b878113be9">
<fme:FEATURE_ID>1000316885</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831648.18278</fme:EASTING>
<fme:NORTHING>820076.49095</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.995</fme:SLOPESIZE>
<fme:SLOPEANGLE>302.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.399</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820076.49095 831648.18278 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc72571f8-d83b-4784-8433-7c32e58f2a02">
<fme:FEATURE_ID>1000316884</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831839.77177</fme:EASTING>
<fme:NORTHING>820077.5312</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.43</fme:SLOPESIZE>
<fme:SLOPEANGLE>378.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.686</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820077.53120 831839.77177 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id338235f2-0b02-4aed-8b8d-3022dc50a1df">
<fme:FEATURE_ID>1000317401</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832746.38818</fme:EASTING>
<fme:NORTHING>820077.81481</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.315</fme:SLOPESIZE>
<fme:SLOPEANGLE>136.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.263</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820077.81481 832746.38818 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8fad8c14-7307-4ee1-8027-d9f51fdef0ba">
<fme:FEATURE_ID>1000316883</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831805.90102</fme:EASTING>
<fme:NORTHING>820077.91665</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.61</fme:SLOPESIZE>
<fme:SLOPEANGLE>436.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.722</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820077.91665 831805.90102 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id72aa7141-eecd-47d6-b5ea-1ffd75cb3183">
<fme:FEATURE_ID>1000316882</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831701.08895</fme:EASTING>
<fme:NORTHING>820078.19535</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.645</fme:SLOPESIZE>
<fme:SLOPEANGLE>388.89</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.529</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820078.19535 831701.08895 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id18db5538-569d-462e-94e3-8a83da691fe7">
<fme:FEATURE_ID>1000316881</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831678.91616</fme:EASTING>
<fme:NORTHING>820078.25089</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.635</fme:SLOPESIZE>
<fme:SLOPEANGLE>378.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.927</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820078.25089 831678.91616 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2be1cce4-596d-42d9-8162-e8b7f76e1cfb">
<fme:FEATURE_ID>1000316880</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831843.63267</fme:EASTING>
<fme:NORTHING>820078.4117</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.755</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.551</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820078.41170 831843.63267 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb606d063-b4f7-49c6-83e0-d207682d9d8f">
<fme:FEATURE_ID>1000316879</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831847.51911</fme:EASTING>
<fme:NORTHING>820079.26693</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.57</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.47</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.514</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820079.26693 831847.51911 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7d7774c6-a509-414d-8819-e51c320f09d6">
<fme:FEATURE_ID>1000316878</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831644.40674</fme:EASTING>
<fme:NORTHING>820079.29398</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.835</fme:SLOPESIZE>
<fme:SLOPEANGLE>295.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.367</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820079.29398 831644.40674 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddad02efd-def8-4199-85ec-d776f1f628b3">
<fme:FEATURE_ID>1000316877</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831851.48349</fme:EASTING>
<fme:NORTHING>820079.76687</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.24</fme:SLOPESIZE>
<fme:SLOPEANGLE>368.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.648</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820079.76687 831851.48349 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1a129206-de2b-4e78-8714-414a313ab8af">
<fme:FEATURE_ID>1000316876</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831704.66675</fme:EASTING>
<fme:NORTHING>820079.81127</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6</fme:SLOPESIZE>
<fme:SLOPEANGLE>387.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.2</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820079.81127 831704.66675 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id26011bcf-a394-4cd4-8363-85076947e32f">
<fme:FEATURE_ID>1000316875</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831682.67212</fme:EASTING>
<fme:NORTHING>820079.84217</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.299</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820079.84217 831682.67212 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb0816838-fa13-49a3-8bda-814d48e0a660">
<fme:FEATURE_ID>1000317400</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832743.61102</fme:EASTING>
<fme:NORTHING>820080.11978</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.31</fme:SLOPESIZE>
<fme:SLOPEANGLE>145.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.262</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820080.11978 832743.61102 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idac287864-aea3-4e7d-82df-d4edb8d6334a">
<fme:FEATURE_ID>1000316874</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831686.2553</fme:EASTING>
<fme:NORTHING>820080.28965</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.13</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.226</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820080.28965 831686.25530 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id43bb1af8-7b8d-4d45-860f-b54c9d64a5e1">
<fme:FEATURE_ID>1000316873</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831690.34783</fme:EASTING>
<fme:NORTHING>820080.56155</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.39</fme:SLOPESIZE>
<fme:SLOPEANGLE>374.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.278</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820080.56155 831690.34783 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc0362fba-d2e4-49ae-bbb0-c1bc43ef08f8">
<fme:FEATURE_ID>1000316872</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831855.75052</fme:EASTING>
<fme:NORTHING>820080.80155</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>364.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.17</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820080.80155 831855.75052 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id872ed107-eddd-4585-b917-5651f27ae70f">
<fme:FEATURE_ID>1000316871</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831766.85574</fme:EASTING>
<fme:NORTHING>820081.09902</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.96</fme:SLOPESIZE>
<fme:SLOPEANGLE>440.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.392</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820081.09902 831766.85574 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddcfddeee-0aaa-4890-a2d7-fc93194f5150">
<fme:FEATURE_ID>1000316870</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831694.20849</fme:EASTING>
<fme:NORTHING>820081.49285</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.525</fme:SLOPESIZE>
<fme:SLOPEANGLE>381.24</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.305</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820081.49285 831694.20849 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id23c46e71-2f8e-499a-b3f6-3902f860a9dd">
<fme:FEATURE_ID>1000317961</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832402.31856</fme:EASTING>
<fme:NORTHING>820081.58652</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>38.835</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.767</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820081.58652 832402.31856 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id15b0d4f3-c760-46b0-a7d0-0f560947f57c">
<fme:FEATURE_ID>1000316869</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831875.93367</fme:EASTING>
<fme:NORTHING>820082.10898</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>40.185</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.92</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.037</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820082.10898 831875.93367 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida761df46-aec4-4a68-8fdf-a891660d0dd8">
<fme:FEATURE_ID>1000316868</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831806.8988</fme:EASTING>
<fme:NORTHING>820082.13758</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.605</fme:SLOPESIZE>
<fme:SLOPEANGLE>407.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.521</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820082.13758 831806.89880 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id22120ac1-7816-46f3-b3f0-2ff71d6ea334">
<fme:FEATURE_ID>1000317399</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832740.42735</fme:EASTING>
<fme:NORTHING>820082.1446</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.1</fme:SLOPESIZE>
<fme:SLOPEANGLE>152.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.22</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820082.14460 832740.42735 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id47b1f474-400d-4286-97fc-da96806c11de">
<fme:FEATURE_ID>1000317095</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832428.20502</fme:EASTING>
<fme:NORTHING>820082.29839</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>40.61</fme:SLOPESIZE>
<fme:SLOPEANGLE>309.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.122</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820082.29839 832428.20502 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbfff2e4b-eaf1-45fe-8dd0-7a71c0bbd87b">
<fme:FEATURE_ID>1000317094</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832422.07411</fme:EASTING>
<fme:NORTHING>820082.41228</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.355</fme:SLOPESIZE>
<fme:SLOPEANGLE>311.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.271</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820082.41228 832422.07411 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6435d6c9-29fe-4d3c-8c9d-9780be67b591">
<fme:FEATURE_ID>1000316866</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831697.60964</fme:EASTING>
<fme:NORTHING>820082.82856</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.965</fme:SLOPESIZE>
<fme:SLOPEANGLE>399.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.393</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820082.82856 831697.60964 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id517ec8db-fe17-416d-988d-65fc79762b41">
<fme:FEATURE_ID>1000316865</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831887.65213</fme:EASTING>
<fme:NORTHING>820082.87142</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.985</fme:SLOPESIZE>
<fme:SLOPEANGLE>410.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.797</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820082.87142 831887.65213 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id321bb083-700b-4772-ba65-c9391771b306">
<fme:FEATURE_ID>1000316864</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831643.59862</fme:EASTING>
<fme:NORTHING>820083.63403</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.61</fme:SLOPESIZE>
<fme:SLOPEANGLE>293.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.722</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820083.63403 831643.59862 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide5446e04-c0e2-40ab-a223-6cb53b681d93">
<fme:FEATURE_ID>1000316863</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831884.2663</fme:EASTING>
<fme:NORTHING>820083.74567</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.865</fme:SLOPESIZE>
<fme:SLOPEANGLE>140.19</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.173</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820083.74567 831884.26630 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8e494be7-7b55-4adb-b1bc-99a93a665578">
<fme:FEATURE_ID>1000317398</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832737.1426</fme:EASTING>
<fme:NORTHING>820083.83905</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.29</fme:SLOPESIZE>
<fme:SLOPEANGLE>158.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.258</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820083.83905 832737.14260 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9a6512a2-69f9-44e1-98a1-8b2317fb1dcc">
<fme:FEATURE_ID>1000317397</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832726.81416</fme:EASTING>
<fme:NORTHING>820084.1727</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.53</fme:SLOPESIZE>
<fme:SLOPEANGLE>182.06</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.706</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.17270 832726.81416 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id761b0678-ed06-4366-b96e-197fe6cf5899">
<fme:FEATURE_ID>1000316862</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831680.43989</fme:EASTING>
<fme:NORTHING>820084.22681</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.815</fme:SLOPESIZE>
<fme:SLOPEANGLE>386.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.963</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.22681 831680.43989 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb02c1495-0155-4296-9632-d51ecf530280">
<fme:FEATURE_ID>1000317396</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832730.47689</fme:EASTING>
<fme:NORTHING>820084.33284</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.085</fme:SLOPESIZE>
<fme:SLOPEANGLE>178.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.817</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.33284 832730.47689 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8ed6969e-a096-49ec-abe3-b20b73cf585c">
<fme:FEATURE_ID>1000317395</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832711.24547</fme:EASTING>
<fme:NORTHING>820084.52067</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.125</fme:SLOPESIZE>
<fme:SLOPEANGLE>186.09</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.825</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.52067 832711.24547 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id49dc9cd5-1aca-4521-acdb-5762df851ef2">
<fme:FEATURE_ID>1000316861</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831810.21852</fme:EASTING>
<fme:NORTHING>820084.59061</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.515</fme:SLOPESIZE>
<fme:SLOPEANGLE>391.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.303</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.59061 831810.21852 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4f565881-58e0-4fcd-8a58-ef25fab5904d">
<fme:FEATURE_ID>1000317394</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832733.63059</fme:EASTING>
<fme:NORTHING>820084.66963</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.26</fme:SLOPESIZE>
<fme:SLOPEANGLE>166.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.452</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.66963 832733.63059 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id58fe70d2-979c-490d-8659-ea3c0d771d21">
<fme:FEATURE_ID>1000317393</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832722.69208</fme:EASTING>
<fme:NORTHING>820084.74805</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.34</fme:SLOPESIZE>
<fme:SLOPEANGLE>181.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.468</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.74805 832722.69208 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id46c3d6a7-0685-4443-8458-21421e1e985d">
<fme:FEATURE_ID>1000317392</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832715.00961</fme:EASTING>
<fme:NORTHING>820084.85879</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.2</fme:SLOPESIZE>
<fme:SLOPEANGLE>182.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.84</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.85879 832715.00961 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddacbdc3e-edac-47a5-ae2e-505b01ff0522">
<fme:FEATURE_ID>1000317391</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832718.90131</fme:EASTING>
<fme:NORTHING>820085.01938</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.635</fme:SLOPESIZE>
<fme:SLOPEANGLE>181.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.727</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820085.01938 832718.90131 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id40162183-8462-4815-95a3-e180d178aee9">
<fme:FEATURE_ID>1000316860</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831880.92926</fme:EASTING>
<fme:NORTHING>820085.07734</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>133.94</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.075</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820085.07734 831880.92926 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idef0b72fc-bbc4-40f7-a62f-70a9bc4d5c5c">
<fme:FEATURE_ID>1000317093</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832418.84332</fme:EASTING>
<fme:NORTHING>820085.10231</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.465</fme:SLOPESIZE>
<fme:SLOPEANGLE>310.24</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.093</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820085.10231 832418.84332 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9eabb890-5694-47dd-8b53-7179e11bc941">
<fme:FEATURE_ID>1000316858</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831700.19163</fme:EASTING>
<fme:NORTHING>820085.35456</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.88</fme:SLOPESIZE>
<fme:SLOPEANGLE>422.47</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.176</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820085.35456 831700.19163 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idde6f6c05-c449-4674-8dfd-a3fff3e59e11">
<fme:FEATURE_ID>1000316857</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831890.08123</fme:EASTING>
<fme:NORTHING>820085.47295</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.44</fme:SLOPESIZE>
<fme:SLOPEANGLE>417.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.288</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820085.47295 831890.08123 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd2e82f67-f0be-482d-97f7-8e097571eec1">
<fme:FEATURE_ID>1000316856</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831683.76286</fme:EASTING>
<fme:NORTHING>820085.96861</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.44</fme:SLOPESIZE>
<fme:SLOPEANGLE>394.98</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.688</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820085.96861 831683.76286 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5f027f42-41f7-448e-a0a0-3d88bd494777">
<fme:FEATURE_ID>1000316855</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831813.92208</fme:EASTING>
<fme:NORTHING>820086.51186</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.695</fme:SLOPESIZE>
<fme:SLOPEANGLE>381.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.339</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820086.51186 831813.92208 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd2a8abc0-40d5-4229-8cb9-1a73607cc2ce">
<fme:FEATURE_ID>1000316854</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831642.49004</fme:EASTING>
<fme:NORTHING>820086.95676</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.915</fme:SLOPESIZE>
<fme:SLOPEANGLE>289.81</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.583</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820086.95676 831642.49004 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb123552b-271e-4481-8897-b887a47d5c58">
<fme:FEATURE_ID>1000317092</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832416.08655</fme:EASTING>
<fme:NORTHING>820087.32627</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.74</fme:SLOPESIZE>
<fme:SLOPEANGLE>309.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.548</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820087.32627 832416.08655 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6f278d03-d978-4eeb-8eb5-04ba934d9ed4">
<fme:FEATURE_ID>1000317960</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832398.16567</fme:EASTING>
<fme:NORTHING>820087.68948</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.22</fme:SLOPESIZE>
<fme:SLOPEANGLE>317.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.244</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820087.68948 832398.16567 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id26fb3c77-eb64-4495-bc6d-af3346dd8477">
<fme:FEATURE_ID>1000316853</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831817.95889</fme:EASTING>
<fme:NORTHING>820087.85037</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.58</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.396</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820087.85037 831817.95889 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id08bb4164-1311-48bd-96ae-594d357dc7ab">
<fme:FEATURE_ID>1000316852</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831891.92469</fme:EASTING>
<fme:NORTHING>820088.24972</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>34.125</fme:SLOPESIZE>
<fme:SLOPEANGLE>449.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.825</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820088.24972 831891.92469 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id74dfedff-7368-43c9-a274-2163f2d6e8a2">
<fme:FEATURE_ID>1000316851</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831879.21054</fme:EASTING>
<fme:NORTHING>820088.37198</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.25</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.05</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820088.37198 831879.21054 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc5c6000c-ba9e-47c6-bd4e-de707a03b698">
<fme:FEATURE_ID>1000316850</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831870.23472</fme:EASTING>
<fme:NORTHING>820088.38356</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>54.795</fme:SLOPESIZE>
<fme:SLOPEANGLE>348.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.959</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820088.38356 831870.23472 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide0b8bf50-4283-469f-8d53-28946efa4cdb">
<fme:FEATURE_ID>1000317927</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831763.51669</fme:EASTING>
<fme:NORTHING>820088.42535</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>48.725</fme:SLOPESIZE>
<fme:SLOPEANGLE>428.44</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.745</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820088.42535 831763.51669 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id53fb1b40-6725-49cf-91f3-9c04703d429b">
<fme:FEATURE_ID>1000316848</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831821.76836</fme:EASTING>
<fme:NORTHING>820088.85766</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.57</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820088.85766 831821.76836 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6041c2ca-c09c-4995-b603-c9f7479753ce">
<fme:FEATURE_ID>1000316847</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831711.97382</fme:EASTING>
<fme:NORTHING>820088.86059</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.53</fme:SLOPESIZE>
<fme:SLOPEANGLE>400.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.706</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820088.86059 831711.97382 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id746f16ef-130d-4144-9c24-017c8c6dae3c">
<fme:FEATURE_ID>1000316846</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831700.70656</fme:EASTING>
<fme:NORTHING>820089.52258</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.51</fme:SLOPESIZE>
<fme:SLOPEANGLE>439.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.302</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820089.52258 831700.70656 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idba3f4e97-e1ff-477d-bbd7-c8f000df8827">
<fme:FEATURE_ID>1000316845</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831825.62959</fme:EASTING>
<fme:NORTHING>820089.66195</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.84</fme:SLOPESIZE>
<fme:SLOPEANGLE>372.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.368</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820089.66195 831825.62959 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id252ae6ec-4cfa-4dea-bd1b-994dd863c7de">
<fme:FEATURE_ID>1000317925</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831853.87899</fme:EASTING>
<fme:NORTHING>820089.70916</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>368.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.525</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820089.70916 831853.87899 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id28e101d3-23cb-4b4d-bd4f-a9201c8d841e">
<fme:FEATURE_ID>1000317091</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832412.92728</fme:EASTING>
<fme:NORTHING>820089.83373</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.62</fme:SLOPESIZE>
<fme:SLOPEANGLE>308.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.124</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820089.83373 832412.92728 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc0cb22a3-a7d5-456c-ad2f-0b2f202436af">
<fme:FEATURE_ID>1000316844</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831829.51675</fme:EASTING>
<fme:NORTHING>820090.36476</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.88</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.24</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.376</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820090.36476 831829.51675 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide7b773e2-e5d0-4b4f-9f83-c485d3598704">
<fme:FEATURE_ID>1000317924</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831849.93403</fme:EASTING>
<fme:NORTHING>820090.53018</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.615</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.21</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.123</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820090.53018 831849.93403 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id17b2580d-51e4-4aec-877a-dd135671ab2f">
<fme:FEATURE_ID>1000316843</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831640.59174</fme:EASTING>
<fme:NORTHING>820090.60621</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.2</fme:SLOPESIZE>
<fme:SLOPEANGLE>289.27</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.24</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820090.60621 831640.59174 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id030ccf89-02fc-4c30-b14e-e4cc9667b09f">
<fme:FEATURE_ID>1000316842</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831833.48156</fme:EASTING>
<fme:NORTHING>820090.7631</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.095</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.219</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820090.76310 831833.48156 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id59964d93-0cc1-4fcb-97a4-1601018e87ca">
<fme:FEATURE_ID>1000316841</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831837.44497</fme:EASTING>
<fme:NORTHING>820091.46627</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.725</fme:SLOPESIZE>
<fme:SLOPEANGLE>372.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.145</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820091.46627 831837.44497 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf009d015-7f1d-4046-910f-11b811f490fe">
<fme:FEATURE_ID>1000316840</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831689.07585</fme:EASTING>
<fme:NORTHING>820091.80867</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.71</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.17</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.142</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820091.80867 831689.07585 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2a52df2d-cfbb-489e-8d11-ad19e3c85fa8">
<fme:FEATURE_ID>1000316839</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831863.50568</fme:EASTING>
<fme:NORTHING>820091.93573</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>61.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>354.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>12.332</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820091.93573 831863.50568 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2ff7241a-cbfc-451c-b788-119fffa40462">
<fme:FEATURE_ID>1000316838</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831841.40874</fme:EASTING>
<fme:NORTHING>820092.09319</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.86</fme:SLOPESIZE>
<fme:SLOPEANGLE>372.25</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.772</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820092.09319 831841.40874 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id14dcc50f-336e-499b-b84d-3fabb1bc2a34">
<fme:FEATURE_ID>1000316837</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831644.80545</fme:EASTING>
<fme:NORTHING>820092.1741</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.485</fme:SLOPESIZE>
<fme:SLOPEANGLE>309.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.897</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820092.17410 831644.80545 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id721d7653-0cbe-495c-840f-0dfbb32069c9">
<fme:FEATURE_ID>1000317923</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831858.16483</fme:EASTING>
<fme:NORTHING>820092.1918</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.44</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.688</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820092.19180 831858.16483 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id780a7d6a-e3df-438e-ac32-fee294bd12d3">
<fme:FEATURE_ID>1000316836</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831892.10966</fme:EASTING>
<fme:NORTHING>820092.28931</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.86</fme:SLOPESIZE>
<fme:SLOPEANGLE>114.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.972</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820092.28931 831892.10966 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3a850565-cf92-42eb-8b45-96c9b7d5f407">
<fme:FEATURE_ID>1000316835</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831878.48059</fme:EASTING>
<fme:NORTHING>820092.30598</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.25</fme:SLOPESIZE>
<fme:SLOPEANGLE>131.51</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.05</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820092.30598 831878.48059 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7ecd41bd-248e-4ce6-a8e0-a051499e1800">
<fme:FEATURE_ID>1000317090</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832410.19995</fme:EASTING>
<fme:NORTHING>820092.62144</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.91</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.08</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.782</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820092.62144 832410.19995 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5526c187-f060-4540-9c2a-fe0a19e6cb80">
<fme:FEATURE_ID>1000316834</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831845.34569</fme:EASTING>
<fme:NORTHING>820093.02484</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.915</fme:SLOPESIZE>
<fme:SLOPEANGLE>372</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.783</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820093.02484 831845.34569 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0717c86a-fb58-40df-bed5-d38b12ca952f">
<fme:FEATURE_ID>1000317959</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832393.94633</fme:EASTING>
<fme:NORTHING>820093.26287</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>43.645</fme:SLOPESIZE>
<fme:SLOPEANGLE>316.51</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.729</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820093.26287 832393.94633 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id44c347b1-4af3-4f6f-8848-65fff24eba5e">
<fme:FEATURE_ID>1000317926</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831767.91802</fme:EASTING>
<fme:NORTHING>820093.44861</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>45.815</fme:SLOPESIZE>
<fme:SLOPEANGLE>420.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.163</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820093.44861 831767.91802 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0baa19e7-8cbf-4bd9-8326-7080d02a869a">
<fme:FEATURE_ID>1000316833</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831700.53594</fme:EASTING>
<fme:NORTHING>820093.45902</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.485</fme:SLOPESIZE>
<fme:SLOPEANGLE>94.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.097</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820093.45902 831700.53594 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd3c0f791-5ff8-4f68-8895-cacdd3c10b0a">
<fme:FEATURE_ID>1000316832</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831638.82123</fme:EASTING>
<fme:NORTHING>820094.10383</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.695</fme:SLOPESIZE>
<fme:SLOPEANGLE>289.1</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.339</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820094.10383 831638.82123 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida37bcc37-cd62-4226-b12a-9c737c8799d1">
<fme:FEATURE_ID>1000316831</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831875.79894</fme:EASTING>
<fme:NORTHING>820094.88516</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.965</fme:SLOPESIZE>
<fme:SLOPEANGLE>142.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.993</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820094.88516 831875.79894 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3aedb8a4-4829-4f88-b464-089316f077ba">
<fme:FEATURE_ID>1000316830</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831690.7376</fme:EASTING>
<fme:NORTHING>820095.3975</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.505</fme:SLOPESIZE>
<fme:SLOPEANGLE>429.44</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.501</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820095.39750 831690.73760 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide2ad1500-58b1-4ad6-9c58-e8b901abb15a">
<fme:FEATURE_ID>1000316829</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831642.67865</fme:EASTING>
<fme:NORTHING>820095.74635</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.58</fme:SLOPESIZE>
<fme:SLOPEANGLE>302.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.916</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820095.74635 831642.67865 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6f0fa0d2-4b9c-4193-a8d4-385c106d4664">
<fme:FEATURE_ID>1000316828</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831889.80475</fme:EASTING>
<fme:NORTHING>820095.8862</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.575</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.76</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.115</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820095.88620 831889.80475 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id14999303-6088-4a88-b3c8-f0796b131c43">
<fme:FEATURE_ID>1000317089</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832408.18332</fme:EASTING>
<fme:NORTHING>820096.19794</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.705</fme:SLOPESIZE>
<fme:SLOPEANGLE>309.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.941</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820096.19794 832408.18332 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idba3395cf-6ef5-4e9b-9d0b-64bc148141d8">
<fme:FEATURE_ID>1000316827</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831699.50517</fme:EASTING>
<fme:NORTHING>820096.45185</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>116.14</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.175</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820096.45185 831699.50517 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id32aa864c-e446-46cb-aa94-a1648d3b2edc">
<fme:FEATURE_ID>1000316826</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831708.22616</fme:EASTING>
<fme:NORTHING>820096.56615</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.485</fme:SLOPESIZE>
<fme:SLOPEANGLE>146.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.097</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820096.56615 831708.22616 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id974ee29b-ff5f-4479-a718-be4713c4af1a">
<fme:FEATURE_ID>1000316825</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831872.22863</fme:EASTING>
<fme:NORTHING>820097.18107</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.18</fme:SLOPESIZE>
<fme:SLOPEANGLE>134.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.036</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820097.18107 831872.22863 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ideb019b85-c6ad-45fd-b6cd-ea23b129f317">
<fme:FEATURE_ID>1000316824</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831637.63312</fme:EASTING>
<fme:NORTHING>820098.13743</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.905</fme:SLOPESIZE>
<fme:SLOPEANGLE>287.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.381</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820098.13743 831637.63312 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id410c5ed9-99bc-4c3e-b1a6-3bc4c97ecdc8">
<fme:FEATURE_ID>1000316823</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831886.94518</fme:EASTING>
<fme:NORTHING>820098.43922</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.095</fme:SLOPESIZE>
<fme:SLOPEANGLE>136.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.619</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820098.43922 831886.94518 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id89d86036-7938-444a-9912-43a3be970fa9">
<fme:FEATURE_ID>1000316822</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831704.75871</fme:EASTING>
<fme:NORTHING>820098.60851</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.995</fme:SLOPESIZE>
<fme:SLOPEANGLE>145.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.799</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820098.60851 831704.75871 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9824dad8-7302-4a8b-87e3-853b021fe0aa">
<fme:FEATURE_ID>1000316821</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831770.86854</fme:EASTING>
<fme:NORTHING>820098.79572</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>46.315</fme:SLOPESIZE>
<fme:SLOPEANGLE>419.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.263</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820098.79572 831770.86854 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb03f4c1b-c6ff-4ca5-8b8e-0f059bfca3ce">
<fme:FEATURE_ID>1000316820</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831692.16904</fme:EASTING>
<fme:NORTHING>820099.31552</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.67</fme:SLOPESIZE>
<fme:SLOPEANGLE>431.11</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.534</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820099.31552 831692.16904 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id297135e8-399e-438a-9263-5dc12dc7662a">
<fme:FEATURE_ID>1000316819</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831640.857</fme:EASTING>
<fme:NORTHING>820099.31995</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.86</fme:SLOPESIZE>
<fme:SLOPEANGLE>288.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.572</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820099.31995 831640.85700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddc9f6517-2862-4bab-8eba-05da8ce76704">
<fme:FEATURE_ID>1000317958</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832389.43336</fme:EASTING>
<fme:NORTHING>820099.3561</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>46.405</fme:SLOPESIZE>
<fme:SLOPEANGLE>316.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.281</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820099.35610 832389.43336 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6894471f-17c7-40c3-8a7b-b430409904b1">
<fme:FEATURE_ID>1000316818</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831697.58269</fme:EASTING>
<fme:NORTHING>820099.8218</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.19</fme:SLOPESIZE>
<fme:SLOPEANGLE>117.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.038</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820099.82180 831697.58269 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9e9d05ec-6950-4339-8b27-eea4fd574280">
<fme:FEATURE_ID>1000316817</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831869.34181</fme:EASTING>
<fme:NORTHING>820100.14039</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.44</fme:SLOPESIZE>
<fme:SLOPEANGLE>138.21</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.088</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820100.14039 831869.34181 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id596e1d2f-96e2-4cc4-a0ff-30a08b203d6a">
<fme:FEATURE_ID>1000316816</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831883.42795</fme:EASTING>
<fme:NORTHING>820100.25272</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>153.43</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.975</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820100.25272 831883.42795 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2fda3d65-fc33-469b-90ce-8f9c76a6ec25">
<fme:FEATURE_ID>1000317088</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832408.19993</fme:EASTING>
<fme:NORTHING>820100.74383</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.605</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.121</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820100.74383 832408.19993 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbc76ca2c-a50e-4b92-b992-155a2c40f12c">
<fme:FEATURE_ID>1000316815</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831879.4817</fme:EASTING>
<fme:NORTHING>820101.35313</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.205</fme:SLOPESIZE>
<fme:SLOPEANGLE>161.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.241</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820101.35313 831879.48170 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idee58dd6a-a68f-4a64-b80d-ed1bb5ef2342">
<fme:FEATURE_ID>1000316814</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831701.64223</fme:EASTING>
<fme:NORTHING>820101.74462</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.1</fme:SLOPESIZE>
<fme:SLOPEANGLE>138.59</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.02</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820101.74462 831701.64223 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id90c74c06-1e9d-46d1-b98b-695de83247c0">
<fme:FEATURE_ID>1000316813</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831636.49692</fme:EASTING>
<fme:NORTHING>820101.94263</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.835</fme:SLOPESIZE>
<fme:SLOPEANGLE>284.97</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.367</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820101.94263 831636.49692 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd3c2b62a-2189-4d2b-8f1b-c992afff2528">
<fme:FEATURE_ID>1000316812</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831875.5352</fme:EASTING>
<fme:NORTHING>820102.50435</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.745</fme:SLOPESIZE>
<fme:SLOPEANGLE>162.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.949</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820102.50435 831875.53520 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1f0951cc-53a7-4cba-99ad-88711d03a014">
<fme:FEATURE_ID>1000316811</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831639.54521</fme:EASTING>
<fme:NORTHING>820102.59098</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.16</fme:SLOPESIZE>
<fme:SLOPEANGLE>281.91</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.432</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820102.59098 831639.54521 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id61e743f9-9ec4-4b2f-a3ff-77902fea0842">
<fme:FEATURE_ID>1000316810</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831866.48028</fme:EASTING>
<fme:NORTHING>820103.12521</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.75</fme:SLOPESIZE>
<fme:SLOPEANGLE>139.18</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.15</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820103.12521 831866.48028 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4ee03264-4fda-4de3-9b07-be522afcf198">
<fme:FEATURE_ID>1000316809</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831693.75326</fme:EASTING>
<fme:NORTHING>820103.18342</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.885</fme:SLOPESIZE>
<fme:SLOPEANGLE>431.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.177</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820103.18342 831693.75326 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide24b7065-3251-4486-ad4d-d36b3643192e">
<fme:FEATURE_ID>1000317957</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832384.63361</fme:EASTING>
<fme:NORTHING>820104.60891</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>46.825</fme:SLOPESIZE>
<fme:SLOPEANGLE>319.24</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.365</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820104.60891 832384.63361 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7bc3541b-5bd8-4ce2-8c5d-29f57e0df5e8">
<fme:FEATURE_ID>1000316808</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831773.84118</fme:EASTING>
<fme:NORTHING>820104.85419</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>49.4</fme:SLOPESIZE>
<fme:SLOPEANGLE>415.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.88</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820104.85419 831773.84118 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide57b4f66-1969-4a39-bd1a-4a6b5776d7bc">
<fme:FEATURE_ID>1000316806</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831635.51281</fme:EASTING>
<fme:NORTHING>820105.85009</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.105</fme:SLOPESIZE>
<fme:SLOPEANGLE>285.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.621</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820105.85009 831635.51281 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9cd47930-5db6-4140-bc1e-e8c56a399c7d">
<fme:FEATURE_ID>1000316805</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831638.76463</fme:EASTING>
<fme:NORTHING>820106.47392</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.82</fme:SLOPESIZE>
<fme:SLOPEANGLE>276.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.564</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820106.47392 831638.76463 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf2a34606-dc20-4645-a41a-eb52798f8e1f">
<fme:FEATURE_ID>1000317087</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832409.12922</fme:EASTING>
<fme:NORTHING>820106.84076</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.23</fme:SLOPESIZE>
<fme:SLOPEANGLE>309.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.846</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820106.84076 832409.12922 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id13d45119-f535-4c67-9373-462e59087a2a">
<fme:FEATURE_ID>1000316804</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831859.8511</fme:EASTING>
<fme:NORTHING>820107.08423</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.795</fme:SLOPESIZE>
<fme:SLOPEANGLE>150.74</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.959</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820107.08423 831859.85110 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id95ce1e35-90a8-47bb-b20d-5f471c7a8557">
<fme:FEATURE_ID>1000316803</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831798.72404</fme:EASTING>
<fme:NORTHING>820107.12199</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>35.05</fme:SLOPESIZE>
<fme:SLOPEANGLE>151.59</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.01</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820107.12199 831798.72404 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc50f0038-b62e-419f-9416-ded79bd0545e">
<fme:FEATURE_ID>1000316802</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831695.48836</fme:EASTING>
<fme:NORTHING>820107.40757</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.24</fme:SLOPESIZE>
<fme:SLOPEANGLE>432.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.448</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820107.40757 831695.48836 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida04e2242-ea78-47ca-ac3d-7c55d5fae8ea">
<fme:FEATURE_ID>1000316801</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831856.56445</fme:EASTING>
<fme:NORTHING>820108.51774</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.475</fme:SLOPESIZE>
<fme:SLOPEANGLE>159.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.295</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820108.51774 831856.56445 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida7074be6-3450-4629-bcf8-aee6e3c94938">
<fme:FEATURE_ID>1000316800</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831777.30638</fme:EASTING>
<fme:NORTHING>820108.85729</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>38.165</fme:SLOPESIZE>
<fme:SLOPEANGLE>415.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.633</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820108.85729 831777.30638 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida1db1996-db3e-4933-bc01-da25178d641d">
<fme:FEATURE_ID>1000316799</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831852.97582</fme:EASTING>
<fme:NORTHING>820109.26409</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.12</fme:SLOPESIZE>
<fme:SLOPEANGLE>165.89</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.424</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.26409 831852.97582 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idac89cdc1-f0ef-42bf-ad87-c26669dc62c7">
<fme:FEATURE_ID>1000317084</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832405.71234</fme:EASTING>
<fme:NORTHING>820109.34685</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.15</fme:SLOPESIZE>
<fme:SLOPEANGLE>315.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.83</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.34685 832405.71234 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5660a792-4b78-4b22-905d-b5e3ef89f8f6">
<fme:FEATURE_ID>1000316798</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831634.58045</fme:EASTING>
<fme:NORTHING>820109.55459</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.05</fme:SLOPESIZE>
<fme:SLOPEANGLE>284.09</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.21</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.55459 831634.58045 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2e1a05d7-9f61-4b86-a42c-4255d7359bc9">
<fme:FEATURE_ID>1000317956</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832380.11964</fme:EASTING>
<fme:NORTHING>820109.57446</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>49.59</fme:SLOPESIZE>
<fme:SLOPEANGLE>319.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.918</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.57446 832380.11964 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idadcff9cf-f865-48fa-a670-4f5576ae4dd7">
<fme:FEATURE_ID>1210014687</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832842.27792</fme:EASTING>
<fme:NORTHING>820109.68416</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.188</fme:SLOPESIZE>
<fme:SLOPEANGLE>140.711</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.838</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.68416 832842.27792 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id50c62d6e-08c5-41e4-b3c8-1c5869ddee5c">
<fme:FEATURE_ID>1000316797</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831849.76994</fme:EASTING>
<fme:NORTHING>820109.70731</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.22</fme:SLOPESIZE>
<fme:SLOPEANGLE>177.12</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.044</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.70731 831849.76994 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide6837f69-b29c-431b-b385-0070a7ac6086">
<fme:FEATURE_ID>1000316795</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831804.941</fme:EASTING>
<fme:NORTHING>820109.89246</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.43</fme:SLOPESIZE>
<fme:SLOPEANGLE>164.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.486</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.89246 831804.94100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idec48d6ae-890a-45d2-846f-8c732858de44">
<fme:FEATURE_ID>1000316794</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831845.98012</fme:EASTING>
<fme:NORTHING>820109.97017</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.03</fme:SLOPESIZE>
<fme:SLOPEANGLE>175.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.006</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.97017 831845.98012 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcdabd782-fc1c-4097-a1a5-3b492c531f9d">
<fme:FEATURE_ID>1000316793</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831638.56908</fme:EASTING>
<fme:NORTHING>820110.30864</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.94</fme:SLOPESIZE>
<fme:SLOPEANGLE>267.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.588</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820110.30864 831638.56908 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide06e6a0b-350f-46c1-b22e-d18caea9a72e">
<fme:FEATURE_ID>1000316792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831842.13905</fme:EASTING>
<fme:NORTHING>820110.309</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.845</fme:SLOPESIZE>
<fme:SLOPEANGLE>177.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.169</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820110.30900 831842.13905 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id31206f26-559a-4013-a919-3ab880054ea9">
<fme:FEATURE_ID>1000316791</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831838.37568</fme:EASTING>
<fme:NORTHING>820110.34335</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.74</fme:SLOPESIZE>
<fme:SLOPEANGLE>177.11</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.548</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820110.34335 831838.37568 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id55a0036b-6543-4b23-af71-5e5465258025">
<fme:FEATURE_ID>1000316790</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831697.38134</fme:EASTING>
<fme:NORTHING>820110.4894</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.315</fme:SLOPESIZE>
<fme:SLOPEANGLE>433.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.663</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820110.48940 831697.38134 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2d6bde34-ec12-4502-80da-8e626c8b7965">
<fme:FEATURE_ID>1000316789</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831810.32868</fme:EASTING>
<fme:NORTHING>820110.52566</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.58</fme:SLOPESIZE>
<fme:SLOPEANGLE>156.77</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.316</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820110.52566 831810.32868 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5fa34a2f-9f61-4e23-b851-95881c3df60d">
<fme:FEATURE_ID>1000316788</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831782.83966</fme:EASTING>
<fme:NORTHING>820111.01515</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.34</fme:SLOPESIZE>
<fme:SLOPEANGLE>414.8</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.468</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820111.01515 831782.83966 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddca40d57-81d6-4b0b-a727-f3ef38e08873">
<fme:FEATURE_ID>1000317463</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832838.71372</fme:EASTING>
<fme:NORTHING>820111.58122</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.155</fme:SLOPESIZE>
<fme:SLOPEANGLE>137.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.631</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820111.58122 832838.71372 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2e7fdf61-bfa7-4ce3-ae30-5775976fd771">
<fme:FEATURE_ID>1000316787</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831796.76624</fme:EASTING>
<fme:NORTHING>820112.65085</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.605</fme:SLOPESIZE>
<fme:SLOPEANGLE>141.14</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.121</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820112.65085 831796.76624 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf47e4d44-b8f3-4a7a-9943-e53e2b227826">
<fme:FEATURE_ID>1000316786</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831807.23914</fme:EASTING>
<fme:NORTHING>820113.33164</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>9</fme:SLOPESIZE>
<fme:SLOPEANGLE>153.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.8</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820113.33164 831807.23914 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id09a62a08-0bfe-44a3-8359-9f5e82f04018">
<fme:FEATURE_ID>1000317461</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832835.30141</fme:EASTING>
<fme:NORTHING>820113.45318</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.675</fme:SLOPESIZE>
<fme:SLOPEANGLE>137.05</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.135</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820113.45318 832835.30141 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf6608219-7ddf-472b-b84a-d82af6925552">
<fme:FEATURE_ID>1000316785</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831633.51994</fme:EASTING>
<fme:NORTHING>820113.48716</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.695</fme:SLOPESIZE>
<fme:SLOPEANGLE>284.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.339</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820113.48716 831633.51994 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5fd357c9-d8b2-41e8-8280-a9acdb73d80b">
<fme:FEATURE_ID>1000317460</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832829.93335</fme:EASTING>
<fme:NORTHING>820113.77194</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.255</fme:SLOPESIZE>
<fme:SLOPEANGLE>133.71</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.251</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820113.77194 832829.93335 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id333dad7e-ca67-44f9-827b-b9b90f0bc63d">
<fme:FEATURE_ID>1000317955</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832375.16538</fme:EASTING>
<fme:NORTHING>820114.38022</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>51.585</fme:SLOPESIZE>
<fme:SLOPEANGLE>321.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.317</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820114.38022 832375.16538 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id391d3226-c019-49cf-aa78-bf2f12dda582">
<fme:FEATURE_ID>1000316784</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831639.211</fme:EASTING>
<fme:NORTHING>820114.50262</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.075</fme:SLOPESIZE>
<fme:SLOPEANGLE>259.38</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.615</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820114.50262 831639.21100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8e05e462-9e84-4489-b81f-4ad7130818c0">
<fme:FEATURE_ID>1000316783</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831811.88359</fme:EASTING>
<fme:NORTHING>820115.23165</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>146.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.733</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820115.23165 831811.88359 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4c69c908-751c-442e-afb6-d69e2cb52741">
<fme:FEATURE_ID>1000316989</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832050.55561</fme:EASTING>
<fme:NORTHING>820116.38208</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.145</fme:SLOPESIZE>
<fme:SLOPEANGLE>349.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.629</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820116.38208 832050.55561 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddbcf970c-4cb4-4a59-a707-085dbb28ab92">
<fme:FEATURE_ID>1000316782</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831808.26545</fme:EASTING>
<fme:NORTHING>820116.86692</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.19</fme:SLOPESIZE>
<fme:SLOPEANGLE>144.77</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.638</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820116.86692 831808.26545 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3f1d0153-5ac1-486c-9e35-014e4a1404ee">
<fme:FEATURE_ID>1000316781</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831632.53516</fme:EASTING>
<fme:NORTHING>820117.54701</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.52</fme:SLOPESIZE>
<fme:SLOPEANGLE>286.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.304</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820117.54701 831632.53516 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide71fb9b9-f206-4428-842c-ef3ed385accb">
<fme:FEATURE_ID>1000316780</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831795.82727</fme:EASTING>
<fme:NORTHING>820117.80322</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.235</fme:SLOPESIZE>
<fme:SLOPEANGLE>132.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.047</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820117.80322 831795.82727 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6aa3c7a2-1b92-4abd-b3c0-0d5fdf451af3">
<fme:FEATURE_ID>1000316779</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831640.44077</fme:EASTING>
<fme:NORTHING>820118.03879</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>247.25</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.326</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820118.03879 831640.44077 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id949c3a3a-03bd-4133-bfc3-5ba2482efc18">
<fme:FEATURE_ID>1000316988</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832054.84503</fme:EASTING>
<fme:NORTHING>820118.10279</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.7</fme:SLOPESIZE>
<fme:SLOPEANGLE>352.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.54</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820118.10279 832054.84503 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id60b1ec7a-f976-496d-baae-09777bd9943a">
<fme:FEATURE_ID>1000317954</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832369.74766</fme:EASTING>
<fme:NORTHING>820118.14254</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>48.815</fme:SLOPESIZE>
<fme:SLOPEANGLE>321.12</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.763</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820118.14254 832369.74766 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id37ce8e99-a84e-4f79-8d08-038ddba01d4c">
<fme:FEATURE_ID>1000317457</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832829.18672</fme:EASTING>
<fme:NORTHING>820118.44288</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.12</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.424</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820118.44288 832829.18672 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id50d12a5b-2ed4-4a1a-b7d5-d2cab242871e">
<fme:FEATURE_ID>1000316778</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831804.97624</fme:EASTING>
<fme:NORTHING>820118.85923</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>143.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.732</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820118.85923 831804.97624 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfdb79713-971d-4dad-9002-a6cceabbb054">
<fme:FEATURE_ID>1000316987</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832059.28947</fme:EASTING>
<fme:NORTHING>820119.29088</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.975</fme:SLOPESIZE>
<fme:SLOPEANGLE>357.11</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.395</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820119.29088 832059.28947 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2c654b3a-bcd8-43dd-89ed-11d48cf9b636">
<fme:FEATURE_ID>1000316986</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832063.8098</fme:EASTING>
<fme:NORTHING>820120.53005</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>39.99</fme:SLOPESIZE>
<fme:SLOPEANGLE>364.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.998</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820120.53005 832063.80980 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb7fe54fb-4747-497c-8ffd-8b8453c3e927">
<fme:FEATURE_ID>1000316777</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831631.83234</fme:EASTING>
<fme:NORTHING>820121.10008</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.61</fme:SLOPESIZE>
<fme:SLOPEANGLE>281.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.322</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820121.10008 831631.83234 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id24b31022-d264-44c6-a81e-c1adc41a40c7">
<fme:FEATURE_ID>1000316776</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831801.83727</fme:EASTING>
<fme:NORTHING>820121.36024</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.22</fme:SLOPESIZE>
<fme:SLOPEANGLE>143.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.444</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820121.36024 831801.83727 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcb8b94b5-cd60-4279-8008-0b201fe58b0d">
<fme:FEATURE_ID>1000316775</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831642.40718</fme:EASTING>
<fme:NORTHING>820121.73051</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.76</fme:SLOPESIZE>
<fme:SLOPEANGLE>240.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.352</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820121.73051 831642.40718 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id82775277-bb9b-4da2-8e6e-05ee2d01239f">
<fme:FEATURE_ID>1000317953</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832364.17794</fme:EASTING>
<fme:NORTHING>820121.83083</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>47.87</fme:SLOPESIZE>
<fme:SLOPEANGLE>320.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.574</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820121.83083 832364.17794 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id713a9d0b-1eda-44d2-a05b-16de20df6d3f">
<fme:FEATURE_ID>1000316774</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831795.32558</fme:EASTING>
<fme:NORTHING>820121.86521</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.4</fme:SLOPESIZE>
<fme:SLOPEANGLE>124.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.88</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820121.86521 831795.32558 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id25f54620-f0dc-42e2-9f9c-015e106204f3">
<fme:FEATURE_ID>1000316985</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832068.50612</fme:EASTING>
<fme:NORTHING>820122.25259</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.682</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820122.25259 832068.50612 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id79c4ca74-3aae-4ba7-a8cc-6840001e047c">
<fme:FEATURE_ID>1000316773</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831798.85151</fme:EASTING>
<fme:NORTHING>820123.70948</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.015</fme:SLOPESIZE>
<fme:SLOPEANGLE>142.71</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.203</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820123.70948 831798.85151 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida28538f6-61d3-48d1-8460-e672459dc939">
<fme:FEATURE_ID>1000316984</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832072.59054</fme:EASTING>
<fme:NORTHING>820124.32798</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.225</fme:SLOPESIZE>
<fme:SLOPEANGLE>381.14</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.645</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820124.32798 832072.59054 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8a0f94d6-98e4-4bf0-ac0f-6324504f792d">
<fme:FEATURE_ID>1000316772</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831631.05304</fme:EASTING>
<fme:NORTHING>820124.70366</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.73</fme:SLOPESIZE>
<fme:SLOPEANGLE>276.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.346</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820124.70366 831631.05304 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf947f48a-d831-4253-9d89-69ed797393ad">
<fme:FEATURE_ID>1000317952</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832356.22631</fme:EASTING>
<fme:NORTHING>820124.97253</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>40.23</fme:SLOPESIZE>
<fme:SLOPEANGLE>324.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.046</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820124.97253 832356.22631 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id48d901fc-cac6-4487-b3af-2a4a08ec298b">
<fme:FEATURE_ID>1000316771</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831644.34781</fme:EASTING>
<fme:NORTHING>820125.49836</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.9</fme:SLOPESIZE>
<fme:SLOPEANGLE>241.73</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.18</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820125.49836 831644.34781 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6d33198d-7956-46be-b2e3-b4affb6ce451">
<fme:FEATURE_ID>1000316983</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832078.02524</fme:EASTING>
<fme:NORTHING>820125.79981</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.67</fme:SLOPESIZE>
<fme:SLOPEANGLE>381.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.134</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820125.79981 832078.02524 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8eb21be7-5f45-4e97-9148-fcbd4585d233">
<fme:FEATURE_ID>1000316769</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831796.09277</fme:EASTING>
<fme:NORTHING>820126.46616</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.635</fme:SLOPESIZE>
<fme:SLOPEANGLE>140.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.727</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820126.46616 831796.09277 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbbed1500-c948-4c4e-b87a-e99dc987e7cf">
<fme:FEATURE_ID>1000316982</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832083.79172</fme:EASTING>
<fme:NORTHING>820127.01916</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.675</fme:SLOPESIZE>
<fme:SLOPEANGLE>380.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.135</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820127.01916 832083.79172 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id33f2e497-985d-4777-9e2d-71ac1fe32711">
<fme:FEATURE_ID>1210014686</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832826.68154</fme:EASTING>
<fme:NORTHING>820127.64372</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.116</fme:SLOPESIZE>
<fme:SLOPEANGLE>163.179</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.223</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820127.64372 832826.68154 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id934581f4-cd83-4e03-aa3f-23ca6ff342dc">
<fme:FEATURE_ID>1000316768</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831630.63168</fme:EASTING>
<fme:NORTHING>820127.87697</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.26</fme:SLOPESIZE>
<fme:SLOPEANGLE>263.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.252</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820127.87697 831630.63168 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id45ce8603-f9f4-41aa-a075-fdd534f9cd0a">
<fme:FEATURE_ID>1000317951</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832349.05155</fme:EASTING>
<fme:NORTHING>820128.102</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.73</fme:SLOPESIZE>
<fme:SLOPEANGLE>331.01</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.746</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820128.10200 832349.05155 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id464b88dd-441e-4cb4-8db8-be2eb7119d6d">
<fme:FEATURE_ID>1000316767</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831801.72887</fme:EASTING>
<fme:NORTHING>820128.37047</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.37</fme:SLOPESIZE>
<fme:SLOPEANGLE>132.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.274</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820128.37047 831801.72887 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfe07182e-4a7e-4f1c-aea5-64623eedd540">
<fme:FEATURE_ID>1000316766</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831646.82417</fme:EASTING>
<fme:NORTHING>820128.88754</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.025</fme:SLOPESIZE>
<fme:SLOPEANGLE>231.96</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.205</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820128.88754 831646.82417 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id413f71a3-3fee-446d-a13d-e0d0bc528fb4">
<fme:FEATURE_ID>1000316981</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832088.76658</fme:EASTING>
<fme:NORTHING>820128.97153</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.76</fme:SLOPESIZE>
<fme:SLOPEANGLE>381.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.352</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820128.97153 832088.76658 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id190820a4-d37e-43d4-99d9-ec3d2543537b">
<fme:FEATURE_ID>1000316765</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831797.7283</fme:EASTING>
<fme:NORTHING>820130.23265</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.47</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.74</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.894</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820130.23265 831797.72830 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7e8aa473-c396-497f-ace1-3f50532885b0">
<fme:FEATURE_ID>1000317950</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832341.47585</fme:EASTING>
<fme:NORTHING>820130.3176</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>343.38</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.475</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820130.31760 832341.47585 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1340dd5b-6ab9-4c71-bbd5-3c920fb8c4c7">
<fme:FEATURE_ID>1000316764</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831649.76318</fme:EASTING>
<fme:NORTHING>820131.1865</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.015</fme:SLOPESIZE>
<fme:SLOPEANGLE>205.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.603</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820131.18650 831649.76318 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6536fa13-1889-441a-bb9f-298fa740c69b">
<fme:FEATURE_ID>1000316980</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832092.62107</fme:EASTING>
<fme:NORTHING>820131.29987</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.005</fme:SLOPESIZE>
<fme:SLOPEANGLE>380.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.401</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820131.29987 832092.62107 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbdc7806c-1514-4f93-8e9f-a158a41b0306">
<fme:FEATURE_ID>1000316763</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831631.73477</fme:EASTING>
<fme:NORTHING>820131.31091</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.115</fme:SLOPESIZE>
<fme:SLOPEANGLE>238.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.223</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820131.31091 831631.73477 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5c1e2875-bfe7-4fc9-93be-eeba623e2f06">
<fme:FEATURE_ID>1000317949</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832334.26774</fme:EASTING>
<fme:NORTHING>820132.87159</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.345</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.869</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820132.87159 832334.26774 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2149623b-f9a5-4e81-9df1-48453840cd2d">
<fme:FEATURE_ID>1000316762</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831653.69641</fme:EASTING>
<fme:NORTHING>820132.93095</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.475</fme:SLOPESIZE>
<fme:SLOPEANGLE>198.71</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.495</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820132.93095 831653.69641 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf1ed8808-a89b-4d61-b91c-ebd805659a5f">
<fme:FEATURE_ID>1000317921</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831795.04396</fme:EASTING>
<fme:NORTHING>820133.39608</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.455</fme:SLOPESIZE>
<fme:SLOPEANGLE>126.25</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.091</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820133.39608 831795.04396 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd25d5bb4-f903-4867-a99b-d84fb23a37ae">
<fme:FEATURE_ID>1000316979</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832096.22</fme:EASTING>
<fme:NORTHING>820133.9064</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.24</fme:SLOPESIZE>
<fme:SLOPEANGLE>379.1</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.248</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820133.90640 832096.22000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1af8e350-235f-4e87-b434-11fe84a5c35f">
<fme:FEATURE_ID>1000316761</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831634.69551</fme:EASTING>
<fme:NORTHING>820134.42282</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.44</fme:SLOPESIZE>
<fme:SLOPEANGLE>230.98</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.288</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820134.42282 831634.69551 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2f8dba9b-e6ed-4c41-a742-68438c1a7b5d">
<fme:FEATURE_ID>1000317948</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832327.92482</fme:EASTING>
<fme:NORTHING>820134.68393</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.87</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.774</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820134.68393 832327.92482 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idafd54b53-8c32-4932-86d0-6b2c079ed393">
<fme:FEATURE_ID>1000317075</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832360.99367</fme:EASTING>
<fme:NORTHING>820136.07017</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.19</fme:SLOPESIZE>
<fme:SLOPEANGLE>332.92</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.838</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820136.07017 832360.99367 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id03d91d3a-9b00-4052-8df3-84c2809add8c">
<fme:FEATURE_ID>1000316978</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832116.93297</fme:EASTING>
<fme:NORTHING>820136.10662</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.445</fme:SLOPESIZE>
<fme:SLOPEANGLE>349.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.289</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820136.10662 832116.93297 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbc3afb63-a50d-45c2-ba81-beaef2758a79">
<fme:FEATURE_ID>1000316977</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832099.84618</fme:EASTING>
<fme:NORTHING>820136.10675</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.835</fme:SLOPESIZE>
<fme:SLOPEANGLE>380.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.967</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820136.10675 832099.84618 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id35e3d969-e161-4a8b-b358-e75463ce04db">
<fme:FEATURE_ID>1000316760</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831638.29817</fme:EASTING>
<fme:NORTHING>820136.16579</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.335</fme:SLOPESIZE>
<fme:SLOPEANGLE>218.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.067</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820136.16579 831638.29817 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ideb5d0ba0-a0cc-4233-b280-b27b1bf08a87">
<fme:FEATURE_ID>1000318046</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832322.23322</fme:EASTING>
<fme:NORTHING>820136.48215</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.815</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.77</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.763</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820136.48215 832322.23322 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddb9b00e3-f4cb-4300-a0de-3718433541e0">
<fme:FEATURE_ID>1000317920</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831792.76655</fme:EASTING>
<fme:NORTHING>820136.53586</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.985</fme:SLOPESIZE>
<fme:SLOPEANGLE>126.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.197</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820136.53586 831792.76655 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide8cb91b5-e067-4ad8-981b-d2d8918e340f">
<fme:FEATURE_ID>1000316976</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832112.78175</fme:EASTING>
<fme:NORTHING>820137.58661</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.7</fme:SLOPESIZE>
<fme:SLOPEANGLE>354.05</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.94</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820137.58661 832112.78175 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id423aac5f-a78e-48d0-b62b-ac64a044ae67">
<fme:FEATURE_ID>1000316975</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832108.53526</fme:EASTING>
<fme:NORTHING>820137.64387</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.24</fme:SLOPESIZE>
<fme:SLOPEANGLE>363.73</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.848</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820137.64387 832108.53526 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idac48e4df-8a44-40c9-9839-dfe80666a038">
<fme:FEATURE_ID>1000316974</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832104.11055</fme:EASTING>
<fme:NORTHING>820137.75118</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.32</fme:SLOPESIZE>
<fme:SLOPEANGLE>373.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.064</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820137.75118 832104.11055 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8ab9c009-9d6b-41b3-922e-7862c5465fc0">
<fme:FEATURE_ID>1000316759</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831641.87425</fme:EASTING>
<fme:NORTHING>820138.16271</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.545</fme:SLOPESIZE>
<fme:SLOPEANGLE>211.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.709</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820138.16271 831641.87425 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2aaee819-094b-4701-91b8-afa0b98e20e2">
<fme:FEATURE_ID>1000317947</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832316.20723</fme:EASTING>
<fme:NORTHING>820138.44019</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.925</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.785</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820138.44019 832316.20723 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5678ca5b-1d73-407a-9723-ead0f31c8bd5">
<fme:FEATURE_ID>1000317074</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832344.93643</fme:EASTING>
<fme:NORTHING>820138.95646</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.585</fme:SLOPESIZE>
<fme:SLOPEANGLE>193.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.317</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820138.95646 832344.93643 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id316e118a-689a-4423-9915-d7b783102397">
<fme:FEATURE_ID>1000316758</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831922.27464</fme:EASTING>
<fme:NORTHING>820139.81133</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.53</fme:SLOPESIZE>
<fme:SLOPEANGLE>119.08</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.706</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820139.81133 831922.27464 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id11ebe002-0dd3-4ecb-8e5f-f8c09b679d59">
<fme:FEATURE_ID>1000317919</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831790.64048</fme:EASTING>
<fme:NORTHING>820139.95574</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>124.76</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.699</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820139.95574 831790.64048 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id66b8801c-9de1-4adc-940c-4f547cfac12f">
<fme:FEATURE_ID>1000317946</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832310.3381</fme:EASTING>
<fme:NORTHING>820140.09558</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.925</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.785</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820140.09558 832310.33810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id56915bc0-ee84-4d9b-8166-ca2476d0b929">
<fme:FEATURE_ID>1000317073</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832350.50459</fme:EASTING>
<fme:NORTHING>820140.4159</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.835</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.167</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820140.41590 832350.50459 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcc6e1877-9ff5-4f34-b844-202dcf94f4ee">
<fme:FEATURE_ID>1000317072</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832348.69831</fme:EASTING>
<fme:NORTHING>820140.48824</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>217.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.796</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820140.48824 832348.69831 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc77bb7ff-f80e-4d3a-ad66-65aa5470a687">
<fme:FEATURE_ID>1000316757</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831645.1429</fme:EASTING>
<fme:NORTHING>820140.6663</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.01</fme:SLOPESIZE>
<fme:SLOPEANGLE>213.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.202</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820140.66630 831645.14290 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7b257054-4855-4e8f-b6dc-42ec2344fb4e">
<fme:FEATURE_ID>1000316756</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831744.6091</fme:EASTING>
<fme:NORTHING>820141.73592</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.145</fme:SLOPESIZE>
<fme:SLOPEANGLE>125.01</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.229</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820141.73592 831744.60910 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id70d1c02d-8673-443e-8a98-0e5ebc5fca20">
<fme:FEATURE_ID>1000316755</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831918.07012</fme:EASTING>
<fme:NORTHING>820141.8498</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.52</fme:SLOPESIZE>
<fme:SLOPEANGLE>119.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.504</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820141.84980 831918.07012 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id78ce7ee8-d6d7-4ed5-b029-395d5fabf1ca">
<fme:FEATURE_ID>1000317945</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832304.30951</fme:EASTING>
<fme:NORTHING>820142.05445</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.99</fme:SLOPESIZE>
<fme:SLOPEANGLE>343.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.998</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820142.05445 832304.30951 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb39d239b-1903-4869-a36d-c738df53d8aa">
<fme:FEATURE_ID>1000317071</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832359.30265</fme:EASTING>
<fme:NORTHING>820142.26314</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.455</fme:SLOPESIZE>
<fme:SLOPEANGLE>338.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.891</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820142.26314 832359.30265 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id488758bf-986f-4e4d-9ed7-1630f84601c7">
<fme:FEATURE_ID>1000317070</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832355.07967</fme:EASTING>
<fme:NORTHING>820142.38113</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>344.05</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.796</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820142.38113 832355.07967 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id119da2bc-e95e-4154-82dd-26cebe3f4e9b">
<fme:FEATURE_ID>1000317069</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832352.73924</fme:EASTING>
<fme:NORTHING>820142.42693</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.11</fme:SLOPESIZE>
<fme:SLOPEANGLE>247.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.822</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820142.42693 832352.73924 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id03681568-94cd-4af5-adc3-6c3c50e73f07">
<fme:FEATURE_ID>1000316754</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831648.41228</fme:EASTING>
<fme:NORTHING>820143.01752</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.18</fme:SLOPESIZE>
<fme:SLOPEANGLE>215.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.036</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820143.01752 831648.41228 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ideb2d7367-ed36-42c7-9703-d306f9ee6d9f">
<fme:FEATURE_ID>1000317944</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832297.38696</fme:EASTING>
<fme:NORTHING>820144.16131</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.99</fme:SLOPESIZE>
<fme:SLOPEANGLE>343.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.998</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820144.16131 832297.38696 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id94e1757f-a42d-4dd2-99f2-952cc8d0c244">
<fme:FEATURE_ID>1000317918</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831790.11174</fme:EASTING>
<fme:NORTHING>820144.19363</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.57</fme:SLOPESIZE>
<fme:SLOPEANGLE>126.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.114</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820144.19363 831790.11174 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id282ca136-4706-4dec-aaff-4b5229239a8b">
<fme:FEATURE_ID>1000316753</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831916.81187</fme:EASTING>
<fme:NORTHING>820144.6125</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.805</fme:SLOPESIZE>
<fme:SLOPEANGLE>145.59</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.361</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820144.61250 831916.81187 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id41eee7f6-3d20-4032-8bd3-810daaf53cfa">
<fme:FEATURE_ID>1000316752</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831742.58497</fme:EASTING>
<fme:NORTHING>820145.10541</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.885</fme:SLOPESIZE>
<fme:SLOPEANGLE>121.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.177</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820145.10541 831742.58497 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id12abe6cf-bf20-47c8-8241-36f14ad725d1">
<fme:FEATURE_ID>1000316751</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831651.42814</fme:EASTING>
<fme:NORTHING>820145.18976</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.415</fme:SLOPESIZE>
<fme:SLOPEANGLE>216</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.083</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820145.18976 831651.42814 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb04fc0c5-e299-4366-a4d4-7512936e3623">
<fme:FEATURE_ID>1000317068</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832359.26925</fme:EASTING>
<fme:NORTHING>820146.35178</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.825</fme:SLOPESIZE>
<fme:SLOPEANGLE>266.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.765</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820146.35178 832359.26925 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1d5920af-f3da-4f50-998b-a584de618754">
<fme:FEATURE_ID>1000317943</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832290.34161</fme:EASTING>
<fme:NORTHING>820146.41155</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.4</fme:SLOPESIZE>
<fme:SLOPEANGLE>347.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.08</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820146.41155 832290.34161 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb90675d7-6241-4b7b-889c-8068eb794631">
<fme:FEATURE_ID>1000316750</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831912.14924</fme:EASTING>
<fme:NORTHING>820146.75055</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.355</fme:SLOPESIZE>
<fme:SLOPEANGLE>125.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.071</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820146.75055 831912.14924 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb93a59c8-aa68-47a8-9612-549c1eef20de">
<fme:FEATURE_ID>1000317067</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832354.38202</fme:EASTING>
<fme:NORTHING>820147.91588</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>268.18</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.299</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820147.91588 832354.38202 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd8b8d4cf-7ecd-4e34-ac5d-ead4c58bd4b2">
<fme:FEATURE_ID>1000317917</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831789.03292</fme:EASTING>
<fme:NORTHING>820148.03368</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>125.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.475</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820148.03368 831789.03292 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2bd3b787-ea84-4e04-b51b-e6a3b0542b6a">
<fme:FEATURE_ID>1000316749</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831653.93192</fme:EASTING>
<fme:NORTHING>820148.14723</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.895</fme:SLOPESIZE>
<fme:SLOPEANGLE>226.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.779</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820148.14723 831653.93192 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id22235a47-80ec-471f-acd4-3c73c3008400">
<fme:FEATURE_ID>1000316748</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831740.68876</fme:EASTING>
<fme:NORTHING>820148.29767</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.81</fme:SLOPESIZE>
<fme:SLOPEANGLE>120.94</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.162</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820148.29767 831740.68876 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd558e531-9605-40ca-8344-1e471b6a53e6">
<fme:FEATURE_ID>1000317942</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832283.26996</fme:EASTING>
<fme:NORTHING>820148.59335</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.82</fme:SLOPESIZE>
<fme:SLOPEANGLE>347.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.164</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820148.59335 832283.26996 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcf831ba2-9b96-4649-8ee5-8a4ac0d1ae47">
<fme:FEATURE_ID>1000316747</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831908.52428</fme:EASTING>
<fme:NORTHING>820149.95987</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.715</fme:SLOPESIZE>
<fme:SLOPEANGLE>95.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.343</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820149.95987 831908.52428 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id58478cca-e7a4-44f6-a42c-87c979acb37e">
<fme:FEATURE_ID>1000317066</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832359.87224</fme:EASTING>
<fme:NORTHING>820150.21324</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.155</fme:SLOPESIZE>
<fme:SLOPEANGLE>270.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.831</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820150.21324 832359.87224 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfddde146-59b1-4f7b-85d5-59090d0be399">
<fme:FEATURE_ID>1000317941</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832276.33249</fme:EASTING>
<fme:NORTHING>820150.70378</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.75</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.75</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820150.70378 832276.33249 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf8a0fb53-5a0c-4e8d-82cd-ebbb4506bc72">
<fme:FEATURE_ID>1000317916</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831786.86355</fme:EASTING>
<fme:NORTHING>820151.45002</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.43</fme:SLOPESIZE>
<fme:SLOPEANGLE>125.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.286</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820151.45002 831786.86355 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4844cbb5-d426-4846-86dc-e9953bbfa72e">
<fme:FEATURE_ID>1000316746</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831738.76592</fme:EASTING>
<fme:NORTHING>820151.74384</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.27</fme:SLOPESIZE>
<fme:SLOPEANGLE>113.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.254</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820151.74384 831738.76592 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id65e1fab8-a616-4fcd-939f-28032c1fd89e">
<fme:FEATURE_ID>1000317065</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832354.37371</fme:EASTING>
<fme:NORTHING>820152.18238</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.72</fme:SLOPESIZE>
<fme:SLOPEANGLE>288.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.344</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820152.18238 832354.37371 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida419327f-83a8-4bed-8379-b78adc419cf6">
<fme:FEATURE_ID>1000317940</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832269.25898</fme:EASTING>
<fme:NORTHING>820152.96126</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.395</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.58</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.679</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820152.96126 832269.25898 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5ef06ed2-ab5a-4ea9-95f4-80c731dead77">
<fme:FEATURE_ID>1000317064</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832360.93222</fme:EASTING>
<fme:NORTHING>820154.53278</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.175</fme:SLOPESIZE>
<fme:SLOPEANGLE>282.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.635</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820154.53278 832360.93222 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7b1b3be6-ab85-4c8e-8b12-e355711bf574">
<fme:FEATURE_ID>1000316745</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831911.32455</fme:EASTING>
<fme:NORTHING>820154.89939</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.57</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820154.89939 831911.32455 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0343ade6-caf2-4200-9a71-386a734469d6">
<fme:FEATURE_ID>1000316744</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831736.84264</fme:EASTING>
<fme:NORTHING>820155.29155</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.07</fme:SLOPESIZE>
<fme:SLOPEANGLE>111.19</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.814</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820155.29155 831736.84264 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id16abc839-d289-496b-9890-24729b372f75">
<fme:FEATURE_ID>1000317063</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832351.82181</fme:EASTING>
<fme:NORTHING>820156.31645</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.5</fme:SLOPESIZE>
<fme:SLOPEANGLE>316.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.3</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820156.31645 832351.82181 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcc4b4dae-5462-4d3b-a70f-43974057d3b0">
<fme:FEATURE_ID>1000316743</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831913.52176</fme:EASTING>
<fme:NORTHING>820158.23626</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.965</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.593</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820158.23626 831913.52176 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id63088571-ee1d-4cf2-b3c5-ad355770c005">
<fme:FEATURE_ID>1000317062</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832347.79865</fme:EASTING>
<fme:NORTHING>820158.31411</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.195</fme:SLOPESIZE>
<fme:SLOPEANGLE>333.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.839</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820158.31411 832347.79865 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide05ef4f6-1e2a-420b-8450-06c677bb805e">
<fme:FEATURE_ID>1000316742</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831734.48935</fme:EASTING>
<fme:NORTHING>820158.35481</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.03</fme:SLOPESIZE>
<fme:SLOPEANGLE>109.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.206</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820158.35481 831734.48935 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf9b4bfd7-9db4-444a-827b-e5e75c19e652">
<fme:FEATURE_ID>1000317922</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831779.3266</fme:EASTING>
<fme:NORTHING>820158.90339</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>445.43</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.325</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820158.90339 831779.32660 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id30d429f8-2672-4a22-bb92-8c43bfb77fe4">
<fme:FEATURE_ID>1000317061</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832343.54848</fme:EASTING>
<fme:NORTHING>820159.32089</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.44</fme:SLOPESIZE>
<fme:SLOPEANGLE>343.47</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.088</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820159.32089 832343.54848 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id43bc95ac-ec4d-46b2-af2f-237ae3fac8f7">
<fme:FEATURE_ID>1000317442</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832818.0672</fme:EASTING>
<fme:NORTHING>820159.60864</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.42</fme:SLOPESIZE>
<fme:SLOPEANGLE>217.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.884</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820159.60864 832818.06720 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbcfcb70e-2203-4829-8167-0f25b5c952f7">
<fme:FEATURE_ID>1000317060</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832339.73138</fme:EASTING>
<fme:NORTHING>820159.99843</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.87</fme:SLOPESIZE>
<fme:SLOPEANGLE>339.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.574</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820159.99843 832339.73138 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2ebb2f14-55ce-4ed1-90bf-cb5570cf9a09">
<fme:FEATURE_ID>1000317059</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832363.18375</fme:EASTING>
<fme:NORTHING>820160.93732</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.69</fme:SLOPESIZE>
<fme:SLOPEANGLE>307.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.938</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820160.93732 832363.18375 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idce330011-8d6f-4491-b676-a6d53f1b4976">
<fme:FEATURE_ID>1000317440</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832820.96335</fme:EASTING>
<fme:NORTHING>820161.5447</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.215</fme:SLOPESIZE>
<fme:SLOPEANGLE>215.9</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.843</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820161.54470 832820.96335 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfb2c6c60-2546-469e-93c3-2d336dc4c381">
<fme:FEATURE_ID>1000316741</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831915.76973</fme:EASTING>
<fme:NORTHING>820161.5987</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.995</fme:SLOPESIZE>
<fme:SLOPEANGLE>415.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.799</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820161.59870 831915.76973 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida0d53dec-a146-4832-be2e-bc2a1c326bef">
<fme:FEATURE_ID>1000317058</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832335.905</fme:EASTING>
<fme:NORTHING>820161.59897</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.035</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.1</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.607</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820161.59897 832335.90500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbf4812c9-9d40-484c-999d-84da754568f1">
<fme:FEATURE_ID>1000316740</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831731.16757</fme:EASTING>
<fme:NORTHING>820161.8965</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.83</fme:SLOPESIZE>
<fme:SLOPEANGLE>102.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.566</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820161.89650 831731.16757 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idca141957-c4b7-4a51-a139-831d36ae568a">
<fme:FEATURE_ID>1000316973</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832156.89004</fme:EASTING>
<fme:NORTHING>820161.93588</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.335</fme:SLOPESIZE>
<fme:SLOPEANGLE>92.94</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.667</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820161.93588 832156.89004 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id05467551-b6fb-4dac-9a71-7249153f0966">
<fme:FEATURE_ID>1000316739</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831781.43659</fme:EASTING>
<fme:NORTHING>820162.0145</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.5</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.9</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820162.01450 831781.43659 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbfa43a10-da7a-422a-8235-abef92052691">
<fme:FEATURE_ID>1000317057</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832359.13451</fme:EASTING>
<fme:NORTHING>820163.26509</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.73</fme:SLOPESIZE>
<fme:SLOPEANGLE>318.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.146</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820163.26509 832359.13451 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc83a2d58-0bda-4bf6-adac-bc3274317ae1">
<fme:FEATURE_ID>1000316738</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831785.44758</fme:EASTING>
<fme:NORTHING>820163.42908</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.74</fme:SLOPESIZE>
<fme:SLOPEANGLE>404.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.748</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820163.42908 831785.44758 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5bf5246c-8f29-4f8d-8f23-9f6fd9fec445">
<fme:FEATURE_ID>1000317439</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832823.73203</fme:EASTING>
<fme:NORTHING>820163.65828</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.17</fme:SLOPESIZE>
<fme:SLOPEANGLE>212.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.834</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820163.65828 832823.73203 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id208823a1-ccf9-4ed3-8c74-cd7b975d10af">
<fme:FEATURE_ID>1000317056</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832332.62644</fme:EASTING>
<fme:NORTHING>820163.91962</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.99</fme:SLOPESIZE>
<fme:SLOPEANGLE>339.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.398</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820163.91962 832332.62644 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8c57811d-6859-467e-9113-78a22f946708">
<fme:FEATURE_ID>1000317055</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832363.60946</fme:EASTING>
<fme:NORTHING>820164.39203</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>333.51</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.125</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820164.39203 832363.60946 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8c60d27b-c107-4ef5-91b9-4998e39ff52c">
<fme:FEATURE_ID>1000316737</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831918.22221</fme:EASTING>
<fme:NORTHING>820164.70811</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.085</fme:SLOPESIZE>
<fme:SLOPEANGLE>415.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.617</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820164.70811 831918.22221 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4a9ff73a-9ef2-4671-99ab-196301b8e0e3">
<fme:FEATURE_ID>1000318118</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832826.40056</fme:EASTING>
<fme:NORTHING>820164.95905</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.43</fme:SLOPESIZE>
<fme:SLOPEANGLE>195.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.886</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820164.95905 832826.40056 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id262d67f2-9e00-4b01-b351-4d6d70ba9f66">
<fme:FEATURE_ID>1000316736</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831788.923</fme:EASTING>
<fme:NORTHING>820165.19695</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.07</fme:SLOPESIZE>
<fme:SLOPEANGLE>396.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.014</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820165.19695 831788.92300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8f4c6283-5796-4467-ad33-eee077b0f16a">
<fme:FEATURE_ID>1000317438</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832815.05438</fme:EASTING>
<fme:NORTHING>820165.36671</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.87</fme:SLOPESIZE>
<fme:SLOPEANGLE>181.42</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.774</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820165.36671 832815.05438 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id665d6953-f3dd-4877-8af5-e80f4c1abc4b">
<fme:FEATURE_ID>1000317054</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832355.41562</fme:EASTING>
<fme:NORTHING>820165.77133</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.805</fme:SLOPESIZE>
<fme:SLOPEANGLE>329.43</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.961</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820165.77133 832355.41562 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb93b5478-741f-4f09-9cc5-990e56562199">
<fme:FEATURE_ID>1000316735</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831730.53761</fme:EASTING>
<fme:NORTHING>820166.21192</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>94.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.482</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820166.21192 831730.53761 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd01c632c-a19c-4dc7-8a87-41227081b582">
<fme:FEATURE_ID>1000316972</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832155.57361</fme:EASTING>
<fme:NORTHING>820166.32376</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.285</fme:SLOPESIZE>
<fme:SLOPEANGLE>93.92</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.257</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820166.32376 832155.57361 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id18fd94d8-9016-4de2-8683-3e988a18843d">
<fme:FEATURE_ID>1000317053</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832329.1103</fme:EASTING>
<fme:NORTHING>820166.80724</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.699</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820166.80724 832329.11030 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc832d949-2af7-4ec3-b439-6664b2d79a84">
<fme:FEATURE_ID>1210014671</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832338.86604</fme:EASTING>
<fme:NORTHING>820166.9944</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>16.61</fme:SLOPESIZE>
<fme:SLOPEANGLE>12.529</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.322</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820166.99440 832338.86604 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8c1e02d5-264e-4810-bd1a-5d3dbc58219f">
<fme:FEATURE_ID>1000316734</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831792.29653</fme:EASTING>
<fme:NORTHING>820167.01517</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.805</fme:SLOPESIZE>
<fme:SLOPEANGLE>393.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.361</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820167.01517 831792.29653 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddfc47bec-7dfd-4d15-b52f-9a18751f7a2e">
<fme:FEATURE_ID>1000316733</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831920.62374</fme:EASTING>
<fme:NORTHING>820167.84268</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.635</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.527</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820167.84268 831920.62374 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id497b611e-0f40-429b-8d01-a1bd7b2f85c0">
<fme:FEATURE_ID>1000317052</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832351.54474</fme:EASTING>
<fme:NORTHING>820167.94711</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.825</fme:SLOPESIZE>
<fme:SLOPEANGLE>334.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.165</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820167.94711 832351.54474 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id381f4610-54d9-4ecd-970a-e43c1f04214a">
<fme:FEATURE_ID>1000317051</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832342.38617</fme:EASTING>
<fme:NORTHING>820168.3339</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.265</fme:SLOPESIZE>
<fme:SLOPEANGLE>366.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.453</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820168.33390 832342.38617 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb31d678d-5563-4af8-9443-8003a896859b">
<fme:FEATURE_ID>1000317437</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832811.05473</fme:EASTING>
<fme:NORTHING>820168.43094</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.755</fme:SLOPESIZE>
<fme:SLOPEANGLE>182.89</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.751</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820168.43094 832811.05473 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id59ff33cc-7b51-45c5-9894-0763e2bbf989">
<fme:FEATURE_ID>1000317436</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832818.78782</fme:EASTING>
<fme:NORTHING>820168.47273</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>182.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.082</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820168.47273 832818.78782 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2aba21f7-0b81-4ae7-a6f0-b4a47d939136">
<fme:FEATURE_ID>1000317050</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832362.15111</fme:EASTING>
<fme:NORTHING>820168.68083</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.015</fme:SLOPESIZE>
<fme:SLOPEANGLE>331.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.803</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820168.68083 832362.15111 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf8e396a8-dc90-4da2-bc8a-495f699b6ce6">
<fme:FEATURE_ID>1000317049</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832325.37846</fme:EASTING>
<fme:NORTHING>820168.97524</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.62</fme:SLOPESIZE>
<fme:SLOPEANGLE>338.42</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.324</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820168.97524 832325.37846 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idec9ecfb7-27c0-4a91-906c-d45263ab781d">
<fme:FEATURE_ID>1000317048</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832346.58193</fme:EASTING>
<fme:NORTHING>820169.13009</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>352.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.099</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820169.13009 832346.58193 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idee960317-b331-4f0d-bbc3-1e758cd6622c">
<fme:FEATURE_ID>1000316732</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831795.15821</fme:EASTING>
<fme:NORTHING>820169.54236</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.45</fme:SLOPESIZE>
<fme:SLOPEANGLE>397.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.29</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820169.54236 831795.15821 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id70eb9ccc-03cd-4b5d-90f8-17601f362484">
<fme:FEATURE_ID>1000316731</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831731.00234</fme:EASTING>
<fme:NORTHING>820170.22731</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.305</fme:SLOPESIZE>
<fme:SLOPEANGLE>90.25</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.261</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820170.22731 831731.00234 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd65abd7c-c322-45d7-8ebf-75d869eaf7cc">
<fme:FEATURE_ID>1000317209</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832709.01867</fme:EASTING>
<fme:NORTHING>820170.72904</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.685</fme:SLOPESIZE>
<fme:SLOPEANGLE>156.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.337</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820170.72904 832709.01867 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id27ffa752-3ca8-4749-8195-be966b840bda">
<fme:FEATURE_ID>1000316971</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832152.78241</fme:EASTING>
<fme:NORTHING>820170.7305</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.935</fme:SLOPESIZE>
<fme:SLOPEANGLE>94.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.387</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820170.73050 832152.78241 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2ac9dabe-727c-445d-b96b-1e3e36fdfcbf">
<fme:FEATURE_ID>1000317435</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832822.37001</fme:EASTING>
<fme:NORTHING>820170.84195</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.59</fme:SLOPESIZE>
<fme:SLOPEANGLE>183.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.718</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820170.84195 832822.37001 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id016ab035-6161-4c68-a3d1-07b2c066f3dd">
<fme:FEATURE_ID>1000316730</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831923.17828</fme:EASTING>
<fme:NORTHING>820170.87635</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.805</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.361</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820170.87635 831923.17828 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfca1b119-a3b5-4693-90a4-2a5193978fe4">
<fme:FEATURE_ID>1000317046</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832358.78871</fme:EASTING>
<fme:NORTHING>820171.01006</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.69</fme:SLOPESIZE>
<fme:SLOPEANGLE>333.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.538</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820171.01006 832358.78871 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd8a0b130-130b-47d5-a89a-2339ded3379a">
<fme:FEATURE_ID>1000317208</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832714.2581</fme:EASTING>
<fme:NORTHING>820171.14644</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>171.52</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.996</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820171.14644 832714.25810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddfb2409b-e16d-4f6e-89c7-f88ba194f78c">
<fme:FEATURE_ID>1000317045</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832321.31733</fme:EASTING>
<fme:NORTHING>820171.33642</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.4</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.68</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820171.33642 832321.31733 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idba820c89-17ae-4eb5-b36b-1ddfe0043beb">
<fme:FEATURE_ID>1000317044</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832337.52083</fme:EASTING>
<fme:NORTHING>820171.72655</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.175</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.96</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.835</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820171.72655 832337.52083 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idaf85cf2e-605a-4989-b8c3-f9e74c846907">
<fme:FEATURE_ID>1000317043</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832346.75487</fme:EASTING>
<fme:NORTHING>820171.77164</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.595</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.17</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.119</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820171.77164 832346.75487 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id99272af4-5317-4c7b-9e6d-cc07fb9c4a40">
<fme:FEATURE_ID>1000317042</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832355.25066</fme:EASTING>
<fme:NORTHING>820172.0945</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.23</fme:SLOPESIZE>
<fme:SLOPEANGLE>331.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.446</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820172.09450 832355.25066 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0cefa731-61bb-4c54-9b64-1f33def086a5">
<fme:FEATURE_ID>1000316729</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831797.20568</fme:EASTING>
<fme:NORTHING>820172.19302</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.92</fme:SLOPESIZE>
<fme:SLOPEANGLE>405.18</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.384</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820172.19302 831797.20568 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6d21f1ec-b165-4503-9214-b916dcba77b0">
<fme:FEATURE_ID>1000317434</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832845.3718</fme:EASTING>
<fme:NORTHING>820172.22577</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.055</fme:SLOPESIZE>
<fme:SLOPEANGLE>177.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.211</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820172.22577 832845.37180 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id161bd287-38fc-440d-994a-3dca58952833">
<fme:FEATURE_ID>1000317041</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832351.05275</fme:EASTING>
<fme:NORTHING>820172.39031</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.505</fme:SLOPESIZE>
<fme:SLOPEANGLE>333.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.701</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820172.39031 832351.05275 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id843eada2-fc46-49ee-ad38-a091f82ffa62">
<fme:FEATURE_ID>1000317040</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832333.42391</fme:EASTING>
<fme:NORTHING>820172.40348</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.8</fme:SLOPESIZE>
<fme:SLOPEANGLE>339.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.96</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820172.40348 832333.42391 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id728cc7ad-5a4b-4880-b3b3-05ddc32c4fac">
<fme:FEATURE_ID>1000317433</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832849.36467</fme:EASTING>
<fme:NORTHING>820172.71683</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.65</fme:SLOPESIZE>
<fme:SLOPEANGLE>181.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.93</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820172.71683 832849.36467 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idec9afca2-f765-406f-a2a6-d82e76859573">
<fme:FEATURE_ID>1000317432</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832841.8345</fme:EASTING>
<fme:NORTHING>820172.9293</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.46</fme:SLOPESIZE>
<fme:SLOPEANGLE>165.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.092</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820172.92930 832841.83450 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id25794c40-c264-4c83-9e6f-04b58486b855">
<fme:FEATURE_ID>1000317431</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832853.35759</fme:EASTING>
<fme:NORTHING>820173.18245</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.745</fme:SLOPESIZE>
<fme:SLOPEANGLE>188.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.949</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820173.18245 832853.35759 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddc6cde1e-9a5b-415a-a5db-09c3a7d1d00f">
<fme:FEATURE_ID>1000317039</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832316.88661</fme:EASTING>
<fme:NORTHING>820173.6126</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.326</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820173.61260 832316.88661 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide95e755e-1ce4-44bf-98c9-b84c0fc7b108">
<fme:FEATURE_ID>1000317206</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832702.80577</fme:EASTING>
<fme:NORTHING>820173.8648</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>35.795</fme:SLOPESIZE>
<fme:SLOPEANGLE>146.9</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.159</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820173.86480 832702.80577 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb3d9cbdb-4485-4a49-946d-4514eba20e7b">
<fme:FEATURE_ID>1210014685</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832328.66795</fme:EASTING>
<fme:NORTHING>820173.88209</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.133</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.974</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.027</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820173.88209 832328.66795 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8d1ddd77-e7dd-4244-a73c-9f910c4e3adb">
<fme:FEATURE_ID>1000317430</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832857.5281</fme:EASTING>
<fme:NORTHING>820173.90244</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.325</fme:SLOPESIZE>
<fme:SLOPEANGLE>193.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.065</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820173.90244 832857.52810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbff26538-6e0a-4fca-a0a1-4aefa8d03335">
<fme:FEATURE_ID>1000316728</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831926.01136</fme:EASTING>
<fme:NORTHING>820174.16524</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.615</fme:SLOPESIZE>
<fme:SLOPEANGLE>414.39</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.123</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820174.16524 831926.01136 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id62d5cccd-bd21-45f0-a684-b86c1e64a1e1">
<fme:FEATURE_ID>1000316727</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831731.6196</fme:EASTING>
<fme:NORTHING>820174.24341</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.9</fme:SLOPESIZE>
<fme:SLOPEANGLE>447.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.18</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820174.24341 831731.61960 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3396f675-4668-496c-b874-f29846fe1a01">
<fme:FEATURE_ID>1000316726</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831798.97265</fme:EASTING>
<fme:NORTHING>820175.02029</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.78</fme:SLOPESIZE>
<fme:SLOPEANGLE>409.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.556</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820175.02029 831798.97265 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcd409674-2df3-4862-9d45-0506cf0a718f">
<fme:FEATURE_ID>1000317429</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832861.49384</fme:EASTING>
<fme:NORTHING>820175.23148</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.535</fme:SLOPESIZE>
<fme:SLOPEANGLE>196.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.907</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820175.23148 832861.49384 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id148118be-0b62-465f-a2d7-3bc3a9c66a62">
<fme:FEATURE_ID>1000317428</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832838.72624</fme:EASTING>
<fme:NORTHING>820175.36066</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.915</fme:SLOPESIZE>
<fme:SLOPEANGLE>152.52</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.583</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820175.36066 832838.72624 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide1351472-e381-4ee7-89ce-bb7fc973df87">
<fme:FEATURE_ID>1000316970</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832142.18237</fme:EASTING>
<fme:NORTHING>820175.76276</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>61.25</fme:SLOPESIZE>
<fme:SLOPEANGLE>95.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>12.25</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820175.76276 832142.18237 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idac19188d-0cff-443a-b70a-3da429cffaaa">
<fme:FEATURE_ID>1000317038</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832311.36178</fme:EASTING>
<fme:NORTHING>820176.01342</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>38.505</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.701</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820176.01342 832311.36178 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb527d81b-5035-49d7-9cf3-247bcaab02e3">
<fme:FEATURE_ID>1000317427</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832865.40835</fme:EASTING>
<fme:NORTHING>820176.76356</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.84</fme:SLOPESIZE>
<fme:SLOPEANGLE>202.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.768</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820176.76356 832865.40835 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6206be61-2806-4d0d-988a-a3ce4923e032">
<fme:FEATURE_ID>1000317037</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832325.02037</fme:EASTING>
<fme:NORTHING>820176.95677</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.795</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.19</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.959</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820176.95677 832325.02037 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id51c536f1-45d0-4406-a0e7-2295acef35d3">
<fme:FEATURE_ID>1000316725</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831928.51527</fme:EASTING>
<fme:NORTHING>820177.14786</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.325</fme:SLOPESIZE>
<fme:SLOPEANGLE>413.42</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.865</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820177.14786 831928.51527 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb5fa2dc0-93f1-42d6-949a-fdfd73719d1d">
<fme:FEATURE_ID>1000317426</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832835.77027</fme:EASTING>
<fme:NORTHING>820177.97015</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.825</fme:SLOPESIZE>
<fme:SLOPEANGLE>136.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.165</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820177.97015 832835.77027 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0995faf6-cc41-4fd6-bb5a-4406b4931405">
<fme:FEATURE_ID>1000317036</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832305.5828</fme:EASTING>
<fme:NORTHING>820178.3121</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>39.955</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.08</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.991</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820178.31210 832305.58280 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4c6c578f-f135-4472-aa62-227c89016495">
<fme:FEATURE_ID>1000316724</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831732.23635</fme:EASTING>
<fme:NORTHING>820178.38649</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.555</fme:SLOPESIZE>
<fme:SLOPEANGLE>447.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.711</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820178.38649 831732.23635 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddf5bc754-e7df-4388-ac4f-3afa80009305">
<fme:FEATURE_ID>1000317425</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832869.22092</fme:EASTING>
<fme:NORTHING>820178.42245</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.355</fme:SLOPESIZE>
<fme:SLOPEANGLE>204.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.671</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820178.42245 832869.22092 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id746b1ab0-6ca4-452d-be53-cb8fc9b9f19a">
<fme:FEATURE_ID>1000317204</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832698.67487</fme:EASTING>
<fme:NORTHING>820179.01103</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.32</fme:SLOPESIZE>
<fme:SLOPEANGLE>138.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.264</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820179.01103 832698.67487 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id74a37357-0523-439c-bfa4-c09762b7cf76">
<fme:FEATURE_ID>1000317203</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832545.63897</fme:EASTING>
<fme:NORTHING>820179.6268</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.455</fme:SLOPESIZE>
<fme:SLOPEANGLE>206.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.091</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820179.62680 832545.63897 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idabefa3c7-3007-4986-b252-a06334df269c">
<fme:FEATURE_ID>1000317035</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832321.78437</fme:EASTING>
<fme:NORTHING>820179.69266</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.205</fme:SLOPESIZE>
<fme:SLOPEANGLE>339.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.441</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820179.69266 832321.78437 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide3a72b87-ee02-41b5-acf1-3cf1f453ed13">
<fme:FEATURE_ID>1000317976</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831931.04459</fme:EASTING>
<fme:NORTHING>820180.13064</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.365</fme:SLOPESIZE>
<fme:SLOPEANGLE>414.44</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.673</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820180.13064 831931.04459 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6054c9dc-c55b-4649-8d63-58988e8c1fad">
<fme:FEATURE_ID>1000317034</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832299.09228</fme:EASTING>
<fme:NORTHING>820180.22835</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>39.09</fme:SLOPESIZE>
<fme:SLOPEANGLE>344.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.818</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820180.22835 832299.09228 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9fcee0bb-9c73-4c6c-9fce-b68654a9bc50">
<fme:FEATURE_ID>1000317202</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832539.76085</fme:EASTING>
<fme:NORTHING>820180.63014</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21</fme:SLOPESIZE>
<fme:SLOPEANGLE>172.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.2</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820180.63014 832539.76085 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc9d0a499-fd9b-47f8-a11c-ceb5d69298c6">
<fme:FEATURE_ID>1000317033</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832292.42526</fme:EASTING>
<fme:NORTHING>820181.33154</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>35.71</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.142</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820181.33154 832292.42526 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc779a7c5-82f9-4e40-b9fe-983c875db601">
<fme:FEATURE_ID>1000316969</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832139.86831</fme:EASTING>
<fme:NORTHING>820181.49226</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>66.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>95.24</fme:SLOPEANGLE>
<fme:SLOPESIZE200>13.275</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820181.49226 832139.86831 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id57d1b59e-001c-4bc5-95a5-824d9c29ba27">
<fme:FEATURE_ID>1000317032</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832287.02709</fme:EASTING>
<fme:NORTHING>820181.71855</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.933</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820181.71855 832287.02709 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id26a79fb5-7eec-4369-9eaf-466be31f45b3">
<fme:FEATURE_ID>1000317201</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832564.63653</fme:EASTING>
<fme:NORTHING>820182.00327</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.805</fme:SLOPESIZE>
<fme:SLOPEANGLE>191.27</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.761</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820182.00327 832564.63653 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id361ba5f2-55b3-46da-8b78-702fcfe7a0fe">
<fme:FEATURE_ID>1000316723</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831732.59878</fme:EASTING>
<fme:NORTHING>820182.52845</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.605</fme:SLOPESIZE>
<fme:SLOPEANGLE>448.84</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.321</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820182.52845 831732.59878 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id54826be2-7772-4926-809d-0755c6170034">
<fme:FEATURE_ID>1000317031</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832318.75111</fme:EASTING>
<fme:NORTHING>820182.80982</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.435</fme:SLOPESIZE>
<fme:SLOPEANGLE>339.73</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.287</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820182.80982 832318.75111 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1943683d-c0c1-417b-abfd-635f2e2cfbdf">
<fme:FEATURE_ID>1000317030</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832281.10155</fme:EASTING>
<fme:NORTHING>820183.18663</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.455</fme:SLOPESIZE>
<fme:SLOPEANGLE>329.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.291</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820183.18663 832281.10155 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0d2efb45-56a7-4c0e-8429-e8a5216fca86">
<fme:FEATURE_ID>1000317199</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832559.62292</fme:EASTING>
<fme:NORTHING>820183.21158</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.055</fme:SLOPESIZE>
<fme:SLOPEANGLE>166.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.411</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820183.21158 832559.62292 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0e39f6a5-7eff-4209-a7e0-fe2257cd6d1e">
<fme:FEATURE_ID>1000317975</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831933.95364</fme:EASTING>
<fme:NORTHING>820183.49604</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.42</fme:SLOPESIZE>
<fme:SLOPEANGLE>414.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.284</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820183.49604 831933.95364 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbaa5e58c-6685-4eae-8baa-2d6d5441300f">
<fme:FEATURE_ID>1000317198</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832535.8613</fme:EASTING>
<fme:NORTHING>820184.53255</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.93</fme:SLOPESIZE>
<fme:SLOPEANGLE>148.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.786</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820184.53255 832535.86130 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id25e305a7-4e76-4227-bbbb-b6d6fb79ec5b">
<fme:FEATURE_ID>1000317197</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832547.94326</fme:EASTING>
<fme:NORTHING>820185.0914</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.425</fme:SLOPESIZE>
<fme:SLOPEANGLE>237.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.885</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820185.09140 832547.94326 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idca24fb92-2195-409f-acb4-5c97cc8a3121">
<fme:FEATURE_ID>1000317196</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832569.31064</fme:EASTING>
<fme:NORTHING>820185.36519</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.285</fme:SLOPESIZE>
<fme:SLOPEANGLE>224.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.657</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820185.36519 832569.31064 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id790ae5e2-bdcb-4d2d-8b8f-a97960a2fe4d">
<fme:FEATURE_ID>1000317195</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832555.80245</fme:EASTING>
<fme:NORTHING>820185.69209</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.175</fme:SLOPESIZE>
<fme:SLOPEANGLE>147.96</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.235</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820185.69209 832555.80245 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id85b20158-0795-4356-b196-5a1f343cced0">
<fme:FEATURE_ID>1000317029</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832293.1536</fme:EASTING>
<fme:NORTHING>820186.13286</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.77</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820186.13286 832293.15360 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb04e2743-4283-4a30-8391-557e4b9f422f">
<fme:FEATURE_ID>1000317028</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832278.67867</fme:EASTING>
<fme:NORTHING>820186.38135</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.36</fme:SLOPESIZE>
<fme:SLOPEANGLE>276.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.672</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820186.38135 832278.67867 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id78008431-f3b1-446f-9fef-dcff6a83e29a">
<fme:FEATURE_ID>1000316722</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831731.84329</fme:EASTING>
<fme:NORTHING>820186.48771</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.69</fme:SLOPESIZE>
<fme:SLOPEANGLE>92.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.738</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820186.48771 831731.84329 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id88eb5686-b238-43b6-89a2-204e3a7c4851">
<fme:FEATURE_ID>1000317974</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831936.76173</fme:EASTING>
<fme:NORTHING>820186.68321</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.585</fme:SLOPESIZE>
<fme:SLOPEANGLE>415.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.117</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820186.68321 831936.76173 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idde9fddf5-9ea4-4d45-bbcd-7ed021dc8aad">
<fme:FEATURE_ID>1000317027</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832315.71582</fme:EASTING>
<fme:NORTHING>820186.96826</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.72</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.944</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820186.96826 832315.71582 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb7b5377f-a8cb-452b-b482-75deab495495">
<fme:FEATURE_ID>1000317973</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831950.53925</fme:EASTING>
<fme:NORTHING>820187.53184</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.705</fme:SLOPESIZE>
<fme:SLOPEANGLE>321.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.541</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820187.53184 831950.53925 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idee8af4c2-50d3-4c6d-9f7e-1ec1b33220a3">
<fme:FEATURE_ID>1000316968</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832136.91568</fme:EASTING>
<fme:NORTHING>820187.87926</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>73.74</fme:SLOPESIZE>
<fme:SLOPEANGLE>91.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>14.748</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820187.87926 832136.91568 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcdfd5e04-8f1e-4fca-a6d9-5bf249a3e75c">
<fme:FEATURE_ID>1000317192</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832552.94853</fme:EASTING>
<fme:NORTHING>820188.20006</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>146.47</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.299</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820188.20006 832552.94853 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc3b9586f-308f-4223-ad56-d490823167fe">
<fme:FEATURE_ID>1000317026</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832298.21161</fme:EASTING>
<fme:NORTHING>820188.30231</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.09</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.98</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.418</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820188.30231 832298.21161 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5ae9300e-7cdb-4ee3-9637-5e28ab1acb11">
<fme:FEATURE_ID>1000317191</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832549.10603</fme:EASTING>
<fme:NORTHING>820188.92836</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.72</fme:SLOPESIZE>
<fme:SLOPEANGLE>237.96</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.544</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820188.92836 832549.10603 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id025c19f8-af44-45ac-aeb9-08ad4cae1e19">
<fme:FEATURE_ID>1000317190</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832571.84725</fme:EASTING>
<fme:NORTHING>820189.07808</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>238.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.57</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820189.07808 832571.84725 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1ab8be92-6c21-4e9d-84aa-79fc001ab79a">
<fme:FEATURE_ID>1000316721</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831730.80959</fme:EASTING>
<fme:NORTHING>820190.11556</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.76</fme:SLOPESIZE>
<fme:SLOPEANGLE>96.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.352</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820190.11556 831730.80959 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3ec80a8e-b489-470c-8c2d-98d65d0e94f5">
<fme:FEATURE_ID>1000317972</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831939.5433</fme:EASTING>
<fme:NORTHING>820190.12423</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.725</fme:SLOPESIZE>
<fme:SLOPEANGLE>391.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.145</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820190.12423 831939.54330 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id104d6d27-0af2-4337-a5be-aa1975ab9a2a">
<fme:FEATURE_ID>1000317025</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832280.98604</fme:EASTING>
<fme:NORTHING>820190.24642</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.385</fme:SLOPESIZE>
<fme:SLOPEANGLE>275.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.077</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820190.24642 832280.98604 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc6d4a202-c869-4633-a118-27cce501b0b2">
<fme:FEATURE_ID>1000317971</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831947.19613</fme:EASTING>
<fme:NORTHING>820190.2599</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.5</fme:SLOPESIZE>
<fme:SLOPEANGLE>330.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.7</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820190.25990 831947.19613 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id614433e8-d629-41e7-9c64-286743bc4380">
<fme:FEATURE_ID>1000317024</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832303.80283</fme:EASTING>
<fme:NORTHING>820190.9808</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.295</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.659</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820190.98080 832303.80283 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbcbd98ef-58d2-4ac1-9d88-eeb65d9e16d1">
<fme:FEATURE_ID>1000316720</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831795.03153</fme:EASTING>
<fme:NORTHING>820191.66619</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.77</fme:SLOPESIZE>
<fme:SLOPEANGLE>307.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.354</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820191.66619 831795.03153 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id616fad4c-1bf3-49e5-be85-b4f9e8cb2786">
<fme:FEATURE_ID>1000317187</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832551.66933</fme:EASTING>
<fme:NORTHING>820192.00652</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.825</fme:SLOPESIZE>
<fme:SLOPEANGLE>237.76</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.765</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820192.00652 832551.66933 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfcf62a18-6f8e-4fdf-9e0b-148b517f2de8">
<fme:FEATURE_ID>1000317186</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832573.6213</fme:EASTING>
<fme:NORTHING>820192.51005</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.545</fme:SLOPESIZE>
<fme:SLOPEANGLE>241.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.509</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820192.51005 832573.62130 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida08d8327-3089-427a-b076-9892cac9ce7e">
<fme:FEATURE_ID>1000317970</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831943.42284</fme:EASTING>
<fme:NORTHING>820192.52886</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.23</fme:SLOPESIZE>
<fme:SLOPEANGLE>360.91</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.446</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820192.52886 831943.42284 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id91826bc7-0ba9-439c-8e96-c98504647fad">
<fme:FEATURE_ID>1000316719</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831730.13096</fme:EASTING>
<fme:NORTHING>820193.94814</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.675</fme:SLOPESIZE>
<fme:SLOPEANGLE>96.24</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.335</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820193.94814 831730.13096 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8af56049-af07-4ed2-a2e6-4669ced49fb9">
<fme:FEATURE_ID>1000317023</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832311.4792</fme:EASTING>
<fme:NORTHING>820194.07004</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>44.255</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.2</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.851</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820194.07004 832311.47920 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id34a0b8ea-57d8-44e3-af3f-844566a8e9eb">
<fme:FEATURE_ID>1000317022</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832280.95291</fme:EASTING>
<fme:NORTHING>820194.18271</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.48</fme:SLOPESIZE>
<fme:SLOPEANGLE>275.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.296</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820194.18271 832280.95291 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id71832dc9-a326-4e76-8f3c-90ec15149bdc">
<fme:FEATURE_ID>1000316718</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831792.7797</fme:EASTING>
<fme:NORTHING>820194.7807</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.315</fme:SLOPESIZE>
<fme:SLOPEANGLE>305.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.463</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820194.78070 831792.77970 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8a9c5bee-b243-478b-ba0a-c7c2c1fe12c0">
<fme:FEATURE_ID>1000316967</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832136.57689</fme:EASTING>
<fme:NORTHING>820195.42075</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>76.385</fme:SLOPESIZE>
<fme:SLOPEANGLE>445.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>15.277</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820195.42075 832136.57689 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id712b6e70-8960-48eb-80d1-f0fedf455975">
<fme:FEATURE_ID>1000317183</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832575.34449</fme:EASTING>
<fme:NORTHING>820195.9165</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.11</fme:SLOPESIZE>
<fme:SLOPEANGLE>241.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.422</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820195.91650 832575.34449 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1e980216-e743-4107-9cfd-326d7ad40290">
<fme:FEATURE_ID>1000316717</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831729.75754</fme:EASTING>
<fme:NORTHING>820197.7567</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.685</fme:SLOPESIZE>
<fme:SLOPEANGLE>96</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.537</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820197.75670 831729.75754 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id583325d1-3f5f-45ab-afd9-701c54e067db">
<fme:FEATURE_ID>1210014676</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832361.54701</fme:EASTING>
<fme:NORTHING>820197.84557</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.242</fme:SLOPESIZE>
<fme:SLOPEANGLE>346.329</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.648</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820197.84557 832361.54701 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id77f128bc-2e6d-41b7-91d5-b4b568c05caa">
<fme:FEATURE_ID>1000317021</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832279.54619</fme:EASTING>
<fme:NORTHING>820198.09064</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>275.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.875</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820198.09064 832279.54619 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcb8d0393-579d-4b3d-977d-58d731e66837">
<fme:FEATURE_ID>1000316716</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831790.27219</fme:EASTING>
<fme:NORTHING>820198.19887</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.22</fme:SLOPESIZE>
<fme:SLOPEANGLE>305.92</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.444</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820198.19887 831790.27219 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id98946218-1232-461a-bbf0-c0683174199a">
<fme:FEATURE_ID>1000317181</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832577.16963</fme:EASTING>
<fme:NORTHING>820199.247</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.89</fme:SLOPESIZE>
<fme:SLOPEANGLE>241.47</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.378</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820199.24700 832577.16963 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc91498ca-c3e6-432a-b7eb-06908462221a">
<fme:FEATURE_ID>1210014675</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832358.64903</fme:EASTING>
<fme:NORTHING>820200.13545</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>19.254</fme:SLOPESIZE>
<fme:SLOPEANGLE>346.759</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.851</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820200.13545 832358.64903 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id79e60ba1-4342-49f7-8e0c-1d4bc6c862c3">
<fme:FEATURE_ID>1000316966</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832140.6189</fme:EASTING>
<fme:NORTHING>820201.30555</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>63.25</fme:SLOPESIZE>
<fme:SLOPEANGLE>442.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>12.65</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820201.30555 832140.61890 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbd5ed9c1-7a32-457d-aa03-67b99896d913">
<fme:FEATURE_ID>1000316715</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831729.35762</fme:EASTING>
<fme:NORTHING>820201.79373</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>93.08</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.326</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820201.79373 831729.35762 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb849e873-f2cc-4837-9e92-f51a384f922b">
<fme:FEATURE_ID>1000317020</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832279.33492</fme:EASTING>
<fme:NORTHING>820202.07734</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.23</fme:SLOPESIZE>
<fme:SLOPEANGLE>275.85</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.846</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820202.07734 832279.33492 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idce066e53-ed7f-40a1-b43d-e55fdd70905b">
<fme:FEATURE_ID>1000317177</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832578.6638</fme:EASTING>
<fme:NORTHING>820202.70375</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.245</fme:SLOPESIZE>
<fme:SLOPEANGLE>240.51</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.249</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820202.70375 832578.66380 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id35408d4e-c0a8-47a5-b592-564508a2c808">
<fme:FEATURE_ID>1000316714</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831790.40171</fme:EASTING>
<fme:NORTHING>820203.2289</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.415</fme:SLOPESIZE>
<fme:SLOPEANGLE>302.21</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.083</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820203.22890 831790.40171 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id17e66251-667e-4b18-a16b-82e2d6e93a2f">
<fme:FEATURE_ID>1000316713</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831729.49043</fme:EASTING>
<fme:NORTHING>820206.11248</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>90.25</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.275</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820206.11248 831729.49043 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb075c6a8-b2ef-457e-aa69-d6bd88091570">
<fme:FEATURE_ID>1000317019</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832279.58142</fme:EASTING>
<fme:NORTHING>820206.11576</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.735</fme:SLOPESIZE>
<fme:SLOPEANGLE>278.18</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.347</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820206.11576 832279.58142 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0f7ed7ce-3698-4ab4-9884-62b3b3d3face">
<fme:FEATURE_ID>1000317173</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832580.36143</fme:EASTING>
<fme:NORTHING>820206.18634</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.58</fme:SLOPESIZE>
<fme:SLOPEANGLE>241.18</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.116</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820206.18634 832580.36143 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd411a806-ee43-4817-8914-cbc06fd48602">
<fme:FEATURE_ID>1000316712</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831788.35083</fme:EASTING>
<fme:NORTHING>820206.87767</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.82</fme:SLOPESIZE>
<fme:SLOPEANGLE>298.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.364</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820206.87767 831788.35083 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0e4dbead-86f1-4533-8ae0-80911aa36291">
<fme:FEATURE_ID>1310096846</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832748.124</fme:EASTING>
<fme:NORTHING>820207.956</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.468</fme:SLOPESIZE>
<fme:SLOPEANGLE>165.826</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.694</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820207.95583 832748.12368 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf1519a16-e32e-4c4d-b9c4-f66be2b8bff0">
<fme:FEATURE_ID>1210014674</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832358.45555</fme:EASTING>
<fme:NORTHING>820208.54634</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.874</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.906</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.375</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820208.54634 832358.45555 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7736f62d-35b7-4cde-b0de-aececf2b95f8">
<fme:FEATURE_ID>1000317172</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832507.57708</fme:EASTING>
<fme:NORTHING>820209.46055</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.25</fme:SLOPESIZE>
<fme:SLOPEANGLE>150.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.25</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820209.46055 832507.57708 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc9e9566e-3f40-40b3-8c8b-091d396629f2">
<fme:FEATURE_ID>1000316711</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831786.73711</fme:EASTING>
<fme:NORTHING>820209.46155</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.99</fme:SLOPESIZE>
<fme:SLOPEANGLE>272.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.398</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820209.46155 831786.73711 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id69751aa6-4f6c-402b-a772-8b405809682e">
<fme:FEATURE_ID>1000317171</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832581.93203</fme:EASTING>
<fme:NORTHING>820209.5671</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.52</fme:SLOPESIZE>
<fme:SLOPEANGLE>240.76</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.904</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820209.56710 832581.93203 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idaedbb6c7-e5b7-43b3-9caa-02dfe85a7527">
<fme:FEATURE_ID>1000317170</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832512.30806</fme:EASTING>
<fme:NORTHING>820209.7245</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.97</fme:SLOPESIZE>
<fme:SLOPEANGLE>148.91</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.594</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820209.72450 832512.30806 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7fbfa621-1c06-431c-900b-02486397f949">
<fme:FEATURE_ID>1000317169</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832516.98852</fme:EASTING>
<fme:NORTHING>820209.78519</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.335</fme:SLOPESIZE>
<fme:SLOPEANGLE>150.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.467</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820209.78519 832516.98852 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf5bf70ca-9711-4ccc-a076-4e289b16d43c">
<fme:FEATURE_ID>1000317168</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832495.72206</fme:EASTING>
<fme:NORTHING>820209.94334</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.23</fme:SLOPESIZE>
<fme:SLOPEANGLE>143.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.246</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820209.94334 832495.72206 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9de75cd6-d4ae-4f50-9ad2-06713554ebbb">
<fme:FEATURE_ID>1000317167</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832502.48831</fme:EASTING>
<fme:NORTHING>820210.08464</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.32</fme:SLOPESIZE>
<fme:SLOPEANGLE>148.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.264</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820210.08464 832502.48831 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide63e36ed-b522-4c5e-bdca-f5550e0f491e">
<fme:FEATURE_ID>1000316710</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831730.43678</fme:EASTING>
<fme:NORTHING>820210.46024</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.11</fme:SLOPESIZE>
<fme:SLOPEANGLE>443.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.822</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820210.46024 831730.43678 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id39b83898-fdef-46a6-998f-e482afc213c0">
<fme:FEATURE_ID>1210014678</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832338.31906</fme:EASTING>
<fme:NORTHING>820210.6777</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>55.632</fme:SLOPESIZE>
<fme:SLOPEANGLE>344.564</fme:SLOPEANGLE>
<fme:SLOPESIZE200>11.126</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820210.67770 832338.31906 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida813cc24-b5da-4a91-a33f-e8e691f71cc0">
<fme:FEATURE_ID>1000317018</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832280.71663</fme:EASTING>
<fme:NORTHING>820210.99419</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>37.73</fme:SLOPESIZE>
<fme:SLOPEANGLE>285.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.546</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820210.99419 832280.71663 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id720919b6-fb06-450a-92b1-5789f6433a13">
<fme:FEATURE_ID>1210014680</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832327.13951</fme:EASTING>
<fme:NORTHING>820211.29828</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>48.385</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.821</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.677</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820211.29828 832327.13951 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id795a9d58-9e54-425c-980d-219d9025b8cf">
<fme:FEATURE_ID>1000317166</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832487.55345</fme:EASTING>
<fme:NORTHING>820211.52588</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>52.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>128.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.482</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820211.52588 832487.55345 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddbed0973-f5d6-4a76-ab7b-b30f7e9bf5bb">
<fme:FEATURE_ID>1210014681</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832321.48916</fme:EASTING>
<fme:NORTHING>820211.90909</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>39.486</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.844</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.897</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820211.90909 832321.48916 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2369005e-ce73-4e34-bc94-d75784fcabb8">
<fme:FEATURE_ID>1210014684</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832305.63805</fme:EASTING>
<fme:NORTHING>820212.20473</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.673</fme:SLOPESIZE>
<fme:SLOPEANGLE>344.624</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.935</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820212.20473 832305.63805 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc7d45102-ec92-4998-a313-870f98cda087">
<fme:FEATURE_ID>1210014677</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832345.0167</fme:EASTING>
<fme:NORTHING>820212.21147</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>58.21</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.94</fme:SLOPEANGLE>
<fme:SLOPESIZE200>11.642</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820212.21147 832345.01670 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfaa8c9a6-0493-4569-bc6b-b1d2c8bf9034">
<fme:FEATURE_ID>1000316709</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831787.33434</fme:EASTING>
<fme:NORTHING>820212.30909</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.405</fme:SLOPESIZE>
<fme:SLOPEANGLE>244.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.281</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820212.30909 831787.33434 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idebf7b6a6-9ed9-4d9e-b647-969795dd6735">
<fme:FEATURE_ID>1210014679</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832333.40812</fme:EASTING>
<fme:NORTHING>820212.36486</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>57.412</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.692</fme:SLOPEANGLE>
<fme:SLOPESIZE200>11.482</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820212.36486 832333.40812 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2a757c79-1081-4966-b498-50cc5bc35793">
<fme:FEATURE_ID>1210014673</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832354.94379</fme:EASTING>
<fme:NORTHING>820212.66947</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>50.242</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.996</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.048</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820212.66947 832354.94379 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id62cfbafb-dac7-4672-9b95-e7339e1a36cc">
<fme:FEATURE_ID>1210014682</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832316.43623</fme:EASTING>
<fme:NORTHING>820212.67749</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.328</fme:SLOPESIZE>
<fme:SLOPEANGLE>339.228</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.266</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820212.67749 832316.43623 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id12ddbc59-1285-453c-bcee-767c8d3dd7cd">
<fme:FEATURE_ID>1000317164</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832583.37559</fme:EASTING>
<fme:NORTHING>820212.89679</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.235</fme:SLOPESIZE>
<fme:SLOPEANGLE>238.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.647</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820212.89679 832583.37559 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5c9bc345-d34f-4918-ae05-3d9bf6453281">
<fme:FEATURE_ID>1210014672</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832349.74786</fme:EASTING>
<fme:NORTHING>820212.95359</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>74.699</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>14.94</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820212.95359 832349.74786 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id40991319-cbcf-4a2d-9e7e-450800449519">
<fme:FEATURE_ID>1210014683</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832311.08653</fme:EASTING>
<fme:NORTHING>820213.13741</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.106</fme:SLOPESIZE>
<fme:SLOPEANGLE>338.663</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.221</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820213.13741 832311.08653 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide1d910b5-4430-41cf-ae7f-f5124e1df823">
<fme:FEATURE_ID>1000316965</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832183.28172</fme:EASTING>
<fme:NORTHING>820213.40686</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>79.415</fme:SLOPESIZE>
<fme:SLOPEANGLE>363.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>15.883</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820213.40686 832183.28172 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id13c796a2-c277-42e6-88a4-60ae6a3e6a3b">
<fme:FEATURE_ID>1000316708</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831732.22532</fme:EASTING>
<fme:NORTHING>820214.12579</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.18</fme:SLOPESIZE>
<fme:SLOPEANGLE>436.9</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.236</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820214.12579 831732.22532 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ideba980cf-4443-4118-a96c-4b5571b493ba">
<fme:FEATURE_ID>1000317017</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832274.85903</fme:EASTING>
<fme:NORTHING>820214.46091</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.995</fme:SLOPESIZE>
<fme:SLOPEANGLE>309.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.999</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820214.46091 832274.85903 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id59c54da9-8875-4419-916a-5722456fa8ba">
<fme:FEATURE_ID>1000316964</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832189.63214</fme:EASTING>
<fme:NORTHING>820214.80662</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>81.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>362.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>16.375</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820214.80662 832189.63214 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id43927fb9-5e29-431b-accc-0d87924c56bb">
<fme:FEATURE_ID>1000317162</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832478.36323</fme:EASTING>
<fme:NORTHING>820215.21399</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>66.37</fme:SLOPESIZE>
<fme:SLOPEANGLE>112.27</fme:SLOPEANGLE>
<fme:SLOPESIZE200>13.274</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820215.21399 832478.36323 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id68b71f7e-d6c1-4422-86db-352d61b18a0c">
<fme:FEATURE_ID>1000316963</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832165.47447</fme:EASTING>
<fme:NORTHING>820215.3086</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>71.74</fme:SLOPESIZE>
<fme:SLOPEANGLE>362.89</fme:SLOPEANGLE>
<fme:SLOPESIZE200>14.348</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820215.30860 832165.47447 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf32ce35e-8e1b-42d7-bd40-617c5b46a172">
<fme:FEATURE_ID>1000316707</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831789.04727</fme:EASTING>
<fme:NORTHING>820215.82192</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.27</fme:SLOPESIZE>
<fme:SLOPEANGLE>242.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.654</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820215.82192 831789.04727 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id27bd4c42-b569-44bf-bbad-1274d43fa199">
<fme:FEATURE_ID>1000317883</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832249.33037</fme:EASTING>
<fme:NORTHING>820215.91482</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.95</fme:SLOPESIZE>
<fme:SLOPEANGLE>355.27</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.79</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820215.91482 832249.33037 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id18f5e229-116f-42d5-8408-15732f68fb31">
<fme:FEATURE_ID>1000317161</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832585.09884</fme:EASTING>
<fme:NORTHING>820216.27785</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.765</fme:SLOPESIZE>
<fme:SLOPEANGLE>238.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.553</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820216.27785 832585.09884 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb4e993a1-8d83-4af5-acc6-f033144a5227">
<fme:FEATURE_ID>1000316962</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832171.13772</fme:EASTING>
<fme:NORTHING>820216.85766</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>74.84</fme:SLOPESIZE>
<fme:SLOPEANGLE>363.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>14.968</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820216.85766 832171.13772 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide1e62e7c-8903-4e8a-bb55-2856630da6ad">
<fme:FEATURE_ID>1000317016</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832270.41826</fme:EASTING>
<fme:NORTHING>820217.06692</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.36</fme:SLOPESIZE>
<fme:SLOPEANGLE>337.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.072</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820217.06692 832270.41826 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id56c33cce-f464-4518-a0dc-85e6bda5de9a">
<fme:FEATURE_ID>1000316961</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832177.11131</fme:EASTING>
<fme:NORTHING>820217.23978</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>74.615</fme:SLOPESIZE>
<fme:SLOPEANGLE>363.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>14.923</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820217.23978 832177.11131 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8b70b374-f39e-40c1-b71a-b39d8fcc1ff9">
<fme:FEATURE_ID>1000316706</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831734.65173</fme:EASTING>
<fme:NORTHING>820217.31154</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.59</fme:SLOPESIZE>
<fme:SLOPEANGLE>428.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.918</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820217.31154 831734.65173 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida879482a-4115-4579-a0ef-b0ee5adbffaf">
<fme:FEATURE_ID>1000317015</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832266.28001</fme:EASTING>
<fme:NORTHING>820217.69327</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.865</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.38</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.373</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820217.69327 832266.28001 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id92834a22-eb42-406c-9a2b-4cd6fc4df159">
<fme:FEATURE_ID>1000317014</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832262.56488</fme:EASTING>
<fme:NORTHING>820218.26944</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.79</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.05</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.958</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820218.26944 832262.56488 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd82f26c5-d0bf-4386-9f5e-295d7973ced7">
<fme:FEATURE_ID>1000316960</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832201.49004</fme:EASTING>
<fme:NORTHING>820218.46586</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>66.895</fme:SLOPESIZE>
<fme:SLOPEANGLE>362.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>13.379</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820218.46586 832201.49004 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddc0f6c6d-6e86-4880-880e-6e2caf0cfb74">
<fme:FEATURE_ID>1000316705</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831790.81112</fme:EASTING>
<fme:NORTHING>820219.33498</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>241.06</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.37</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820219.33498 831790.81112 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3ec33a2b-8502-497d-bdf0-59c3312f063f">
<fme:FEATURE_ID>1000316959</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832195.48477</fme:EASTING>
<fme:NORTHING>820219.4804</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>93.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>361.73</fme:SLOPEANGLE>
<fme:SLOPESIZE200>18.796</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820219.48040 832195.48477 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3d04c4ac-612b-4a89-a74a-12cfa95a8299">
<fme:FEATURE_ID>1000317159</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832586.59272</fme:EASTING>
<fme:NORTHING>820219.88699</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.71</fme:SLOPESIZE>
<fme:SLOPEANGLE>240.08</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.342</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820219.88699 832586.59272 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id33b9a264-b55a-4950-a98c-627d42b45599">
<fme:FEATURE_ID>1000317882</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832244.83099</fme:EASTING>
<fme:NORTHING>820220.03531</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.695</fme:SLOPESIZE>
<fme:SLOPEANGLE>352.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.339</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820220.03531 832244.83099 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf44bf1dd-68b0-4f5c-a554-04cd721baa5d">
<fme:FEATURE_ID>1000317013</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832259.45784</fme:EASTING>
<fme:NORTHING>820220.0913</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.845</fme:SLOPESIZE>
<fme:SLOPEANGLE>341.2</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.369</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820220.09130 832259.45784 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id252fc327-56b4-437b-8e51-f7918881bdd3">
<fme:FEATURE_ID>1000316704</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831737.63905</fme:EASTING>
<fme:NORTHING>820220.16955</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.93</fme:SLOPESIZE>
<fme:SLOPEANGLE>415.03</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.986</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820220.16955 831737.63905 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc3c45b2b-94f1-483c-a6b4-546cc74c3d98">
<fme:FEATURE_ID>1000317012</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832286.95483</fme:EASTING>
<fme:NORTHING>820221.06419</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.31</fme:SLOPESIZE>
<fme:SLOPEANGLE>323.47</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.662</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820221.06419 832286.95483 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8fcabbb2-226b-4297-81ed-1bce1b9e9175">
<fme:FEATURE_ID>1000317881</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832220.91323</fme:EASTING>
<fme:NORTHING>820222.30868</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.575</fme:SLOPESIZE>
<fme:SLOPEANGLE>392.17</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.115</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820222.30868 832220.91323 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id85a7a78d-a95d-483a-b3cc-384b2f197ade">
<fme:FEATURE_ID>1000317158</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832473.03285</fme:EASTING>
<fme:NORTHING>820222.38925</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>76.945</fme:SLOPESIZE>
<fme:SLOPEANGLE>95.12</fme:SLOPEANGLE>
<fme:SLOPESIZE200>15.389</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820222.38925 832473.03285 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3143501a-5775-40ea-a207-29710a52244b">
<fme:FEATURE_ID>1000316703</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831793.38803</fme:EASTING>
<fme:NORTHING>820222.97859</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.62</fme:SLOPESIZE>
<fme:SLOPEANGLE>229.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.124</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820222.97859 831793.38803 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3fdae21f-d096-4e4e-b7d3-d95929e8471d">
<fme:FEATURE_ID>1000317011</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832260.26474</fme:EASTING>
<fme:NORTHING>820223.75002</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.2</fme:SLOPESIZE>
<fme:SLOPEANGLE>384.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.64</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820223.75002 832260.26474 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida2ffd6e9-247d-475c-99e0-496d9ca99111">
<fme:FEATURE_ID>1000316702</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831817.68893</fme:EASTING>
<fme:NORTHING>820224.60882</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>173.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.775</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820224.60882 831817.68893 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id17931cbe-65c9-4572-862d-38a01e453483">
<fme:FEATURE_ID>1000317010</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832284.60684</fme:EASTING>
<fme:NORTHING>820224.99552</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.7</fme:SLOPESIZE>
<fme:SLOPEANGLE>328.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.54</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820224.99552 832284.60684 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ideb327d1c-1d1c-4ab4-9592-60d457bd0728">
<fme:FEATURE_ID>1000316701</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831821.52559</fme:EASTING>
<fme:NORTHING>820225.23524</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.67</fme:SLOPESIZE>
<fme:SLOPEANGLE>184.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.934</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820225.23524 831821.52559 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida8dab58f-f6cd-4e6d-b29c-d331ac687b79">
<fme:FEATURE_ID>1000316700</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831813.7444</fme:EASTING>
<fme:NORTHING>820225.32824</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.935</fme:SLOPESIZE>
<fme:SLOPEANGLE>171.97</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.587</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820225.32824 831813.74440 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id17a0b001-b37e-4e1b-bc96-30d649a06965">
<fme:FEATURE_ID>1000316699</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831796.8337</fme:EASTING>
<fme:NORTHING>820225.68615</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.53</fme:SLOPESIZE>
<fme:SLOPEANGLE>225.81</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.506</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820225.68615 831796.83370 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide73e4fbe-0898-4ac7-a89a-edc3148be229">
<fme:FEATURE_ID>1000317880</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832238.4845</fme:EASTING>
<fme:NORTHING>820226.19235</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.365</fme:SLOPESIZE>
<fme:SLOPEANGLE>359.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.073</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820226.19235 832238.48450 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf410d0bb-967a-4249-b4df-8eaac4011941">
<fme:FEATURE_ID>1000317009</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832280.86493</fme:EASTING>
<fme:NORTHING>820226.25733</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.5</fme:SLOPESIZE>
<fme:SLOPEANGLE>331.9</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.5</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820226.25733 832280.86493 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3637ccf6-deb6-43d7-9570-1a15ddc4daa0">
<fme:FEATURE_ID>1000317008</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832263.76932</fme:EASTING>
<fme:NORTHING>820226.77959</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>367.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.57</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820226.77959 832263.76932 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id77a7f12c-0795-481a-bca9-ebef216aac15">
<fme:FEATURE_ID>1000317007</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832276.71602</fme:EASTING>
<fme:NORTHING>820227.51828</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>337.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.132</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820227.51828 832276.71602 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0c30bb8b-6100-4e77-936e-933bb079275a">
<fme:FEATURE_ID>1000317879</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832230.62242</fme:EASTING>
<fme:NORTHING>820227.56585</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.07</fme:SLOPESIZE>
<fme:SLOPEANGLE>368.47</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.214</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820227.56585 832230.62242 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9602ca50-08eb-40cd-81fe-59815a6427c5">
<fme:FEATURE_ID>1000317006</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832268.11688</fme:EASTING>
<fme:NORTHING>820228.00786</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.39</fme:SLOPESIZE>
<fme:SLOPEANGLE>353.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.078</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820228.00786 832268.11688 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6f539255-f318-439f-88bc-05c27819c3ca">
<fme:FEATURE_ID>1000317005</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832272.36497</fme:EASTING>
<fme:NORTHING>820228.06769</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.77</fme:SLOPESIZE>
<fme:SLOPEANGLE>344.57</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.354</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820228.06769 832272.36497 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfab0facc-8501-4dc4-8b39-1a4b86dcc576">
<fme:FEATURE_ID>1000317894</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831836.7966</fme:EASTING>
<fme:NORTHING>820228.35491</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>46.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>355.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.396</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820228.35491 831836.79660 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf77ec114-d8d7-447d-8e51-d4087073fecc">
<fme:FEATURE_ID>1000316697</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831799.48989</fme:EASTING>
<fme:NORTHING>820228.66972</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.18</fme:SLOPESIZE>
<fme:SLOPEANGLE>218.03</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.836</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820228.66972 831799.48989 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcf08d0c7-b2b7-4c75-a7b1-4b4f7ee56043">
<fme:FEATURE_ID>1000316696</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831805.56632</fme:EASTING>
<fme:NORTHING>820228.82324</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.475</fme:SLOPESIZE>
<fme:SLOPEANGLE>158.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.095</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820228.82324 831805.56632 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6c570cd6-fe5c-419e-924d-2a7b33a281d3">
<fme:FEATURE_ID>1000317892</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831841.05054</fme:EASTING>
<fme:NORTHING>820229.29635</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>44.815</fme:SLOPESIZE>
<fme:SLOPEANGLE>366.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.963</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820229.29635 831841.05054 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id77e983ad-f34d-4bf7-bb25-5797b50ba2ab">
<fme:FEATURE_ID>1000317893</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831850.77882</fme:EASTING>
<fme:NORTHING>820229.29635</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.075</fme:SLOPESIZE>
<fme:SLOPEANGLE>379.2</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.615</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820229.29635 831850.77882 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2c7d52ee-57fd-4f02-a74b-64c45d2b8d3c">
<fme:FEATURE_ID>1000317891</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831845.96699</fme:EASTING>
<fme:NORTHING>820229.40096</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.1</fme:SLOPESIZE>
<fme:SLOPEANGLE>371.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.22</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820229.40096 831845.96699 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id929cadf4-d2b0-4367-9e4f-ee53e9fb0392">
<fme:FEATURE_ID>1000316695</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831802.74055</fme:EASTING>
<fme:NORTHING>820229.54754</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.725</fme:SLOPESIZE>
<fme:SLOPEANGLE>175.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.545</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820229.54754 831802.74055 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3a0604a7-5340-47b7-b24b-d0fecd0dcbd2">
<fme:FEATURE_ID>1000317153</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832474.92472</fme:EASTING>
<fme:NORTHING>820230.67171</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>73.86</fme:SLOPESIZE>
<fme:SLOPEANGLE>438.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>14.772</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820230.67171 832474.92472 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7e4b77b2-d588-41f3-aff2-0df8d241993c">
<fme:FEATURE_ID>1000317150</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832482.34155</fme:EASTING>
<fme:NORTHING>820236.40111</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>59.635</fme:SLOPESIZE>
<fme:SLOPEANGLE>423.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>11.927</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820236.40111 832482.34155 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd871fb5a-920b-4c3b-b6de-6e750216b6e4">
<fme:FEATURE_ID>1000317149</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832488.46408</fme:EASTING>
<fme:NORTHING>820240.55329</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>50.115</fme:SLOPESIZE>
<fme:SLOPEANGLE>419.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.023</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820240.55329 832488.46408 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id67fc1f90-b77c-49ee-bef9-a11d6771c997">
<fme:FEATURE_ID>1000317148</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832494.00154</fme:EASTING>
<fme:NORTHING>820244.70425</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>42.535</fme:SLOPESIZE>
<fme:SLOPEANGLE>418.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.507</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820244.70425 832494.00154 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddc3bdbba-e8a0-4080-a3cd-b1fef35e0513">
<fme:FEATURE_ID>1000317147</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832498.90342</fme:EASTING>
<fme:NORTHING>820248.67612</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>418.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.333</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820248.67612 832498.90342 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1abff52f-3909-4be0-af1a-9449accb2d1e">
<fme:FEATURE_ID>1000317146</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832502.02287</fme:EASTING>
<fme:NORTHING>820253.55842</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>35.53</fme:SLOPESIZE>
<fme:SLOPEANGLE>419.9</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.106</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820253.55842 832502.02287 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6ff73fe9-84f3-4a72-8f05-89accf4fc039">
<fme:FEATURE_ID>1000317145</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832506.92925</fme:EASTING>
<fme:NORTHING>820255.19401</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.925</fme:SLOPESIZE>
<fme:SLOPEANGLE>419.12</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.185</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820255.19401 832506.92925 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id349bc0bb-c009-4e2d-b423-bcffa6f8bae2">
<fme:FEATURE_ID>1000317144</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832511.98872</fme:EASTING>
<fme:NORTHING>820256.576</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.49</fme:SLOPESIZE>
<fme:SLOPEANGLE>418.77</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.898</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820256.57600 832511.98872 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1f6a1cc6-a9b7-490b-85bc-0d9a0f53a7ae">
<fme:FEATURE_ID>1210014670</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832641.17456</fme:EASTING>
<fme:NORTHING>820260.33928</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.198</fme:SLOPESIZE>
<fme:SLOPEANGLE>157.751</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.44</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820260.33928 832641.17456 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide9645db4-5f3b-4120-aaa4-0db9c69450a9">
<fme:FEATURE_ID>1000318045</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832499.59139</fme:EASTING>
<fme:NORTHING>820261.27307</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.765</fme:SLOPESIZE>
<fme:SLOPEANGLE>417.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.753</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820261.27307 832499.59139 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd3306da0-b2c7-4fb9-b754-005070cb2e57">
<fme:FEATURE_ID>1210014669</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832635.40283</fme:EASTING>
<fme:NORTHING>820262.61585</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.677</fme:SLOPESIZE>
<fme:SLOPEANGLE>153.789</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.535</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820262.61585 832635.40283 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide607b4a3-bc4f-4e97-9db8-65e028b81a67">
<fme:FEATURE_ID>1000316694</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831670.42864</fme:EASTING>
<fme:NORTHING>820263.61949</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>225.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.125</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820263.61949 831670.42864 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfdd3a29f-de1c-4526-a64d-01b559bfea95">
<fme:FEATURE_ID>1210014668</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832631.91462</fme:EASTING>
<fme:NORTHING>820264.28294</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.089</fme:SLOPESIZE>
<fme:SLOPEANGLE>150.642</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.618</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820264.28294 832631.91462 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id39ce6086-b2b5-4e68-ae5d-c2a2b914740a">
<fme:FEATURE_ID>1000317142</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832501.49256</fme:EASTING>
<fme:NORTHING>820264.73068</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.3</fme:SLOPESIZE>
<fme:SLOPEANGLE>416.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.66</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820264.73068 832501.49256 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8de40ce2-b33c-469b-823f-d3297aa7b0cf">
<fme:FEATURE_ID>1000316693</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831673.18942</fme:EASTING>
<fme:NORTHING>820266.01913</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.23</fme:SLOPESIZE>
<fme:SLOPEANGLE>231.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.246</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820266.01913 831673.18942 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id52b32adb-5c28-4271-a0c3-fd7c20225e21">
<fme:FEATURE_ID>1000317141</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832503.59805</fme:EASTING>
<fme:NORTHING>820267.75706</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.725</fme:SLOPESIZE>
<fme:SLOPEANGLE>418.38</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.745</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820267.75706 832503.59805 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4c3fd133-5770-46e5-8c7f-d6c3e641d8a1">
<fme:FEATURE_ID>1000316692</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831675.49104</fme:EASTING>
<fme:NORTHING>820268.74694</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.99</fme:SLOPESIZE>
<fme:SLOPEANGLE>228.9</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.198</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820268.74694 831675.49104 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4d95eba4-cc54-41db-a0d3-3b6d6940c312">
<fme:FEATURE_ID>1000317140</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832506.23767</fme:EASTING>
<fme:NORTHING>820270.83533</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.42</fme:SLOPESIZE>
<fme:SLOPEANGLE>418.08</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.484</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820270.83533 832506.23767 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd4abc5aa-7ab1-43ee-b362-d638426867c5">
<fme:FEATURE_ID>1000316691</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831677.96942</fme:EASTING>
<fme:NORTHING>820271.75482</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11</fme:SLOPESIZE>
<fme:SLOPEANGLE>234.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.2</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820271.75482 831677.96942 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc3d06ff1-1eb4-4734-b5a1-ea9f08c55b76">
<fme:FEATURE_ID>1000317139</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832509.13265</fme:EASTING>
<fme:NORTHING>820273.40627</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.575</fme:SLOPESIZE>
<fme:SLOPEANGLE>418.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.515</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820273.40627 832509.13265 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id171ac361-c822-407d-8e56-19a6428fef99">
<fme:FEATURE_ID>1000316690</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831680.52169</fme:EASTING>
<fme:NORTHING>820275.29643</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.755</fme:SLOPESIZE>
<fme:SLOPEANGLE>234.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.951</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820275.29643 831680.52169 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id581de386-08e9-46e6-81ea-4920050cff11">
<fme:FEATURE_ID>1000317138</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832511.82375</fme:EASTING>
<fme:NORTHING>820276.15453</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.305</fme:SLOPESIZE>
<fme:SLOPEANGLE>418.8</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.061</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820276.15453 832511.82375 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb8795532-343e-4ef3-83e7-b81ee8b0ed7c">
<fme:FEATURE_ID>1000316689</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831682.10741</fme:EASTING>
<fme:NORTHING>820278.90993</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.4</fme:SLOPESIZE>
<fme:SLOPEANGLE>249.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.88</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820278.90993 831682.10741 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0263a3bc-3820-4ca8-a488-248e08588b3e">
<fme:FEATURE_ID>1000317137</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832514.61645</fme:EASTING>
<fme:NORTHING>820279.00456</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.6</fme:SLOPESIZE>
<fme:SLOPEANGLE>417.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.52</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820279.00456 832514.61645 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf787fc2b-0ef0-4e4f-94c4-f44479b7c5cd">
<fme:FEATURE_ID>1000317136</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832517.33322</fme:EASTING>
<fme:NORTHING>820281.65135</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.47</fme:SLOPESIZE>
<fme:SLOPEANGLE>419.05</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.894</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820281.65135 832517.33322 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4908641b-d514-4848-b582-534864d820b4">
<fme:FEATURE_ID>1000316687</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831681.65483</fme:EASTING>
<fme:NORTHING>820283.45403</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.845</fme:SLOPESIZE>
<fme:SLOPEANGLE>288.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.369</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820283.45403 831681.65483 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcabef623-e278-44d8-b485-6274f5804b37">
<fme:FEATURE_ID>1210014902</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831840.61931</fme:EASTING>
<fme:NORTHING>820284.2381</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.991</fme:SLOPESIZE>
<fme:SLOPEANGLE>250.977</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.598</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820284.23810 831840.61931 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4a83e3b8-5fd1-4b29-852c-dd64ba8387fe">
<fme:FEATURE_ID>1000317135</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832519.92222</fme:EASTING>
<fme:NORTHING>820284.57712</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.06</fme:SLOPESIZE>
<fme:SLOPEANGLE>420.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.612</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820284.57712 832519.92222 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4c54251e-b356-498a-aae8-8de046821906">
<fme:FEATURE_ID>1000317907</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831844.7015</fme:EASTING>
<fme:NORTHING>820286.82143</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.745</fme:SLOPESIZE>
<fme:SLOPEANGLE>152.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.549</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820286.82143 831844.70150 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida020a0b5-7bad-4084-a130-2ca8e084ecb9">
<fme:FEATURE_ID>1000317134</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832522.76578</fme:EASTING>
<fme:NORTHING>820287.42731</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.35</fme:SLOPESIZE>
<fme:SLOPEANGLE>420.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.87</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820287.42731 832522.76578 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6b5c891d-9a0c-4aec-af2d-cb28d04df425">
<fme:FEATURE_ID>1000316684</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831680.77059</fme:EASTING>
<fme:NORTHING>820287.86925</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.695</fme:SLOPESIZE>
<fme:SLOPEANGLE>298.19</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.339</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820287.86925 831680.77059 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id65c0530d-77a3-4799-b898-86566bb62236">
<fme:FEATURE_ID>1000317507</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833101.375</fme:EASTING>
<fme:NORTHING>820288.3125</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.645</fme:SLOPESIZE>
<fme:SLOPEANGLE>284.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.329</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820288.31250 833101.37500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4c051bdb-33b1-4765-b489-cd641db43538">
<fme:FEATURE_ID>1000317906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831849.21886</fme:EASTING>
<fme:NORTHING>820288.74634</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.84</fme:SLOPESIZE>
<fme:SLOPEANGLE>181.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.768</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820288.74634 831849.21886 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id30cb8d93-ff45-4d1c-953b-3b457ac7a14f">
<fme:FEATURE_ID>1000317905</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831839.37834</fme:EASTING>
<fme:NORTHING>820288.82948</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.065</fme:SLOPESIZE>
<fme:SLOPEANGLE>251.76</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.213</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820288.82948 831839.37834 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id304d0095-4d4b-4dc4-a523-a7cf14e28d32">
<fme:FEATURE_ID>1000316682</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831679.33016</fme:EASTING>
<fme:NORTHING>820291.57084</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.685</fme:SLOPESIZE>
<fme:SLOPEANGLE>287.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.737</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820291.57084 831679.33016 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5f6ee939-9c02-4ab0-8349-fffa0d886521">
<fme:FEATURE_ID>1000317504</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833099.1875</fme:EASTING>
<fme:NORTHING>820291.625</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.74</fme:SLOPESIZE>
<fme:SLOPEANGLE>301.03</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.148</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820291.62500 833099.18750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4219b8f8-fcc5-4011-9977-3daaaf87f5b5">
<fme:FEATURE_ID>1000317904</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831851.84988</fme:EASTING>
<fme:NORTHING>820291.72954</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.5</fme:SLOPESIZE>
<fme:SLOPEANGLE>231.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.7</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820291.72954 831851.84988 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id068619b3-bb1e-4261-8c50-0860f1401d1b">
<fme:FEATURE_ID>1210014898</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831843.78853</fme:EASTING>
<fme:NORTHING>820291.97299</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.56</fme:SLOPESIZE>
<fme:SLOPEANGLE>132.652</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.512</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820291.97299 831843.78853 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id65f539b3-1271-4c5a-bdce-8bb1b8cfa232">
<fme:FEATURE_ID>1000317903</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831838.23774</fme:EASTING>
<fme:NORTHING>820293.70068</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.325</fme:SLOPESIZE>
<fme:SLOPEANGLE>255.51</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.865</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820293.70068 831838.23774 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd1166f67-18fc-4307-955f-75884a9dd08b">
<fme:FEATURE_ID>1000317902</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831838.79385</fme:EASTING>
<fme:NORTHING>820294.43969</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.87</fme:SLOPESIZE>
<fme:SLOPEANGLE>99.44</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.574</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820294.43969 831838.79385 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5716a9a5-9b80-4a29-8a05-4dd255ce38a9">
<fme:FEATURE_ID>1000317502</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833096.3125</fme:EASTING>
<fme:NORTHING>820294.625</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.79</fme:SLOPESIZE>
<fme:SLOPEANGLE>310.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.958</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820294.62500 833096.31250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc6711796-d06d-488a-88b1-e14534b2a2fd">
<fme:FEATURE_ID>1000317901</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831853.56468</fme:EASTING>
<fme:NORTHING>820294.91185</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.915</fme:SLOPESIZE>
<fme:SLOPEANGLE>249.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.583</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820294.91185 831853.56468 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id795648b2-82e7-4356-a333-906ad98ddab3">
<fme:FEATURE_ID>1000316680</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831678.11923</fme:EASTING>
<fme:NORTHING>820295.12107</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.62</fme:SLOPESIZE>
<fme:SLOPEANGLE>281.89</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.924</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820295.12107 831678.11923 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9c341e40-186c-4b12-8cea-8fde8b28c7df">
<fme:FEATURE_ID>1000317900</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831837.66315</fme:EASTING>
<fme:NORTHING>820297.10138</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.35</fme:SLOPESIZE>
<fme:SLOPEANGLE>265.44</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.27</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820297.10138 831837.66315 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfe5a7cf3-a8d3-4e0c-8033-9459986454fb">
<fme:FEATURE_ID>1000317500</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833093.5</fme:EASTING>
<fme:NORTHING>820297.4375</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.105</fme:SLOPESIZE>
<fme:SLOPEANGLE>311.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.821</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820297.43750 833093.50000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id49f6ee22-eca3-49ce-95bf-c3509158c185">
<fme:FEATURE_ID>1000317899</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831838.24455</fme:EASTING>
<fme:NORTHING>820297.8659</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.905</fme:SLOPESIZE>
<fme:SLOPEANGLE>103.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.781</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820297.86590 831838.24455 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide0349148-0a42-4097-9c1b-1e51fae1002b">
<fme:FEATURE_ID>1000317898</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831854.79578</fme:EASTING>
<fme:NORTHING>820298.21896</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.51</fme:SLOPESIZE>
<fme:SLOPEANGLE>260.33</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.502</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820298.21896 831854.79578 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idec1477cb-bbe8-4e43-a3aa-22b040b4b3b2">
<fme:FEATURE_ID>1000317783</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832156.71208</fme:EASTING>
<fme:NORTHING>820298.42054</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.79</fme:SLOPESIZE>
<fme:SLOPEANGLE>303.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.958</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820298.42054 832156.71208 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id20799c2c-5d9c-4c53-a6ca-ab13dc17456a">
<fme:FEATURE_ID>1000316678</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831677.89854</fme:EASTING>
<fme:NORTHING>820298.98048</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.53</fme:SLOPESIZE>
<fme:SLOPEANGLE>276.06</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.906</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820298.98048 831677.89854 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd2992ee8-e0de-4b30-9db0-2908b8a7ccda">
<fme:FEATURE_ID>1000317498</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833090.875</fme:EASTING>
<fme:NORTHING>820300.3125</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.105</fme:SLOPESIZE>
<fme:SLOPEANGLE>311.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.821</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820300.31250 833090.87500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id57a31e91-1ff4-4aff-ab46-c792e53409e6">
<fme:FEATURE_ID>1000317782</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832154.46018</fme:EASTING>
<fme:NORTHING>820301.61058</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.58</fme:SLOPESIZE>
<fme:SLOPEANGLE>301.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.716</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820301.61058 832154.46018 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id04c8ab27-38d1-44b7-8fc8-8a2a8c87dbf9">
<fme:FEATURE_ID>1000317895</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831855.03461</fme:EASTING>
<fme:NORTHING>820301.67406</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.175</fme:SLOPESIZE>
<fme:SLOPEANGLE>273.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.435</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820301.67406 831855.03461 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb3fd619e-5550-42e8-b281-b826656eec6a">
<fme:FEATURE_ID>1000316676</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831656.72928</fme:EASTING>
<fme:NORTHING>820302.16248</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.91</fme:SLOPESIZE>
<fme:SLOPEANGLE>235.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.582</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820302.16248 831656.72928 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4d472557-9459-4b07-bae3-eb375b0bdcc3">
<fme:FEATURE_ID>1000316675</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831678.1605</fme:EASTING>
<fme:NORTHING>820302.94363</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.805</fme:SLOPESIZE>
<fme:SLOPEANGLE>268.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.561</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820302.94363 831678.16050 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id61f66f6e-6979-487f-a3fb-b7eddb03e5d4">
<fme:FEATURE_ID>1000316672</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831658.67585</fme:EASTING>
<fme:NORTHING>820304.68549</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.45</fme:SLOPESIZE>
<fme:SLOPEANGLE>230.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.69</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820304.68549 831658.67585 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbd35e95a-4f5e-4aa3-91ca-2b7c3c570ec4">
<fme:FEATURE_ID>1000317781</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832152.84273</fme:EASTING>
<fme:NORTHING>820305.1082</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.69</fme:SLOPESIZE>
<fme:SLOPEANGLE>302.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.738</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820305.10820 832152.84273 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddff27437-efc3-4791-892d-ec0b55e18732">
<fme:FEATURE_ID>1000317495</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833082.8125</fme:EASTING>
<fme:NORTHING>820305.125</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.84</fme:SLOPESIZE>
<fme:SLOPEANGLE>228.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.768</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820305.12500 833082.81250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida0100bf7-2bf5-4ee4-b70a-9fe74febaaa3">
<fme:FEATURE_ID>1000316671</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831678.37268</fme:EASTING>
<fme:NORTHING>820306.67801</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.115</fme:SLOPESIZE>
<fme:SLOPEANGLE>269.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.823</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820306.67801 831678.37268 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbc004aec-bb91-4eb6-85ce-8bc9982ebcfb">
<fme:FEATURE_ID>1000316670</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831708.90914</fme:EASTING>
<fme:NORTHING>820306.9156</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.055</fme:SLOPESIZE>
<fme:SLOPEANGLE>433.44</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.211</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820306.91560 831708.90914 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcebc558c-5812-427e-ad1f-3242ee4fdd05">
<fme:FEATURE_ID>1000316669</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831661.81758</fme:EASTING>
<fme:NORTHING>820307.18844</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.595</fme:SLOPESIZE>
<fme:SLOPEANGLE>223.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.519</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820307.18844 831661.81758 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8a4e4db1-f745-4ec1-a0ea-d22d593a66b3">
<fme:FEATURE_ID>1000317494</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833085.5625</fme:EASTING>
<fme:NORTHING>820308.25</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.675</fme:SLOPESIZE>
<fme:SLOPEANGLE>239.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.535</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820308.25000 833085.56250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5b0c97d2-60ce-4fa7-93b0-366d718a1a2e">
<fme:FEATURE_ID>1000317780</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832151.07175</fme:EASTING>
<fme:NORTHING>820308.80832</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.69</fme:SLOPESIZE>
<fme:SLOPEANGLE>300.59</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.738</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820308.80832 832151.07175 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddba09280-bb94-4af7-ba37-62842ebf9581">
<fme:FEATURE_ID>1000316667</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831665.21618</fme:EASTING>
<fme:NORTHING>820309.10838</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>214.63</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.725</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820309.10838 831665.21618 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf4a81508-74fc-4252-99ad-688079c525dc">
<fme:FEATURE_ID>1000317493</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833153.375</fme:EASTING>
<fme:NORTHING>820309.4375</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.57</fme:SLOPESIZE>
<fme:SLOPEANGLE>305.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.114</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820309.43750 833153.37500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddb1a8213-609d-466c-b263-a25a3be16140">
<fme:FEATURE_ID>1000316666</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831710.57374</fme:EASTING>
<fme:NORTHING>820309.94525</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.04</fme:SLOPESIZE>
<fme:SLOPEANGLE>430.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.408</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820309.94525 831710.57374 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc33a8dea-3b77-4339-9115-b9f2592ff67d">
<fme:FEATURE_ID>1000316664</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831678.50761</fme:EASTING>
<fme:NORTHING>820310.61518</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.7</fme:SLOPESIZE>
<fme:SLOPEANGLE>269.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.94</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820310.61518 831678.50761 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id341c7515-d1a0-4732-b509-365b00b1ed5e">
<fme:FEATURE_ID>1000316663</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831668.64143</fme:EASTING>
<fme:NORTHING>820310.74903</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.11</fme:SLOPESIZE>
<fme:SLOPEANGLE>197.74</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.422</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820310.74903 831668.64143 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5a573d1c-da4a-4f8b-940c-a567ea265984">
<fme:FEATURE_ID>1000318144</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833168.88736</fme:EASTING>
<fme:NORTHING>820311.43754</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>336.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.882</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820311.43754 833168.88736 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5e70f31a-82b8-4a83-b8ba-4a2ec5e11521">
<fme:FEATURE_ID>1000317779</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832149.53105</fme:EASTING>
<fme:NORTHING>820312.17931</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13</fme:SLOPESIZE>
<fme:SLOPEANGLE>297.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.6</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820312.17931 832149.53105 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id111cc250-9fde-4365-96cf-73f97433a26c">
<fme:FEATURE_ID>1000317492</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833088.4375</fme:EASTING>
<fme:NORTHING>820312.1875</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>35.9</fme:SLOPESIZE>
<fme:SLOPEANGLE>252.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.18</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820312.18750 833088.43750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd8d539cc-0450-4cc9-979a-accfa3457f05">
<fme:FEATURE_ID>1000316662</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831710.40891</fme:EASTING>
<fme:NORTHING>820312.68748</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.935</fme:SLOPESIZE>
<fme:SLOPEANGLE>116.58</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.787</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820312.68748 831710.40891 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5e802703-ab33-4fcf-9834-33cd0f2d90b6">
<fme:FEATURE_ID>1000317491</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833153.375</fme:EASTING>
<fme:NORTHING>820313.5</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.96</fme:SLOPESIZE>
<fme:SLOPEANGLE>308.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.792</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820313.50000 833153.37500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfaec9076-d969-4659-b3a9-0e62f7d0a40c">
<fme:FEATURE_ID>1000316661</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831857.44725</fme:EASTING>
<fme:NORTHING>820313.69776</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.55</fme:SLOPESIZE>
<fme:SLOPEANGLE>184.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.11</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820313.69776 831857.44725 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5248940c-e579-4784-9933-dc55056ebf64">
<fme:FEATURE_ID>1000316660</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831844.93584</fme:EASTING>
<fme:NORTHING>820314.02301</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.43</fme:SLOPESIZE>
<fme:SLOPEANGLE>178.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.286</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820314.02301 831844.93584 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id636ebe09-dc32-4cc1-8e00-2df6eb6a1c23">
<fme:FEATURE_ID>1000318143</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833165.93736</fme:EASTING>
<fme:NORTHING>820314.03754</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>46.93</fme:SLOPESIZE>
<fme:SLOPEANGLE>318.1</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.386</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820314.03754 833165.93736 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7ec71dc2-cfc9-467c-bdf3-20953cae2ed0">
<fme:FEATURE_ID>1000316659</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831840.46001</fme:EASTING>
<fme:NORTHING>820314.18086</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.645</fme:SLOPESIZE>
<fme:SLOPEANGLE>166.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.329</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820314.18086 831840.46001 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2ef99c2c-6f24-4ec4-a6dd-26da0040ec8e">
<fme:FEATURE_ID>1000316658</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831853.32524</fme:EASTING>
<fme:NORTHING>820314.33976</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.8</fme:SLOPESIZE>
<fme:SLOPEANGLE>182.03</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.16</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820314.33976 831853.32524 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide7cc00b2-8391-49d7-9be5-4d120b6338c6">
<fme:FEATURE_ID>1000316657</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831849.28211</fme:EASTING>
<fme:NORTHING>820314.39795</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.235</fme:SLOPESIZE>
<fme:SLOPEANGLE>180.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.047</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820314.39795 831849.28211 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id230617f2-6ca5-4dcc-87bd-2681b409b9ca">
<fme:FEATURE_ID>1000316656</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831678.66855</fme:EASTING>
<fme:NORTHING>820314.42554</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.94</fme:SLOPESIZE>
<fme:SLOPEANGLE>268.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.188</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820314.42554 831678.66855 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id355c718b-1315-407e-939e-8027eca49258">
<fme:FEATURE_ID>1000316655</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831708.33953</fme:EASTING>
<fme:NORTHING>820314.8878</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.795</fme:SLOPESIZE>
<fme:SLOPEANGLE>146.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.759</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820314.88780 831708.33953 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb6d7d15e-cf19-48a2-8498-37ce620b1915">
<fme:FEATURE_ID>1000317778</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832147.65892</fme:EASTING>
<fme:NORTHING>820315.75202</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>298.6</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.733</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820315.75202 832147.65892 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc14da293-30ac-4139-941d-0c2226855046">
<fme:FEATURE_ID>1000316654</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831860.89397</fme:EASTING>
<fme:NORTHING>820316.22747</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.2</fme:SLOPESIZE>
<fme:SLOPEANGLE>185.73</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.44</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820316.22747 831860.89397 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9d54d296-5683-4ac8-aead-bb511bacbcac">
<fme:FEATURE_ID>1000317490</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833163.75</fme:EASTING>
<fme:NORTHING>820316.375</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>310.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.175</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820316.37500 833163.75000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida07dd572-a7ba-4a10-9daf-8195da9d97f9">
<fme:FEATURE_ID>1210087328</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831836.203</fme:EASTING>
<fme:NORTHING>820317.275</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>5</fme:RULEID>
<fme:SLOPESIZE>139.819</fme:SLOPESIZE>
<fme:SLOPEANGLE>155.031</fme:SLOPEANGLE>
<fme:SLOPESIZE200>27.964</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820317.27508 831836.20349 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3e019d01-a7ae-4af9-a752-f668c40a1a3a">
<fme:FEATURE_ID>1000317489</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833090.375</fme:EASTING>
<fme:NORTHING>820317.3125</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.64</fme:SLOPESIZE>
<fme:SLOPEANGLE>260.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.328</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820317.31250 833090.37500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide9cfa39e-3c50-4706-a269-e44d1675bdac">
<fme:FEATURE_ID>1000316652</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831701.25739</fme:EASTING>
<fme:NORTHING>820317.90396</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.445</fme:SLOPESIZE>
<fme:SLOPEANGLE>155.79</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.689</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820317.90396 831701.25739 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4e4f7e9e-78bb-4201-851c-d0a66506b63a">
<fme:FEATURE_ID>1000317488</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833153.375</fme:EASTING>
<fme:NORTHING>820318.0625</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>307.09</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.525</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820318.06250 833153.37500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd3e4d341-3319-4e83-8ba5-04e1342add39">
<fme:FEATURE_ID>1000317777</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832146.34556</fme:EASTING>
<fme:NORTHING>820319.45415</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.315</fme:SLOPESIZE>
<fme:SLOPEANGLE>297.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.663</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820319.45415 832146.34556 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id59d469d3-a671-4386-8eb8-c9bd3eed38e1">
<fme:FEATURE_ID>1000317487</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833161.375</fme:EASTING>
<fme:NORTHING>820319.5</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.6</fme:SLOPESIZE>
<fme:SLOPEANGLE>309.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.12</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820319.50000 833161.37500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3b4cc4e7-b336-4319-be96-9cb1c1219047">
<fme:FEATURE_ID>1000316650</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831697.71475</fme:EASTING>
<fme:NORTHING>820319.76758</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.28</fme:SLOPESIZE>
<fme:SLOPEANGLE>153.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.656</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820319.76758 831697.71475 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4054c317-049d-4d22-ae55-f7f0863ccf0f">
<fme:FEATURE_ID>1000316649</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831671.09267</fme:EASTING>
<fme:NORTHING>820319.82682</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.635</fme:SLOPESIZE>
<fme:SLOPEANGLE>311.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.327</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820319.82682 831671.09267 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0c9041e4-52a8-4d79-a0f4-29feb8122c77">
<fme:FEATURE_ID>1000316648</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831693.58867</fme:EASTING>
<fme:NORTHING>820321.32385</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.475</fme:SLOPESIZE>
<fme:SLOPEANGLE>155.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.895</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820321.32385 831693.58867 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9aaa2d35-8864-4a48-a25f-cfb9ffaeac9e">
<fme:FEATURE_ID>1000317486</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833159.1875</fme:EASTING>
<fme:NORTHING>820322.375</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.125</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.225</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820322.37500 833159.18750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idca8e1b63-8b01-4ca1-afb3-f2d2775630ea">
<fme:FEATURE_ID>1000317776</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832144.65313</fme:EASTING>
<fme:NORTHING>820322.64668</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.775</fme:SLOPESIZE>
<fme:SLOPEANGLE>291.51</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.555</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820322.64668 832144.65313 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id51fb0adc-d7cb-4bfc-90e8-7c0bc9ff2235">
<fme:FEATURE_ID>1000316646</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831668.58787</fme:EASTING>
<fme:NORTHING>820322.73638</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.29</fme:SLOPESIZE>
<fme:SLOPEANGLE>283.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.858</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820322.73638 831668.58787 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id101006af-ee46-46b9-98cb-ed8ba1ea4127">
<fme:FEATURE_ID>1000317485</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833090.9375</fme:EASTING>
<fme:NORTHING>820322.9375</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>42.44</fme:SLOPESIZE>
<fme:SLOPEANGLE>262.97</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.488</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820322.93750 833090.93750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5abae0e4-6da1-4bd5-87b7-feaa7a571e6c">
<fme:FEATURE_ID>1000316958</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832011.61909</fme:EASTING>
<fme:NORTHING>820322.94319</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>7.595</fme:SLOPESIZE>
<fme:SLOPEANGLE>144.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.519</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820322.94319 832011.61909 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide8fcdf55-1a79-4226-bc2f-f79a990060bd">
<fme:FEATURE_ID>1000316645</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831689.43534</fme:EASTING>
<fme:NORTHING>820323.28635</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.72</fme:SLOPESIZE>
<fme:SLOPEANGLE>153.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.944</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820323.28635 831689.43534 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id71ceead6-94bc-47e1-a58d-4a125aa2a7a3">
<fme:FEATURE_ID>1000317484</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833155.5</fme:EASTING>
<fme:NORTHING>820324.625</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.64</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.328</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820324.62500 833155.50000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd0551edc-2302-4949-9a71-8c9343a46e3a">
<fme:FEATURE_ID>1000316644</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831685.48548</fme:EASTING>
<fme:NORTHING>820325.22435</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.19</fme:SLOPESIZE>
<fme:SLOPEANGLE>155.03</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.838</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820325.22435 831685.48548 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3364935f-d992-4bf6-aafa-f74e02f860a7">
<fme:FEATURE_ID>1000316957</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832008.14835</fme:EASTING>
<fme:NORTHING>820325.79766</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.28</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.96</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.656</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820325.79766 832008.14835 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id10e1ac62-2981-4312-a517-685f5c0827d9">
<fme:FEATURE_ID>1210087327</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831828.776</fme:EASTING>
<fme:NORTHING>820325.909</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>5</fme:RULEID>
<fme:SLOPESIZE>122.737</fme:SLOPESIZE>
<fme:SLOPEANGLE>155.351</fme:SLOPEANGLE>
<fme:SLOPESIZE200>24.547</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820325.90904 831828.77647 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id808a7f3d-e7ca-4ac5-85a6-91a9043c0933">
<fme:FEATURE_ID>1000316642</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831669.20932</fme:EASTING>
<fme:NORTHING>820325.91378</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.875</fme:SLOPESIZE>
<fme:SLOPEANGLE>243.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.975</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820325.91378 831669.20932 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2ecb2c49-42e6-4f19-b4ab-7afa6d7093f9">
<fme:FEATURE_ID>1000316641</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831681.86839</fme:EASTING>
<fme:NORTHING>820326.68127</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.13</fme:SLOPESIZE>
<fme:SLOPEANGLE>160.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.826</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820326.68127 831681.86839 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id69248f9f-4951-4c52-9360-430076a1f79f">
<fme:FEATURE_ID>1000318030</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832442.81347</fme:EASTING>
<fme:NORTHING>820327.40623</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>46.955</fme:SLOPESIZE>
<fme:SLOPEANGLE>427.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.391</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820327.40623 832442.81347 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id30e8bc74-39b3-480c-a7c9-8329fa669145">
<fme:FEATURE_ID>1000316640</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831678.15096</fme:EASTING>
<fme:NORTHING>820327.83304</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.955</fme:SLOPESIZE>
<fme:SLOPEANGLE>164.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.991</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820327.83304 831678.15096 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7fc4247d-e257-4604-879f-959789743b6d">
<fme:FEATURE_ID>1000317483</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833091.4375</fme:EASTING>
<fme:NORTHING>820328.375</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.09</fme:SLOPESIZE>
<fme:SLOPEANGLE>263.96</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.218</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820328.37500 833091.43750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfd9ddc3e-34bd-4695-a9b4-311630b99654">
<fme:FEATURE_ID>1000317482</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833154.3125</fme:EASTING>
<fme:NORTHING>820328.6875</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.705</fme:SLOPESIZE>
<fme:SLOPEANGLE>307.18</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.541</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820328.68750 833154.31250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbb436d52-f772-42b9-a2e9-d2567146da0f">
<fme:FEATURE_ID>1000316956</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832006.04927</fme:EASTING>
<fme:NORTHING>820328.93758</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.3</fme:SLOPESIZE>
<fme:SLOPEANGLE>119.49</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.06</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820328.93758 832006.04927 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide6466e00-ee36-48de-925f-3c675fe2c23b">
<fme:FEATURE_ID>1000316638</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831671.73821</fme:EASTING>
<fme:NORTHING>820328.99816</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.565</fme:SLOPESIZE>
<fme:SLOPEANGLE>208.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.913</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820328.99816 831671.73821 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id84e21da8-65d9-40a4-a14f-afa318a3c739">
<fme:FEATURE_ID>1000316637</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831674.94099</fme:EASTING>
<fme:NORTHING>820329.21559</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.435</fme:SLOPESIZE>
<fme:SLOPEANGLE>180.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.887</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820329.21559 831674.94099 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id320848ea-2f9a-4673-b64a-6f33d9828a1d">
<fme:FEATURE_ID>1210087326</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831821.123</fme:EASTING>
<fme:NORTHING>820331.869</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>5</fme:RULEID>
<fme:SLOPESIZE>112.247</fme:SLOPESIZE>
<fme:SLOPEANGLE>160.942</fme:SLOPEANGLE>
<fme:SLOPESIZE200>22.449</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820331.86887 831821.12347 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb4a5d95c-8cb2-4a55-8171-69e67cfaa076">
<fme:FEATURE_ID>1000317481</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833151.9375</fme:EASTING>
<fme:NORTHING>820331.9375</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.933</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820331.93750 833151.93750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8a66bfd5-a3a9-4be9-af19-88fe854ad7dc">
<fme:FEATURE_ID>1000316955</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832003.0852</fme:EASTING>
<fme:NORTHING>820332.20063</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.165</fme:SLOPESIZE>
<fme:SLOPEANGLE>107.3</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.433</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820332.20063 832003.08520 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbb76d550-9457-4bbd-a18a-1aa0d19f824a">
<fme:FEATURE_ID>1000317480</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833091.9375</fme:EASTING>
<fme:NORTHING>820333.6875</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>39.055</fme:SLOPESIZE>
<fme:SLOPEANGLE>266.05</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.811</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820333.68750 833091.93750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id02d6390e-c53a-46f0-a193-6e3887fcb82d">
<fme:FEATURE_ID>1000318029</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832444.52623</fme:EASTING>
<fme:NORTHING>820334.18258</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>42.69</fme:SLOPESIZE>
<fme:SLOPEANGLE>415.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.538</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820334.18258 832444.52623 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4c7ecc81-cab7-40c6-ba37-674a68790c4e">
<fme:FEATURE_ID>1000316954</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831999.64254</fme:EASTING>
<fme:NORTHING>820334.44568</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>109.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.726</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820334.44568 831999.64254 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3f4607fd-c5c6-4713-a66e-0a5ace2b08b2">
<fme:FEATURE_ID>1000317479</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833149.5625</fme:EASTING>
<fme:NORTHING>820335.1875</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.365</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.95</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.273</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820335.18750 833149.56250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1347bc3d-4d7b-4927-8646-4089434c2efa">
<fme:FEATURE_ID>1210087329</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831816.102</fme:EASTING>
<fme:NORTHING>820335.703</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.698</fme:SLOPESIZE>
<fme:SLOPEANGLE>151.763</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.54</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820335.70336 831816.10187 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5143280e-da79-4a4a-b562-662545645c8e">
<fme:FEATURE_ID>1000316953</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831997.97349</fme:EASTING>
<fme:NORTHING>820338.09549</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.2</fme:SLOPESIZE>
<fme:SLOPEANGLE>107.75</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.44</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820338.09549 831997.97349 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5a529300-834d-45ed-9f7d-a81fbb564497">
<fme:FEATURE_ID>1000318024</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832447.59673</fme:EASTING>
<fme:NORTHING>820338.78959</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>47.1</fme:SLOPESIZE>
<fme:SLOPEANGLE>413.23</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.42</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820338.78959 832447.59673 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5db00497-ebc7-4bc0-be22-396bf276bde0">
<fme:FEATURE_ID>1210087330</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831811.595</fme:EASTING>
<fme:NORTHING>820339.853</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.498</fme:SLOPESIZE>
<fme:SLOPEANGLE>150.524</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.7</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820339.85277 831811.59544 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2279cdd8-bc49-47a0-8493-48cf6525a60a">
<fme:FEATURE_ID>1000316952</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831996.70965</fme:EASTING>
<fme:NORTHING>820342.1026</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.775</fme:SLOPESIZE>
<fme:SLOPEANGLE>106.4</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.355</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820342.10260 831996.70965 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcfcc0e0f-c851-476e-afb0-c26733c60b3d">
<fme:FEATURE_ID>1000317004</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832143.95563</fme:EASTING>
<fme:NORTHING>820342.17416</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>6.16</fme:SLOPESIZE>
<fme:SLOPEANGLE>248.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.232</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820342.17416 832143.95563 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4303180d-34fd-4415-bb01-5dc78947277c">
<fme:FEATURE_ID>1000317123</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832511.69094</fme:EASTING>
<fme:NORTHING>820345.02317</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.755</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.42</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.951</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820345.02317 832511.69094 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf9607092-afb3-4542-810a-dd2a55a96f68">
<fme:FEATURE_ID>1000316951</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832034.04699</fme:EASTING>
<fme:NORTHING>820345.36737</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.92</fme:SLOPESIZE>
<fme:SLOPEANGLE>132.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.384</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820345.36737 832034.04699 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id31fe210c-9f4c-43a5-94f9-7e8187124e00">
<fme:FEATURE_ID>1000316950</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831995.37044</fme:EASTING>
<fme:NORTHING>820345.90626</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.96</fme:SLOPESIZE>
<fme:SLOPEANGLE>107.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.592</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820345.90626 831995.37044 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7b8fc077-0426-4e05-a9a0-17f80bc76962">
<fme:FEATURE_ID>1000317003</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832145.03125</fme:EASTING>
<fme:NORTHING>820346.14092</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.92</fme:SLOPESIZE>
<fme:SLOPEANGLE>277.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.784</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820346.14092 832145.03125 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id817567a5-1cd0-46e1-9f97-7c95c78852eb">
<fme:FEATURE_ID>1000316949</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832031.64559</fme:EASTING>
<fme:NORTHING>820347.87101</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.93</fme:SLOPESIZE>
<fme:SLOPEANGLE>124.91</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.586</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820347.87101 832031.64559 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc1c2ee31-d9bf-4ae2-a2f0-1c35a8f7b19f">
<fme:FEATURE_ID>1000317473</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833091.3125</fme:EASTING>
<fme:NORTHING>820348.125</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>279.77</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.499</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820348.12500 833091.31250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcde267d9-dfd5-4ec3-9807-227511265f6c">
<fme:FEATURE_ID>1000316948</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831994.26133</fme:EASTING>
<fme:NORTHING>820349.43157</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.47</fme:SLOPESIZE>
<fme:SLOPEANGLE>108.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.694</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820349.43157 831994.26133 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id098b27bc-6fae-470d-9265-e1fc6faf1d1a">
<fme:FEATURE_ID>1000317002</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832145.14057</fme:EASTING>
<fme:NORTHING>820350.1288</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.975</fme:SLOPESIZE>
<fme:SLOPEANGLE>301.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.395</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820350.12880 832145.14057 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbfe42340-9e15-4084-a8dd-5f1bfefe2e0a">
<fme:FEATURE_ID>1210087382</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831906.981</fme:EASTING>
<fme:NORTHING>820350.591</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>62.081</fme:SLOPESIZE>
<fme:SLOPEANGLE>188.723</fme:SLOPEANGLE>
<fme:SLOPESIZE200>12.416</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820350.59062 831906.98150 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id22c74f12-932b-43ae-85ee-c812aa64f3c4">
<fme:FEATURE_ID>1210087381</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831897.298</fme:EASTING>
<fme:NORTHING>820350.843</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>58.326</fme:SLOPESIZE>
<fme:SLOPEANGLE>182.227</fme:SLOPEANGLE>
<fme:SLOPESIZE200>11.665</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820350.84261 831897.29785 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd51dec83-69f8-4a2b-a724-c9ef161ef8e0">
<fme:FEATURE_ID>1000316947</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832029.34088</fme:EASTING>
<fme:NORTHING>820351.51798</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.59</fme:SLOPESIZE>
<fme:SLOPEANGLE>125.58</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.318</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820351.51798 832029.34088 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8e69f199-b559-4719-8e4a-dae1e53f0c78">
<fme:FEATURE_ID>1000317472</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833090.5</fme:EASTING>
<fme:NORTHING>820351.9375</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.685</fme:SLOPESIZE>
<fme:SLOPEANGLE>285.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.337</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820351.93750 833090.50000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd31710f6-b798-4ca0-9a4f-3eedb72a4d7c">
<fme:FEATURE_ID>1000316946</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831992.99762</fme:EASTING>
<fme:NORTHING>820353.4133</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.355</fme:SLOPESIZE>
<fme:SLOPEANGLE>107.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.671</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820353.41330 831992.99762 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idafe81cfa-f111-4663-b4dd-a80ff90b7234">
<fme:FEATURE_ID>1210087383</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831916.771</fme:EASTING>
<fme:NORTHING>820353.902</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>60.518</fme:SLOPESIZE>
<fme:SLOPEANGLE>197.464</fme:SLOPEANGLE>
<fme:SLOPESIZE200>12.104</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820353.90224 831916.77062 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9dffecd9-606d-4d15-9035-cd9f7fe5d24d">
<fme:FEATURE_ID>1000317001</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832143.11194</fme:EASTING>
<fme:NORTHING>820354.56431</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>327.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.482</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820354.56431 832143.11194 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7d599b96-e6a9-479b-a18e-ce6ac4b1875f">
<fme:FEATURE_ID>1000317000</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832134.36278</fme:EASTING>
<fme:NORTHING>820355.10952</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.775</fme:SLOPESIZE>
<fme:SLOPEANGLE>344.74</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.155</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820355.10952 832134.36278 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1f4b9f12-c581-4865-a691-60f55bb9ae63">
<fme:FEATURE_ID>1000316945</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832026.93451</fme:EASTING>
<fme:NORTHING>820355.16448</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.295</fme:SLOPESIZE>
<fme:SLOPEANGLE>125.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.459</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820355.16448 832026.93451 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id477634b5-b0d9-4d03-8115-d4d74a77deae">
<fme:FEATURE_ID>1000316999</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832130.37004</fme:EASTING>
<fme:NORTHING>820355.2695</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.88</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.99</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.576</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820355.26950 832130.37004 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb7ae96f9-0bdf-4360-b8ba-b1fc1a3598dd">
<fme:FEATURE_ID>1210087380</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831888.948</fme:EASTING>
<fme:NORTHING>820355.405</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>44.059</fme:SLOPESIZE>
<fme:SLOPEANGLE>178.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.812</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820355.40458 831888.94792 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddb00128e-cb24-4809-ba77-e64101d17d17">
<fme:FEATURE_ID>1000316998</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832138.42943</fme:EASTING>
<fme:NORTHING>820355.45778</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.335</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.267</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820355.45778 832138.42943 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0727107c-b3bf-4471-81ec-2f0d11446b22">
<fme:FEATURE_ID>1000317471</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833089.25</fme:EASTING>
<fme:NORTHING>820355.5625</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>290.84</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.126</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820355.56250 833089.25000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2d52469d-e302-4b46-a024-9525f100d7b5">
<fme:FEATURE_ID>1000316997</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832126.50262</fme:EASTING>
<fme:NORTHING>820355.83641</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.8</fme:SLOPESIZE>
<fme:SLOPEANGLE>347.01</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.36</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820355.83641 832126.50262 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id735f3a47-053c-4991-b91d-65324228b78f">
<fme:FEATURE_ID>1000316996</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832122.762</fme:EASTING>
<fme:NORTHING>820356.48007</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.295</fme:SLOPESIZE>
<fme:SLOPEANGLE>344.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.859</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820356.48007 832122.76200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id30d2d7de-c1d7-4d03-9bc5-5f070e3f8455">
<fme:FEATURE_ID>1000316944</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831991.76035</fme:EASTING>
<fme:NORTHING>820357.1666</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.52</fme:SLOPESIZE>
<fme:SLOPEANGLE>108.81</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.504</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820357.16660 831991.76035 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide33defaa-2133-4a52-ae88-79390e18054c">
<fme:FEATURE_ID>1000316995</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832118.79072</fme:EASTING>
<fme:NORTHING>820357.52911</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.465</fme:SLOPESIZE>
<fme:SLOPEANGLE>344.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.893</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820357.52911 832118.79072 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0086d0c4-a873-4b49-806e-b61833be3241">
<fme:FEATURE_ID>1000316994</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832115.1003</fme:EASTING>
<fme:NORTHING>820358.32538</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.285</fme:SLOPESIZE>
<fme:SLOPEANGLE>343.42</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.657</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820358.32538 832115.10030 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id633b70ee-db39-4d4f-8f64-50ca4ef221b6">
<fme:FEATURE_ID>1000316993</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832110.87887</fme:EASTING>
<fme:NORTHING>820358.45896</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.965</fme:SLOPESIZE>
<fme:SLOPEANGLE>345.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.993</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820358.45896 832110.87887 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5c60d0a9-0249-4dfd-b6d6-05a698dc9e24">
<fme:FEATURE_ID>1210087384</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831923.672</fme:EASTING>
<fme:NORTHING>820358.71</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>50.326</fme:SLOPESIZE>
<fme:SLOPEANGLE>197.856</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.065</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820358.70958 831923.67170 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9aba11d8-7557-4797-ae4b-1e83165d0dc4">
<fme:FEATURE_ID>1000316943</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832024.35018</fme:EASTING>
<fme:NORTHING>820358.78476</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.465</fme:SLOPESIZE>
<fme:SLOPEANGLE>125.01</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.893</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820358.78476 832024.35018 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4320cd26-1de0-4f17-9ebf-34a76648a483">
<fme:FEATURE_ID>1000316992</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832107.11247</fme:EASTING>
<fme:NORTHING>820359.17871</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.59</fme:SLOPESIZE>
<fme:SLOPEANGLE>342.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.918</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820359.17871 832107.11247 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id950b6ffe-ebf5-4560-b650-46ce9069e315">
<fme:FEATURE_ID>1000317470</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833087.75</fme:EASTING>
<fme:NORTHING>820359.1875</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.575</fme:SLOPESIZE>
<fme:SLOPEANGLE>293.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.115</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820359.18750 833087.75000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id573204d4-b917-413a-9e4e-8b4340cbc386">
<fme:FEATURE_ID>1000316990</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832103.11835</fme:EASTING>
<fme:NORTHING>820359.66888</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>343.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.732</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820359.66888 832103.11835 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id007835fb-18b0-4674-84eb-00ca2ac13593">
<fme:FEATURE_ID>1000316942</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831990.70076</fme:EASTING>
<fme:NORTHING>820360.9969</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.065</fme:SLOPESIZE>
<fme:SLOPEANGLE>110.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.813</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820360.99690 831990.70076 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd29f8db3-f458-4e72-b564-3894929c1dae">
<fme:FEATURE_ID>1000316941</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832021.73957</fme:EASTING>
<fme:NORTHING>820362.60818</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.045</fme:SLOPESIZE>
<fme:SLOPEANGLE>123.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.009</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820362.60818 832021.73957 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id87be755f-141f-4ab7-9321-abda00ffa3d0">
<fme:FEATURE_ID>1210087385</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831932.031</fme:EASTING>
<fme:NORTHING>820362.893</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>46.934</fme:SLOPESIZE>
<fme:SLOPEANGLE>200.785</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.387</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820362.89305 831932.03142 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9af8d536-115e-4fe4-9bc5-1c86bc00d9f4">
<fme:FEATURE_ID>1000316940</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831993.27948</fme:EASTING>
<fme:NORTHING>820364.31004</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>5.64</fme:SLOPESIZE>
<fme:SLOPEANGLE>360.26</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.128</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820364.31004 831993.27948 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6591bdbe-684f-49fb-97bd-c0d31dae7cb8">
<fme:FEATURE_ID>1000316939</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>831997.32133</fme:EASTING>
<fme:NORTHING>820364.5312</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.53</fme:SLOPESIZE>
<fme:SLOPEANGLE>361.67</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.706</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820364.53120 831997.32133 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id810a6bf9-d4b6-46af-a768-59e4e0305bcd">
<fme:FEATURE_ID>1000316938</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832001.41461</fme:EASTING>
<fme:NORTHING>820364.62561</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.86</fme:SLOPESIZE>
<fme:SLOPEANGLE>358.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.972</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820364.62561 832001.41461 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1b38bb43-be5d-4c7c-bdb0-24edd63e90ad">
<fme:FEATURE_ID>1000316937</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832005.38102</fme:EASTING>
<fme:NORTHING>820364.6687</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.435</fme:SLOPESIZE>
<fme:SLOPEANGLE>359.83</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.887</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820364.66870 832005.38102 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0e5b4d8e-0bf5-4bd1-bc1d-b30d0c923992">
<fme:FEATURE_ID>1000316936</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832009.1425</fme:EASTING>
<fme:NORTHING>820365.04099</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.495</fme:SLOPESIZE>
<fme:SLOPEANGLE>365.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.699</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820365.04099 832009.14250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4096e509-d188-4b85-a4eb-f2de526abffd">
<fme:FEATURE_ID>1210087386</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831939.318</fme:EASTING>
<fme:NORTHING>820365.98</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>48.613</fme:SLOPESIZE>
<fme:SLOPEANGLE>199.272</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.723</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820365.97986 831939.31804 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc888c484-3cc7-468a-bb72-239f572cf3f8">
<fme:FEATURE_ID>1000316935</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832019.38355</fme:EASTING>
<fme:NORTHING>820366.35646</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.005</fme:SLOPESIZE>
<fme:SLOPEANGLE>123.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.001</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820366.35646 832019.38355 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd9d6e752-bca4-4391-b542-9f0c2e28def5">
<fme:FEATURE_ID>1000316934</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832016.19194</fme:EASTING>
<fme:NORTHING>820369.33915</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.1</fme:SLOPESIZE>
<fme:SLOPEANGLE>124.97</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.82</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820369.33915 832016.19194 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2e070175-4b6d-433b-a925-7ebed505355f">
<fme:FEATURE_ID>1210087387</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831946.584</fme:EASTING>
<fme:NORTHING>820370.045</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>46.061</fme:SLOPESIZE>
<fme:SLOPEANGLE>200.323</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.212</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820370.04538 831946.58363 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id98f89042-b14f-4744-acfe-1e754518fc8a">
<fme:FEATURE_ID>1000316933</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832013.17959</fme:EASTING>
<fme:NORTHING>820372.01787</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.355</fme:SLOPESIZE>
<fme:SLOPEANGLE>124.52</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.671</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820372.01787 832013.17959 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3b31af43-a1bb-4382-b812-43b5a45f794f">
<fme:FEATURE_ID>1210087389</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831961.446</fme:EASTING>
<fme:NORTHING>820372.038</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>65.947</fme:SLOPESIZE>
<fme:SLOPEANGLE>192.253</fme:SLOPEANGLE>
<fme:SLOPESIZE200>13.189</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820372.03779 831961.44619 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbfb13b6c-4a31-4df7-84af-2834ac613ae8">
<fme:FEATURE_ID>1210087390</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831970.816</fme:EASTING>
<fme:NORTHING>820372.056</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>73.355</fme:SLOPESIZE>
<fme:SLOPEANGLE>191.81</fme:SLOPEANGLE>
<fme:SLOPESIZE200>14.671</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820372.05628 831970.81645 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id98834ac7-0b71-460c-93f0-282968256aa5">
<fme:FEATURE_ID>1210087391</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831981.658</fme:EASTING>
<fme:NORTHING>820372.933</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>79.663</fme:SLOPESIZE>
<fme:SLOPEANGLE>192.325</fme:SLOPEANGLE>
<fme:SLOPESIZE200>15.933</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820372.93350 831981.65826 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id721335f7-194f-4680-9fca-6335eadafd37">
<fme:FEATURE_ID>1210087388</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831952.768</fme:EASTING>
<fme:NORTHING>820373.751</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>46.786</fme:SLOPESIZE>
<fme:SLOPEANGLE>197.939</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.357</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820373.75096 831952.76787 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id941e2178-11d0-448a-ae2e-e9d71af36ebf">
<fme:FEATURE_ID>1000316932</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832011.2089</fme:EASTING>
<fme:NORTHING>820374.87898</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.705</fme:SLOPESIZE>
<fme:SLOPEANGLE>122.15</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.141</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820374.87898 832011.20890 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id515b2ff4-5678-40fe-9bdc-b8ddb69066f0">
<fme:FEATURE_ID>1210087392</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831989.188</fme:EASTING>
<fme:NORTHING>820384.614</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>55.504</fme:SLOPESIZE>
<fme:SLOPEANGLE>192.095</fme:SLOPEANGLE>
<fme:SLOPESIZE200>11.101</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820384.61384 831989.18819 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcc804603-5b59-418e-8344-08267b979055">
<fme:FEATURE_ID>1210014666</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833116.23566</fme:EASTING>
<fme:NORTHING>820396.08813</fme:NORTHING>
<fme:SYMBOL>185</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>5</fme:RULEID>
<fme:SLOPESIZE>93.264</fme:SLOPESIZE>
<fme:SLOPEANGLE>191.915</fme:SLOPEANGLE>
<fme:SLOPESIZE200>18.653</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820396.08813 833116.23566 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id91196903-0f4b-45b5-812d-def244d1f26a">
<fme:FEATURE_ID>1210014664</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833123.37728</fme:EASTING>
<fme:NORTHING>820397.51193</fme:NORTHING>
<fme:SYMBOL>185</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>5</fme:RULEID>
<fme:SLOPESIZE>95.365</fme:SLOPESIZE>
<fme:SLOPEANGLE>169.628</fme:SLOPEANGLE>
<fme:SLOPESIZE200>19.073</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820397.51193 833123.37728 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9577965c-f614-4361-8005-c0ae9a1b39f8">
<fme:FEATURE_ID>1210014663</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833128.43933</fme:EASTING>
<fme:NORTHING>820397.617</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>77.051</fme:SLOPESIZE>
<fme:SLOPEANGLE>165.588</fme:SLOPEANGLE>
<fme:SLOPESIZE200>15.41</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820397.61700 833128.43933 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2b4d6d45-e68a-4bca-9cec-0a913284e636">
<fme:FEATURE_ID>1000317210</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832428.91095</fme:EASTING>
<fme:NORTHING>820398.57857</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.34</fme:SLOPESIZE>
<fme:SLOPEANGLE>132.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.068</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820398.57857 832428.91095 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9956cca9-23fd-4833-a8ee-4d6191ac8dce">
<fme:FEATURE_ID>1000318002</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832428.91095</fme:EASTING>
<fme:NORTHING>820398.57857</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.34</fme:SLOPESIZE>
<fme:SLOPEANGLE>132.48</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.068</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820398.57857 832428.91095 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idaf51fe87-d5d9-4122-beae-838676902675">
<fme:FEATURE_ID>1000316627</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832424.54304</fme:EASTING>
<fme:NORTHING>820401.62588</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.555</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.311</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820401.62588 832424.54304 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id8b6d7a21-5953-4cbc-a2bd-f549a06af305">
<fme:FEATURE_ID>1000316626</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832420.15662</fme:EASTING>
<fme:NORTHING>820404.47991</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>25.515</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.103</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820404.47991 832420.15662 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6a1597e7-1d92-4fbc-8149-54edb27ddaad">
<fme:FEATURE_ID>1000316625</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832415.74868</fme:EASTING>
<fme:NORTHING>820407.55023</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.69</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.138</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820407.55023 832415.74868 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id10dea782-3c03-4964-961b-12a9ea9c3bd9">
<fme:FEATURE_ID>1000316624</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832411.07186</fme:EASTING>
<fme:NORTHING>820411.32299</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>34.905</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.981</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820411.32299 832411.07186 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id41cba19e-af8a-48f9-afd1-1bfffc6010e9">
<fme:FEATURE_ID>1000316623</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832406.78122</fme:EASTING>
<fme:NORTHING>820415.56576</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.825</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.365</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820415.56576 832406.78122 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc63f6fe7-8f53-45b9-80e1-4279c15880f3">
<fme:FEATURE_ID>1000316622</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832404.1243</fme:EASTING>
<fme:NORTHING>820421.15718</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.955</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.591</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820421.15718 832404.12430 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id15ac2ce0-52c8-47f4-961f-020d05fe6bb8">
<fme:FEATURE_ID>1000316621</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832401.32845</fme:EASTING>
<fme:NORTHING>820425.96184</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.84</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.58</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.968</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820425.96184 832401.32845 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6dc794bd-fbb1-4648-96fa-2616d59e46c7">
<fme:FEATURE_ID>1000316620</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832398.43567</fme:EASTING>
<fme:NORTHING>820430.95376</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.48</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.47</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.296</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820430.95376 832398.43567 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9da5836f-338a-4202-af95-d0cc25cc39b3">
<fme:FEATURE_ID>1000316619</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832396.47086</fme:EASTING>
<fme:NORTHING>820436.20393</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.332</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820436.20393 832396.47086 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcaf28280-2de7-41b9-adc2-80028f608b61">
<fme:FEATURE_ID>1000316618</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832390.69208</fme:EASTING>
<fme:NORTHING>820439.33977</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.72</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.744</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820439.33977 832390.69208 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1d8a267f-d99f-4961-b9ae-9fdd57d8d01a">
<fme:FEATURE_ID>1000316617</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832384.89955</fme:EASTING>
<fme:NORTHING>820444.2098</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.585</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.517</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820444.20980 832384.89955 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6f88602f-91fc-4e22-8253-74f0f2f12908">
<fme:FEATURE_ID>1000316616</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832382.81031</fme:EASTING>
<fme:NORTHING>820450.2704</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>26.47</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.294</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820450.27040 832382.81031 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd36d6d12-245d-4117-9202-16edf6cf9284">
<fme:FEATURE_ID>1000316615</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832381.23933</fme:EASTING>
<fme:NORTHING>820455.1902</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>131.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.796</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820455.19020 832381.23933 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id058d37e0-a32b-4279-b2ee-a345e7cbf8cd">
<fme:FEATURE_ID>1000316614</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832378.60553</fme:EASTING>
<fme:NORTHING>820459.04959</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.77</fme:SLOPESIZE>
<fme:SLOPEANGLE>131.45</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.554</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820459.04959 832378.60553 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7864558b-75bc-4ca3-b5f5-abe6a219efa6">
<fme:FEATURE_ID>1000316613</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832375.90317</fme:EASTING>
<fme:NORTHING>820462.73399</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>17.26</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.452</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820462.73399 832375.90317 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id05904a3d-6b28-48cf-b538-d8cf3a4703eb">
<fme:FEATURE_ID>1000316612</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832371.22509</fme:EASTING>
<fme:NORTHING>820465.27338</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>23.415</fme:SLOPESIZE>
<fme:SLOPEANGLE>131.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.683</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820465.27338 832371.22509 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3afde2de-14b8-49fb-8e0b-7d0d0e2aefc8">
<fme:FEATURE_ID>1000316611</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832365.88551</fme:EASTING>
<fme:NORTHING>820467.43575</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.95</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.39</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820467.43575 832365.88551 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id95546214-a51f-418d-a15d-8e75e3945b91">
<fme:FEATURE_ID>1000318217</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833161.90695</fme:EASTING>
<fme:NORTHING>820469.33439</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.785</fme:SLOPESIZE>
<fme:SLOPEANGLE>443</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.357</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820469.33439 833161.90695 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id08bf4af6-730d-4fd0-82a8-326d4072cde7">
<fme:FEATURE_ID>1000316610</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832361.84693</fme:EASTING>
<fme:NORTHING>820471.88639</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>32.83</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.566</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820471.88639 832361.84693 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf0234f18-cb74-4b50-bc51-0cdf391534e4">
<fme:FEATURE_ID>1000318216</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833161.05199</fme:EASTING>
<fme:NORTHING>820473.53483</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.82</fme:SLOPESIZE>
<fme:SLOPEANGLE>91.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.764</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820473.53483 833161.05199 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9d7e5a95-4fe8-4a39-9071-3d60a87a431e">
<fme:FEATURE_ID>1000318215</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833159.93683</fme:EASTING>
<fme:NORTHING>820475.95101</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>16.375</fme:SLOPESIZE>
<fme:SLOPEANGLE>118.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.275</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820475.95101 833159.93683 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idafa37171-0af5-4489-b116-add6f83e59e7">
<fme:FEATURE_ID>1000316609</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832359.48529</fme:EASTING>
<fme:NORTHING>820477.27276</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.84</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.568</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820477.27276 832359.48529 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2a19877c-e5c5-4347-bb5f-b5179abd7716">
<fme:FEATURE_ID>1000318214</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833158.22692</fme:EASTING>
<fme:NORTHING>820478.18133</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.07</fme:SLOPESIZE>
<fme:SLOPEANGLE>153.87</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.414</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820478.18133 833158.22692 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbbb7ac3c-4c78-462f-b46d-8dc733f46ab6">
<fme:FEATURE_ID>1000316608</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832357.53624</fme:EASTING>
<fme:NORTHING>820482.61796</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.532</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820482.61796 832357.53624 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3b6f6eaf-f711-4d2f-936c-e2b1d73068c1">
<fme:FEATURE_ID>1000316607</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832354.43695</fme:EASTING>
<fme:NORTHING>820487.84336</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.885</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.86</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.777</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820487.84336 832354.43695 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc105c31e-1185-489b-9295-18fcabfd028e">
<fme:FEATURE_ID>1000316606</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832350.73674</fme:EASTING>
<fme:NORTHING>820491.65639</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>19.09</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.8</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.818</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820491.65639 832350.73674 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id695e59db-5401-4d9c-9b6f-23f605c86bf5">
<fme:FEATURE_ID>1000316605</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832344.84533</fme:EASTING>
<fme:NORTHING>820493.77547</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.53</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.706</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820493.77547 832344.84533 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id127efbea-96ec-40e5-a590-385d771cbefb">
<fme:FEATURE_ID>1000316604</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832341.03013</fme:EASTING>
<fme:NORTHING>820497.30557</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>30.685</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.137</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820497.30557 832341.03013 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id449a7bbb-63b4-407b-9be5-8bf4f7de0865">
<fme:FEATURE_ID>1000316603</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832337.71934</fme:EASTING>
<fme:NORTHING>820502.41741</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.225</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.845</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820502.41741 832337.71934 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id50d12bd7-ae34-4533-8649-f7c7c7914cba">
<fme:FEATURE_ID>1000316602</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832333.87857</fme:EASTING>
<fme:NORTHING>820506.19082</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.235</fme:SLOPESIZE>
<fme:SLOPEANGLE>129.56</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.247</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820506.19082 832333.87857 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idef393a34-0f80-4fc9-86de-a87161555e71">
<fme:FEATURE_ID>1000316601</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832331.21418</fme:EASTING>
<fme:NORTHING>820511.0125</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.17</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.634</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820511.01250 832331.21418 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idae7a3fa0-032f-49c1-aba7-379744510dde">
<fme:FEATURE_ID>1000318209</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833079.3904</fme:EASTING>
<fme:NORTHING>820514.42419</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.155</fme:SLOPESIZE>
<fme:SLOPEANGLE>147.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.031</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820514.42419 833079.39040 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1c0116b3-ca39-4145-8424-010514eecaca">
<fme:FEATURE_ID>1000316600</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832329.76507</fme:EASTING>
<fme:NORTHING>820516.21162</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>21.435</fme:SLOPESIZE>
<fme:SLOPEANGLE>130.52</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.287</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820516.21162 832329.76507 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7255db33-cc94-434b-98b9-7a4e2f5f46d5">
<fme:FEATURE_ID>1000318208</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833075.87657</fme:EASTING>
<fme:NORTHING>820516.56661</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.545</fme:SLOPESIZE>
<fme:SLOPEANGLE>147.04</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.109</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820516.56661 833075.87657 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida47c7985-296f-4593-ae8f-85f6f60855d3">
<fme:FEATURE_ID>1000318207</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833072.36273</fme:EASTING>
<fme:NORTHING>820518.70904</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.93</fme:SLOPESIZE>
<fme:SLOPEANGLE>146.41</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.186</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820518.70904 833072.36273 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6b98f120-0c92-4f23-a748-dceed8b1db5b">
<fme:FEATURE_ID>1000318206</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833068.8489</fme:EASTING>
<fme:NORTHING>820520.85147</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.325</fme:SLOPESIZE>
<fme:SLOPEANGLE>145.82</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.265</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820520.85147 833068.84890 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id29cc64b8-9eb0-48b7-89fe-15b7925a996e">
<fme:FEATURE_ID>1000318205</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833065.33507</fme:EASTING>
<fme:NORTHING>820522.99389</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.715</fme:SLOPESIZE>
<fme:SLOPEANGLE>145.27</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.343</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820522.99389 833065.33507 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfb2813eb-9b17-4743-bdac-53f3fb813ee2">
<fme:FEATURE_ID>1000318204</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833061.73015</fme:EASTING>
<fme:NORTHING>820524.89342</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.11</fme:SLOPESIZE>
<fme:SLOPEANGLE>144.76</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.422</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820524.89342 833061.73015 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id05c39fa9-a335-467b-971e-c0f10394e52a">
<fme:FEATURE_ID>1000318203</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833058.18595</fme:EASTING>
<fme:NORTHING>820527.00548</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.5</fme:SLOPESIZE>
<fme:SLOPEANGLE>144.28</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.5</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820527.00548 833058.18595 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida51e1eb6-ab44-41dc-85a4-71748219467c">
<fme:FEATURE_ID>1000318202</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833054.64484</fme:EASTING>
<fme:NORTHING>820529.03616</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.245</fme:SLOPESIZE>
<fme:SLOPEANGLE>145.29</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.449</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820529.03616 833054.64484 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id1b7b4dbc-0cb7-4386-8719-029720d2c9bd">
<fme:FEATURE_ID>1000318201</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833051.13236</fme:EASTING>
<fme:NORTHING>820531.1434</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.11</fme:SLOPESIZE>
<fme:SLOPEANGLE>144.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.422</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820531.14340 833051.13236 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida1f739a9-e4b7-40ca-8178-35bff9ff6cc1">
<fme:FEATURE_ID>1000318200</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833047.5947</fme:EASTING>
<fme:NORTHING>820533.39412</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.185</fme:SLOPESIZE>
<fme:SLOPEANGLE>144</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.437</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820533.39412 833047.59470 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb73b2420-590b-411e-a823-7fcea2298c27">
<fme:FEATURE_ID>1000318199</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833044.08454</fme:EASTING>
<fme:NORTHING>820535.49956</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.02</fme:SLOPESIZE>
<fme:SLOPEANGLE>143.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.604</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820535.49956 833044.08454 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfbfd14f1-62ec-4452-999f-de25f9f48a87">
<fme:FEATURE_ID>1000318198</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833040.56709</fme:EASTING>
<fme:NORTHING>820537.61037</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.15</fme:SLOPESIZE>
<fme:SLOPEANGLE>143.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.63</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820537.61037 833040.56709 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9b9eb22d-ac48-42b3-bde1-aa1116ebf4f3">
<fme:FEATURE_ID>1000318197</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833036.94771</fme:EASTING>
<fme:NORTHING>820539.79751</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.625</fme:SLOPESIZE>
<fme:SLOPEANGLE>141.81</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.525</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820539.79751 833036.94771 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idae7fee47-1bb1-46fa-a469-19e80ace1137">
<fme:FEATURE_ID>1000318196</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833033.34305</fme:EASTING>
<fme:NORTHING>820541.87862</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.14</fme:SLOPESIZE>
<fme:SLOPEANGLE>142.07</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.228</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820541.87862 833033.34305 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id10fb3a98-f908-407a-bf61-cf7bc4332522">
<fme:FEATURE_ID>1210014648</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833020.13189</fme:EASTING>
<fme:NORTHING>820545.21228</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.493</fme:SLOPESIZE>
<fme:SLOPEANGLE>323.673</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.899</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820545.21228 833020.13189 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6b57679e-cffd-4ce6-8778-43be09e9753b">
<fme:FEATURE_ID>1210014654</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833016.63748</fme:EASTING>
<fme:NORTHING>820547.23335</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.207</fme:SLOPESIZE>
<fme:SLOPEANGLE>324.075</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.841</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820547.23335 833016.63748 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbf2f0dc4-4efa-42ed-9c1c-8d3020d3af2f">
<fme:FEATURE_ID>1210014644</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833013.14307</fme:EASTING>
<fme:NORTHING>820549.25441</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.922</fme:SLOPESIZE>
<fme:SLOPEANGLE>324.492</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.784</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820549.25441 833013.14307 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4770bf66-687f-4b3b-bb03-f6967dd8ed76">
<fme:FEATURE_ID>1210014645</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833009.64866</fme:EASTING>
<fme:NORTHING>820551.27547</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.637</fme:SLOPESIZE>
<fme:SLOPEANGLE>324.927</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.727</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820551.27547 833009.64866 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0af71fee-b8c8-47a3-839a-475544b5b705">
<fme:FEATURE_ID>1000316592</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832283.96434</fme:EASTING>
<fme:NORTHING>820552.69387</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.58</fme:SLOPESIZE>
<fme:SLOPEANGLE>115.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.916</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820552.69387 832283.96434 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id91ce3e89-9957-418e-b6d7-a02ff4e83249">
<fme:FEATURE_ID>1210014656</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833006.15425</fme:EASTING>
<fme:NORTHING>820553.29653</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.354</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.381</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.671</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820553.29653 833006.15425 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb4c5fecf-5f5b-43ab-9e0e-7301f53e6a4e">
<fme:FEATURE_ID>1210014662</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833002.65984</fme:EASTING>
<fme:NORTHING>820555.3176</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.071</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.854</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.614</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820555.31760 833002.65984 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd3437fe8-4e7d-48f5-aaca-7952def5915f">
<fme:FEATURE_ID>1000316591</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832281.84821</fme:EASTING>
<fme:NORTHING>820557.07129</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.955</fme:SLOPESIZE>
<fme:SLOPEANGLE>118.5</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.991</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820557.07129 832281.84821 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id54c40dae-a45f-47e7-bb40-cab2e30585fa">
<fme:FEATURE_ID>1210014650</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832999.16543</fme:EASTING>
<fme:NORTHING>820557.33866</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.789</fme:SLOPESIZE>
<fme:SLOPEANGLE>326.349</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.558</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820557.33866 832999.16543 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd4d4d892-211f-4bd2-a514-1bbc47ba9bba">
<fme:FEATURE_ID>1210014652</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832995.67102</fme:EASTING>
<fme:NORTHING>820559.35972</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.508</fme:SLOPESIZE>
<fme:SLOPEANGLE>326.865</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.502</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820559.35972 832995.67102 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id10751c8c-07e7-49b1-9c8c-309201ca4baf">
<fme:FEATURE_ID>1000316590</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832280.30122</fme:EASTING>
<fme:NORTHING>820560.841</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.66</fme:SLOPESIZE>
<fme:SLOPEANGLE>126.74</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.732</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820560.84100 832280.30122 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd274566f-50c4-4a73-b209-d8998870a54c">
<fme:FEATURE_ID>1210014659</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832992.1766</fme:EASTING>
<fme:NORTHING>820561.38078</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.228</fme:SLOPESIZE>
<fme:SLOPEANGLE>327.405</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.446</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820561.38078 832992.17660 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id62dcff2e-6f97-42ac-b1ea-01fc0d4692b5">
<fme:FEATURE_ID>1210014647</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832988.68219</fme:EASTING>
<fme:NORTHING>820563.40184</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.95</fme:SLOPESIZE>
<fme:SLOPEANGLE>327.971</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.39</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820563.40184 832988.68219 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id980b5184-8dab-4dca-af06-fec26aa1830c">
<fme:FEATURE_ID>1210014638</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832985.18778</fme:EASTING>
<fme:NORTHING>820565.42291</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.672</fme:SLOPESIZE>
<fme:SLOPEANGLE>328.563</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.334</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820565.42291 832985.18778 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id646ce14f-9f52-4bbe-8a22-16b0ec2dab78">
<fme:FEATURE_ID>1210014641</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832981.69337</fme:EASTING>
<fme:NORTHING>820567.44397</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.396</fme:SLOPESIZE>
<fme:SLOPEANGLE>329.184</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.279</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820567.44397 832981.69337 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb4a88f18-4ecc-4d64-b715-98dda0c06b30">
<fme:FEATURE_ID>1000316587</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832269.93862</fme:EASTING>
<fme:NORTHING>820567.64423</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>18.235</fme:SLOPESIZE>
<fme:SLOPEANGLE>142.72</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.647</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820567.64423 832269.93862 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ida6642194-8fb5-44ce-8f6b-312d081968f6">
<fme:FEATURE_ID>1210014661</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832978.19896</fme:EASTING>
<fme:NORTHING>820569.46503</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.122</fme:SLOPESIZE>
<fme:SLOPEANGLE>329.836</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.224</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820569.46503 832978.19896 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id23f9cae8-eed6-440b-bf95-0eb46882e13f">
<fme:FEATURE_ID>1000316586</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832264.44852</fme:EASTING>
<fme:NORTHING>820570.66227</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>24.29</fme:SLOPESIZE>
<fme:SLOPEANGLE>133.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.858</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820570.66227 832264.44852 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id06a1f39e-3bfa-4254-9346-e36dad753477">
<fme:FEATURE_ID>1210014657</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832974.70455</fme:EASTING>
<fme:NORTHING>820571.48609</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.848</fme:SLOPESIZE>
<fme:SLOPEANGLE>330.521</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.17</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820571.48609 832974.70455 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id12950bf5-a3ab-40b4-bd66-05049611125d">
<fme:FEATURE_ID>1210014640</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832971.21014</fme:EASTING>
<fme:NORTHING>820573.50716</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.577</fme:SLOPESIZE>
<fme:SLOPEANGLE>331.241</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.115</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820573.50716 832971.21014 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id747709b7-6ae1-4ed8-971f-e51a6ed2438b">
<fme:FEATURE_ID>1210014660</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832967.71573</fme:EASTING>
<fme:NORTHING>820575.52822</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.307</fme:SLOPESIZE>
<fme:SLOPEANGLE>331.999</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.061</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820575.52822 832967.71573 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7c90cf95-96a2-4490-ac4d-94704be3aa07">
<fme:FEATURE_ID>1000316585</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832258.55716</fme:EASTING>
<fme:NORTHING>820577.26739</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.84</fme:SLOPESIZE>
<fme:SLOPEANGLE>102.37</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.768</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820577.26739 832258.55716 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id35635df3-13d4-4c40-8ca1-3729f904180c">
<fme:FEATURE_ID>1210014653</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832964.22132</fme:EASTING>
<fme:NORTHING>820577.54928</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>10.039</fme:SLOPESIZE>
<fme:SLOPEANGLE>332.797</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.008</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820577.54928 832964.22132 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd832d672-0a48-4eea-b22a-1bc31c8828f2">
<fme:FEATURE_ID>1210014655</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832960.72691</fme:EASTING>
<fme:NORTHING>820579.57034</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.773</fme:SLOPESIZE>
<fme:SLOPEANGLE>333.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.955</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820579.57034 832960.72691 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcb5c3663-813d-4ee0-b7f2-fdada54f1425">
<fme:FEATURE_ID>1210014637</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832957.2325</fme:EASTING>
<fme:NORTHING>820581.5914</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.51</fme:SLOPESIZE>
<fme:SLOPEANGLE>334.529</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.902</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820581.59140 832957.23250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idca85f580-9186-45b8-80e4-87345ab6efce">
<fme:FEATURE_ID>1210014643</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832953.73809</fme:EASTING>
<fme:NORTHING>820583.61247</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.249</fme:SLOPESIZE>
<fme:SLOPEANGLE>335.468</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.85</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820583.61247 832953.73809 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6e34257f-5d12-493a-b92d-613aee063ad1">
<fme:FEATURE_ID>1210014649</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832950.24367</fme:EASTING>
<fme:NORTHING>820585.63353</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.99</fme:SLOPESIZE>
<fme:SLOPEANGLE>336.462</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.798</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820585.63353 832950.24367 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idbec05786-3093-4e91-b375-6d3b02586fb3">
<fme:FEATURE_ID>1210014646</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832946.74926</fme:EASTING>
<fme:NORTHING>820587.65459</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>8.734</fme:SLOPESIZE>
<fme:SLOPEANGLE>337.514</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.747</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820587.65459 832946.74926 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id49f97bd8-221f-4a1e-a05b-70db2afb6234">
<fme:FEATURE_ID>1000316584</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832251.43475</fme:EASTING>
<fme:NORTHING>820588.9515</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>54.27</fme:SLOPESIZE>
<fme:SLOPEANGLE>426.76</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.854</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820588.95150 832251.43475 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9870abcc-002b-4e26-9ed3-e0fad89c92e1">
<fme:FEATURE_ID>1210014651</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832943.25485</fme:EASTING>
<fme:NORTHING>820589.67565</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.531</fme:SLOPESIZE>
<fme:SLOPEANGLE>338.629</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.706</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820589.67565 832943.25485 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id74a01d80-99b9-4dfa-9663-325b254f333b">
<fme:FEATURE_ID>1210014642</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832942.35973</fme:EASTING>
<fme:NORTHING>820591.7118</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.582</fme:SLOPESIZE>
<fme:SLOPEANGLE>279.62</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.516</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820591.71180 832942.35973 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idabce1878-20c6-4dee-a6e7-e4d09948dfab">
<fme:FEATURE_ID>1210014639</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832942.75319</fme:EASTING>
<fme:NORTHING>820593.99878</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>13.37</fme:SLOPESIZE>
<fme:SLOPEANGLE>240.479</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.674</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820593.99878 832942.75319 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id082980b5-7f99-4c02-8ab5-5b9b4ca01018">
<fme:FEATURE_ID>1210014658</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832944.4008</fme:EASTING>
<fme:NORTHING>820595.57262</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.945</fme:SLOPESIZE>
<fme:SLOPEANGLE>172.221</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.589</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820595.57262 832944.40080 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id38111c35-879d-4722-9d1a-0f34196a30a0">
<fme:FEATURE_ID>1000316583</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832252.71319</fme:EASTING>
<fme:NORTHING>820597.82741</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>67.94</fme:SLOPESIZE>
<fme:SLOPEANGLE>413.31</fme:SLOPEANGLE>
<fme:SLOPESIZE200>13.588</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820597.82741 832252.71319 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id710e4422-b30e-4ba0-bf19-4850b229abbf">
<fme:FEATURE_ID>1000316582</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832262.08998</fme:EASTING>
<fme:NORTHING>820599.9165</fme:NORTHING>
<fme:SYMBOL>184</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>4</fme:RULEID>
<fme:SLOPESIZE>53.675</fme:SLOPESIZE>
<fme:SLOPEANGLE>404.43</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.735</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820599.91650 832262.08998 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id44ab3365-a717-4990-b043-93b8772682c5">
<fme:FEATURE_ID>1000316581</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832266.85331</fme:EASTING>
<fme:NORTHING>820603.57039</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>50.825</fme:SLOPESIZE>
<fme:SLOPEANGLE>402.01</fme:SLOPEANGLE>
<fme:SLOPESIZE200>10.165</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820603.57039 832266.85331 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id914130ba-a95a-4f19-9bc2-9c4b4cf2d444">
<fme:FEATURE_ID>1000316580</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832271.6728</fme:EASTING>
<fme:NORTHING>820607.21754</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>47.425</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.88</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.485</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820607.21754 832271.67280 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb91ec428-3141-4e52-8ad0-3fa644e0fdb6">
<fme:FEATURE_ID>1000316579</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832276.48781</fme:EASTING>
<fme:NORTHING>820610.86128</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>45.82</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.77</fme:SLOPEANGLE>
<fme:SLOPESIZE200>9.164</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820610.86128 832276.48781 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4e42370f-c724-4c99-99e1-12e79fd8d979">
<fme:FEATURE_ID>1000316578</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832281.28741</fme:EASTING>
<fme:NORTHING>820614.51418</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>43.89</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.778</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820614.51418 832281.28741 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id71bdc335-1a94-4815-9053-0332203bb4d1">
<fme:FEATURE_ID>1000316577</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832286.08225</fme:EASTING>
<fme:NORTHING>820618.1667</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.61</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.66</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.322</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820618.16670 832286.08225 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id45719483-3162-4dbc-9871-430327db61aa">
<fme:FEATURE_ID>1000316576</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832290.874</fme:EASTING>
<fme:NORTHING>820621.81691</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>38.76</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.752</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820621.81691 832290.87400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idc20f4cd9-2b74-4a4c-8a8e-482dc4aa4403">
<fme:FEATURE_ID>1000316575</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832295.66302</fme:EASTING>
<fme:NORTHING>820625.465</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>35.535</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.65</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.107</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820625.46500 832295.66302 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2bd4461b-d1a1-49f0-9b1f-743d411910d8">
<fme:FEATURE_ID>1000316574</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832300.44977</fme:EASTING>
<fme:NORTHING>820629.11218</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.235</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.69</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.647</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820629.11218 832300.44977 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id072b149b-4074-4784-989e-edcb26d0b31a">
<fme:FEATURE_ID>1000316573</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832305.23482</fme:EASTING>
<fme:NORTHING>820632.75819</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>28.975</fme:SLOPESIZE>
<fme:SLOPEANGLE>401.76</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.795</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820632.75819 832305.23482 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb3dc51f2-918c-48ec-ad58-aa3d22bab617">
<fme:FEATURE_ID>1000317877</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832239.67769</fme:EASTING>
<fme:NORTHING>820707.80325</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.51</fme:SLOPESIZE>
<fme:SLOPEANGLE>160.77</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.902</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820707.80325 832239.67769 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf16954c9-5fbd-42d0-a8c3-87918552f758">
<fme:FEATURE_ID>1000317876</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832235.50217</fme:EASTING>
<fme:NORTHING>820708.79019</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.96</fme:SLOPESIZE>
<fme:SLOPEANGLE>163.78</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.392</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820708.79019 832235.50217 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id57a867ab-7155-46f0-8c8c-c061b4878d16">
<fme:FEATURE_ID>1000317875</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832231.54597</fme:EASTING>
<fme:NORTHING>820710.24108</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.96</fme:SLOPESIZE>
<fme:SLOPEANGLE>162.97</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.392</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820710.24108 832231.54597 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3fb8f541-f923-4b85-b821-f6b3f3242c40">
<fme:FEATURE_ID>1000317874</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832227.58978</fme:EASTING>
<fme:NORTHING>820711.69196</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.965</fme:SLOPESIZE>
<fme:SLOPEANGLE>162.16</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.393</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820711.69196 832227.58978 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4693ce6d-d3b7-4c45-aa90-25791f66c828">
<fme:FEATURE_ID>1000317873</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832223.63358</fme:EASTING>
<fme:NORTHING>820713.14285</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.97</fme:SLOPESIZE>
<fme:SLOPEANGLE>161.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.394</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820713.14285 832223.63358 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id20dcd798-d710-4b27-acca-a491b0094cf3">
<fme:FEATURE_ID>1000317872</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832219.67738</fme:EASTING>
<fme:NORTHING>820714.59374</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.98</fme:SLOPESIZE>
<fme:SLOPEANGLE>160.55</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.396</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820714.59374 832219.67738 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id9b24569a-0959-46ea-b1cd-e42837b55c6f">
<fme:FEATURE_ID>1000317871</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832215.72118</fme:EASTING>
<fme:NORTHING>820716.04462</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.995</fme:SLOPESIZE>
<fme:SLOPEANGLE>159.74</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.399</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820716.04462 832215.72118 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3594294d-c0dc-4f63-9bff-263138fed9a9">
<fme:FEATURE_ID>1000317870</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832211.76498</fme:EASTING>
<fme:NORTHING>820717.49551</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.005</fme:SLOPESIZE>
<fme:SLOPEANGLE>158.94</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.401</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820717.49551 832211.76498 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf2232e42-245d-41b0-8265-e1e63acdf14f">
<fme:FEATURE_ID>1000317869</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832207.80878</fme:EASTING>
<fme:NORTHING>820718.9464</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.025</fme:SLOPESIZE>
<fme:SLOPEANGLE>158.14</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.405</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820718.94640 832207.80878 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3117660b-85eb-4c66-a5ce-ef13cbf8e444">
<fme:FEATURE_ID>1000317868</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832203.85259</fme:EASTING>
<fme:NORTHING>820720.39729</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.04</fme:SLOPESIZE>
<fme:SLOPEANGLE>157.34</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.408</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820720.39729 832203.85259 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id52e9cd52-e445-4c67-b917-1307288d0f89">
<fme:FEATURE_ID>1000317867</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832176.81716</fme:EASTING>
<fme:NORTHING>820721.31674</fme:NORTHING>
<fme:SYMBOL>181</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>1</fme:RULEID>
<fme:SLOPESIZE>8.505</fme:SLOPESIZE>
<fme:SLOPEANGLE>200.38</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.701</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820721.31674 832176.81716 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="ide6d63b5b-a03c-4df5-aac7-ed3921f32342">
<fme:FEATURE_ID>1000317866</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832199.89639</fme:EASTING>
<fme:NORTHING>820721.84817</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>12.06</fme:SLOPESIZE>
<fme:SLOPEANGLE>156.54</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.412</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820721.84817 832199.89639 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2cb8dddf-3272-4908-9c1a-7fc3d035b7c2">
<fme:FEATURE_ID>1000317865</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832180.15757</fme:EASTING>
<fme:NORTHING>820722.75919</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.85</fme:SLOPESIZE>
<fme:SLOPEANGLE>201.12</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.97</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820722.75919 832180.15757 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id457385d3-6326-40ad-bc42-4c7bc0055ed0">
<fme:FEATURE_ID>1000317864</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832196.17638</fme:EASTING>
<fme:NORTHING>820722.98695</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.67</fme:SLOPESIZE>
<fme:SLOPEANGLE>169.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.334</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820722.98695 832196.17638 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2e679221-981e-4d6c-894e-c6a72a051641">
<fme:FEATURE_ID>1000317863</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832191.7731</fme:EASTING>
<fme:NORTHING>820723.89797</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.8</fme:SLOPESIZE>
<fme:SLOPEANGLE>166.7</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.36</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820723.89797 832191.77310 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id89a13560-a646-4126-804d-acd7f8f97f48">
<fme:FEATURE_ID>1000317862</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832187.82535</fme:EASTING>
<fme:NORTHING>820724.809</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.32</fme:SLOPESIZE>
<fme:SLOPEANGLE>174.71</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.264</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820724.80900 832187.82535 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5490720e-ac79-4aa9-a497-1a00ced02340">
<fme:FEATURE_ID>1000317861</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>832183.19431</fme:EASTING>
<fme:NORTHING>820725.49226</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>11.49</fme:SLOPESIZE>
<fme:SLOPEANGLE>177.92</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.298</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820725.49226 832183.19431 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id302a978c-931b-4182-8e17-2724e249eccb">
<fme:FEATURE_ID>1000318195</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833747.0028</fme:EASTING>
<fme:NORTHING>820847.63065</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>9.985</fme:SLOPESIZE>
<fme:SLOPEANGLE>340.91</fme:SLOPEANGLE>
<fme:SLOPESIZE200>1.997</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820847.63065 833747.00280 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id57107ad7-db51-4863-9658-35054d36fd79">
<fme:FEATURE_ID>1000318194</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833743.84742</fme:EASTING>
<fme:NORTHING>820850.09384</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.685</fme:SLOPESIZE>
<fme:SLOPEANGLE>324.73</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.937</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820850.09384 833743.84742 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="iddcbb0a09-8395-4b15-b791-048ef25435c2">
<fme:FEATURE_ID>1000318193</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833740.3079</fme:EASTING>
<fme:NORTHING>820852.37998</fme:NORTHING>
<fme:SYMBOL>182</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>14.45</fme:SLOPESIZE>
<fme:SLOPEANGLE>323.93</fme:SLOPEANGLE>
<fme:SLOPESIZE200>2.89</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820852.37998 833740.30790 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb57164cb-7d44-4b62-a161-299e66a7e397">
<fme:FEATURE_ID>1000318191</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833723.72605</fme:EASTING>
<fme:NORTHING>820865.99993</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.665</fme:SLOPESIZE>
<fme:SLOPEANGLE>339.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.133</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820865.99993 833723.72605 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idad4aa881-68b0-4909-8e58-ca2b0c42f6fa">
<fme:FEATURE_ID>1000318190</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833720.28322</fme:EASTING>
<fme:NORTHING>820869.44252</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.52</fme:SLOPESIZE>
<fme:SLOPEANGLE>324.98</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.304</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820869.44252 833720.28322 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idb27ef4cb-17c9-4dbc-b4c6-07d30ec24e39">
<fme:FEATURE_ID>1210088701</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833717.108</fme:EASTING>
<fme:NORTHING>820871.179</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>22.437</fme:SLOPESIZE>
<fme:SLOPEANGLE>322.058</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.487</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820871.17912 833717.10824 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idf018dd50-a7db-419b-a685-54c290824e3a">
<fme:FEATURE_ID>1210088700</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833713.342</fme:EASTING>
<fme:NORTHING>820873.607</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>20.781</fme:SLOPESIZE>
<fme:SLOPEANGLE>326.083</fme:SLOPEANGLE>
<fme:SLOPESIZE200>4.156</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820873.60701 833713.34151 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idaad80fcf-84dd-4961-9086-dedecaea3266">
<fme:FEATURE_ID>1210088699</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833709.212</fme:EASTING>
<fme:NORTHING>820876.28</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.039</fme:SLOPESIZE>
<fme:SLOPEANGLE>330.524</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.008</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820876.27999 833709.21205 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id48d1b726-f483-42f0-b191-f7ae1d780a45">
<fme:FEATURE_ID>1210088698</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833705.519</fme:EASTING>
<fme:NORTHING>820879.353</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.557</fme:SLOPESIZE>
<fme:SLOPEANGLE>327.771</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.111</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820879.35292 833705.51870 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6223c147-6283-45ef-bb39-d6959520be1f">
<fme:FEATURE_ID>1210088697</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833701.684</fme:EASTING>
<fme:NORTHING>820881.706</fme:NORTHING>
<fme:SYMBOL/>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>2</fme:RULEID>
<fme:SLOPESIZE>15.971</fme:SLOPESIZE>
<fme:SLOPEANGLE>322.306</fme:SLOPEANGLE>
<fme:SLOPESIZE200>3.194</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820881.70630 833701.68446 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idcb0ed078-36a2-4f26-9824-66dfc9868e43">
<fme:FEATURE_ID>1000318185</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833699.28206</fme:EASTING>
<fme:NORTHING>820885.25626</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.91</fme:SLOPESIZE>
<fme:SLOPEANGLE>320.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.382</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820885.25626 833699.28206 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4d11e6ce-a5f8-4e20-ab3a-86cd19cafed3">
<fme:FEATURE_ID>1000318184</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833695.98875</fme:EASTING>
<fme:NORTHING>820888.39637</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>34.985</fme:SLOPESIZE>
<fme:SLOPEANGLE>322.32</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.997</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820888.39637 833695.98875 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3e646d26-d113-4bcd-ab3f-6c10ec2a5dc6">
<fme:FEATURE_ID>1000318183</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833692.99334</fme:EASTING>
<fme:NORTHING>820891.94829</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>36.615</fme:SLOPESIZE>
<fme:SLOPEANGLE>312.61</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.323</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820891.94829 833692.99334 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id4a745bfc-6130-41c9-89cf-32f6c30b19eb">
<fme:FEATURE_ID>1000318182</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833690.47307</fme:EASTING>
<fme:NORTHING>820895.8144</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>39.91</fme:SLOPESIZE>
<fme:SLOPEANGLE>308.36</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.982</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820895.81440 833690.47307 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idfd824a96-e3f2-4831-a73f-e8b4d3560687">
<fme:FEATURE_ID>1000318181</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833686.64379</fme:EASTING>
<fme:NORTHING>820900.97549</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>40.325</fme:SLOPESIZE>
<fme:SLOPEANGLE>308.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.065</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820900.97549 833686.64379 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id34c5f61b-e869-4477-9dcc-acfd2711684f">
<fme:FEATURE_ID>1000318180</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833682.81452</fme:EASTING>
<fme:NORTHING>820906.13659</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>40.74</fme:SLOPESIZE>
<fme:SLOPEANGLE>307.68</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.148</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820906.13659 833682.81452 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id7df7a69d-920c-4e75-820a-dafb91e81486">
<fme:FEATURE_ID>1000318179</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833678.98524</fme:EASTING>
<fme:NORTHING>820911.29768</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.155</fme:SLOPESIZE>
<fme:SLOPEANGLE>307.35</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.231</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820911.29768 833678.98524 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5baea988-728b-480a-a355-b453b1958ab1">
<fme:FEATURE_ID>1000318178</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833676.609</fme:EASTING>
<fme:NORTHING>820914.5804</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>42.41</fme:SLOPESIZE>
<fme:SLOPEANGLE>306.46</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.482</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820914.58040 833676.60900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd7731fa0-038a-46c2-a25c-315aaae4ed42">
<fme:FEATURE_ID>1000318177</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833672.096</fme:EASTING>
<fme:NORTHING>820919.46009</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>41.79</fme:SLOPESIZE>
<fme:SLOPEANGLE>314.02</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.358</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820919.46009 833672.09600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id2a89e405-474e-44bf-b7a0-b7ffac2117d7">
<fme:FEATURE_ID>1000318176</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833667.68086</fme:EASTING>
<fme:NORTHING>820923.6691</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>42.06</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.74</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.412</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820923.66910 833667.68086 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id0dc1626b-64da-4bc1-8d82-ff464cb652cf">
<fme:FEATURE_ID>1000318175</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833662.31324</fme:EASTING>
<fme:NORTHING>820927.17992</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>40.92</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.64</fme:SLOPEANGLE>
<fme:SLOPESIZE200>8.184</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820927.17992 833662.31324 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3f595053-bfa6-4923-bf71-934bd06b2bbc">
<fme:FEATURE_ID>1000318174</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833656.94562</fme:EASTING>
<fme:NORTHING>820930.69074</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>39.775</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.53</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.955</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820930.69074 833656.94562 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd98490db-7bb3-48db-8a22-a679d16ac7f7">
<fme:FEATURE_ID>1000318173</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833651.578</fme:EASTING>
<fme:NORTHING>820934.20157</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>38.63</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.42</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.726</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820934.20157 833651.57800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idd352c8e1-e659-4406-a4dc-5ff27dcae163">
<fme:FEATURE_ID>1000318172</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833646.77712</fme:EASTING>
<fme:NORTHING>820937.33448</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>37.58</fme:SLOPESIZE>
<fme:SLOPEANGLE>326.03</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.516</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820937.33448 833646.77712 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="idad6de85e-8fd2-4102-a17f-118b219d938f">
<fme:FEATURE_ID>1000318171</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833642.71359</fme:EASTING>
<fme:NORTHING>820940.08525</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>37.195</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.03</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.439</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820940.08525 833642.71359 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id931409bd-6a20-4ed6-895e-b35d1911f541">
<fme:FEATURE_ID>1000318170</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833638.07806</fme:EASTING>
<fme:NORTHING>820942.67041</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>35.21</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.06</fme:SLOPEANGLE>
<fme:SLOPESIZE200>7.042</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820942.67041 833638.07806 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id5e2afc6f-1b95-43dc-9cb5-8a5fea5d5b32">
<fme:FEATURE_ID>1000318169</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833633.44254</fme:EASTING>
<fme:NORTHING>820945.25556</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>33.225</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.09</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.645</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820945.25556 833633.44254 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id3c5518a9-a7ed-4bef-b8da-8fbfb3d4b676">
<fme:FEATURE_ID>1000318168</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833628.80701</fme:EASTING>
<fme:NORTHING>820947.84071</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>31.24</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.13</fme:SLOPEANGLE>
<fme:SLOPESIZE200>6.248</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820947.84071 833628.80701 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id6d6d41a5-4dc8-406f-a677-814853816142">
<fme:FEATURE_ID>1000318167</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833624.17149</fme:EASTING>
<fme:NORTHING>820950.42587</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>29.255</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.17</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.851</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820950.42587 833624.17149 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
<gml:featureMember>
<fme:Slope gml:id="id10675d82-2e1e-4e33-8ff0-014aaa3f7cc4">
<fme:FEATURE_ID>1000318166</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SLA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>99</fme:DISPLAY>
<fme:EASTING>833619.53596</fme:EASTING>
<fme:NORTHING>820953.01102</fme:NORTHING>
<fme:SYMBOL>183</fme:SYMBOL>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:RULEID>3</fme:RULEID>
<fme:SLOPESIZE>27.27</fme:SLOPESIZE>
<fme:SLOPEANGLE>325.22</fme:SLOPEANGLE>
<fme:SLOPESIZE200>5.454</fme:SLOPESIZE200>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820953.01102 833619.53596 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:Slope>
</gml:featureMember>
</gml:FeatureCollection>
