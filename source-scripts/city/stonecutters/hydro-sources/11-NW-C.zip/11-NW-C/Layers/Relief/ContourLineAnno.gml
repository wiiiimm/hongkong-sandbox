<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme ContourLineAnno.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>819813.14661 831641.62521</gml:lowerCorner>
<gml:upperCorner>820708.39274 833210.68082</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idd08c3443-e52f-46e9-80c8-5167a4d400ae">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>25.7693340068764</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103526</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831638.1863216</fme:EASTING>
<fme:NORTHING>820162.9913137</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820168.04664 831641.62521</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idcf95eea9-284a-4d26-8a60-95055bbfa663">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>13.2985833849093</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103527</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832130.78975195</fme:EASTING>
<fme:NORTHING>820145.00439953</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820149.19785 832135.23915</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id653cbfad-17b5-4de7-9871-2472c0904a30">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>14.2725133750004</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103525</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832618.3445686</fme:EASTING>
<fme:NORTHING>820234.7612241</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820239.02970 832622.72205</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id98bcc716-7722-4171-8350-d98feae12526">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>56.3099877125262</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103522</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832235.56161176</fme:EASTING>
<fme:NORTHING>820392.27023473</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820398.37169 832235.95456</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idebc0c704-0c1f-4d2e-af71-2bf713e9e831">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-28.3792234603428</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103533</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832563.72593218</fme:EASTING>
<fme:NORTHING>819812.97313479</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819813.14661 832569.83757</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id7c0a9f5f-7d0d-47cb-ba11-35dd54e9892d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>5.24713891332442</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103531</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832778.7248695</fme:EASTING>
<fme:NORTHING>819891.0144983</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819894.54342 832783.71776</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id88759030-4df2-477e-b055-53fefc929358">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>30</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-24.3411311400623</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103538</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832131.36207793</fme:EASTING>
<fme:NORTHING>820253.29775652</fme:NORTHING>
<fme:CONTOURHEIGHT>30</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820253.90120 832137.44633</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id8efd98c8-8c63-4f14-ad6e-080d51945ba7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-2.00960484736081</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103529</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832572.86037119</fme:EASTING>
<fme:NORTHING>820048.95254612</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820051.82253 832578.25903</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idde7fd87d-ec2a-4341-b2d6-48f19649d0ca">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-23.4985516360642</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103530</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>832692.1187204</fme:EASTING>
<fme:NORTHING>820027.4584696</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820028.15131 832698.19344</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id1c2f006b-6878-486b-8986-8374074bd9da">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>38.0590332858938</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103528</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>831722.35751828</fme:EASTING>
<fme:NORTHING>820062.93535984</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820068.60682 831724.64155</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idb3507a77-a880-4858-955e-55917ae61ce5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-77.5500034959479</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103532</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832667.4468406</fme:EASTING>
<fme:NORTHING>819833.8927961</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>819829.38178 832671.57394</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id087ec699-e0e7-463d-b900-aa873935859d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103534</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832848.48994651</fme:EASTING>
<fme:NORTHING>820095.13952992</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820093.55762 832854.39586</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id1e16f5f8-d729-41cd-bb29-64cdec44fd59">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-70.4975519263097</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103540</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>831795.00920424</fme:EASTING>
<fme:NORTHING>820147.99437744</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820144.02421 831799.65893</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id8404619e-a31e-42aa-8a16-06e615da6a33">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>17.4298715032286</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103523</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832387.69332528</fme:EASTING>
<fme:NORTHING>820378.88092815</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820383.38403 832391.82907</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id5cb13688-e9b2-44db-a2da-0d3e204fdef5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-2.31467434185593</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103520</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832176.0912712</fme:EASTING>
<fme:NORTHING>820642.11003</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820644.95122 832181.50513</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id33821c4c-b3a0-4152-9a15-ed0d6974086d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-93.6214886328423</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103536</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832395.08895933</fme:EASTING>
<fme:NORTHING>820152.89798045</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820147.42073 832397.80595</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id7b0cc043-3508-45c7-bfdf-bc8e67a55d7c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-59.6567724648952</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103541</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832178.69408899</fme:EASTING>
<fme:NORTHING>820711.41754236</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820708.39274 832184.00755</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id82dba645-3aea-404e-b5a1-6f7e382ac074">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.8871466508804</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103539</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>831979.24158072</fme:EASTING>
<fme:NORTHING>820211.06553341</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260709</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820177.15766 831916.31884</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id128cb15e-6b2d-4f03-b0c0-205ed03b4f50">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>40</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>5.40379867754572</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103537</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832358.91670445</fme:EASTING>
<fme:NORTHING>820203.24002341</fme:NORTHING>
<fme:CONTOURHEIGHT>40</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820206.78258 832363.89992</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id69503948-96ca-4a09-a90f-dc68a638fa22">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-27.4268854382293</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103521</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>832283.4966729</fme:EASTING>
<fme:NORTHING>820513.9048907</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820514.17993 832289.60458</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idd73c3255-7f31-4779-aa81-1fd0037f4b80">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-45.0000767333235</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001103535</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>833204.77490527</fme:EASTING>
<fme:NORTHING>820365.2867556</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820363.70484 833210.68082</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
</gml:FeatureCollection>
