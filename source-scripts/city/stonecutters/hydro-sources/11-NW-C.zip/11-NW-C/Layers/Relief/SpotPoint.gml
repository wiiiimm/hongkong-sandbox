<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme SpotPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>819648.36027 830096.50299 0.00000</gml:lowerCorner>
<gml:upperCorner>820982.72000 833705.01100 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:SpotPoint gml:id="id777297bf-3d6c-4d10-a9dc-46653e6277f1">
<fme:FEATURE_ID>1001130398</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832757.12</fme:EASTING>
<fme:NORTHING>819648.36</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819648.36027 832757.12191 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id89f24287-98d8-4d3e-be13-07d07c4282c7">
<fme:FEATURE_ID>1001130405</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832703.43</fme:EASTING>
<fme:NORTHING>819690.59</fme:NORTHING>
<fme:SPOTHEIGHT>28.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819690.59386 832703.42841 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0efc5182-a3e4-4a48-8b35-797bba4ad95f">
<fme:FEATURE_ID>1001130406</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832535.13</fme:EASTING>
<fme:NORTHING>819804.44</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819804.44160 832535.12865 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb4841838-fd60-461d-96c9-d35206a6cbbd">
<fme:FEATURE_ID>1001130407</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832242.33</fme:EASTING>
<fme:NORTHING>819809.77</fme:NORTHING>
<fme:SPOTHEIGHT>4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819809.76885 832242.32924 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id96201d2a-b630-4acb-9bdc-f5c9446400d9">
<fme:FEATURE_ID>1001130408</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831805.38</fme:EASTING>
<fme:NORTHING>819829.91</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819829.90779 831805.37562 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4411b5fd-c3d5-40ca-b50d-ce197ec7ce10">
<fme:FEATURE_ID>1001130404</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832760.61</fme:EASTING>
<fme:NORTHING>819834.03</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819834.03057 832760.61087 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9ba6ce0e-a98d-4a80-88b9-2198cdf831d8">
<fme:FEATURE_ID>1001130419</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831392.98</fme:EASTING>
<fme:NORTHING>819879.04</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819879.04400 831392.97950 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3da5633f-62be-49ff-8b6b-2964c8a9b5cf">
<fme:FEATURE_ID>1001130399</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832900.45</fme:EASTING>
<fme:NORTHING>819885.53</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819885.53014 832900.44828 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id78a713ad-3088-4887-b695-62256eef1a22">
<fme:FEATURE_ID>1001130379</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832611.3</fme:EASTING>
<fme:NORTHING>819892.04</fme:NORTHING>
<fme:SPOTHEIGHT>46.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819892.04479 832611.29783 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idaf6d2b01-b57b-4fb4-870b-31b55bc4bedb">
<fme:FEATURE_ID>1001130427</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832279.01</fme:EASTING>
<fme:NORTHING>819918.14</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819918.14062 832279.00977 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5b35aa04-3cb7-40fc-bb4c-c96d60b9ae04">
<fme:FEATURE_ID>1001130395</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831598.05</fme:EASTING>
<fme:NORTHING>819946.5</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819946.49590 831598.05134 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id65151dea-4cee-4525-b010-5ca087e191e1">
<fme:FEATURE_ID>1001130438</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832049.02</fme:EASTING>
<fme:NORTHING>819993.74</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>819993.74177 832049.01619 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbe2eaab5-ad0d-4e67-9b08-9fa17b5b2194">
<fme:FEATURE_ID>1001130425</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831080.55</fme:EASTING>
<fme:NORTHING>820014.48</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820014.48166 831080.54679 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0818b686-a892-43c7-a7a6-e547064b2dba">
<fme:FEATURE_ID>1001130374</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832721.82</fme:EASTING>
<fme:NORTHING>820027.29</fme:NORTHING>
<fme:SPOTHEIGHT>54.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820027.28908 832721.81722 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3ac0fe20-791d-4022-9258-e0efb8437994">
<fme:FEATURE_ID>1001130392</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831245.54</fme:EASTING>
<fme:NORTHING>820029.24</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820029.23668 831245.54140 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3e4c69d5-1b52-4a05-b51f-5cd5c3187e7d">
<fme:FEATURE_ID>1001130413</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831875.9</fme:EASTING>
<fme:NORTHING>820033.12</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820033.12026 831875.90219 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2f0f6ece-2b9f-4707-ab22-aa1df585e558">
<fme:FEATURE_ID>1001130416</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832780.49</fme:EASTING>
<fme:NORTHING>820035.69</fme:NORTHING>
<fme:SPOTHEIGHT>33.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820035.69444 832780.48800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id40c90749-fce2-42ef-9a26-3b63a9b27c14">
<fme:FEATURE_ID>1001130391</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832332.15</fme:EASTING>
<fme:NORTHING>820052.96</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820052.95982 832332.14780 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida910cf30-9891-47df-9008-8e51b09783ba">
<fme:FEATURE_ID>1001130403</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832417.03</fme:EASTING>
<fme:NORTHING>820066.18</fme:NORTHING>
<fme:SPOTHEIGHT>6.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820066.17578 832417.03440 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida74b3395-7a13-496e-94e7-60ff96dc76d7">
<fme:FEATURE_ID>1001130378</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832489.12</fme:EASTING>
<fme:NORTHING>820084.24</fme:NORTHING>
<fme:SPOTHEIGHT>43.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820084.23517 832489.11786 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0ab894ee-6bbd-4e1a-887f-06ae32c2e6a5">
<fme:FEATURE_ID>1001130414</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832190.82</fme:EASTING>
<fme:NORTHING>820096.09</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820096.08984 832190.82031 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id586d95b7-34c7-41f3-b5f0-6db16cb2c57a">
<fme:FEATURE_ID>1001130415</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832965.41</fme:EASTING>
<fme:NORTHING>820097.37</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820097.37328 832965.40838 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id153e1eea-1b9c-4ad2-9194-bc6d042fa6eb">
<fme:FEATURE_ID>1001130380</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831647.83</fme:EASTING>
<fme:NORTHING>820109.31</fme:NORTHING>
<fme:SPOTHEIGHT>68.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820109.30575 831647.82607 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb066d5e1-df36-44ea-8f0f-78db447e9523">
<fme:FEATURE_ID>1001130426</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831450.35</fme:EASTING>
<fme:NORTHING>820112.42</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820112.42300 831450.34550 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd13a74df-2691-4233-b75b-4d7f0f347551">
<fme:FEATURE_ID>1001130375</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831753.75</fme:EASTING>
<fme:NORTHING>820117.4</fme:NORTHING>
<fme:SPOTHEIGHT>48.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820117.40381 831753.75089 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id673e40b7-4a12-49c3-afbd-a3c2d730b355">
<fme:FEATURE_ID>1001130377</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832638.82</fme:EASTING>
<fme:NORTHING>820135.58</fme:NORTHING>
<fme:SPOTHEIGHT>36.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820135.58375 832638.81648 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfb937b85-8637-42f1-9d25-917844a737b9">
<fme:FEATURE_ID>1001130423</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831826.33</fme:EASTING>
<fme:NORTHING>820164.89</fme:NORTHING>
<fme:SPOTHEIGHT>40.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820164.88545 831826.33448 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddd4bec48-6220-4f26-82e5-4893fcd418f3">
<fme:FEATURE_ID>1001130390</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833037</fme:EASTING>
<fme:NORTHING>820169.44</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820169.43750 833037.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9eb73038-27ef-42ba-a049-ccf3cc8938d5">
<fme:FEATURE_ID>1001130389</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832435.52</fme:EASTING>
<fme:NORTHING>820172.19</fme:NORTHING>
<fme:SPOTHEIGHT>39.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820172.19422 832435.52289 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida7b210e7-ddc5-470c-a28a-c25a70096ca6">
<fme:FEATURE_ID>1001130428</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832187.27</fme:EASTING>
<fme:NORTHING>820176</fme:NORTHING>
<fme:SPOTHEIGHT>7.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820176.00106 832187.26544 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0ecdfdd4-9d28-40a8-a7c8-37db28ecfc23">
<fme:FEATURE_ID>1001130396</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831989.62</fme:EASTING>
<fme:NORTHING>820185.29</fme:NORTHING>
<fme:SPOTHEIGHT>5.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820185.29438 831989.62086 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id30658609-1a65-446d-ac1d-8375e3c6cc03">
<fme:FEATURE_ID>1210007616</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830951.72</fme:EASTING>
<fme:NORTHING>820208.98</fme:NORTHING>
<fme:SPOTHEIGHT>67.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820208.98400 830951.72100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idade8e94b-1365-4447-bb3f-d69fab656f9d">
<fme:FEATURE_ID>1001130401</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832867.93</fme:EASTING>
<fme:NORTHING>820225.97</fme:NORTHING>
<fme:SPOTHEIGHT>4.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820225.97363 832867.92764 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0479fbe5-f59c-4c50-b0fc-a3a1417ddf08">
<fme:FEATURE_ID>1001130388</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831463.59</fme:EASTING>
<fme:NORTHING>820228.69</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820228.68945 831463.58984 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id23b1345a-c5cd-4d38-8f1f-9c98caa95d0b">
<fme:FEATURE_ID>1001130436</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832554.76</fme:EASTING>
<fme:NORTHING>820232.19</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820232.19114 832554.75642 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id615942d9-ba48-4aed-a8a0-55b4db52fb37">
<fme:FEATURE_ID>1001130424</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831843.74</fme:EASTING>
<fme:NORTHING>820239.92</fme:NORTHING>
<fme:SPOTHEIGHT>58.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820239.92161 831843.73721 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id773152e0-318e-46fb-9489-91883df5e1e0">
<fme:FEATURE_ID>1001130387</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831789.2</fme:EASTING>
<fme:NORTHING>820254.37</fme:NORTHING>
<fme:SPOTHEIGHT>30.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820254.37135 831789.20175 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc37257b9-1d6a-40a0-95de-1ab8a95aeca4">
<fme:FEATURE_ID>1210007610</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831557.23</fme:EASTING>
<fme:NORTHING>820261.26</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820261.26216 831557.22455 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida4488eae-ca21-4bb8-95e6-8db1538ed9db">
<fme:FEATURE_ID>1001130386</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832944.23</fme:EASTING>
<fme:NORTHING>820280.12</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820280.12464 832944.23068 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5112416f-c37a-4655-9417-f954d6714c8f">
<fme:FEATURE_ID>1001130432</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830594.56</fme:EASTING>
<fme:NORTHING>820285.13</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820285.12660 830594.55760 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd6047694-397e-4e78-928e-7092045e4d29">
<fme:FEATURE_ID>1001130402</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833147</fme:EASTING>
<fme:NORTHING>820304.5</fme:NORTHING>
<fme:SPOTHEIGHT>22.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820304.50000 833147.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7ecb0eaa-b6d9-4345-8b0a-5e7cc8053940">
<fme:FEATURE_ID>1001130372</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832272.48</fme:EASTING>
<fme:NORTHING>820366.07</fme:NORTHING>
<fme:SPOTHEIGHT>59</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820366.07449 832272.48485 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id529281c7-841d-40f2-9cdf-707a565bece7">
<fme:FEATURE_ID>1210007611</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831567.65</fme:EASTING>
<fme:NORTHING>820367.34</fme:NORTHING>
<fme:SPOTHEIGHT>47.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820367.33600 831567.64800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd9363706-8004-4064-a0a2-2ffb967d2224">
<fme:FEATURE_ID>1001130373</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833141.87</fme:EASTING>
<fme:NORTHING>820378.49</fme:NORTHING>
<fme:SPOTHEIGHT>31.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820378.48527 833141.87255 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id896ab4aa-9a90-4904-ba4c-a02a8d803e3b">
<fme:FEATURE_ID>1001130385</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832900.77</fme:EASTING>
<fme:NORTHING>820379.98</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820379.97884 832900.76662 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7b96d097-bee2-4fb0-a96d-98157b55511a">
<fme:FEATURE_ID>1001130418</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831770.17</fme:EASTING>
<fme:NORTHING>820389.15</fme:NORTHING>
<fme:SPOTHEIGHT>6.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820389.15042 831770.16860 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6ac36411-d45e-4e27-86ad-a65c6d62cec4">
<fme:FEATURE_ID>1001130410</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831332.91</fme:EASTING>
<fme:NORTHING>820395.6</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820395.59961 831332.91016 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3a6fb5ae-dcf7-4a48-9ad9-0f4025d20022">
<fme:FEATURE_ID>1001130437</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832492.34</fme:EASTING>
<fme:NORTHING>820400.92</fme:NORTHING>
<fme:SPOTHEIGHT>4.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240729</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820400.92141 832492.33497 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6feedc16-13be-4db2-ba37-4c025cd1c1d0">
<fme:FEATURE_ID>1001130384</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832221.26</fme:EASTING>
<fme:NORTHING>820407.38</fme:NORTHING>
<fme:SPOTHEIGHT>40.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820407.37961 832221.26133 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id387d00c1-bc23-4ccd-a225-0bb450c302cf">
<fme:FEATURE_ID>1001130383</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833064.5</fme:EASTING>
<fme:NORTHING>820410.56</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820410.56250 833064.50000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7ba5658b-6524-420f-bf5f-d460450ea904">
<fme:FEATURE_ID>1001130431</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832599.06</fme:EASTING>
<fme:NORTHING>820425.61</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820425.60921 832599.05893 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7ae99531-ec80-4460-86d6-245abf541ea2">
<fme:FEATURE_ID>1001130397</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832009.87</fme:EASTING>
<fme:NORTHING>820427.87</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820427.86824 832009.86873 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1df265bd-f0f1-4d78-a7a7-28d8202b40bb">
<fme:FEATURE_ID>1001130376</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832115</fme:EASTING>
<fme:NORTHING>820435.11</fme:NORTHING>
<fme:SPOTHEIGHT>35.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820435.11271 832115.00122 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddf08711c-4f15-44cd-ac5d-9c500f2d1ba4">
<fme:FEATURE_ID>1001130382</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833010.15</fme:EASTING>
<fme:NORTHING>820449.13</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820449.13355 833010.15385 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide148bb67-fefc-4da3-a4a7-6fc4026683bc">
<fme:FEATURE_ID>1001130381</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832541.41</fme:EASTING>
<fme:NORTHING>820486.4</fme:NORTHING>
<fme:SPOTHEIGHT>5.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820486.40039 832541.41016 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide9eaef37-d51a-4f01-b163-06df76dba4d2">
<fme:FEATURE_ID>1001130409</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830923.83</fme:EASTING>
<fme:NORTHING>820502.55</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820502.55284 830923.82676 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbd8a6c0b-aec0-455e-a83e-bfaed8fa97af">
<fme:FEATURE_ID>1001130394</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832370.14</fme:EASTING>
<fme:NORTHING>820543.96</fme:NORTHING>
<fme:SPOTHEIGHT>4.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820543.96454 832370.13812 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id473b932d-08be-4a6c-8468-80a13a4485c0">
<fme:FEATURE_ID>1210007615</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831931.1</fme:EASTING>
<fme:NORTHING>820579.98</fme:NORTHING>
<fme:SPOTHEIGHT>19</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820579.98200 831931.10000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id868b4482-660d-4e9e-a496-ad340a7e293e">
<fme:FEATURE_ID>1001130421</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832580.61</fme:EASTING>
<fme:NORTHING>820592.11</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820592.11301 832580.61300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5fa9e795-3094-49f7-81c0-c2e10ecf8862">
<fme:FEATURE_ID>1001130371</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832189.67</fme:EASTING>
<fme:NORTHING>820609.23</fme:NORTHING>
<fme:SPOTHEIGHT>44.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820609.22728 832189.67079 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id149e581e-9e64-4edc-8be5-6ce389c0200a">
<fme:FEATURE_ID>1210007613</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831865</fme:EASTING>
<fme:NORTHING>820612.28</fme:NORTHING>
<fme:SPOTHEIGHT>32.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820612.27800 831865.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide84715b7-5d49-4ca1-a1de-87aca2229685">
<fme:FEATURE_ID>1210007612</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831960.26</fme:EASTING>
<fme:NORTHING>820651.81</fme:NORTHING>
<fme:SPOTHEIGHT>31.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820651.80700 831960.25900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd655d798-e05f-43f7-b817-cf244b3dd283">
<fme:FEATURE_ID>1001130400</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832096.75</fme:EASTING>
<fme:NORTHING>820651.94</fme:NORTHING>
<fme:SPOTHEIGHT>3.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820651.93677 832096.75092 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8dee5aee-2de1-4794-94f8-56fe3cb8d6d6">
<fme:FEATURE_ID>1001130411</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831413.9</fme:EASTING>
<fme:NORTHING>820681.38</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820681.38086 831413.90039 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id64ee22a2-c325-4452-a902-53aa4b4ed826">
<fme:FEATURE_ID>1001130422</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832185.89</fme:EASTING>
<fme:NORTHING>820693.35</fme:NORTHING>
<fme:SPOTHEIGHT>11.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820693.35405 832185.89068 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd920c851-5b01-4642-959a-88ed4eeca4c9">
<fme:FEATURE_ID>1001130412</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>831781.88</fme:EASTING>
<fme:NORTHING>820695.1</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820695.10081 831781.88059 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6fd80dab-e00e-4d86-8c5d-e4894431ea5c">
<fme:FEATURE_ID>1210007617</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830233.75</fme:EASTING>
<fme:NORTHING>820746.75</fme:NORTHING>
<fme:SPOTHEIGHT>87.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820746.74799 830233.74903 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id39904de2-be33-416e-94fe-181ab6d2b6f6">
<fme:FEATURE_ID>1001130430</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832618.11</fme:EASTING>
<fme:NORTHING>820784.68</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820784.68235 832618.10584 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2271e3e6-9a20-4540-b1bb-d181d53f619c">
<fme:FEATURE_ID>1001130435</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833669.75</fme:EASTING>
<fme:NORTHING>820818.98</fme:NORTHING>
<fme:SPOTHEIGHT>5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820818.98400 833669.75100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5b50af83-b675-4e36-89a3-7d40d7f3ed3a">
<fme:FEATURE_ID>1001130393</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832374.25</fme:EASTING>
<fme:NORTHING>820826.01</fme:NORTHING>
<fme:SPOTHEIGHT>5.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820826.00520 832374.24630 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd3585609-f660-4169-a27b-59745cbf55f1">
<fme:FEATURE_ID>1001130433</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833705.01</fme:EASTING>
<fme:NORTHING>820890.39</fme:NORTHING>
<fme:SPOTHEIGHT>10.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820890.39200 833705.01100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id10853996-5d7d-4179-8fea-de85d8a401bb">
<fme:FEATURE_ID>1210007614</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832275.45</fme:EASTING>
<fme:NORTHING>820892.5</fme:NORTHING>
<fme:SPOTHEIGHT>26.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820892.50000 832275.44800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb91dcb87-dd6a-4d9b-95ed-0fc8e64daf8f">
<fme:FEATURE_ID>1210007618</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>830096.5</fme:EASTING>
<fme:NORTHING>820903.33</fme:NORTHING>
<fme:SPOTHEIGHT>85.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820903.32501 830096.50299 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbbe67c97-cac8-460d-ad2f-9819c608b8be">
<fme:FEATURE_ID>1210007270</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>833523.04</fme:EASTING>
<fme:NORTHING>820907.78</fme:NORTHING>
<fme:SPOTHEIGHT>6.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820907.78087 833523.03526 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf0d69eb4-b7db-4453-b8b0-f5a5069f5024">
<fme:FEATURE_ID>1001130420</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832013.41</fme:EASTING>
<fme:NORTHING>820968.17</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820968.16992 832013.41016 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddd1d289a-1176-48bb-a087-48675f629688">
<fme:FEATURE_ID>1001130429</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>832647.47</fme:EASTING>
<fme:NORTHING>820982.72</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>F</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820982.72000 832647.47000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
</gml:FeatureCollection>
