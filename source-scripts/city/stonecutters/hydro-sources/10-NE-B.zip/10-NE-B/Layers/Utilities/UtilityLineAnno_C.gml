<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityLineAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821019.27423 826863.79078</gml:lowerCorner>
<gml:upperCorner>823193.60417 829136.47475</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id966f58b9-5c19-40d0-8e19-f9b19807bc70">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>81.3136320120238</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162349</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>826865.27497263</fme:EASTING>
<fme:NORTHING>822746.175028</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822755.43974 826863.79078</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id184a1db7-f5b4-45f9-9756-9d5ac1778d9d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-62.7983567823818</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162356</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>828452.146</fme:EASTING>
<fme:NORTHING>821183.652</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821183.96886 828452.22290</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id5cf9d6ce-f46a-46dd-a720-1d918adb1e8c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>28.4570076545521</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162352</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827530.06944754</fme:EASTING>
<fme:NORTHING>822441.29036817</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822448.06760 827536.55843</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id330a5255-7c8d-4584-941d-7d7c0ade1c9e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.044786839184</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162347</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>828951.84404826</fme:EASTING>
<fme:NORTHING>821092.73175901</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821093.61743 828968.49460</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id5cdd6094-b6bd-48da-acca-978a45c89f6a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-82.5364949127139</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162348</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>828635.0672684</fme:EASTING>
<fme:NORTHING>821200.70194833</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821172.46225 828638.76680</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id74852db6-14b2-4797-a73d-f91259703fa3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-47.895939424443</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162351</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>829136.482</fme:EASTING>
<fme:NORTHING>821249.724</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821250.05039 829136.47475</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id9df54bb3-04af-41c5-933d-5962e848ca0a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-56.4087150290625</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162354</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827392.46924909</fme:EASTING>
<fme:NORTHING>822698.2590069</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822692.40257 827399.80000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="ideef69030-cd9e-4d8d-8ad0-d116472194b1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>20.1125524845816</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162350</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827205.76697015</fme:EASTING>
<fme:NORTHING>822250.82280567</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822260.75644 827232.89346</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id299558cf-b2d4-4c54-b50e-fbc7490af834">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-8.76905584913413</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162353</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>826854.81892826</fme:EASTING>
<fme:NORTHING>823192.13334462</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823193.60417 826864.08578</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id688a77ad-8564-4820-8af9-cd78ae5230af">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-7.76515972830521</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162357</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827044.69837379</fme:EASTING>
<fme:NORTHING>822878.76044962</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822880.39341 827053.93803</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="idb1aea62c-c34c-46a3-94ba-d8b1a137c35f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>81.3843443427199</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162358</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827246.41758027</fme:EASTING>
<fme:NORTHING>822799.44889349</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822808.71176 827244.92195</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id165f5bf8-4776-4f66-921d-93113503f859">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.8489822747881</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162359</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827101.89662684</fme:EASTING>
<fme:NORTHING>822721.4240662</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822730.64569 827100.16473</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id8d434171-0891-4fad-b985-3b358ad33e69">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>81.4444471399642</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162360</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827240.44701909</fme:EASTING>
<fme:NORTHING>822706.18121378</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822715.44251 827238.94168</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id602f3176-7060-421b-aaa2-215fe0da16f7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.818452983824438</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162355</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827640.82278104</fme:EASTING>
<fme:NORTHING>821016.28051885</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821019.27423 827649.71522</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
