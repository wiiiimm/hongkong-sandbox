<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityPolyAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821013.26318 826462.57191</gml:lowerCorner>
<gml:upperCorner>823648.72912 829187.24449</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="idf29a89ef-bd3a-4be8-a115-2c83517a945c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310000482</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>826842.135</fme:EASTING>
<fme:NORTHING>823323.497</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823323.49658 826842.13520</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id17cbaee3-119b-489b-b23f-25c560455fd1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173865</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>827019.069</fme:EASTING>
<fme:NORTHING>822845.301</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822845.30101 827019.06928</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id5c187d3e-59fe-4eb4-91fa-3826ff229d25">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-7.79891936361299</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173869</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>827006.7395691</fme:EASTING>
<fme:NORTHING>822929.57709943</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822929.46774 827030.07009</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="idfeda7fed-3bff-4742-83d3-b5f75438a0f5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173868</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>826858.35717499</fme:EASTING>
<fme:NORTHING>823233.64702505</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823236.70456 826881.48672</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="iddd4a78cf-653e-47d1-b0ab-61d0297c77d2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173870</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>827309.2751204</fme:EASTING>
<fme:NORTHING>822772.74897604</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822775.80651 827332.40467</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id3048a99d-5128-4dde-9326-5163edd5dd5d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173862</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>826452.08803274</fme:EASTING>
<fme:NORTHING>823645.67160404</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823648.72912 826462.57191</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="idf16f4f52-da1b-415f-94b3-7fce6e26947c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173867</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>828384.35991744</fme:EASTING>
<fme:NORTHING>821074.69341719</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821074.69342 828402.73423</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id6bd9bcdc-44bd-45d1-b64a-11cfe66b25b3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173866</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>828618.18777263</fme:EASTING>
<fme:NORTHING>821071.21321852</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821074.27075 828641.31732</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id1ca6aa38-64ae-495e-abf3-203929f0a0f0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173861</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>828968.09266501</fme:EASTING>
<fme:NORTHING>821393.85940449</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821396.91692 828978.57655</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="idab5b6118-4356-4ed5-b12e-98e116b37568">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173860</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>828900.19194529</fme:EASTING>
<fme:NORTHING>821126.151256</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821129.20878 828910.67583</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id5e9a9ccb-b1eb-4fa0-9c7b-935745ca648a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173871</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>828941.07663312</fme:EASTING>
<fme:NORTHING>821029.40542207</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821032.46295 828964.20618</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="ide29f2d33-db58-4e28-b55e-e802faeed433">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173864</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>827759.21166127</fme:EASTING>
<fme:NORTHING>821010.20564552</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821013.26318 827782.34121</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id102fd233-8b04-4b8c-aedc-2815a6e511d1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173872</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>829164.11493945</fme:EASTING>
<fme:NORTHING>821018.3750062</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821021.43254 829187.24449</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="idcad56626-b3f8-4060-896f-e79dafb8f283">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Gas Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173863</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>827668.15091227</fme:EASTING>
<fme:NORTHING>821011.22762412</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821014.28515 827690.39981</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
