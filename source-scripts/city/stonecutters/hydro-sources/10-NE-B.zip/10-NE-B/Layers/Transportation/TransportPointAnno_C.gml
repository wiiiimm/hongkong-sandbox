<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821049.07746 826405.92055</gml:lowerCorner>
<gml:upperCorner>823988.34320 829882.93451</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id055749b3-2e46-4a86-aef9-72d34eb26bfd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長隆街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>22.0112787707056</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000091</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829399.032</fme:EASTING>
<fme:NORTHING>823500.085</fme:NORTHING>
<fme:ST_CODE>10199</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002769</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823500.08454 829399.03214</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id29940e58-7c6e-49e1-b63e-66f60c03d622">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青葵公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000022</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829619.58860037</fme:EASTING>
<fme:NORTHING>823320.74942438</fme:NORTHING>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002891</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823327.28254 829646.69688</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id748323ba-5851-4c35-9fb9-66bd278b7ad8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長青橋</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.6559862171161</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000302</fme:FEATURE_ID>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:EASTING>829707.65497896</fme:EASTING>
<fme:NORTHING>823379.05426274</fme:NORTHING>
<fme:ST_CODE>39484</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002868</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823388.78919 829732.17259</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id7f44ca51-2e14-4b5a-b473-d98198a08fce">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>66.1940561975064</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000351</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829241.40313916</fme:EASTING>
<fme:NORTHING>822075.14261982</fme:NORTHING>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003025</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822091.82540 829245.00367</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id749402fc-6ad6-4964-8607-bf3c0998df79">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵青橋</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>15.4612138833585</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000477</fme:FEATURE_ID>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:EASTING>829748.30172427</fme:EASTING>
<fme:NORTHING>823259.30714328</fme:NORTHING>
<fme:ST_CODE>39486</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003111</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823265.82935 829761.12983</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id08916033-40fa-4319-a797-69323fa383e8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>涌美路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-3.69139103020173</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000502</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828625.26469032</fme:EASTING>
<fme:NORTHING>823537.10320598</fme:NORTHING>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002792</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823535.69030 828647.16476</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id382e784b-5ce3-4361-ac34-0f2d57adee62">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青強街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-63.0838577867181</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000584</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827471.9</fme:EASTING>
<fme:NORTHING>821447.709</fme:NORTHING>
<fme:ST_CODE>12425</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003029</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821447.68121 827471.91426</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id3698056c-cee9-4531-a942-5e9180051e60">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>寮肚路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000605</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828122.7049095</fme:EASTING>
<fme:NORTHING>823756.87048482</fme:NORTHING>
<fme:ST_CODE>11243</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002797</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823745.33520 828133.55666</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idbe7c4dec-58e0-4a8e-944e-e1385590324c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長青公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000939</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>826980.2361629</fme:EASTING>
<fme:NORTHING>823438.06813949</fme:NORTHING>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001078</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823537.77208 826979.15097</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id59bc364a-47df-4235-8719-47e1aca5528e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣鄉事會路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-52.7146591530592</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000970</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829142.02512101</fme:EASTING>
<fme:NORTHING>823625.78834614</fme:NORTHING>
<fme:ST_CODE>12448</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003181</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823588.86939 829170.13491</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id8d1b956f-9902-433d-b070-dd026356decf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青鴻路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-25.253175419374</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001793</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829213.94757219</fme:EASTING>
<fme:NORTHING>822240.93502128</fme:NORTHING>
<fme:ST_CODE>14168</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002893</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822237.54113 829227.86145</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idc59a6a54-6867-4fe2-b89b-c3cb7044cca1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002125</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827493.39755044</fme:EASTING>
<fme:NORTHING>821571.55494552</fme:NORTHING>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002717</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821589.35642 827490.47816</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idf01db535-e5fb-41ca-a990-9fbc13f41feb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青尚里</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-85.2001660486591</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001502</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829366.729</fme:EASTING>
<fme:NORTHING>821048.295</fme:NORTHING>
<fme:ST_CODE>14222</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003183</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821049.07746 829366.87802</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idf8bda8e0-6c42-4c54-b8b3-b07edf0b25b8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-28.4052484347413</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002179</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828683.82134458</fme:EASTING>
<fme:NORTHING>821261.3302966</fme:NORTHING>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002761</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821256.40362 828700.16167</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idbd8c0c80-4b6f-4c6c-9f5a-1295299cbbe2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>南灣隧道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.7592947191766</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001567</fme:FEATURE_ID>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:EASTING>828559.49365149</fme:EASTING>
<fme:NORTHING>822109.91026639</fme:NORTHING>
<fme:ST_CODE>39536</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002806</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822099.04521 828579.78636</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id6d1620eb-19ba-48fc-83ec-4fc1fb1c0ea7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青康路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-1.45865748757679</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001921</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828436.84268761</fme:EASTING>
<fme:NORTHING>823374.33683626</fme:NORTHING>
<fme:ST_CODE>10248</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003109</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823373.67933 828462.66417</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id85dbe846-a361-4aff-bfcc-b6912b35caf2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長環街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.2236660814327</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001278</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829334.43442066</fme:EASTING>
<fme:NORTHING>823625.46026357</fme:NORTHING>
<fme:ST_CODE>10216</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002633</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823631.24233 829349.32323</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idbf6df60f-18a5-4e43-9151-e09e2210f0b6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青沙公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-43.4506163483895</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001293</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827192.997</fme:EASTING>
<fme:NORTHING>823053.304</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002431</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823053.37241 827193.35919</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb129f942-50ee-4d74-966b-9dc9f911bfd8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青沙公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001000021173</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001950</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829269.74</fme:EASTING>
<fme:NORTHING>822524.883</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210015920</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822525.19298 829270.54263</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id32f6dfd3-c0d8-4f52-9a69-ca8c7c76eb3f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長好街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-56.1797947127195</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001305</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829259.99558338</fme:EASTING>
<fme:NORTHING>823564.44313222</fme:NORTHING>
<fme:ST_CODE>10192</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002621</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823554.24165 829270.28028</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id661981a9-9976-4b4e-878d-41331edf03fd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣西路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.6863841785975</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001980</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828226.02904996</fme:EASTING>
<fme:NORTHING>823802.84180357</fme:NORTHING>
<fme:ST_CODE>12450</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002616</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823825.28959 828235.24179</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id908d205c-ecd7-4593-91ac-220380c16faa">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青高路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>43.9860179020465</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001688</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829215.25040416</fme:EASTING>
<fme:NORTHING>821164.65566589</fme:NORTHING>
<fme:ST_CODE>14198</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003024</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821176.30382 829223.19095</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ide6d7852a-60ed-467b-bba1-de9fc8b4fe4b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣西北交匯處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003756</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>826848.44189004</fme:EASTING>
<fme:NORTHING>823742.32618892</fme:NORTHING>
<fme:ST_CODE>13786</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003154</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823742.32619 826888.39472</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idcc229a19-db46-47f2-9f7f-8d07fed4a3f7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青尚路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-51.8366207984173</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003123</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829074.25958236</fme:EASTING>
<fme:NORTHING>821163.19715333</fme:NORTHING>
<fme:ST_CODE>13716</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002850</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821152.15827 829081.85172</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id78c3cf99-bd06-46fe-9455-1ad89963f639">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青芊街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003198</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828327.68111486</fme:EASTING>
<fme:NORTHING>823303.72529193</fme:NORTHING>
<fme:ST_CODE>12414</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001079</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823303.26490 828342.60698</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id0424d4df-16e8-4718-ace4-e0596c41b683">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>下高灘街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>73.3365229279098</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002534</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829037.35976544</fme:EASTING>
<fme:NORTHING>823480.29652158</fme:NORTHING>
<fme:ST_CODE>10633</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002852</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823498.36527 829042.76810</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb4d20506-2a3a-4e8f-97d6-fca69d8a6d92">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>細山路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-43.152406942184</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003233</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829006.90998003</fme:EASTING>
<fme:NORTHING>822735.36030791</fme:NORTHING>
<fme:ST_CODE>11851</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014514</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822724.97706 829017.98544</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb57e5086-4396-41b6-8224-f98a45b1e920">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青敬路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-85.5978464401075</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003248</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829065.57072616</fme:EASTING>
<fme:NORTHING>823952.64393863</fme:NORTHING>
<fme:ST_CODE>12426</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003114</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823931.24004 829067.21848</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id38419b4e-25a0-482d-9443-4bcc28f0774f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣西路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>70.0375219715552</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002934</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827921.73351302</fme:EASTING>
<fme:NORTHING>822401.45214613</fme:NORTHING>
<fme:ST_CODE>12450</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000213</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822425.27736 827930.38751</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id5238b264-4fc4-4319-8321-ebf3fb6bc51a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>楓樹窩路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002940</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828589.68200341</fme:EASTING>
<fme:NORTHING>823864.71990959</fme:NORTHING>
<fme:ST_CODE>10582</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003185</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823840.57552 828592.15540</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ida379134b-fe9d-4839-bd9d-08125e7998e8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長青隧道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>1.8125435307368</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002957</fme:FEATURE_ID>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:EASTING>828403.65960412</fme:EASTING>
<fme:NORTHING>822877.41820631</fme:NORTHING>
<fme:ST_CODE>13784</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006706</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822881.57100 828426.14063</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idf3ab2727-2a84-4a7b-9f3d-9d6b84575f43">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青南街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-54.4623129080844</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003288</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827830.36699399</fme:EASTING>
<fme:NORTHING>821278.06784715</fme:NORTHING>
<fme:ST_CODE>12433</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002716</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821268.44116 827840.76571</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id0d0b6728-01d2-45d1-a06b-155d422dfc10">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣交匯處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003614</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829387.522</fme:EASTING>
<fme:NORTHING>823146.151</fme:NORTHING>
<fme:ST_CODE>14092</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001050</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823146.36429 829387.51284</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id903ebdf9-a74a-41d2-b2f4-a5f32b0af679">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣航運路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-86.7060347757537</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002970</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829438.7410322</fme:EASTING>
<fme:NORTHING>822090.40865998</fme:NORTHING>
<fme:ST_CODE>14171</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003028</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822061.86137 829443.82938</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idcf6a9fb1-59d9-412f-a52d-161b45f54afc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青沙公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001000021173</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.07938610486</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003332</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829353.167</fme:EASTING>
<fme:NORTHING>821496.336</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003014</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821496.42593 829353.52506</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9e1044bb-dd43-4347-b0ff-f0d1d76644a0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>清梅街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-12.5288096035212</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003640</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827797.82941788</fme:EASTING>
<fme:NORTHING>822488.0205994</fme:NORTHING>
<fme:ST_CODE>13036</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003116</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822487.73744 827812.31702</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id1ffdeced-ddb7-4957-919a-4a8b0dc59e63">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵裕里</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-53.1300946543692</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003641</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829872.12163463</fme:EASTING>
<fme:NORTHING>823605.58601898</fme:NORTHING>
<fme:ST_CODE>13992</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001038</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823595.94616 829882.93451</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id986d06f6-fef5-4048-80e4-746d3e5634d6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青嶼幹線</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>16.8211654053386</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005009</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>826380.19692369</fme:EASTING>
<fme:NORTHING>823780.74167658</fme:NORTHING>
<fme:ST_CODE>13782</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210012983</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823789.27328 826405.92055</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idefabd6f7-a886-40a6-a002-6fa5c8eb7c8d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>清譽街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>4.01416868583476</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004694</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828542.138</fme:EASTING>
<fme:NORTHING>823988.109</fme:NORTHING>
<fme:ST_CODE>12453</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001084</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823988.34320 828542.42242</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id9a2ecf87-eaba-4295-aae0-48a651d8e4ac">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西草灣路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-14.8336730925809</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005063</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827600.541</fme:EASTING>
<fme:NORTHING>822695.52</fme:NORTHING>
<fme:ST_CODE>11854</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003110</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822695.69851 827600.70240</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id6b63a55f-b3d9-4984-b201-ebe0b53ab15f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>清心街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>18.0853264161281</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005074</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828468.66427779</fme:EASTING>
<fme:NORTHING>823735.08026876</fme:NORTHING>
<fme:ST_CODE>12439</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002771</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823742.18706 828481.19290</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id255564e0-3a7b-4e9a-8ba1-26f016611f24">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長達路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.6293716450762</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004160</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829318.87795291</fme:EASTING>
<fme:NORTHING>823582.51386578</fme:NORTHING>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001086</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823568.31623 829324.43355</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idf79b2d01-efa6-496d-bba2-a8578623e285">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青綠街</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004165</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828758.17984391</fme:EASTING>
<fme:NORTHING>823837.61966514</fme:NORTHING>
<fme:ST_CODE>12429</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001080</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823822.85076 828762.68826</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ideddf32b8-302c-4e2f-86e7-8998e6a5f25d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003842</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829302.81408005</fme:EASTING>
<fme:NORTHING>822819.81249723</fme:NORTHING>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001034</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822832.27751 829318.84566</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idc0309edb-bd07-4283-b77c-115ca1e365d3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>楓樹窩路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004865</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829164.03884415</fme:EASTING>
<fme:NORTHING>823775.20128157</fme:NORTHING>
<fme:ST_CODE>10582</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001085</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823778.62222 829188.83347</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id8702710c-0918-442b-9640-6e0dda65eb6b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>葵青路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>15.7420399051809</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004868</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829632.35122945</fme:EASTING>
<fme:NORTHING>823247.26913569</fme:NORTHING>
<fme:ST_CODE>11101</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001083</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823253.50173 829648.19108</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idfd262f99-b2f3-4d2a-b4be-3f4c8261d979">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長輝路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.4523615948997</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003967</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829459.54090017</fme:EASTING>
<fme:NORTHING>823491.4922237</fme:NORTHING>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001051</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823478.58404 829465.43646</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id78cca922-2492-4d94-a363-b836c6509760">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣航運路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-40.2805026927212</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003981</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829771.403</fme:EASTING>
<fme:NORTHING>821096.678</fme:NORTHING>
<fme:ST_CODE>14171</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001035</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821096.51885 829771.92147</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="ide71342b0-5a42-4575-9050-3e4a68a1dff0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長輝路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>86.0307276405709</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005142</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829572.66779403</fme:EASTING>
<fme:NORTHING>823017.97039407</fme:NORTHING>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002773</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823032.32556 829570.79059</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id97d7c6e6-b957-48d2-90d9-99470549de89">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣大橋</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>15.9554135400528</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005296</fme:FEATURE_ID>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:EASTING>829693.25</fme:EASTING>
<fme:NORTHING>823282.039</fme:NORTHING>
<fme:ST_CODE>39485</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002765</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823282.03869 829693.25021</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idd71c5878-5bdf-438f-ad6f-a1dc3c918ac2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青沙公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.7581842592922</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011546</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827613.856</fme:EASTING>
<fme:NORTHING>822782.12</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002707</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822782.21163 827614.21355</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id19dc303a-c181-489b-86e2-c2f615fa835d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長青公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-27.7674823978674</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011547</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827286.907</fme:EASTING>
<fme:NORTHING>822953.591</fme:NORTHING>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003243</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822953.80407 827287.14442</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="id23053889-5e55-4022-b249-5f590a955bb9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長青公路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-1.04638115034934</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011548</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827757.76</fme:EASTING>
<fme:NORTHING>822873.597</fme:NORTHING>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003241</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822873.89356 827757.87632</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_C gml:id="idb497592e-a202-4cea-b540-d2df82e35387">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>道路</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>5.27389449168337</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000700</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827879.802</fme:EASTING>
<fme:NORTHING>821378.887</fme:NORTHING>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210002906</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821379.11086 827879.90074</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
