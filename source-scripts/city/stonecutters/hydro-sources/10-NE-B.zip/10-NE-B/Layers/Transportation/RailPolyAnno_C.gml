<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme RailPolyAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>823946.10276 827029.01983</gml:lowerCorner>
<gml:upperCorner>823946.10276 827029.01983</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:RailPolyAnno_C gml:id="iddc24093c-ab6c-443f-aa46-a114ea048438">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>港鐵（機場快綫及東涌綫）隧道</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>16.6664558534919</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162314</fme:FEATURE_ID>
<fme:FEATURECODE>RTN</fme:FEATURECODE>
<fme:EASTING>826957.24434194</fme:EASTING>
<fme:NORTHING>823921.02439042</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823946.10276 827029.01983</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:RailPolyAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
