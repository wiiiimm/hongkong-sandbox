<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme RailPoly.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>823709.93750 826250.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>824000.00000 827178.59374 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:RailPoly gml:id="idb3caf7b6-2d97-48e6-aaaf-dcae744f4c38">
<fme:FEATURE_ID>1001162310</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RTN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>UG</fme:DATALEVEL>
<fme:EASTING>827729.82</fme:EASTING>
<fme:NORTHING>824218.66</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:multiSurfaceProperty>
<gml:MultiSurface srsName="EPSG:2326" srsDimension="3">
<gml:surfaceMember>
<gml:Surface>
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823939.72376 826927.12381 0.00000 823933.20015 826906.93148 0.00000 823935.52381 826905.58044 0.00000 823942.11382 826926.08198 0.00000 823988.28218 827080.14658 0.00000 824000.00000 827117.62782 0.00000 824000.00000 827126.17410 0.00000 823985.89212 827081.18840 0.00000 823939.72376 826927.12381 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceMember>
<gml:surfaceMember>
<gml:Surface>
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823956.28161 827034.55663 0.00000 823920.93811 826914.35122 0.00000 823923.31075 826912.92342 0.00000 823958.77301 827033.81294 0.00000 824000.00000 827169.64174 0.00000 824000.00000 827178.59374 0.00000 823956.28161 827034.55663 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceMember>
</gml:MultiSurface>
</gml:multiSurfaceProperty>
</fme:RailPoly>
</gml:featureMember>
<gml:featureMember>
<fme:RailPoly gml:id="idb1bea1ed-aa4e-46e7-9659-21fd8046e214">
<fme:FEATURE_ID>1001162289</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>US</fme:DATALEVEL>
<fme:EASTING>824972.28</fme:EASTING>
<fme:NORTHING>823349.31</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>K</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>823777.56250 826470.56250 0.00000 823763.18750 826417.87500 0.00000 823758.68750 826401.50000 0.00000 823745.93750 826354.68750 0.00000 823740.81250 826336.43750 0.00000 823733.06250 826328.31250 0.00000 823732.93750 826328.06250 0.00000 823709.93750 826250.00000 0.00000 823752.68750 826250.00000 0.00000 823772.56250 826315.87500 0.00000 823772.75000 826316.43750 0.00000 823770.81250 826327.75000 0.00000 823776.43750 826345.62500 0.00000 823791.81250 826392.37500 0.00000 823796.75000 826407.37500 0.00000 823814.75000 826462.25000 0.00000 823819.00000 826474.75000 0.00000 823825.12500 826490.56250 0.00000 823828.68750 826498.81250 0.00000 823835.18750 826512.68750 0.00000 823845.43750 826532.18750 0.00000 823795.62500 826546.93750 0.00000 823793.75000 826535.12500 0.00000 823791.81250 826525.12500 0.00000 823786.87500 826504.75000 0.00000 823781.56250 826485.31250 0.00000 823777.56250 826470.56250 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:RailPoly>
</gml:featureMember>
</gml:FeatureCollection>
