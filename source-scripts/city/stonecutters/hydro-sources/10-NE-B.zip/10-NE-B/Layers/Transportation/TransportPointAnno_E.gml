<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821111.34990 826410.75960</gml:lowerCorner>
<gml:upperCorner>823983.47643 829969.25022</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idfa375854-0035-43ab-b802-646f3b6a502d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI TAI RD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000006</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829941.25428867</fme:EASTING>
<fme:NORTHING>823426.09149121</fme:NORTHING>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002774</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823425.89598 829969.25022</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id635862a0-e5f6-4a2b-89f2-2dba7b4d371e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING MUI ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-12.5152074520756</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000011</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827832.25173727</fme:EASTING>
<fme:NORTHING>822479.74254029</fme:NORTHING>
<fme:ST_CODE>13036</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003116</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822474.95304 827867.93826</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id31dbbe6e-92f9-4b95-a3b5-a6ce6b8c70bc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI
INTERCHANGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000027</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829387.755</fme:EASTING>
<fme:NORTHING>823130.616</fme:NORTHING>
<fme:ST_CODE>14092</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001050</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823130.57722 829387.75535</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ide6bdb4ae-766f-4b61-bdb7-0eb1c23409d6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-66.5476653000678</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000148</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827498.94167081</fme:EASTING>
<fme:NORTHING>821497.58320408</fme:NORTHING>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002717</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821455.69627 827521.11262</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id51ce5f94-f1a3-49df-aa10-9389cf2bd3ed">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING KO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>41.4076664188065</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000276</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829273.9873087</fme:EASTING>
<fme:NORTHING>821219.64735967</fme:NORTHING>
<fme:ST_CODE>14198</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003024</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821249.49494 829303.21089</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idb65f41c9-0512-41f5-8dcf-116d6dcfdb9a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI TSING BRIDGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>15.5809952549091</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000318</fme:FEATURE_ID>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:EASTING>829720.14915045</fme:EASTING>
<fme:NORTHING>823237.28178658</fme:NORTHING>
<fme:ST_CODE>39486</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003111</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823255.85634 829772.75854</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id853e6bfd-4bed-4f67-9dca-22d6174d2308">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI YUE LANE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000337</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829904.06335437</fme:EASTING>
<fme:NORTHING>823578.79618955</fme:NORTHING>
<fme:ST_CODE>13992</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001038</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823591.70624 829942.03400</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc3264d68-dad2-47ae-90c2-98aab5d13d16">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING TIM ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.8999950074336</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000338</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827503.446</fme:EASTING>
<fme:NORTHING>822656.22</fme:NORTHING>
<fme:ST_CODE>12441</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002767</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822656.21991 827503.44637</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id9774933f-249c-451f-ae66-420d2a79c790">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING KWAI HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.8014161960978</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000364</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829692.77259579</fme:EASTING>
<fme:NORTHING>823346.02145433</fme:NORTHING>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002891</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823375.23260 829765.80046</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id94102029-1880-455e-9727-89e767bb6511">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000488</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828851.60763397</fme:EASTING>
<fme:NORTHING>821214.95943242</fme:NORTHING>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002849</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821231.26223 828894.12372</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id7077d127-f5af-42d6-8806-841e0f219fb0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING KEUNG STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000576</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827506.24501149</fme:EASTING>
<fme:NORTHING>821364.56720603</fme:NORTHING>
<fme:ST_CODE>12425</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003029</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821291.54074 827517.32997</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id8675567e-5198-4293-8d8b-4306985eb66f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI ROAD WEST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>67.9464977439659</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000652</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828117.97548994</fme:EASTING>
<fme:NORTHING>823523.92430818</fme:NORTHING>
<fme:ST_CODE>12450</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003211</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823587.87507 828139.92409</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc0edff78-ebfe-4299-b0eb-4a8246f2b13f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG FAI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.6191904875785</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000761</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829479.33459628</fme:EASTING>
<fme:NORTHING>823446.87977473</fme:NORTHING>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001051</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823398.88675 829501.08582</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ide6f55dca-50aa-463b-82d7-876a382d8c1c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>NAM WAN TUNNEL</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-37.2018039402234</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001434</fme:FEATURE_ID>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:EASTING>828509.77718953</fme:EASTING>
<fme:NORTHING>822104.88419517</fme:NORTHING>
<fme:ST_CODE>39536</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002806</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822073.74346 828556.86922</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idb5376f7f-26ff-4d0c-91e8-c55fd631d56a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING SHEUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.77820283157285</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001212</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829379.34767509</fme:EASTING>
<fme:NORTHING>821104.62780014</fme:NORTHING>
<fme:ST_CODE>13716</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002798</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821111.34990 829434.73888</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id94d1290f-a7c3-4830-99d5-d2648724ac75">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING CHIN STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001677</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828560.27547072</fme:EASTING>
<fme:NORTHING>823227.63673472</fme:NORTHING>
<fme:ST_CODE>12414</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002795</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823249.08302 828606.97457</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ida4ef1e9c-eebe-4c80-b363-b61afb4e14cc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING HUNG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>65.8928796691556</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001016</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829129.55832114</fme:EASTING>
<fme:NORTHING>822375.86701681</fme:NORTHING>
<fme:ST_CODE>14168</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002893</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822421.88951 829146.80236</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id595f7705-4eab-4474-9213-737c8923060c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHUNG MEI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001702</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828770.56668374</fme:EASTING>
<fme:NORTHING>823523.18430795</fme:NORTHING>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002792</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823522.31880 828815.45143</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id927407e9-daa8-46e9-8920-850f45c3d33a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG TSING TUNNEL</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001044</fme:FEATURE_ID>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:EASTING>828350.90798186</fme:EASTING>
<fme:NORTHING>822837.83142054</fme:NORTHING>
<fme:ST_CODE>13784</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210016120</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822843.51688 828422.80293</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id52788faf-cd3a-46f0-8ef1-e08dac9f1417">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SHEUNG KO TAN ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001082</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828931.71803974</fme:EASTING>
<fme:NORTHING>823518.12414105</fme:NORTHING>
<fme:ST_CODE>12032</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003184</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823566.43305 828941.63969</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id6e0a0ddf-3af6-45ee-9644-5059b0068a20">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING LUK STREET</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001593</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828799.24792533</fme:EASTING>
<fme:NORTHING>823781.64093275</fme:NORTHING>
<fme:ST_CODE>12429</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001080</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823773.44467 828847.56075</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id9bbc720f-58b1-4d04-84bb-a26d802c3e08">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG TSING HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.73139632907448</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002304</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827732.13600765</fme:EASTING>
<fme:NORTHING>822924.7151464</fme:NORTHING>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002632</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822934.89827 827822.50275</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idb3ce2029-7279-4799-ae11-5ec98abdac6d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG TSING BRIDGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.695110333963</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001922</fme:FEATURE_ID>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:EASTING>829710.52200812</fme:EASTING>
<fme:NORTHING>823327.73014827</fme:NORTHING>
<fme:ST_CODE>39484</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002868</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823341.07061 829744.05344</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id9bce3436-4ca3-46dd-9163-6b76e9045a05">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SAI TSO WAN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>77.3950033799194</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001715</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827744.83767574</fme:EASTING>
<fme:NORTHING>822383.38646107</fme:NORTHING>
<fme:ST_CODE>11854</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002791</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822434.21365 827753.07052</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ida6cf2d47-b3b5-4484-9d1b-993f1a2adf49">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>64.9831100272894</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001952</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829315.04791795</fme:EASTING>
<fme:NORTHING>822241.39025354</fme:NORTHING>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003106</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822285.75939 829331.70462</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id545d3637-d519-4da6-a5df-ca78ffeb3c8e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>NORTH WEST TSING YI
INTERCHANGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001964</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>826815.5000868</fme:EASTING>
<fme:NORTHING>823709.88222691</fme:NORTHING>
<fme:ST_CODE>13786</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003154</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823713.13475 826890.14469</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id28c0f9c6-e01b-4d48-8359-f6b037125c1b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>47.9829347396637</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002202</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829171.672</fme:EASTING>
<fme:NORTHING>822703.428</fme:NORTHING>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002784</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822703.42776 829171.67183</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id33f0d27b-6398-4afb-8e5c-2fb7150004ab">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG TAT ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.5221099342585</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001772</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829377.3691007</fme:EASTING>
<fme:NORTHING>823432.37288038</fme:NORTHING>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001086</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823375.74912 829399.64856</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idc6b9553b-32ae-408a-8ff7-20d7e146d168">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LIU TO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-78.4861708095441</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002011</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828078.45643784</fme:EASTING>
<fme:NORTHING>823941.84304216</fme:NORTHING>
<fme:ST_CODE>11243</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002797</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823909.27369 828088.21126</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id1b645f71-f0c5-4e16-8abd-dfc4db517f34">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>LANTAU LINK</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>15.6848617377825</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002275</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>826366.32086597</fme:EASTING>
<fme:NORTHING>823756.16087734</fme:NORTHING>
<fme:ST_CODE>13782</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210012983</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823768.63938 826410.75960</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ide478b737-aa02-46b2-91a8-780dbf2b6aa9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHING HONG ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-17.4386004865871</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002759</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828797.82260634</fme:EASTING>
<fme:NORTHING>823287.43969239</fme:NORTHING>
<fme:ST_CODE>10248</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000245</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823262.74919 828876.42450</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id3b72ca21-6b01-4f27-8370-901a04ff8015">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SAI SHAN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-42.6359145674403</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002764</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829037.16749045</fme:EASTING>
<fme:NORTHING>822705.96108261</fme:NORTHING>
<fme:ST_CODE>11851</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210014514</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822677.02644 829068.59412</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="idcc38b630-9c0d-41d4-870e-b670d4a496b9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG WAN ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003415</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829212.39983687</fme:EASTING>
<fme:NORTHING>823559.34399863</fme:NORTHING>
<fme:ST_CODE>10216</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210012586</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823586.93775 829254.13731</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id2914dd44-08bf-41e6-93aa-275508bb3815">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING  SHA  HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.0000000021173</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.0011029591098</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003223</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829547.911</fme:EASTING>
<fme:NORTHING>821338.442</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003014</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821338.44214 829547.91070</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id721a6451-9beb-4407-a8cb-9465c5e438aa">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI HONG WAN ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-73.4554836849768</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002807</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829515.75380838</fme:EASTING>
<fme:NORTHING>821754.57247112</fme:NORTHING>
<fme:ST_CODE>14171</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002718</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821674.36658 829543.40717</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id4131f30a-a914-4c5b-85da-031cc8acf3fe">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI ROAD WEST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002860</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828002.781</fme:EASTING>
<fme:NORTHING>822636.77</fme:NORTHING>
<fme:ST_CODE>12450</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000213</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822618.89587 827999.84879</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id7a50dde2-bb53-48be-9118-0a7510b889a8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING SUM ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>22.1113074928164</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002692</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828518.55360125</fme:EASTING>
<fme:NORTHING>823755.07599617</fme:NORTHING>
<fme:ST_CODE>12439</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002766</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823772.05875 828552.23049</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ide693e688-a2d0-4313-b998-698a4fa3e951">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI HEUNG SZE WUI ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002702</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829286.18523791</fme:EASTING>
<fme:NORTHING>823425.51818841</fme:NORTHING>
<fme:ST_CODE>12448</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003115</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823350.86582 829346.96720</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id08b2f783-f43b-4be7-a288-e0e11277ca15">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG TSING HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002727</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827045.60954524</fme:EASTING>
<fme:NORTHING>823340.98405139</fme:NORTHING>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001078</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823200.56724 827079.69941</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id14bd7b6d-fb84-437e-9c83-b1be55681bad">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YU ST</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003699</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828477.314</fme:EASTING>
<fme:NORTHING>823983.601</fme:NORTHING>
<fme:ST_CODE>12453</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002618</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823983.47643 828477.40952</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id09884c5e-5032-49e7-8a81-59f2c031ff22">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>FUNG SHUE WO ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003702</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>828621.43911408</fme:EASTING>
<fme:NORTHING>823762.04782125</fme:NORTHING>
<fme:ST_CODE>10582</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003185</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823721.11970 828680.37042</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id26b6b36b-c3d2-4136-a798-d456440090e0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING  SHA  HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.0000000021173</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003722</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829078.54</fme:EASTING>
<fme:NORTHING>821937.086</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002514</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821937.10831 829078.30960</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id29cbe8b5-7468-4781-bd91-74b7df9798b1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING KING ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003523</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829066.01101507</fme:EASTING>
<fme:NORTHING>823894.04643605</fme:NORTHING>
<fme:ST_CODE>12426</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003114</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823848.86368 829071.41227</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id1c3079d4-92c3-4f25-b1c2-5a3e756a562c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI BRIDGE</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>15.7671862275961</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003576</fme:FEATURE_ID>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:EASTING>829777.34532385</fme:EASTING>
<fme:NORTHING>823302.67088249</fme:NORTHING>
<fme:ST_CODE>39485</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002765</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823314.39254 829818.85954</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="ideaf3671f-133f-4fa2-aeb8-7e1c981fdcb9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KWAI TSING ROAD</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>15.5928078366338</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003580</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>829846.28739166</fme:EASTING>
<fme:NORTHING>823307.60519035</fme:NORTHING>
<fme:ST_CODE>11101</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210001113</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823324.83635 829908.03238</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id74495e3f-e878-42de-863c-2ca39e83e6a1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING SHA HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.3352696390407</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008635</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827664.711</fme:EASTING>
<fme:NORTHING>822772.484</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002525</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822772.48352 827664.71116</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id998bc47e-04ba-4914-8ccf-44f29a5c7f99">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING SHA HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-38.160344656949</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008636</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827615.255</fme:EASTING>
<fme:NORTHING>822757.553</fme:NORTHING>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002707</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822757.55338 827615.25498</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPointAnno_E gml:id="id345bc6d3-7126-4277-b302-b03a93e12341">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHEUNG TSING HIGHWAY</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008637</fme:FEATURE_ID>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:EASTING>827739.599</fme:EASTING>
<fme:NORTHING>822835.557</fme:NORTHING>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003241</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822835.34372 827739.50753</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
