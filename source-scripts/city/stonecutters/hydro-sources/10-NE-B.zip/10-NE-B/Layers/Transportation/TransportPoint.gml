<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme TransportPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821066.22000 826304.01300 0.00000</gml:lowerCorner>
<gml:upperCorner>823983.67100 829971.91900 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:TransportPoint gml:id="idd217899a-f7f9-4a2a-a6a0-c5696c7688b2">
<fme:FEATURE_ID>1210003183</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829363.694</fme:EASTING>
<fme:NORTHING>821066.22</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHEUNG LANE</fme:ENGLISHNAME>
<fme:CHINESENAME>青尚里</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14222</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821066.22000 829363.69400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd6042bc5-2020-4138-b391-0679a5f8ebc4">
<fme:FEATURE_ID>1210002798</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829488.084</fme:EASTING>
<fme:NORTHING>821114.551</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青尚路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13716</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821114.55100 829488.08400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8ee2a9ad-e8b4-4a4f-a9a8-5680194569f5">
<fme:FEATURE_ID>1210003024</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829212.438</fme:EASTING>
<fme:NORTHING>821165.898</fme:NORTHING>
<fme:ENGLISHNAME>TSING KO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青高路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14198</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821165.89800 829212.43800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id83a6b838-7b34-4bf8-b256-155a78fe9de4">
<fme:FEATURE_ID>1210002850</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829015.949</fme:EASTING>
<fme:NORTHING>821235.53</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHEUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青尚路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13716</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821235.53000 829015.94900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8d0f977c-7ab1-466b-aef0-f70784949da9">
<fme:FEATURE_ID>1210002716</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827831.012</fme:EASTING>
<fme:NORTHING>821306.581</fme:NORTHING>
<fme:ENGLISHNAME>TSING NAM STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>青南街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821306.58100 827831.01200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idad395a16-41d0-4dc8-8cf4-328636b5410f">
<fme:FEATURE_ID>1210002849</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829021.78</fme:EASTING>
<fme:NORTHING>821317.004</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821317.00400 829021.78000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idfc81b35e-e3e3-4a4b-b342-f087a7a677aa">
<fme:FEATURE_ID>1210002717</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827574.291</fme:EASTING>
<fme:NORTHING>821325.382</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821325.38200 827574.29100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id233806b1-5e74-4c2a-bf03-b142da9cad29">
<fme:FEATURE_ID>1210002761</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828546.44</fme:EASTING>
<fme:NORTHING>821338.991</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821338.99100 828546.44000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id305c6058-812f-4c1f-a576-85b311fc5891">
<fme:FEATURE_ID>1210002906</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827872.246</fme:EASTING>
<fme:NORTHING>821375.278</fme:NORTHING>
<fme:ENGLISHNAME>ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>道路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>42299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821375.27800 827872.24600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0df0e5eb-2bca-46ad-9228-16c5dc00c8e2">
<fme:FEATURE_ID>1210003014</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829609.359</fme:EASTING>
<fme:NORTHING>821385.904</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821385.90400 829609.35900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0099a355-79db-4829-8b30-56561acb204f">
<fme:FEATURE_ID>1210003029</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827473.129</fme:EASTING>
<fme:NORTHING>821443.455</fme:NORTHING>
<fme:ENGLISHNAME>TSING KEUNG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>青強街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12425</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821443.45500 827473.12900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ida777192e-61b5-47c6-8dc5-7ce55bf67720">
<fme:FEATURE_ID>1210002718</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829531.136</fme:EASTING>
<fme:NORTHING>821733.144</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI HONG WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣航運路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14171</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821733.14400 829531.13600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idded787ef-0755-4d4f-a3d3-060f43c1a0f1">
<fme:FEATURE_ID>1210002514</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829102.068</fme:EASTING>
<fme:NORTHING>821881.757</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821881.75700 829102.06800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7a15f3c3-a1fe-4ed4-aa14-e8763dd5ca69">
<fme:FEATURE_ID>1210003025</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829211.906</fme:EASTING>
<fme:NORTHING>822026.788</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822026.78800 829211.90600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idab62cedf-1cd0-4de8-bce9-8ba9d8b8eff4">
<fme:FEATURE_ID>1210003028</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829435.744</fme:EASTING>
<fme:NORTHING>822092.453</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI HONG WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣航運路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14171</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822092.45300 829435.74400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id2a1f5a38-b96b-4de8-a482-9de7ce7324de">
<fme:FEATURE_ID>1210003293</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829031.702</fme:EASTING>
<fme:NORTHING>822116.427</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822116.42700 829031.70200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id338c5cc8-a733-4d92-a432-90be22bae9ed">
<fme:FEATURE_ID>1210002806</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828466.631</fme:EASTING>
<fme:NORTHING>822183.949</fme:NORTHING>
<fme:ENGLISHNAME>NAM WAN TUNNEL</fme:ENGLISHNAME>
<fme:CHINESENAME>南灣隧道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39536</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822183.94900 828466.63100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id86466199-a51e-4e54-8ba4-80967e793991">
<fme:FEATURE_ID>1210002791</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827727.996</fme:EASTING>
<fme:NORTHING>822312.821</fme:NORTHING>
<fme:ENGLISHNAME>SAI TSO WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>西草灣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11854</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822312.82100 827727.99600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id83101c03-37e0-4aaa-bcc4-bced29521afc">
<fme:FEATURE_ID>1210001035</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829466.366</fme:EASTING>
<fme:NORTHING>822316.656</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI HONG WAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣航運路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14171</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822316.65600 829466.36600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idff32d73a-508b-4699-9474-e9855783d590">
<fme:FEATURE_ID>1210003106</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829341.135</fme:EASTING>
<fme:NORTHING>822317.746</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822317.74600 829341.13500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id66b276f0-0f83-40f9-b63a-5adc8a9cd34e">
<fme:FEATURE_ID>1210002893</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829141.236</fme:EASTING>
<fme:NORTHING>822410.872</fme:NORTHING>
<fme:ENGLISHNAME>TSING HUNG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青鴻路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14168</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822410.87200 829141.23600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb9f6e5b3-a865-4ef6-b32c-c2635f33cb80">
<fme:FEATURE_ID>1210000213</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827930.147</fme:EASTING>
<fme:NORTHING>822421.58</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣西路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12450</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822421.58000 827930.14700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd8cb8d04-208b-4cf1-a9c1-7f4307cb2c17">
<fme:FEATURE_ID>1210003116</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827804.928</fme:EASTING>
<fme:NORTHING>822489.15</fme:NORTHING>
<fme:ENGLISHNAME>TSING MUI STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>清梅街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13036</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822489.15000 827804.92800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ida15d3ab5-70c3-4a57-9f83-c1f2538a7df4">
<fme:FEATURE_ID>1210002767</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827501.554</fme:EASTING>
<fme:NORTHING>822635.435</fme:NORTHING>
<fme:ENGLISHNAME>TSING TIM STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>清甜街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12441</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822635.43500 827501.55400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd558c639-9540-436a-b9b8-41cb817fa694">
<fme:FEATURE_ID>1210002784</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829136.109</fme:EASTING>
<fme:NORTHING>822669.921</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822669.92071 829136.10923 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id223c622c-9072-41e0-9d5c-657a54bb95fe">
<fme:FEATURE_ID>1210014514</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829014.354</fme:EASTING>
<fme:NORTHING>822728.053</fme:NORTHING>
<fme:ENGLISHNAME>SAI SHAN ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>細山路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11851</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822728.05300 829014.35400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6aaa2dfb-768d-42ad-84a6-50a03afa0334">
<fme:FEATURE_ID>1210001034</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829260.166</fme:EASTING>
<fme:NORTHING>822791.289</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822791.28900 829260.16600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id7282f2b4-089e-4a01-8ef4-a15239237829">
<fme:FEATURE_ID>1210016120</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828184.867</fme:EASTING>
<fme:NORTHING>822840.575</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TSING TUNNEL</fme:ENGLISHNAME>
<fme:CHINESENAME>長青隧道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13784</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822840.57500 828184.86700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id70fded80-1cbc-4754-bfaa-aacc5ae39f0d">
<fme:FEATURE_ID>1210002707</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827489.006</fme:EASTING>
<fme:NORTHING>822840.93</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822840.93000 827489.00600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idaff6e502-47d9-4c58-94d4-0ada24ce3ef3">
<fme:FEATURE_ID>1210003241</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827789.949</fme:EASTING>
<fme:NORTHING>822874.001</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TSING HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>長青公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822874.00100 827789.94900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idb6011d9d-6622-45af-abde-4e26001a1001">
<fme:FEATURE_ID>1210003243</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827423.997</fme:EASTING>
<fme:NORTHING>822883.828</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TSING HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>長青公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822883.82800 827423.99700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id555c5c65-88e0-4e1f-ae4d-4ad0f6d25679">
<fme:FEATURE_ID>1210006706</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TNN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828557.068</fme:EASTING>
<fme:NORTHING>822891.114</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TSING TUNNEL</fme:ENGLISHNAME>
<fme:CHINESENAME>長青隧道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13784</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822891.11400 828557.06827 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id0dd6a398-8228-4164-a9c4-9d7640fcc71f">
<fme:FEATURE_ID>1210002525</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827487.666</fme:EASTING>
<fme:NORTHING>822893.362</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822893.36200 827487.66600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id70ce654f-b352-4ee2-a628-df6e3ded42d7">
<fme:FEATURE_ID>1210002632</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827774.3</fme:EASTING>
<fme:NORTHING>822937.403</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TSING HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>長青公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822937.40300 827774.30000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ide26df167-64b5-4f9e-9bea-d6ca3940d652">
<fme:FEATURE_ID>1210002773</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829572.924</fme:EASTING>
<fme:NORTHING>823047.028</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG FAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長輝路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823047.02800 829572.92400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id62453a8c-452a-4d10-bac1-e3da5ca7da26">
<fme:FEATURE_ID>1210002431</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827196.859</fme:EASTING>
<fme:NORTHING>823057.863</fme:NORTHING>
<fme:ENGLISHNAME>TSING SHA HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青沙公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14299</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823057.86300 827196.85900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id1526ea4a-773d-4079-89a4-772953a692c2">
<fme:FEATURE_ID>1210001050</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829406.965</fme:EASTING>
<fme:NORTHING>823126.081</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI INTERCHANGE</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣交匯處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14092</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823126.08100 829406.96500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id8f53348d-fa4e-4663-a701-8e18d4804103">
<fme:FEATURE_ID>1210003111</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829725.759</fme:EASTING>
<fme:NORTHING>823229.717</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TSING BRIDGE</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青橋</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39486</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823229.71700 829725.75900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id5c448126-2dab-45df-967b-55afe0eb5089">
<fme:FEATURE_ID>1210002795</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828582.842</fme:EASTING>
<fme:NORTHING>823238.33</fme:NORTHING>
<fme:ENGLISHNAME>TSING CHIN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>青芊街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12414</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823238.33000 828582.84200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id9a5f3ce3-5e3d-4de9-863f-68b74b21d9d2">
<fme:FEATURE_ID>1210001083</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829675.462</fme:EASTING>
<fme:NORTHING>823260.51</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TSING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11101</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823260.51000 829675.46200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4bedb1e5-afe4-40e6-8dc1-9fb4ae27e08f">
<fme:FEATURE_ID>1210001079</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828185.657</fme:EASTING>
<fme:NORTHING>823267.341</fme:NORTHING>
<fme:ENGLISHNAME>TSING CHIN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>青芊街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12414</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823267.34100 828185.65700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id39abee47-eded-4113-ac72-56362cf24f46">
<fme:FEATURE_ID>1210000245</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828836.346</fme:EASTING>
<fme:NORTHING>823270.015</fme:NORTHING>
<fme:ENGLISHNAME>CHING HONG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青康路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10248</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823270.01500 828836.34600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ide35b902e-a3ef-4e3b-afa1-48f99d76dab7">
<fme:FEATURE_ID>1210002765</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829689.119</fme:EASTING>
<fme:NORTHING>823273.119</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI BRIDGE</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣大橋</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39485</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823273.11900 829689.11900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id27969a08-d436-42ed-b4d2-efecad9c7999">
<fme:FEATURE_ID>1210001113</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829840.435</fme:EASTING>
<fme:NORTHING>823306.683</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TSING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11101</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823306.68300 829840.43500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6026152b-4ec7-4d6d-912f-ccba26a9ae3c">
<fme:FEATURE_ID>1210002891</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829625.93</fme:EASTING>
<fme:NORTHING>823330.529</fme:NORTHING>
<fme:ENGLISHNAME>TSING KWAI HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>青葵公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13783</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823330.52900 829625.93000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ida2e70f97-e6fe-4a0d-ae84-5ddcb95f4c66">
<fme:FEATURE_ID>1210002868</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RBN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829642.126</fme:EASTING>
<fme:NORTHING>823349.564</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TSING BRIDGE</fme:ENGLISHNAME>
<fme:CHINESENAME>長青橋</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>39484</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823349.56400 829642.12600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id5ee93d35-3c8b-4790-9040-47ebf96e3b10">
<fme:FEATURE_ID>1210003115</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829352.327</fme:EASTING>
<fme:NORTHING>823350.91</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI HEUNG SZE WUI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣鄉事會路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823350.91000 829352.32700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id22a97372-53ab-4b24-b9bc-8761f18ef86a">
<fme:FEATURE_ID>1210001051</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829511.481</fme:EASTING>
<fme:NORTHING>823375.498</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG FAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長輝路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823375.49800 829511.48100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id34ce0029-fbe4-4cc6-8ce4-7d62cd0bf411">
<fme:FEATURE_ID>1210003109</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828152.476</fme:EASTING>
<fme:NORTHING>823384.092</fme:NORTHING>
<fme:ENGLISHNAME>CHING HONG ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青康路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10248</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823384.09200 828152.47600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id04a07402-9ec4-407f-8574-936105dea2d4">
<fme:FEATURE_ID>1210001078</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>826994.229</fme:EASTING>
<fme:NORTHING>823388.585</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TSING HIGHWAY</fme:ENGLISHNAME>
<fme:CHINESENAME>長青公路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13785</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823388.58500 826994.22900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idaa17d004-937b-402b-a84c-7e142bab4585">
<fme:FEATURE_ID>1210002774</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829971.919</fme:EASTING>
<fme:NORTHING>823443.909</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TAI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>葵泰路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11098</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823443.90900 829971.91900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id514e1bfb-23d1-48ba-a15b-fd1c56caebc5">
<fme:FEATURE_ID>1210001086</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829362.29</fme:EASTING>
<fme:NORTHING>823470.132</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TAT ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>長達路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823470.13200 829362.29000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id607c2c63-e260-4422-ae75-cd77ba22da6f">
<fme:FEATURE_ID>1210002852</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829036.426</fme:EASTING>
<fme:NORTHING>823485.229</fme:NORTHING>
<fme:ENGLISHNAME>HA KO TAN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>下高灘街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10633</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823485.22900 829036.42600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id2ab12b03-2512-4a28-8459-4aaf3c7f6627">
<fme:FEATURE_ID>1210002769</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829383.866</fme:EASTING>
<fme:NORTHING>823492.223</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG LUNG STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長隆街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10199</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823492.22300 829383.86600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idba23ff7f-1fc3-4a40-a97a-9a1fb64ac33b">
<fme:FEATURE_ID>1210002792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828788.719</fme:EASTING>
<fme:NORTHING>823525.717</fme:NORTHING>
<fme:ENGLISHNAME>CHUNG MEI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>涌美路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823525.71700 828788.71900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id09bd79d1-1d30-45c4-8eae-41417c24cb8a">
<fme:FEATURE_ID>1210003184</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828934.895</fme:EASTING>
<fme:NORTHING>823534.75</fme:NORTHING>
<fme:ENGLISHNAME>SHEUNG KO TAN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>上高灘街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12032</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823534.75000 828934.89500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="ide8da6c94-1262-4e38-937f-360ed3a26009">
<fme:FEATURE_ID>1210003211</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828126.887</fme:EASTING>
<fme:NORTHING>823558.334</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣西路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12450</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823558.33400 828126.88700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd3f63734-8c48-44eb-a34e-16c3ce5de7ce">
<fme:FEATURE_ID>1210012586</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829216.02</fme:EASTING>
<fme:NORTHING>823562.566</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG WAN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長環街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10216</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823562.56600 829216.02000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idde627d97-a81d-4895-83af-430898293c04">
<fme:FEATURE_ID>1210002621</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829263.187</fme:EASTING>
<fme:NORTHING>823568.705</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG HO STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長好街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10192</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823568.70500 829263.18700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id02970701-c579-4328-b85f-dc8cc676df9f">
<fme:FEATURE_ID>1210001038</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829943.763</fme:EASTING>
<fme:NORTHING>823592.924</fme:NORTHING>
<fme:ENGLISHNAME>KWAI YUE LANE</fme:ENGLISHNAME>
<fme:CHINESENAME>葵裕里</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13992</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823592.92400 829943.76300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf77c7d95-889e-4ecb-9875-1e414409b463">
<fme:FEATURE_ID>1210002633</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829330.938</fme:EASTING>
<fme:NORTHING>823623.248</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG WAN STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>長環街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10216</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823623.24800 829330.93800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6f0e3e37-58d0-4a36-a208-e1ac2a0b57df">
<fme:FEATURE_ID>1210003181</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829139.968</fme:EASTING>
<fme:NORTHING>823631.989</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI HEUNG SZE WUI ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣鄉事會路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823631.98900 829139.96800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6fd32109-3cc7-4fc5-ae61-be7089354636">
<fme:FEATURE_ID>1210003154</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>826848.302</fme:EASTING>
<fme:NORTHING>823727.61</fme:NORTHING>
<fme:ENGLISHNAME>NORTH WEST TSING YI INTERCHANGE</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣西北交匯處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13786</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823727.61000 826848.30200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id22e048a1-0190-43d0-be56-f9a9fb8b68af">
<fme:FEATURE_ID>1210002771</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828465.956</fme:EASTING>
<fme:NORTHING>823745.085</fme:NORTHING>
<fme:ENGLISHNAME>TSING SUM STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>清心街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823745.08500 828465.95600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idab7d8a91-958f-4216-b2df-d237f65aef3d">
<fme:FEATURE_ID>1210012983</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>826304.013</fme:EASTING>
<fme:NORTHING>823754.368</fme:NORTHING>
<fme:ENGLISHNAME>LANTAU LINK</fme:ENGLISHNAME>
<fme:CHINESENAME>青嶼幹線</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13782</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823754.36800 826304.01300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id82f07b20-70ac-45d0-8a4e-3fb309acd25e">
<fme:FEATURE_ID>1210003185</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828637.971</fme:EASTING>
<fme:NORTHING>823756.543</fme:NORTHING>
<fme:ENGLISHNAME>FUNG SHUE WO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>楓樹窩路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10582</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823756.54300 828637.97100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id3a341850-fbf7-4fc9-ab4c-33421885dd1e">
<fme:FEATURE_ID>1210002766</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828533.272</fme:EASTING>
<fme:NORTHING>823762.988</fme:NORTHING>
<fme:ENGLISHNAME>TSING SUM STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>清心街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823762.98800 828533.27200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idceac9331-9c37-4dcd-947b-842ce215e1ef">
<fme:FEATURE_ID>1210001085</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829170.27</fme:EASTING>
<fme:NORTHING>823767.587</fme:NORTHING>
<fme:ENGLISHNAME>FUNG SHUE WO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>楓樹窩路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10582</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823767.58700 829170.27000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idd8d1cb21-3cda-455b-9556-dd72dc0830ce">
<fme:FEATURE_ID>1210001080</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828812.008</fme:EASTING>
<fme:NORTHING>823780.27</fme:NORTHING>
<fme:ENGLISHNAME>TSING LUK STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>青綠街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12429</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823780.27000 828812.00800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id6c09eb7d-62a1-4ae0-b47f-2315ab56984d">
<fme:FEATURE_ID>1210002616</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828241.729</fme:EASTING>
<fme:NORTHING>823840.857</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD WEST</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣西路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12450</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823840.85700 828241.72900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idce8281fc-46ec-4f2b-ac09-d6314d86e3c2">
<fme:FEATURE_ID>1210003114</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829073.389</fme:EASTING>
<fme:NORTHING>823926.623</fme:NORTHING>
<fme:ENGLISHNAME>TSING KING ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>青敬路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12426</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823926.62300 829073.38900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id4f853e6e-60d4-4eff-89ce-6ad1407f7284">
<fme:FEATURE_ID>1210002797</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828078.076</fme:EASTING>
<fme:NORTHING>823962.832</fme:NORTHING>
<fme:ENGLISHNAME>LIU TO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>寮肚路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11243</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823962.83200 828078.07600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="idf7eeaa07-6289-45bb-b664-a18058e8fd2e">
<fme:FEATURE_ID>1210002618</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828419.327</fme:EASTING>
<fme:NORTHING>823969.202</fme:NORTHING>
<fme:ENGLISHNAME>TSING YU STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>清譽街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12453</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823969.20200 828419.32700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
<gml:featureMember>
<fme:TransportPoint gml:id="id2549b137-ac34-4e8c-99ba-f39f11b41e63">
<fme:FEATURE_ID>1210001084</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>RDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828508.002</fme:EASTING>
<fme:NORTHING>823983.671</fme:NORTHING>
<fme:ENGLISHNAME>TSING YU STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>清譽街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12453</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823983.67100 828508.00200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:TransportPoint>
</gml:featureMember>
</gml:FeatureCollection>
