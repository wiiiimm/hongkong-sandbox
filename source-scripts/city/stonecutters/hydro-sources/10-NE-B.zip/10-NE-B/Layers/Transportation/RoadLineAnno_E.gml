<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme RoadLineAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821752.05120 827890.15219</gml:lowerCorner>
<gml:upperCorner>822845.91604 828997.12244</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:RoadLineAnno_E gml:id="idfb031c97-3aa3-43c0-93bf-634da8545ccf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tunnel
Portal</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310000061</fme:FEATURE_ID>
<fme:FEATURECODE>TPO</fme:FEATURECODE>
<fme:EASTING>827890.152</fme:EASTING>
<fme:NORTHING>822845.955</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231227</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822845.91604 827890.15219</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:RoadLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:RoadLineAnno_E gml:id="idea0ea93f-816b-41a3-91b4-b7f2e5741685">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tunnel
Portal</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-35.8409678103381</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310000062</fme:FEATURE_ID>
<fme:FEATURECODE>TPO</fme:FEATURECODE>
<fme:EASTING>827915.141</fme:EASTING>
<fme:NORTHING>822565.051</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231227</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822565.01995 827915.11821</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:RoadLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:RoadLineAnno_E gml:id="idd7678daf-9c93-4e4f-98fe-a3bd3a7ed168">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tunnel
Portal</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.7862727051426</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310000063</fme:FEATURE_ID>
<fme:FEATURECODE>TPO</fme:FEATURECODE>
<fme:EASTING>828997.146</fme:EASTING>
<fme:NORTHING>821752.082</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20231227</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821752.05120 828997.12244</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:RoadLineAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
