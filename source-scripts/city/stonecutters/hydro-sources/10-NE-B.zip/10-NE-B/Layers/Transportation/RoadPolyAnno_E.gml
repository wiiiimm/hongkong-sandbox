<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme RoadPolyAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>823721.89353 826338.18067</gml:lowerCorner>
<gml:upperCorner>823721.89353 826338.18067</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:RoadPolyAnno_E gml:id="id621acd8b-f6d4-4088-b3c2-833371aae1c4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Bridge
Tower</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001158419</fme:FEATURE_ID>
<fme:FEATURECODE>ROD</fme:FEATURECODE>
<fme:EASTING>826323.48514898</fme:EASTING>
<fme:NORTHING>823714.22818136</fme:NORTHING>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823721.89353 826338.18067</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:RoadPolyAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
