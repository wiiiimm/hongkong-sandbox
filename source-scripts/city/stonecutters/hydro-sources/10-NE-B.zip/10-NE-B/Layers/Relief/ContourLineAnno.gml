<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme ContourLineAnno.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821205.58068 826818.23607</gml:lowerCorner>
<gml:upperCorner>823990.87767 829114.38898</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id09b0ad19-b0ca-43a8-a5f5-8969f6fefd95">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-56.0463287752603</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095357</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827959.81799803</fme:EASTING>
<fme:NORTHING>823019.51940521</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823014.47763 827966.89883</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="ida36d4edc-c229-42d8-96a0-f3d239d04f4a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.6607537392834</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095378</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>826961.7071443</fme:EASTING>
<fme:NORTHING>823408.53238632</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823408.35575 826967.81869</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idbd0135d7-65bd-472d-b99c-7d7b5101f7a8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>70</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>14.3002703016673</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095380</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>828985.50782763</fme:EASTING>
<fme:NORTHING>823184.85643324</fme:NORTHING>
<fme:CONTOURHEIGHT>70</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823189.12703 828989.88324</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="ida90d8ba2-9661-4330-820f-42116d4a06d9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>66.1612919127018</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095321</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828567.7196155</fme:EASTING>
<fme:NORTHING>822369.4965268</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822378.17499 828568.21158</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idbe3378e0-ce98-4963-8fd3-700ccb3e621d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-59.6008930669287</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095344</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827643.67560547</fme:EASTING>
<fme:NORTHING>821379.78022256</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821374.30914 827650.43023</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id06f66c97-0ddb-413d-a377-fe30c5d67fd7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>60.8515989448604</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095346</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>827460.12597713</fme:EASTING>
<fme:NORTHING>821643.99310185</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821650.10652 827460.03456</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id34768c97-4f2b-4d1e-9668-6c0b452f2056">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>1.87790019110288</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095323</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828585.2513974</fme:EASTING>
<fme:NORTHING>822815.8592246</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822819.18175 828593.28374</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idde68c7a5-1c45-4c46-89c4-1457eb1da563">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>250</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>29.5258921053332</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095320</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828340.06668731</fme:EASTING>
<fme:NORTHING>822149.72647456</fme:NORTHING>
<fme:CONTOURHEIGHT>250</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822156.39693 828345.64008</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id3e447d4b-4fa4-4856-95ed-3033078ffffb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-15.1240147095612</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095377</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>828767.12952654</fme:EASTING>
<fme:NORTHING>823650.51380254</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823652.08399 828773.03857</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idf6d24347-52c8-4873-a616-e4484fe4e623">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>2.70064665530637</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095366</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827285.31119511</fme:EASTING>
<fme:NORTHING>823301.73416477</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823305.17168 827293.29500</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id5e556bd6-e3dc-4095-af70-5069efa33f9a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.2219025092614</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095322</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828945.438</fme:EASTING>
<fme:NORTHING>822143.687</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822143.68736 828945.43777</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idfb31e69c-4189-48ce-af41-dbe0a047dea8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>58.0418504765696</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095355</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828655.81184332</fme:EASTING>
<fme:NORTHING>822353.52578563</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822362.04777 828657.52459</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id690e596f-2650-4a27-b7b8-23337c0068e3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-50.7927860706179</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095385</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828111.83859679</fme:EASTING>
<fme:NORTHING>822211.48318532</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822207.11094 828119.35133</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id0fd59978-4078-49f9-9fa7-66b1ab33f59d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>60</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>38.9670891448067</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095339</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>828189.54115752</fme:EASTING>
<fme:NORTHING>823974.1268063</fme:NORTHING>
<fme:CONTOURHEIGHT>60</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823979.83375 828191.73502</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id733956ff-5d82-4f8c-bd83-87268a685f6c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-18.2325032698982</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095360</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>829045.41729593</fme:EASTING>
<fme:NORTHING>822934.81845203</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822936.06590 829051.40279</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id4043a601-3061-49bd-b9c8-2bde5beed6a6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>250</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-2.35594126665679</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095336</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828425.70349022</fme:EASTING>
<fme:NORTHING>821848.98224317</fme:NORTHING>
<fme:CONTOURHEIGHT>250</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821851.70270 828433.95920</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id609afdcb-7416-441f-87a3-8e093ed10109">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>25.083616659317</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095331</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828555.21913137</fme:EASTING>
<fme:NORTHING>823163.88593453</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823170.10467 828561.29243</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idd3687d2c-7c98-44ac-92b6-a5b4c252ea9f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>42.397455502405</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095319</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828030.0755583</fme:EASTING>
<fme:NORTHING>822407.1962786</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822414.94068 828034.02294</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc5a9e5d8-ac1c-42fc-8ec7-73c0147e7065">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>71.5656920940371</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095341</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>829040.55002839</fme:EASTING>
<fme:NORTHING>823611.66939348</fme:NORTHING>
<fme:CONTOURHEIGHT>10</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823617.65924 829039.32367</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id2ed4b13a-2697-4e18-b22e-a98d42c4b002">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-39.9363921586088</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095348</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827096.13850651</fme:EASTING>
<fme:NORTHING>823769.79552627</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823766.91654 827104.34028</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idd07cb412-57a8-4b66-bc5e-c28870c4e874">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>20</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-52.1250411615235</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095332</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>829108.7248851</fme:EASTING>
<fme:NORTHING>823475.48317935</fme:NORTHING>
<fme:CONTOURHEIGHT>20</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823473.18094 829114.38898</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="ida4410ab8-4123-4f3e-a814-f9dfa5f2f1e0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>10.6849147306217</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095347</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828634.03716189</fme:EASTING>
<fme:NORTHING>821701.7482483</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821706.26141 828641.46609</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id0d3d4fb8-b1ba-4ddf-8607-5cf27a70e9ee">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-83.7052718631515</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095358</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828174.19701352</fme:EASTING>
<fme:NORTHING>822727.25260109</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822719.49999 828178.12826</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id1fcabc8e-27ee-4a3f-95eb-e6e97b273ee7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-14.7830595198059</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095324</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827246.51642944</fme:EASTING>
<fme:NORTHING>823426.55152276</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823427.43163 827255.16415</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id3ff17f67-3d14-4f28-892e-2d4c6a0cab57">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>37.6134165882672</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095342</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828786.90025867</fme:EASTING>
<fme:NORTHING>822764.58293429</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822771.97114 828791.47978</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id1187373a-1cf4-40b2-a722-321d27a34ca2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-29.5115116706713</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095384</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828606.85766048</fme:EASTING>
<fme:NORTHING>821395.82192716</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821395.87461 828612.97154</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id219a43f6-653c-4d00-9933-289f5f4ca860">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>46.9690932739125</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095337</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828628.94592333</fme:EASTING>
<fme:NORTHING>821479.83205566</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821487.86645 828632.26347</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id1f5bf20f-022e-4705-9e99-9faf21d65de9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>47.4537010293395</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095329</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827427.15979341</fme:EASTING>
<fme:NORTHING>823862.58025126</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823870.64242 827430.40927</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id56d99fae-fcc8-4252-952f-a2fc575e9d04">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-20.492616709796</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095333</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828078.00346385</fme:EASTING>
<fme:NORTHING>821565.86268311</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821565.87810 828086.69584</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idbff94707-3617-4fcc-aa7a-8130d9ce0bdd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>43.8308874634053</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095340</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828279.51819988</fme:EASTING>
<fme:NORTHING>823789.59559503</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823795.46801 828281.22029</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id50e8c6b7-c40a-486c-a6d8-452628146b37">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>37.2348359350773</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095325</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827783.3748538</fme:EASTING>
<fme:NORTHING>823219.735021</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823227.09281 827788.00309</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id42f67c76-8f6e-4da9-941e-ea393cd32d3a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-57.9946055742907</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095382</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828400.85950993</fme:EASTING>
<fme:NORTHING>823104.97681509</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823099.69723 828407.76484</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idefe7b5d4-d47f-4b6d-86f2-e6a795db2d9c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.286404647373</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095374</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828122.8841567</fme:EASTING>
<fme:NORTHING>823195.78840133</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823201.59127 828129.35596</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id7ed5b4d4-9cf9-4290-9317-c8f25665f0b4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-46.4688179810141</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095335</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828141.29670676</fme:EASTING>
<fme:NORTHING>821799.2477507</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821795.45437 828149.11770</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id133da743-4d36-428c-b64e-fe8f30357e66">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.0561087059414</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095386</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828234.98025434</fme:EASTING>
<fme:NORTHING>822225.00881881</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822218.92038 828241.18416</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc009e5d0-19f6-4304-ae4f-78b99386f6ec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>62.7004048490849</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095345</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827829.06725484</fme:EASTING>
<fme:NORTHING>821643.6296478</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821652.26258 827830.08220</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id0c5c3e63-8437-44cb-850e-ec31dd0f74bb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-9.92604382107578</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095330</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828783.40001009</fme:EASTING>
<fme:NORTHING>823122.31153391</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823123.92068 828791.94216</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idf115a756-556b-49f1-a083-f5cc901e5dc1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>59.9314508417727</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095363</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827762.08513676</fme:EASTING>
<fme:NORTHING>821547.29025399</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821555.86407 827763.51595</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idf560e00d-2a27-43ac-98b8-7ae0711f5602">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>300</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-36.4308646123039</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095359</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828372.17132458</fme:EASTING>
<fme:NORTHING>822404.6486051</fme:NORTHING>
<fme:CONTOURHEIGHT>300</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822402.27650 828380.53378</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id42ef397e-09c9-4003-b239-fd74c881640e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>250</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>76.2509867921537</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095353</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828490.06592619</fme:EASTING>
<fme:NORTHING>822385.16328267</fme:NORTHING>
<fme:CONTOURHEIGHT>250</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822393.79371 828489.02990</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idb9f05e53-1356-4936-924d-77bf7683e228">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>250</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-23.5434487210166</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095372</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828401.92406185</fme:EASTING>
<fme:NORTHING>822753.9288269</fme:NORTHING>
<fme:CONTOURHEIGHT>250</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822753.48160 828410.60494</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id16d6d24b-bded-4510-961a-2a0c983c0af3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>54.4623303248386</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095350</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827770.17040968</fme:EASTING>
<fme:NORTHING>821887.26317823</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821893.34880 827770.75987</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6eba3cfc-d19f-4e1c-8ddb-f54b41a6f22a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>49.1848990624765</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095381</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828946.00077868</fme:EASTING>
<fme:NORTHING>821897.30760136</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821905.46425 828949.00521</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id10075632-5aca-4a15-b519-298724013276">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>44.9999590522091</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095328</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828203.0450193</fme:EASTING>
<fme:NORTHING>823962.6565473</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823968.56246 828204.62694</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id10e0ab60-c143-4ddf-9e67-67d21b4cc078">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>68.0259837555337</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095318</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827605.05837012</fme:EASTING>
<fme:NORTHING>821832.82576568</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821838.87990 827604.20416</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id82ad0ca9-7d63-46d5-8f08-cf09a3cd5e10">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>64.8851276125969</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095383</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>829022.09875414</fme:EASTING>
<fme:NORTHING>821889.24662649</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821895.33848 829021.57753</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="ided997db1-e0c9-4ba0-b315-0f254ff531f4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>1.02301216867253</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095367</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827588.30330731</fme:EASTING>
<fme:NORTHING>823413.60654145</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823416.80886 827596.38433</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idab5a6f9e-1dea-4dac-8788-5d4817e74f7f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-9.29333165760826</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095334</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828085.55052632</fme:EASTING>
<fme:NORTHING>821742.45973083</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821744.16310 828094.07439</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idd3cb292a-9d17-4d4e-9e86-0274054a9b6e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-18.0604607045226</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095326</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827586.9956871</fme:EASTING>
<fme:NORTHING>823990.4933931</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823990.87767 827595.67958</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id74dfaff2-3c59-4a96-8f31-90627890955a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>300</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.784819339076809</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095375</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828380.63359968</fme:EASTING>
<fme:NORTHING>821939.98214178</fme:NORTHING>
<fme:CONTOURHEIGHT>300</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821943.15084 828388.72786</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc81eef04-c504-44d4-ae99-2215f6460a9b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>21.4252072970295</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095351</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827784.64649569</fme:EASTING>
<fme:NORTHING>821727.79356755</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821733.61211 827791.10423</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id49fe7504-7ced-46a5-a6c3-ad6d14620c1b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>60</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-30.4889528294735</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095365</fme:FEATURE_ID>
<fme:FEATURECODE>CNS</fme:FEATURECODE>
<fme:EASTING>827171.25207928</fme:EASTING>
<fme:NORTHING>823142.36760749</fme:NORTHING>
<fme:CONTOURHEIGHT>60</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823142.31599 827177.36596</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id38a5906d-65f1-4f88-9f1f-9160f53ab55b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>59.0362487079781</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095362</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827816.67573304</fme:EASTING>
<fme:NORTHING>821444.9553119</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821453.50573 827818.24032</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idf3b6dd70-b240-43b7-badf-322390d7ae2a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-27.257850604563</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095349</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828642.45692075</fme:EASTING>
<fme:NORTHING>821615.43964656</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821614.43099 828651.09059</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id1530cfea-1f00-4ad6-83eb-52ca76d48b15">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-22.9887209640886</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095364</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>826812.16775599</fme:EASTING>
<fme:NORTHING>823629.96426102</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823630.71112 826818.23607</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idc3e492dd-7847-4ed1-b7df-4ce7aa018db3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>150</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>22.4427713372768</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095368</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827662.86179672</fme:EASTING>
<fme:NORTHING>823586.72805021</fme:NORTHING>
<fme:CONTOURHEIGHT>150</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823592.66036 827669.21518</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id4bd84c20-9d70-471c-bdfe-9a8f404b32f2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-20.6954335777216</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095352</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827421.92393108</fme:EASTING>
<fme:NORTHING>823475.06921467</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823475.05386 827430.61631</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idb5287630-cfcc-4fff-9876-16b0f8b37ee4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-19.4255454358638</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095371</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827751.24059184</fme:EASTING>
<fme:NORTHING>823672.13875952</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823672.31605 827759.93117</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idb43e6576-5d9c-41ce-9e48-8a08dcb3ff73">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-29.5213582168949</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095376</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827238.8118765</fme:EASTING>
<fme:NORTHING>823245.83052139</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823244.48166 827247.39898</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id2ed4ba5a-75e7-4f1f-94e5-d94569a1a4d1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>56.0138288568775</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095354</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828757.33327309</fme:EASTING>
<fme:NORTHING>822225.3099242</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822233.76595 828759.34652</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id04060da2-bc69-4b61-a38a-8532772f7e87">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-13.8911643597898</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095379</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828085.39695484</fme:EASTING>
<fme:NORTHING>823709.08599106</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823710.78296 828091.27084</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id7c23e199-b66c-4d1a-8b7c-7606b02c3456">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-5.71053468831027</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095369</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827797.88138281</fme:EASTING>
<fme:NORTHING>823796.55162962</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823799.06715 827803.45403</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id3ed84bac-2972-4a79-814f-674b4ceeab14">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-31.5514079228784</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095356</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828290.58855817</fme:EASTING>
<fme:NORTHING>823541.10610866</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823540.94113 828296.70044</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id2ec11fbc-b8ff-4eae-a5ae-7d78c76e4720">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-55.6126137667666</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095343</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827670.59273846</fme:EASTING>
<fme:NORTHING>821210.56870725</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821205.58068 827677.71153</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id119953c2-f9a7-41ce-bb20-5731b71391be">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>200</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-6.20347149001271</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095373</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828326.41586903</fme:EASTING>
<fme:NORTHING>822957.01196757</fme:NORTHING>
<fme:CONTOURHEIGHT>200</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822959.17233 828334.83552</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="id6a4c0d98-c6f4-4639-b087-a957b5198063">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>100</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-1.05114786804084</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095370</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>827636.21100011</fme:EASTING>
<fme:NORTHING>823882.69627491</fme:NORTHING>
<fme:CONTOURHEIGHT>100</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823885.60401 827644.40262</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
<gml:featureMember>
<fme:ContourLineAnno gml:id="idde365d9c-4a82-49d8-b3ee-b663f43df787">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>50</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>69.4439547817966</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001095338</fme:FEATURE_ID>
<fme:FEATURECODE>CIS</fme:FEATURECODE>
<fme:EASTING>828131.60341145</fme:EASTING>
<fme:NORTHING>821429.09361071</fme:NORTHING>
<fme:CONTOURHEIGHT>50</fme:CONTOURHEIGHT>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821435.12475 828130.59965</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:ContourLineAnno>
</gml:featureMember>
</gml:FeatureCollection>
