<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme SpotPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821005.14687 826338.18083 0.00000</gml:lowerCorner>
<gml:upperCorner>823993.17200 829983.94796 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:SpotPoint gml:id="idb0e0ab42-151d-42ac-a490-41809355c102">
<fme:FEATURE_ID>1001110242</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828305.37</fme:EASTING>
<fme:NORTHING>821005.15</fme:NORTHING>
<fme:SPOTHEIGHT>4.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821005.14687 828305.36636 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6de1c9f6-afb4-4ed9-a6af-ee874c94e5f9">
<fme:FEATURE_ID>1001110339</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827464.3</fme:EASTING>
<fme:NORTHING>821020.4</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821020.39544 827464.30245 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide8749bd2-625a-4705-a833-5e0de9b7f8df">
<fme:FEATURE_ID>1210000122</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>0</fme:EASTING>
<fme:NORTHING>0</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821060.93750 829821.56250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd8be30f0-f9b0-4ac8-b10a-b9f8aa077c9f">
<fme:FEATURE_ID>1001110340</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827604.69</fme:EASTING>
<fme:NORTHING>821066.42</fme:NORTHING>
<fme:SPOTHEIGHT>8.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821066.41680 827604.69394 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id19d33527-ed5d-4bc0-afdd-cece89788406">
<fme:FEATURE_ID>1001110318</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827980.44</fme:EASTING>
<fme:NORTHING>821087.56</fme:NORTHING>
<fme:SPOTHEIGHT>6.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821087.56317 827980.43799 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id751ac7f4-69b9-488b-8518-1b2bf9746c17">
<fme:FEATURE_ID>1001110350</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829361.43</fme:EASTING>
<fme:NORTHING>821104.57</fme:NORTHING>
<fme:SPOTHEIGHT>5.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821104.57107 829361.43177 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idddcf015d-ad15-4ecd-96e0-854d088fd069">
<fme:FEATURE_ID>1001110408</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829172.42</fme:EASTING>
<fme:NORTHING>821130.05</fme:NORTHING>
<fme:SPOTHEIGHT>6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821130.05127 829172.41722 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id45f24081-10fb-4eb3-8a23-013a9623f19f">
<fme:FEATURE_ID>1001110314</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829671.48</fme:EASTING>
<fme:NORTHING>821135.04</fme:NORTHING>
<fme:SPOTHEIGHT>5.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821135.04125 829671.48327 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc17c7650-f8b5-4ecb-b6bf-727c9a6bbf54">
<fme:FEATURE_ID>1001110342</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828709.62</fme:EASTING>
<fme:NORTHING>821180.13</fme:NORTHING>
<fme:SPOTHEIGHT>4.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821180.13100 828709.61500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7cdc7240-fa92-46a6-918a-e709287077c6">
<fme:FEATURE_ID>1001110238</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827604.68</fme:EASTING>
<fme:NORTHING>821197.8</fme:NORTHING>
<fme:SPOTHEIGHT>60.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821197.80300 827604.67800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9e20f1e8-368d-4da6-b9a6-d867e1f959ad">
<fme:FEATURE_ID>1001110341</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827840.78</fme:EASTING>
<fme:NORTHING>821204.69</fme:NORTHING>
<fme:SPOTHEIGHT>53</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821204.69200 827840.78300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7ef6d0d1-296e-482f-9e71-e8b628ee9147">
<fme:FEATURE_ID>1001110237</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827518.15</fme:EASTING>
<fme:NORTHING>821209.41</fme:NORTHING>
<fme:SPOTHEIGHT>16.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821209.40800 827518.15400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4a2d0260-c560-4a9d-bced-f9cb1e61272a">
<fme:FEATURE_ID>1001110424</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829437.7</fme:EASTING>
<fme:NORTHING>821213.99</fme:NORTHING>
<fme:SPOTHEIGHT>56.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821213.99400 829437.70000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf949dbc1-e4d8-41a8-94d0-959ef151cf06">
<fme:FEATURE_ID>1001110241</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828117.01</fme:EASTING>
<fme:NORTHING>821236.6</fme:NORTHING>
<fme:SPOTHEIGHT>5.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821236.59605 828117.01209 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc585994f-b682-4754-807f-7ee5deab0225">
<fme:FEATURE_ID>1001110416</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829948.68</fme:EASTING>
<fme:NORTHING>821255.78</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821255.78316 829948.68235 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id60ad86dc-958f-4b1c-88de-54f52669c3a8">
<fme:FEATURE_ID>1001110239</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827299.04</fme:EASTING>
<fme:NORTHING>821275.09</fme:NORTHING>
<fme:SPOTHEIGHT>4.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821275.08600 827299.04350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida6976fe5-34d5-47fb-8489-9a3cdf1111f8">
<fme:FEATURE_ID>1001110343</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828909.27</fme:EASTING>
<fme:NORTHING>821280.31</fme:NORTHING>
<fme:SPOTHEIGHT>16</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821280.31400 828909.26900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb04421a4-33b1-4ce3-bf97-144b4bcdc079">
<fme:FEATURE_ID>1001110407</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828974.56</fme:EASTING>
<fme:NORTHING>821280.63</fme:NORTHING>
<fme:SPOTHEIGHT>6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821280.63177 828974.56393 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddd94e94d-1ba4-4ffb-8b89-c20cd0caba3d">
<fme:FEATURE_ID>1001110244</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828708.81</fme:EASTING>
<fme:NORTHING>821288.07</fme:NORTHING>
<fme:SPOTHEIGHT>21.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821288.07500 828708.81300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id336789d4-97a5-407b-b945-09ca26b0b6c0">
<fme:FEATURE_ID>1001110420</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828561.19</fme:EASTING>
<fme:NORTHING>821331.26</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821331.25500 828561.19300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id099c734d-195b-4b6c-9915-9b02f6a7e25d">
<fme:FEATURE_ID>1001110232</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827721.7</fme:EASTING>
<fme:NORTHING>821336.72</fme:NORTHING>
<fme:SPOTHEIGHT>136.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821336.71700 827721.69800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida85ac26f-8c92-40c8-873c-e20bc37ac3b0">
<fme:FEATURE_ID>1001110409</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827934.94</fme:EASTING>
<fme:NORTHING>821369.07</fme:NORTHING>
<fme:SPOTHEIGHT>73.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821369.06900 827934.93800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id94111751-3a88-4577-b1f8-511704327515">
<fme:FEATURE_ID>1001110406</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828201.35</fme:EASTING>
<fme:NORTHING>821385.54</fme:NORTHING>
<fme:SPOTHEIGHT>26.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821385.53990 828201.34630 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6353d61f-55b4-42aa-ac75-37adb9a2767d">
<fme:FEATURE_ID>1001110345</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829121.15</fme:EASTING>
<fme:NORTHING>821407.79</fme:NORTHING>
<fme:SPOTHEIGHT>8.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821407.79000 829121.14700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id24755574-71c5-4be4-bf6c-3c4f759d20d9">
<fme:FEATURE_ID>1210000042</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>0</fme:EASTING>
<fme:NORTHING>0</fme:NORTHING>
<fme:SPOTHEIGHT>67.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821422.68750 829456.18750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8d950858-8fab-484e-86d3-cd0cf9e157c8">
<fme:FEATURE_ID>1001110243</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828764.98</fme:EASTING>
<fme:NORTHING>821459.93</fme:NORTHING>
<fme:SPOTHEIGHT>81.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821459.93200 828764.98000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idda078a3b-e9c8-4ffe-8c84-bc6c79095cba">
<fme:FEATURE_ID>1001110313</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829560.72</fme:EASTING>
<fme:NORTHING>821484.31</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821484.31000 829560.72000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id122a1d7f-a85b-4fed-99a8-48843940de80">
<fme:FEATURE_ID>1001110319</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828980.8</fme:EASTING>
<fme:NORTHING>821529.04</fme:NORTHING>
<fme:SPOTHEIGHT>44.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821529.03500 828980.79800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd0467b1b-b2cc-463a-a0d6-c5ac6e4bba8c">
<fme:FEATURE_ID>1001110236</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827493.13</fme:EASTING>
<fme:NORTHING>821533.36</fme:NORTHING>
<fme:SPOTHEIGHT>39.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821533.36100 827493.13100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id096c355c-6fe1-4b3b-85ef-21de45efbcef">
<fme:FEATURE_ID>1001110426</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829388.39</fme:EASTING>
<fme:NORTHING>821537.83</fme:NORTHING>
<fme:SPOTHEIGHT>53.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821537.82600 829388.38800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1d8e8643-502b-4bb9-94f7-6f363c36aefa">
<fme:FEATURE_ID>1001110346</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829109.2</fme:EASTING>
<fme:NORTHING>821546.43</fme:NORTHING>
<fme:SPOTHEIGHT>8.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821546.42600 829109.19800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcbc8f6ae-9938-4e48-af63-f0e9f8747900">
<fme:FEATURE_ID>1001110349</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829708.66</fme:EASTING>
<fme:NORTHING>821553.08</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821553.07464 829708.66261 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id29e1b057-11e6-4159-bb2d-cb37757d37bd">
<fme:FEATURE_ID>1001110252</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829191.02</fme:EASTING>
<fme:NORTHING>821564.73</fme:NORTHING>
<fme:SPOTHEIGHT>5.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821564.72600 829191.02400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2e295fae-83f7-4467-8004-7e0b3868b65f">
<fme:FEATURE_ID>1001110405</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827877.73</fme:EASTING>
<fme:NORTHING>821576.14</fme:NORTHING>
<fme:SPOTHEIGHT>177.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821576.14300 827877.72600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id07cf8f1f-5997-47e2-a85e-6b2fc968a46d">
<fme:FEATURE_ID>1001110240</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827362.61</fme:EASTING>
<fme:NORTHING>821579.56</fme:NORTHING>
<fme:SPOTHEIGHT>4.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821579.55900 827362.61350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1a9eb91f-305a-4a84-b195-308f596d28be">
<fme:FEATURE_ID>1001110226</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827741.71</fme:EASTING>
<fme:NORTHING>821585.15</fme:NORTHING>
<fme:SPOTHEIGHT>178.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821585.15100 827741.71200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id07018af1-3e8e-4955-a083-a4009b921b5e">
<fme:FEATURE_ID>1001110246</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827444.32</fme:EASTING>
<fme:NORTHING>821822.83</fme:NORTHING>
<fme:SPOTHEIGHT>4.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821822.82800 827444.31500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide40b65e3-176e-486b-af72-3d38d7d57ea5">
<fme:FEATURE_ID>1001110348</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829840</fme:EASTING>
<fme:NORTHING>821835.88</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821835.88327 829839.99542 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0c7159eb-7258-4721-8cfa-e02803ba1a20">
<fme:FEATURE_ID>1001110351</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829173.58</fme:EASTING>
<fme:NORTHING>821843.75</fme:NORTHING>
<fme:SPOTHEIGHT>7.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821843.74550 829173.58257 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idac683964-62aa-435b-b1ea-a0704e8f45bb">
<fme:FEATURE_ID>1001110245</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827559.34</fme:EASTING>
<fme:NORTHING>821900.08</fme:NORTHING>
<fme:SPOTHEIGHT>24.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821900.07470 827559.34180 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide595da4f-996e-4e2b-b525-7f69ed6410e6">
<fme:FEATURE_ID>1001110316</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829417.31</fme:EASTING>
<fme:NORTHING>821935.66</fme:NORTHING>
<fme:SPOTHEIGHT>5.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821935.66200 829417.30500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id81d5356f-e848-42c9-af38-26b40a5f537e">
<fme:FEATURE_ID>1001110404</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829653.68</fme:EASTING>
<fme:NORTHING>822032.03</fme:NORTHING>
<fme:SPOTHEIGHT>5.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822032.03046 829653.68071 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddc455c93-5cfa-49cc-bb26-d7e94e941d1c">
<fme:FEATURE_ID>1001110402</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827642.96</fme:EASTING>
<fme:NORTHING>822149.29</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822149.29162 827642.96221 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcbc74046-cbbd-4d0b-b347-380c7d229c24">
<fme:FEATURE_ID>1001110320</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829129.86</fme:EASTING>
<fme:NORTHING>822156.49</fme:NORTHING>
<fme:SPOTHEIGHT>6.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822156.48920 829129.86260 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf5323fe6-e5ae-44bc-94c5-f7aa2e5de94c">
<fme:FEATURE_ID>1001110403</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827835.67</fme:EASTING>
<fme:NORTHING>822184.62</fme:NORTHING>
<fme:SPOTHEIGHT>34.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822184.61841 827835.66519 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3b6b26bf-5a45-45e0-b526-eb9a9d4d002a">
<fme:FEATURE_ID>1001110415</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829184.41</fme:EASTING>
<fme:NORTHING>822253.53</fme:NORTHING>
<fme:SPOTHEIGHT>6.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822253.53100 829184.40800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd7cb0e3f-e378-4590-81f3-1f170cf6f231">
<fme:FEATURE_ID>1001110248</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827347.68</fme:EASTING>
<fme:NORTHING>822327.54</fme:NORTHING>
<fme:SPOTHEIGHT>7.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822327.54300 827347.68100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4e3d7d28-11e9-4630-9cdc-847ac85dcef7">
<fme:FEATURE_ID>1001110419</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829735.52</fme:EASTING>
<fme:NORTHING>822346.36</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822346.36200 829735.52350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id72cb43ea-5257-4d77-a463-77cb40080dcb">
<fme:FEATURE_ID>1001110247</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827495.21</fme:EASTING>
<fme:NORTHING>822350.45</fme:NORTHING>
<fme:SPOTHEIGHT>7.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822350.44600 827495.20500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idab76d8df-b250-4acd-ad92-018d0642d547">
<fme:FEATURE_ID>1001110353</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827733.5</fme:EASTING>
<fme:NORTHING>822383.1</fme:NORTHING>
<fme:SPOTHEIGHT>19.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822383.10100 827733.49900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida722d841-8ced-497c-ada5-996620646c6c">
<fme:FEATURE_ID>1210004690</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829003.07</fme:EASTING>
<fme:NORTHING>822384.85</fme:NORTHING>
<fme:SPOTHEIGHT>41.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822384.85420 829003.06690 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0d47e500-2b1d-427d-ac5f-7291fa88bec9">
<fme:FEATURE_ID>1001110227</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828374.28</fme:EASTING>
<fme:NORTHING>822384.89</fme:NORTHING>
<fme:SPOTHEIGHT>312.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822384.88600 828374.28400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb4457a06-5906-4be5-99bd-3d04ecd30f11">
<fme:FEATURE_ID>1001110427</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829120.65</fme:EASTING>
<fme:NORTHING>822446.43</fme:NORTHING>
<fme:SPOTHEIGHT>16.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822446.42800 829120.65100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6d06c31c-75a4-4f6c-8f34-cf5b20ba75a7">
<fme:FEATURE_ID>1001110317</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829458.17</fme:EASTING>
<fme:NORTHING>822448.77</fme:NORTHING>
<fme:SPOTHEIGHT>5.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822448.77400 829458.16700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id37a98f25-c878-40a7-9aa7-509fd1ab63b9">
<fme:FEATURE_ID>1420001320</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827636.34</fme:EASTING>
<fme:NORTHING>822457.31</fme:NORTHING>
<fme:SPOTHEIGHT>19</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822457.31080 827636.33949 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddbd69338-69ab-411a-999c-7cbb377a2b2a">
<fme:FEATURE_ID>1001110352</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827781.31</fme:EASTING>
<fme:NORTHING>822492.24</fme:NORTHING>
<fme:SPOTHEIGHT>18.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822492.23800 827781.31000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd767dea4-0c25-4e9e-85a5-6287c4413c36">
<fme:FEATURE_ID>1001110323</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829382.7</fme:EASTING>
<fme:NORTHING>822493.52</fme:NORTHING>
<fme:SPOTHEIGHT>6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822493.51600 829382.70400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id19f1b8b4-2f3a-4ff2-bb9f-d7d454e5065f">
<fme:FEATURE_ID>1001110399</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827957.53</fme:EASTING>
<fme:NORTHING>822499.6</fme:NORTHING>
<fme:SPOTHEIGHT>56.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822499.59571 827957.53061 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id281d09ec-1e1c-4b2c-acc4-def67d23f13c">
<fme:FEATURE_ID>1001110401</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829616.11</fme:EASTING>
<fme:NORTHING>822524.71</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822524.71200 829616.10850 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc3690448-3166-4c57-a730-e32b0fbe6944">
<fme:FEATURE_ID>1001110250</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827479.19</fme:EASTING>
<fme:NORTHING>822546.29</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822546.28800 827479.18600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide105e4e1-632e-4f6d-b90a-9d5ab1c4539e">
<fme:FEATURE_ID>1001110324</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829314.23</fme:EASTING>
<fme:NORTHING>822559.01</fme:NORTHING>
<fme:SPOTHEIGHT>6.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822559.00800 829314.22800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9bc8fd8c-2f5b-48e5-81ab-b915df111fb8">
<fme:FEATURE_ID>1001110282</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828904.74</fme:EASTING>
<fme:NORTHING>822592.18</fme:NORTHING>
<fme:SPOTHEIGHT>41.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822592.17900 828904.73500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc9b4e50d-7e16-49e9-ac14-c9792c574655">
<fme:FEATURE_ID>1001110421</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827848.09</fme:EASTING>
<fme:NORTHING>822602.44</fme:NORTHING>
<fme:SPOTHEIGHT>38.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822602.44221 827848.09222 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idadaa425d-dee6-40f3-8720-854dca2e75a5">
<fme:FEATURE_ID>1001110281</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829110.77</fme:EASTING>
<fme:NORTHING>822634.47</fme:NORTHING>
<fme:SPOTHEIGHT>23.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822634.46726 829110.76865 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3e800d32-a8d6-4190-856b-699a0c242012">
<fme:FEATURE_ID>1001110422</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827857.19</fme:EASTING>
<fme:NORTHING>822641.48</fme:NORTHING>
<fme:SPOTHEIGHT>39.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822641.48230 827857.19330 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9c87a0f3-a58b-452f-907e-b38b841d65d0">
<fme:FEATURE_ID>1001110274</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827745.7</fme:EASTING>
<fme:NORTHING>822650.6</fme:NORTHING>
<fme:SPOTHEIGHT>16.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822650.60200 827745.69600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbb44e622-b35e-4a67-ad7a-3a6d5df63e04">
<fme:FEATURE_ID>1001110284</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829482.96</fme:EASTING>
<fme:NORTHING>822657.2</fme:NORTHING>
<fme:SPOTHEIGHT>10.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822657.20000 829482.96000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1749b3a5-4a4b-4575-b121-c0abbe909610">
<fme:FEATURE_ID>1001110400</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829372.82</fme:EASTING>
<fme:NORTHING>822672.53</fme:NORTHING>
<fme:SPOTHEIGHT>16.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822672.53000 829372.82000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddb9f5e0d-e1f4-4f57-81a2-c3dfddc581f4">
<fme:FEATURE_ID>1310007630</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827931.99</fme:EASTING>
<fme:NORTHING>822684.43</fme:NORTHING>
<fme:SPOTHEIGHT>21.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822684.42888 827931.98991 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9de77f58-d721-4727-8574-61a53f0a76e0">
<fme:FEATURE_ID>1001110253</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827515.43</fme:EASTING>
<fme:NORTHING>822716.2</fme:NORTHING>
<fme:SPOTHEIGHT>7.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822716.19600 827515.43000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1b9b687c-b6d2-436e-9d95-2b195793df35">
<fme:FEATURE_ID>1001110228</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828385.9</fme:EASTING>
<fme:NORTHING>822735.88</fme:NORTHING>
<fme:SPOTHEIGHT>261.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822735.87800 828385.89600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8a68f64b-59c4-4846-bf5e-e9b8e2dd8ee3">
<fme:FEATURE_ID>1001110280</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828985.32</fme:EASTING>
<fme:NORTHING>822748.24</fme:NORTHING>
<fme:SPOTHEIGHT>32.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822748.24023 828985.32031 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7c7ce68a-5b84-4da4-b52c-38daf0c928eb">
<fme:FEATURE_ID>1310007631</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827751.41</fme:EASTING>
<fme:NORTHING>822770.42</fme:NORTHING>
<fme:SPOTHEIGHT>20.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822770.41863 827751.41143 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id17ff85c7-eddb-484d-9c46-136d4dc0258f">
<fme:FEATURE_ID>1001110366</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829226.57</fme:EASTING>
<fme:NORTHING>822770.45</fme:NORTHING>
<fme:SPOTHEIGHT>26.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822770.44800 829226.57250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0eedd60c-e2f4-4775-8917-3c2c2508aedc">
<fme:FEATURE_ID>1001110283</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829290.27</fme:EASTING>
<fme:NORTHING>822799.49</fme:NORTHING>
<fme:SPOTHEIGHT>26.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822799.49200 829290.27300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6b59a799-4df4-4553-b01f-8800bffb92b3">
<fme:FEATURE_ID>1001110325</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829511.72</fme:EASTING>
<fme:NORTHING>822800.78</fme:NORTHING>
<fme:SPOTHEIGHT>5.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822800.78000 829511.72000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idffd60db8-88cf-45a1-a739-204f94db473d">
<fme:FEATURE_ID>1001110255</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827241.36</fme:EASTING>
<fme:NORTHING>822847.15</fme:NORTHING>
<fme:SPOTHEIGHT>6.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822847.14975 827241.35956 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id94c67e76-964c-4f69-ab87-fe81f0561f9e">
<fme:FEATURE_ID>1001110326</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829513.27</fme:EASTING>
<fme:NORTHING>822868.71</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822868.70700 829513.26800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf20e779f-da6f-40b9-877b-ae1ccd726f09">
<fme:FEATURE_ID>1001110328</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829300.72</fme:EASTING>
<fme:NORTHING>822871.2</fme:NORTHING>
<fme:SPOTHEIGHT>26.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822871.20000 829300.72200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida9ad1f9e-08f1-4f7e-990a-cf702a8c878a">
<fme:FEATURE_ID>1001110275</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827807.93</fme:EASTING>
<fme:NORTHING>822872.39</fme:NORTHING>
<fme:SPOTHEIGHT>49.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822872.38700 827807.92750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idaf4ea1e0-019a-4225-8305-c72d2cd37c27">
<fme:FEATURE_ID>1001110273</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827463.67</fme:EASTING>
<fme:NORTHING>822908.06</fme:NORTHING>
<fme:SPOTHEIGHT>70</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822908.05735 827463.67381 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc161ea83-c4e4-4273-a1ae-185216853937">
<fme:FEATURE_ID>1420001321</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828558.44</fme:EASTING>
<fme:NORTHING>822909.23</fme:NORTHING>
<fme:SPOTHEIGHT>196.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822909.23001 828558.43987 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd811d4cc-ec5d-4ac5-ab54-85ebf649e167">
<fme:FEATURE_ID>1001110256</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826932.29</fme:EASTING>
<fme:NORTHING>822910.74</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822910.74300 826932.29300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8dadb51d-f469-4784-a2e7-f4a77222d100">
<fme:FEATURE_ID>1001110327</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829570.77</fme:EASTING>
<fme:NORTHING>822914.13</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822914.13000 829570.77000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7649ddd8-c181-4adc-940a-a2463aa0db36">
<fme:FEATURE_ID>1001110410</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829634.41</fme:EASTING>
<fme:NORTHING>822916.37</fme:NORTHING>
<fme:SPOTHEIGHT>4.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822916.36792 829634.40513 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id22fedfa8-86b5-4ffa-a0e9-2e9081556f61">
<fme:FEATURE_ID>1001110395</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827997.82</fme:EASTING>
<fme:NORTHING>822946.11</fme:NORTHING>
<fme:SPOTHEIGHT>86.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822946.11100 827997.81650 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide93df154-a9b8-45de-88c0-43f556833597">
<fme:FEATURE_ID>1001110365</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829383.03</fme:EASTING>
<fme:NORTHING>822972.3</fme:NORTHING>
<fme:SPOTHEIGHT>26.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822972.29500 829383.03400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1e2322f1-ee9c-4081-a07a-9d5cc35707fa">
<fme:FEATURE_ID>1001110254</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827041.69</fme:EASTING>
<fme:NORTHING>822981.18</fme:NORTHING>
<fme:SPOTHEIGHT>6.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822981.18300 827041.69200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddf8fb0f6-40be-4e2b-9df0-b78279b728b2">
<fme:FEATURE_ID>1001110270</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826759.53</fme:EASTING>
<fme:NORTHING>822984.22</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822984.21900 826759.52500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ided0b69aa-9509-48aa-b0bc-f3f35007904b">
<fme:FEATURE_ID>1001110272</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827381.86</fme:EASTING>
<fme:NORTHING>822998.98</fme:NORTHING>
<fme:SPOTHEIGHT>62.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822998.98000 827381.86000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id71ebb929-cfa5-4643-8de1-297a48f6a755">
<fme:FEATURE_ID>1001110235</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827845.48</fme:EASTING>
<fme:NORTHING>823031.53</fme:NORTHING>
<fme:SPOTHEIGHT>140.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823031.53400 827845.47600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd35f8296-4eba-424b-9678-51f95046d021">
<fme:FEATURE_ID>1001110288</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829422.9</fme:EASTING>
<fme:NORTHING>823044.74</fme:NORTHING>
<fme:SPOTHEIGHT>26.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823044.74300 829422.89700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf0a26dbf-bc1f-44fd-b80a-210d1c5a337b">
<fme:FEATURE_ID>1001110271</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827232.73</fme:EASTING>
<fme:NORTHING>823055.14</fme:NORTHING>
<fme:SPOTHEIGHT>59</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823055.13574 827232.73482 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id940df29d-fe8e-41e4-bcc7-4ab9b95577eb">
<fme:FEATURE_ID>1001110418</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827135.09</fme:EASTING>
<fme:NORTHING>823057.35</fme:NORTHING>
<fme:SPOTHEIGHT>61.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823057.34500 827135.08550 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id38c728af-3eea-48ff-86a9-75f1daddaff8">
<fme:FEATURE_ID>1001110277</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827940.47</fme:EASTING>
<fme:NORTHING>823059.45</fme:NORTHING>
<fme:SPOTHEIGHT>99.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823059.45287 827940.47283 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0b889305-0a90-4bcb-a10c-2f2c45ad160a">
<fme:FEATURE_ID>1310009290</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829352.44</fme:EASTING>
<fme:NORTHING>823061.07</fme:NORTHING>
<fme:SPOTHEIGHT>26.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241023</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823061.06978 829352.43891 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idda8aaa4b-8f2b-4713-95a1-7126cb1531e3">
<fme:FEATURE_ID>1001110305</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829164.09</fme:EASTING>
<fme:NORTHING>823064.84</fme:NORTHING>
<fme:SPOTHEIGHT>46.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823064.83500 829164.08900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id43da6e69-1b71-46b9-b5fe-d7ccc928a8d7">
<fme:FEATURE_ID>1001110276</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827630.71</fme:EASTING>
<fme:NORTHING>823078.06</fme:NORTHING>
<fme:SPOTHEIGHT>118.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823078.05600 827630.71100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id655d3cf8-8f40-45b3-bfe6-d4cfcc16ba75">
<fme:FEATURE_ID>1001110367</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828510.5</fme:EASTING>
<fme:NORTHING>823102.76</fme:NORTHING>
<fme:SPOTHEIGHT>113.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823102.75744 828510.50436 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id0a46cb83-5c3c-4641-9105-cdf0957959c1">
<fme:FEATURE_ID>1420001040</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829275.76</fme:EASTING>
<fme:NORTHING>823112.55</fme:NORTHING>
<fme:SPOTHEIGHT>67</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260107</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823112.54724 829275.75480 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8da8e9d5-a7cb-4aca-837b-c86f26eebcc2">
<fme:FEATURE_ID>1001110229</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827766.63</fme:EASTING>
<fme:NORTHING>823137.36</fme:NORTHING>
<fme:SPOTHEIGHT>150.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823137.36200 827766.62700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb96bff58-751a-4ef0-afdd-ca88594a06f4">
<fme:FEATURE_ID>1001110304</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829051.43</fme:EASTING>
<fme:NORTHING>823153.68</fme:NORTHING>
<fme:SPOTHEIGHT>81</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823153.67700 829051.43100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd9d40cbd-0cd1-46b9-95ad-6a40ae089436">
<fme:FEATURE_ID>1001110287</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829953.14</fme:EASTING>
<fme:NORTHING>823156.75</fme:NORTHING>
<fme:SPOTHEIGHT>4.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823156.74700 829953.14100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id07b583a2-3dc4-445f-98fa-4b127256b46b">
<fme:FEATURE_ID>1001110397</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829124.73</fme:EASTING>
<fme:NORTHING>823172.82</fme:NORTHING>
<fme:SPOTHEIGHT>53.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823172.82300 829124.73150 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd87decc4-f012-40b8-bcd5-1c5a3fc27334">
<fme:FEATURE_ID>1001110269</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826901.01</fme:EASTING>
<fme:NORTHING>823177.51</fme:NORTHING>
<fme:SPOTHEIGHT>5.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823177.50600 826901.00700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb220cd92-94a0-424a-a3e1-82333f1738b0">
<fme:FEATURE_ID>1001110413</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826791.76</fme:EASTING>
<fme:NORTHING>823194.45</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823194.44500 826791.76200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb924772d-f937-4de3-a5d1-25a1826f125c">
<fme:FEATURE_ID>1001110364</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828917.37</fme:EASTING>
<fme:NORTHING>823195.63</fme:NORTHING>
<fme:SPOTHEIGHT>73.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823195.62896 828917.36723 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id29b76d4a-a36b-4ec9-81e1-be0797a9d6f0">
<fme:FEATURE_ID>1001110398</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829426.92</fme:EASTING>
<fme:NORTHING>823197.43</fme:NORTHING>
<fme:SPOTHEIGHT>27.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823197.43200 829426.91800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id29fb98df-039c-4208-be4f-beffd033e5c7">
<fme:FEATURE_ID>1001110286</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829581.76</fme:EASTING>
<fme:NORTHING>823213.86</fme:NORTHING>
<fme:SPOTHEIGHT>25.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823213.86000 829581.76000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idceb096ca-2fa1-4f01-835e-597f045dc0e6">
<fme:FEATURE_ID>1001110329</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829266.77</fme:EASTING>
<fme:NORTHING>823220.33</fme:NORTHING>
<fme:SPOTHEIGHT>61.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823220.33300 829266.77300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id94b81978-23fd-4a5a-82bb-3e62411ded9b">
<fme:FEATURE_ID>1001110303</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829001.69</fme:EASTING>
<fme:NORTHING>823231.12</fme:NORTHING>
<fme:SPOTHEIGHT>55.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823231.12300 829001.68500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id4a6345cf-9208-45b8-9bce-3ad94e394699">
<fme:FEATURE_ID>1001110292</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828533.19</fme:EASTING>
<fme:NORTHING>823231.46</fme:NORTHING>
<fme:SPOTHEIGHT>68</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823231.45700 828533.19100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8dae86bd-fdb7-4a02-8706-ed4d77126e60">
<fme:FEATURE_ID>1001110396</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828041.84</fme:EASTING>
<fme:NORTHING>823258.6</fme:NORTHING>
<fme:SPOTHEIGHT>73.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823258.60000 828041.84350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id49d516ce-6bfa-474e-8d87-3f311208d3c5">
<fme:FEATURE_ID>1001110291</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829127.98</fme:EASTING>
<fme:NORTHING>823264.17</fme:NORTHING>
<fme:SPOTHEIGHT>52.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823264.16800 829127.98400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id93eba0ab-f51a-4f00-9369-d20b94b762ef">
<fme:FEATURE_ID>1001110363</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828974.9</fme:EASTING>
<fme:NORTHING>823279.91</fme:NORTHING>
<fme:SPOTHEIGHT>36.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823279.90600 828974.89600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id863c9378-91f0-4250-942b-f29086cc8429">
<fme:FEATURE_ID>1001110307</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829546.48</fme:EASTING>
<fme:NORTHING>823280.13</fme:NORTHING>
<fme:SPOTHEIGHT>21.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823280.13000 829546.48000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide486fe3c-405a-44e8-a286-8e45c6925818">
<fme:FEATURE_ID>1001110417</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828792.58</fme:EASTING>
<fme:NORTHING>823287.28</fme:NORTHING>
<fme:SPOTHEIGHT>56.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823287.27700 828792.58200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id78e6f4f6-8670-4636-8c37-acac7c98a865">
<fme:FEATURE_ID>1001110337</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826767.83</fme:EASTING>
<fme:NORTHING>823299.75</fme:NORTHING>
<fme:SPOTHEIGHT>5.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823299.75100 826767.83400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida5d59518-5ceb-45ff-a5c1-1d5b6fb5ea3c">
<fme:FEATURE_ID>1001110311</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829983.95</fme:EASTING>
<fme:NORTHING>823313.38</fme:NORTHING>
<fme:SPOTHEIGHT>26.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823313.38335 829983.94796 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3dcff746-6b60-4d7a-94cc-38e4df5ccb78">
<fme:FEATURE_ID>1001110285</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829534.46</fme:EASTING>
<fme:NORTHING>823324.48</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823324.48000 829534.46400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id018b6d7d-f3f4-43ca-ac06-ffcc21097e73">
<fme:FEATURE_ID>1001110302</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828831.55</fme:EASTING>
<fme:NORTHING>823329.99</fme:NORTHING>
<fme:SPOTHEIGHT>37.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823329.99000 828831.54600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id71ac08b1-9dd4-418b-a594-3d694d8dc88d">
<fme:FEATURE_ID>1001110234</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827464.56</fme:EASTING>
<fme:NORTHING>823330.63</fme:NORTHING>
<fme:SPOTHEIGHT>201.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823330.63200 827464.56300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3fe0e255-b0a8-402c-abc3-5bec6c011e45">
<fme:FEATURE_ID>1001110290</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829079.44</fme:EASTING>
<fme:NORTHING>823336.45</fme:NORTHING>
<fme:SPOTHEIGHT>39.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823336.45000 829079.43700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id614e27d8-6954-4305-8038-51124133fecb">
<fme:FEATURE_ID>1001110289</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828565.23</fme:EASTING>
<fme:NORTHING>823367.27</fme:NORTHING>
<fme:SPOTHEIGHT>57.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823367.27100 828565.22900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id407f3b84-2e62-4874-b055-8617088076cf">
<fme:FEATURE_ID>1001110412</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828056.64</fme:EASTING>
<fme:NORTHING>823384.1</fme:NORTHING>
<fme:SPOTHEIGHT>65.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823384.09900 828056.64350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5abd4968-c909-44d7-a770-bf96023ab5f8">
<fme:FEATURE_ID>1001110393</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828414.1</fme:EASTING>
<fme:NORTHING>823384.33</fme:NORTHING>
<fme:SPOTHEIGHT>57.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823384.33042 828414.09562 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id37cb05ba-3d8e-474e-84f2-839ddc80a81f">
<fme:FEATURE_ID>1001110231</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827597.52</fme:EASTING>
<fme:NORTHING>823384.74</fme:NORTHING>
<fme:SPOTHEIGHT>213.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823384.74300 827597.51800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbd5194ed-66ba-4524-924a-b26d4e8d0d29">
<fme:FEATURE_ID>1001110357</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828274.29</fme:EASTING>
<fme:NORTHING>823396.08</fme:NORTHING>
<fme:SPOTHEIGHT>58</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823396.07600 828274.29300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id33519df9-423e-4ffb-b233-6dc146dca1f0">
<fme:FEATURE_ID>1001110375</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827032.3</fme:EASTING>
<fme:NORTHING>823413.7</fme:NORTHING>
<fme:SPOTHEIGHT>60.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823413.70000 827032.30000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2e11e4cb-6e6c-4960-8eb9-5eb65b7d5477">
<fme:FEATURE_ID>1001110358</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828630.46</fme:EASTING>
<fme:NORTHING>823437.75</fme:NORTHING>
<fme:SPOTHEIGHT>57.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823437.75165 828630.46216 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id1b51a7a4-3e21-4fb9-a8eb-8cff643bca4e">
<fme:FEATURE_ID>1001110259</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826855.44</fme:EASTING>
<fme:NORTHING>823438.85</fme:NORTHING>
<fme:SPOTHEIGHT>5.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823438.85043 826855.43858 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc97e4da5-eb29-4ac7-aeeb-d26b2f06d6f9">
<fme:FEATURE_ID>1001110359</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829138.85</fme:EASTING>
<fme:NORTHING>823439.39</fme:NORTHING>
<fme:SPOTHEIGHT>18.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823439.38700 829138.85300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id967cc5e3-5fb2-4ad1-a89d-9df1b59b980b">
<fme:FEATURE_ID>1001110356</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828169.53</fme:EASTING>
<fme:NORTHING>823443.85</fme:NORTHING>
<fme:SPOTHEIGHT>58.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823443.84878 828169.53156 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf3ed5d6f-d517-4e9e-a7f3-392e49d0f45e">
<fme:FEATURE_ID>1001110310</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829932.54</fme:EASTING>
<fme:NORTHING>823453.75</fme:NORTHING>
<fme:SPOTHEIGHT>30.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823453.75400 829932.53850 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3d079da3-8e20-4d78-8190-dfc3160ac406">
<fme:FEATURE_ID>1001110306</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828974.26</fme:EASTING>
<fme:NORTHING>823459.92</fme:NORTHING>
<fme:SPOTHEIGHT>27.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823459.91700 828974.26200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc46f573c-f64b-47de-9d22-faa78b8faae3">
<fme:FEATURE_ID>1001110389</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829032.31</fme:EASTING>
<fme:NORTHING>823465.59</fme:NORTHING>
<fme:SPOTHEIGHT>25.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823465.58700 829032.31200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida8ba4fb7-8b3d-44c2-a877-0b18c854421e">
<fme:FEATURE_ID>1001110233</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827397</fme:EASTING>
<fme:NORTHING>823471</fme:NORTHING>
<fme:SPOTHEIGHT>200.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823471.00000 827397.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id8408aad0-5d3b-43c0-8978-b4d979b19a4f">
<fme:FEATURE_ID>1001110355</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828432.33</fme:EASTING>
<fme:NORTHING>823472.19</fme:NORTHING>
<fme:SPOTHEIGHT>52.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823472.19138 828432.32695 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6ae6ff5d-6151-457c-a337-bad5bc3d6172">
<fme:FEATURE_ID>1001110388</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829247.17</fme:EASTING>
<fme:NORTHING>823482.28</fme:NORTHING>
<fme:SPOTHEIGHT>12.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823482.28200 829247.17350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id896bc15d-9107-4ac5-b957-1cbd50741460">
<fme:FEATURE_ID>1001110258</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826968.16</fme:EASTING>
<fme:NORTHING>823489.03</fme:NORTHING>
<fme:SPOTHEIGHT>60.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823489.02600 826968.15700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd650853f-af4c-47ca-ab5f-2e8f672c3a62">
<fme:FEATURE_ID>1001110360</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828924.69</fme:EASTING>
<fme:NORTHING>823498.15</fme:NORTHING>
<fme:SPOTHEIGHT>29.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823498.15400 828924.68600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id99f4330d-3b21-4387-ac0f-8dfe3f3433c3">
<fme:FEATURE_ID>1001110354</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828265.89</fme:EASTING>
<fme:NORTHING>823515.04</fme:NORTHING>
<fme:SPOTHEIGHT>57.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823515.03900 828265.89100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc7f5ced6-0032-44fc-827d-a45344dfdd55">
<fme:FEATURE_ID>1001110297</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829441.2</fme:EASTING>
<fme:NORTHING>823519.23</fme:NORTHING>
<fme:SPOTHEIGHT>4.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823519.23000 829441.20000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd40b8a1e-989a-4bc2-89de-4315218ec936">
<fme:FEATURE_ID>1001110411</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828613.41</fme:EASTING>
<fme:NORTHING>823534.34</fme:NORTHING>
<fme:SPOTHEIGHT>39.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823534.33600 828613.41150 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide48ff21a-0012-4b08-8544-709c110b65a0">
<fme:FEATURE_ID>1001110377</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827242.96</fme:EASTING>
<fme:NORTHING>823543.55</fme:NORTHING>
<fme:SPOTHEIGHT>209.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823543.55400 827242.96150 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idf757bba2-6cea-411b-b8d3-37f74ddace2c">
<fme:FEATURE_ID>1001110278</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827471.22</fme:EASTING>
<fme:NORTHING>823554.37</fme:NORTHING>
<fme:SPOTHEIGHT>152.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823554.36700 827471.21700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2bd4a3d7-9274-496a-8a3f-3cef561cb430">
<fme:FEATURE_ID>1001110332</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826762.35</fme:EASTING>
<fme:NORTHING>823580.87</fme:NORTHING>
<fme:SPOTHEIGHT>5.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823580.86689 826762.35081 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idac0a0c5b-f077-48fb-8656-2ec73462940b">
<fme:FEATURE_ID>1001110309</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829850.7</fme:EASTING>
<fme:NORTHING>823620</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823620.00000 829850.70000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="iddc6150a5-6968-4216-add0-a1c2579a7b47">
<fme:FEATURE_ID>1001110331</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826927.87</fme:EASTING>
<fme:NORTHING>823624</fme:NORTHING>
<fme:SPOTHEIGHT>72.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823624.00377 826927.87174 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id388d9f7e-4965-4133-adbd-4ee4a10b6aa3">
<fme:FEATURE_ID>1001110294</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829069.76</fme:EASTING>
<fme:NORTHING>823630.48</fme:NORTHING>
<fme:SPOTHEIGHT>7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823630.48500 829069.76290 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id86d8dc72-9d46-4e54-9648-c52033e292e2">
<fme:FEATURE_ID>1001110384</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828950.36</fme:EASTING>
<fme:NORTHING>823633.92</fme:NORTHING>
<fme:SPOTHEIGHT>22.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823633.92000 828950.35950 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9eb006a8-edc9-4bed-a9d8-847ef1bca33f">
<fme:FEATURE_ID>1001110374</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826563.53</fme:EASTING>
<fme:NORTHING>823683.48</fme:NORTHING>
<fme:SPOTHEIGHT>6.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823683.48442 826563.53204 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida71e9875-f0e2-4312-92f9-071b4664039a">
<fme:FEATURE_ID>1001110295</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829277.14</fme:EASTING>
<fme:NORTHING>823687.52</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823687.52000 829277.14000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida27fac45-8e7b-4b7c-9894-50457a0714c1">
<fme:FEATURE_ID>1001110298</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828187.32</fme:EASTING>
<fme:NORTHING>823692.89</fme:NORTHING>
<fme:SPOTHEIGHT>46.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823692.88702 828187.31926 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9032638c-45eb-4b93-987c-83bfe0edf0db">
<fme:FEATURE_ID>1001110390</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828809.87</fme:EASTING>
<fme:NORTHING>823697.23</fme:NORTHING>
<fme:SPOTHEIGHT>7.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823697.22855 828809.86631 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6f262f05-1229-4d4c-aea9-0b0d4f8b55e5">
<fme:FEATURE_ID>1001110386</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829064.32</fme:EASTING>
<fme:NORTHING>823699.56</fme:NORTHING>
<fme:SPOTHEIGHT>6.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823699.55784 829064.31974 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5941e15c-d4f6-41e0-81e5-04b29cf5e400">
<fme:FEATURE_ID>1001110267</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826822.24</fme:EASTING>
<fme:NORTHING>823701.82</fme:NORTHING>
<fme:SPOTHEIGHT>63.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823701.82435 826822.24436 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7b0f9ba0-3fef-491d-8a31-6b67d0490816">
<fme:FEATURE_ID>1001110261</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827286.45</fme:EASTING>
<fme:NORTHING>823710.14</fme:NORTHING>
<fme:SPOTHEIGHT>185.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823710.14400 827286.45400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbbd6914d-d5af-4a2f-9022-60eee0952d37">
<fme:FEATURE_ID>1001110383</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828622.7</fme:EASTING>
<fme:NORTHING>823722.07</fme:NORTHING>
<fme:SPOTHEIGHT>8.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823722.06815 828622.69670 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idae14faf1-4f25-4812-a6e1-ea64c9d7123f">
<fme:FEATURE_ID>1001110308</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829781.29</fme:EASTING>
<fme:NORTHING>823725.98</fme:NORTHING>
<fme:SPOTHEIGHT>5.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823725.98300 829781.28700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida2df3d95-4545-4fac-9efd-26d25c46ada7">
<fme:FEATURE_ID>1001110262</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826465.55</fme:EASTING>
<fme:NORTHING>823730.4</fme:NORTHING>
<fme:SPOTHEIGHT>5.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823730.39517 826465.55442 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida70172cb-a74e-4592-a120-e449d61327e3">
<fme:FEATURE_ID>1001110293</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828456.52</fme:EASTING>
<fme:NORTHING>823730.86</fme:NORTHING>
<fme:SPOTHEIGHT>10</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823730.85480 828456.51660 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd46019e3-92a6-43f0-8791-8b52f83b1345">
<fme:FEATURE_ID>1001110338</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826835.1</fme:EASTING>
<fme:NORTHING>823743.49</fme:NORTHING>
<fme:SPOTHEIGHT>68.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823743.48600 826835.10300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id45e57380-c92e-4bea-a079-849c8aedee1c">
<fme:FEATURE_ID>1001110376</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826934.95</fme:EASTING>
<fme:NORTHING>823763.96</fme:NORTHING>
<fme:SPOTHEIGHT>70.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823763.96320 826934.94627 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idb20fb9b3-9e83-4b17-8bb6-670c3a6259cb">
<fme:FEATURE_ID>1001110371</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826338.18</fme:EASTING>
<fme:NORTHING>823765.88</fme:NORTHING>
<fme:SPOTHEIGHT>69.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823765.88177 826338.18083 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id09221616-4aa2-4803-ae1c-6000efb730ee">
<fme:FEATURE_ID>1001110336</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826609.26</fme:EASTING>
<fme:NORTHING>823783.57</fme:NORTHING>
<fme:SPOTHEIGHT>57.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823783.56888 826609.25857 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id872d22a1-2db5-46bd-b74c-d8c0ca81f6a1">
<fme:FEATURE_ID>1001110387</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829110.06</fme:EASTING>
<fme:NORTHING>823784.64</fme:NORTHING>
<fme:SPOTHEIGHT>6.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823784.64070 829110.05680 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id76707562-d6b8-430f-bc60-f90169f41068">
<fme:FEATURE_ID>1001110312</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828007.62</fme:EASTING>
<fme:NORTHING>823791.67</fme:NORTHING>
<fme:SPOTHEIGHT>42.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823791.67010 828007.61870 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide3a0edff-749a-48d0-8d3b-bfc0b626a566">
<fme:FEATURE_ID>1001110380</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828607.96</fme:EASTING>
<fme:NORTHING>823792.6</fme:NORTHING>
<fme:SPOTHEIGHT>9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823792.60222 828607.96444 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id17cfb618-df03-4ece-a78c-6b167e1c0a8c">
<fme:FEATURE_ID>1001110369</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827557.26</fme:EASTING>
<fme:NORTHING>823796.37</fme:NORTHING>
<fme:SPOTHEIGHT>84</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823796.36700 827557.25800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3407fe0c-801c-4d18-900b-591510a33536">
<fme:FEATURE_ID>1001110266</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826811.43</fme:EASTING>
<fme:NORTHING>823807.93</fme:NORTHING>
<fme:SPOTHEIGHT>70.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823807.92587 826811.42759 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6a2eb8a0-abf5-4052-bbb0-e1a5b77b6150">
<fme:FEATURE_ID>1001110335</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826693.38</fme:EASTING>
<fme:NORTHING>823815.79</fme:NORTHING>
<fme:SPOTHEIGHT>74.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823815.78800 826693.38100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7110b452-9883-4aa6-a3f6-a76701be611c">
<fme:FEATURE_ID>1001110279</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827862.92</fme:EASTING>
<fme:NORTHING>823821.16</fme:NORTHING>
<fme:SPOTHEIGHT>42.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823821.15510 827862.92380 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida2dd63af-3788-41ac-84a1-d5ce69edf895">
<fme:FEATURE_ID>1001110378</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828106.02</fme:EASTING>
<fme:NORTHING>823824.6</fme:NORTHING>
<fme:SPOTHEIGHT>54.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823824.59500 828106.01950 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcb899ec2-981d-4ecb-b142-17fcb12bab07">
<fme:FEATURE_ID>1001110368</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827576.7</fme:EASTING>
<fme:NORTHING>823847.1</fme:NORTHING>
<fme:SPOTHEIGHT>82.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823847.09600 827576.70400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ida0c90ac7-6ecd-4543-b94d-15d1c7b228b0">
<fme:FEATURE_ID>1001110391</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829284.75</fme:EASTING>
<fme:NORTHING>823847.75</fme:NORTHING>
<fme:SPOTHEIGHT>5.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823847.75430 829284.75150 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfde4a1cc-99fc-49e3-8cfd-72f8cfea094b">
<fme:FEATURE_ID>1001110382</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828748.36</fme:EASTING>
<fme:NORTHING>823848.4</fme:NORTHING>
<fme:SPOTHEIGHT>7.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823848.40100 828748.36220 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id5bf687ca-ea0c-445e-a137-fd9c31de6a33">
<fme:FEATURE_ID>1001110362</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829112.19</fme:EASTING>
<fme:NORTHING>823849.86</fme:NORTHING>
<fme:SPOTHEIGHT>6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823849.86100 829112.18700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id25400671-5b3f-4861-9a47-d5151e6f0f9a">
<fme:FEATURE_ID>1001110373</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826845.37</fme:EASTING>
<fme:NORTHING>823853.85</fme:NORTHING>
<fme:SPOTHEIGHT>62.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823853.85400 826845.37300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id7140fd55-9b6d-4417-8bea-81f0ab683131">
<fme:FEATURE_ID>1001110334</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826704.8</fme:EASTING>
<fme:NORTHING>823855</fme:NORTHING>
<fme:SPOTHEIGHT>69.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823855.00000 826704.80000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id145d05a3-ee53-4050-94de-3ef1b1fca0ec">
<fme:FEATURE_ID>1001110260</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827082.77</fme:EASTING>
<fme:NORTHING>823868.6</fme:NORTHING>
<fme:SPOTHEIGHT>146.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823868.59900 827082.77000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idaca5261b-60f4-49cd-83a1-41cfd06439b8">
<fme:FEATURE_ID>1001110372</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826589.31</fme:EASTING>
<fme:NORTHING>823887.38</fme:NORTHING>
<fme:SPOTHEIGHT>66.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823887.38400 826589.30900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id97e23e66-666c-4f3a-9519-fdb10e30cdd2">
<fme:FEATURE_ID>1001110392</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829293.23</fme:EASTING>
<fme:NORTHING>823894.22</fme:NORTHING>
<fme:SPOTHEIGHT>5.1</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823894.22340 829293.22700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9fa7d70e-4920-4f79-a049-bef97075fe3f">
<fme:FEATURE_ID>1001110268</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826918.18</fme:EASTING>
<fme:NORTHING>823895.38</fme:NORTHING>
<fme:SPOTHEIGHT>74.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823895.37978 826918.18121 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id3e4199c0-d866-4d86-8529-9075f16b02a8">
<fme:FEATURE_ID>1001110370</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828145.18</fme:EASTING>
<fme:NORTHING>823937.32</fme:NORTHING>
<fme:SPOTHEIGHT>54.5</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823937.32200 828145.18400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2ced9905-4327-415b-8bb1-88dddeeb9adc">
<fme:FEATURE_ID>1001110230</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827339.7</fme:EASTING>
<fme:NORTHING>823949.16</fme:NORTHING>
<fme:SPOTHEIGHT>180.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823949.16000 827339.69900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id9c3a71d0-0f81-43be-ae49-8a1d4ba42874">
<fme:FEATURE_ID>1001110385</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829057.46</fme:EASTING>
<fme:NORTHING>823957.3</fme:NORTHING>
<fme:SPOTHEIGHT>6.3</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823957.29500 829057.46350 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbff9d606-6189-4103-a57e-fce142bf04b5">
<fme:FEATURE_ID>1001110264</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826759.47</fme:EASTING>
<fme:NORTHING>823960.72</fme:NORTHING>
<fme:SPOTHEIGHT>61</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823960.72462 826759.47222 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idd6fe3138-b118-46a6-8369-490b566d512d">
<fme:FEATURE_ID>1001110265</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826836.67</fme:EASTING>
<fme:NORTHING>823961.43</fme:NORTHING>
<fme:SPOTHEIGHT>76.9</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823961.43181 826836.66870 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id6fb564ad-0b57-4b0a-89bb-5ead4917de15">
<fme:FEATURE_ID>1001110301</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828402.22</fme:EASTING>
<fme:NORTHING>823969.9</fme:NORTHING>
<fme:SPOTHEIGHT>10</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823969.90200 828402.21700 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idcdbe9c82-d406-4c84-ad54-8c41c846a1f1">
<fme:FEATURE_ID>1001110299</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828282.67</fme:EASTING>
<fme:NORTHING>823971.92</fme:NORTHING>
<fme:SPOTHEIGHT>35.2</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823971.92000 828282.67400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idc056b66d-1176-4eda-acaa-c9293dad5eb5">
<fme:FEATURE_ID>1001110381</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828585.08</fme:EASTING>
<fme:NORTHING>823988.08</fme:NORTHING>
<fme:SPOTHEIGHT>10</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823988.08453 828585.08467 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbb8b3e84-d36f-4550-bcd8-9b363a8a8a51">
<fme:FEATURE_ID>1001110263</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826671.07</fme:EASTING>
<fme:NORTHING>823989.55</fme:NORTHING>
<fme:SPOTHEIGHT>59.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>7</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823989.55067 826671.07354 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbb672eb5-7c76-49bb-ad80-eb9e4147c925">
<fme:FEATURE_ID>1001110379</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828728.56</fme:EASTING>
<fme:NORTHING>823993.17</fme:NORTHING>
<fme:SPOTHEIGHT>8.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823993.17200 828728.55750 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
</gml:FeatureCollection>
