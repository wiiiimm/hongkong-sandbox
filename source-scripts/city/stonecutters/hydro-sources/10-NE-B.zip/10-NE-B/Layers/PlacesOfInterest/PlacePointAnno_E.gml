<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821070.28445 826495.91436</gml:lowerCorner>
<gml:upperCorner>823930.70377 829920.24295</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idcc08978a-b5b5-46e7-8bc2-ca37911a97f7">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Fai San Tsuen</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.186020262530449</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967088</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828650.392</fme:EASTING>
<fme:NORTHING>823704.062</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281672</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823704.06230 828650.39221</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id0cf100a3-d2eb-409b-9956-7aebfb387fa3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CHUN FA LOK</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967064</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828902.643</fme:EASTING>
<fme:NORTHING>822082.703</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279201</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822082.70270 828902.64329</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idad34753f-f0b7-4467-9c08-7620e58fc426">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SHEUNG KO TAN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>9</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967061</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828629.948</fme:EASTING>
<fme:NORTHING>823646.229</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278576</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823646.22914 828629.94806</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idd275af80-24d9-49d8-9dcc-0d06b0260596">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tien Chu (Tsing Yi)
Industrial Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.00000000161162</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967105</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828825.729</fme:EASTING>
<fme:NORTHING>821273.788</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79097</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310014672</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821273.74878 828825.72871</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id69f5dfa1-8c71-400a-926e-5dcf0b5142c1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SHEK WAN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967063</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>827167.383</fme:EASTING>
<fme:NORTHING>823690.942</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278949</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823690.94185 827167.38341</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idf2e01f50-9b21-4bf6-a393-eed20eedcfe3">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Yiu Lian Dockyards Limited</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.881384835036674</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967096</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827492.623</fme:EASTING>
<fme:NORTHING>822251.363</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70305</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283469</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822251.36294 827492.62276</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id696c2800-dd10-40b9-8bc1-8c645e0c65ec">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Greenfield
Garden</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967074</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829199.289</fme:EASTING>
<fme:NORTHING>823670.593</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278573</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823670.59295 829199.28913</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idf6e6c004-e6de-4e08-8f93-43b5bc818f36">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Ching Wah Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967077</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828286.644</fme:EASTING>
<fme:NORTHING>823320.893</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278582</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823320.89350 828286.64399</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idfecae1d1-caaf-488e-93de-06f350b67376">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>NAM WAN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967059</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828003.867</fme:EASTING>
<fme:NORTHING>822269.287</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279479</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822269.28705 828003.86671</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idc4817013-05dc-46c6-9b68-7d3849b1f0f4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>RAMBLER CHANNEL
TYPHOON SHELTER</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.100000281584588</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967118</fme:FEATURE_ID>
<fme:FEATURECODE>TYP</fme:FEATURECODE>
<fme:EASTING>829920.243</fme:EASTING>
<fme:NORTHING>823809.34</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>80015</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006754</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823809.29756 829920.24295</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id6d65f666-54ee-41c0-a5cb-7a0ec0f5a494">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>NAM WAN KOK</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967120</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828878.662</fme:EASTING>
<fme:NORTHING>821505.469</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279481</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821505.46928 828878.66211</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id28ab2bd7-9316-41cf-9967-f49c72b8fd51">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967112</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829370.526</fme:EASTING>
<fme:NORTHING>821872.788</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821872.78760 829370.52578</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9a7d0c44-0765-4fe5-a354-b139dba0ef60">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Sinopec Hong Kong
Oil Terminal</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967113</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828841.074</fme:EASTING>
<fme:NORTHING>821070.323</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70071</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283329</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821070.28445 828841.07385</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id5b3cf761-142c-4d35-9811-a273a6776be1">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Trinseo (Hong Kong) Limited
Tsing Yi Site</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967093</fme:FEATURE_ID>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:EASTING>829080.814</fme:EASTING>
<fme:NORTHING>821458.677</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70073</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210010287</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821458.63832 829080.81385</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idd1d29347-e38d-47a5-b79f-c9d28843107a">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tai Wong Ha
Resite Village</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967083</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828342.94584506</fme:EASTING>
<fme:NORTHING>823913.39299107</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279777</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823917.26215 828337.96733</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id4921ad02-546b-4966-9cb8-fae50d8f0008">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967109</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828115.483</fme:EASTING>
<fme:NORTHING>821184.769</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821184.76911 828115.48291</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id19a2edcb-7aca-421c-8d8c-117c01ab65b9">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Yi Preliminary
Treatment Works</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967115</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829400.052</fme:EASTING>
<fme:NORTHING>822808.227</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77858</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283334</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822808.18865 829400.05174</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id8bb7b9fa-499e-41c4-932d-40415078878f">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Grand Horizon</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967069</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829328.903</fme:EASTING>
<fme:NORTHING>823695.592</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280817</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823695.59156 829328.90267</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id14df2b53-3f0c-47cb-9c88-e68ac562f1b1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>KAM CHUK KOK</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967062</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>827427.055</fme:EASTING>
<fme:NORTHING>823157.232</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279287</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823157.23229 827427.05508</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idd2cf2d45-c927-4616-a464-e380889cb156">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cheung Hong Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967070</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828396.987</fme:EASTING>
<fme:NORTHING>823449.922</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278583</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823449.92202 828396.98731</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id0df9fb0a-c6da-46ba-997f-93b67391cc09">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Rambler
Crest</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967081</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829408.198</fme:EASTING>
<fme:NORTHING>822654.567</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281470</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822654.52450 829408.19763</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idf16501d0-97e6-4aeb-97af-aa0b043fe13f">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Mount Haven</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967080</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>827931.595</fme:EASTING>
<fme:NORTHING>823765.286</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280816</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823765.28607 827931.59526</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id34241fa0-0195-467e-b9d5-0cd7bceea41c">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Chemical Waste Treatment Facilities</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>32.4184518689598</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967106</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829113.67</fme:EASTING>
<fme:NORTHING>821296.06</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>78851</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283467</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821296.05991 829113.66969</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id177c0e5d-a9ea-4c98-b38a-5a63ee47fbdb">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Yi Garden</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967067</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828880.042</fme:EASTING>
<fme:NORTHING>823838.397</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278569</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823838.39653 828880.04217</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id012cd718-1f84-49a0-a2e8-bd57903332a2">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>San Uk
Resite Village</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967086</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828292.1643479</fme:EASTING>
<fme:NORTHING>823826.33866061</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280815</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823837.25404 828333.89830</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9817ba5c-490e-4d16-9839-1f900d0ef480">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Yi Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967068</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828659.92544977</fme:EASTING>
<fme:NORTHING>823910.97734075</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75418</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279830</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823909.19658 828659.93045</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id8888126a-1633-4993-8bbb-4fb30bb80937">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Liu To</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967082</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>827879.71833268</fme:EASTING>
<fme:NORTHING>823638.71819775</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64054</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278580</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823639.56251 827881.83410</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idb33fa91e-3060-450c-852a-825181edc83c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>RAMBLER CHANNEL</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>13</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.3153573583859</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967117</fme:FEATURE_ID>
<fme:FEATURECODE>BAY</fme:FEATURECODE>
<fme:EASTING>829878.044</fme:EASTING>
<fme:NORTHING>822817.595</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001281817</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822817.59504 829878.04409</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id71676751-ee21-427d-8a97-0adce61cdd51">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Mayfair Gardens</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967076</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829097.119</fme:EASTING>
<fme:NORTHING>822780.052</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278579</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822780.05190 829097.11925</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id621eac9f-0f64-4270-b43c-b43fc1d54738">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Yim Tin Kok
Resite Village</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967084</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828279.27769703</fme:EASTING>
<fme:NORTHING>823729.87896852</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279943</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823735.00074 828279.93592</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id3092f2b4-ab82-4826-8096-8a737a0f93aa">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cheung Hong Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967075</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828807.312</fme:EASTING>
<fme:NORTHING>823444.249</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278583</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823444.24857 828807.31223</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idb625b073-ded4-43b2-9faa-8e7385a48804">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SAI TSO WAN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967066</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>827701.076</fme:EASTING>
<fme:NORTHING>822557.615</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279574</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822557.61508 827701.07579</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id47d0eb41-3c1c-4dff-b97c-b0ee2ed7330f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Breakwater</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967089</fme:FEATURE_ID>
<fme:FEATURECODE>TYP</fme:FEATURECODE>
<fme:EASTING>829816.55640197</fme:EASTING>
<fme:NORTHING>823954.63678882</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823930.70377 829828.21615</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id29865610-32d3-4629-9fcc-b05bfb6b29d7">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HA KO TAN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>9</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967060</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>829050.093</fme:EASTING>
<fme:NORTHING>823555.571</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278577</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823555.57062 829050.09251</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id020ba410-144e-4dc1-9d38-5312fee2c09e">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Chevron Hong Kong Limited
Tsing Yi Terminal</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967101</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827405.998</fme:EASTING>
<fme:NORTHING>822347.253</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70304</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001284141</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822347.21417 827405.99809</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id5cb72128-1e27-457d-84aa-ab0d7fea4710">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>ExxonMobil
Tsing Yi Terminal (East)</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967104</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828385.724</fme:EASTING>
<fme:NORTHING>821136.543</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70069</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001284052</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821136.50436 828385.72427</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id8e3e6cd1-9b63-4e5b-8883-00d502fd4cb2">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>NAM WAN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967058</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828068.987</fme:EASTING>
<fme:NORTHING>821460.855</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279480</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821460.85464 828068.98721</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id98f84bb0-7913-4e6d-97a4-dccdb0da63ff">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hong Kong
United Dockyards</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967097</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>826728.264</fme:EASTING>
<fme:NORTHING>823499.395</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>78400</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310012215</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823499.35672 826728.26375</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idcf224818-bde2-4775-92cf-adb6b25a3a8e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tivoli Garden</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967079</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829162.851</fme:EASTING>
<fme:NORTHING>823919.689</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280814</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823919.68869 829162.85139</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9c0bd391-dc38-4f26-b31a-5463ef9a00d5">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Lam Tin
Resite Village</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967085</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828471.20255308</fme:EASTING>
<fme:NORTHING>823580.94556431</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278581</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823583.56211 828469.44367</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idf3ff63e6-5fad-4367-a80d-f1a316c354a3">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open
Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967090</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827471.62339641</fme:EASTING>
<fme:NORTHING>821310.73645854</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821312.60543 827471.62840</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id3c3e300f-b6ac-4ca9-a2b7-089b4bb554ac">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>TSING YI</fme:TextString>
<fme:FontName>Cambria</fme:FontName>
<fme:FontSize>20.0000000018626</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967119</fme:FEATURE_ID>
<fme:FEATURECODE>ISL</fme:FEATURECODE>
<fme:EASTING>828471.50472339</fme:EASTING>
<fme:NORTHING>822671.93598193</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001277511</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822671.93598 828471.50972</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id065053f3-0e2f-4208-a202-e88989d1c150">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SAI SHAN</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>14</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967065</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>829302.072</fme:EASTING>
<fme:NORTHING>822702.562</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278584</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822702.56154 829302.07247</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idb3645641-30ea-475c-92ba-746d713d97f1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Chung Mei
Lo Uk Village</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.186020262530449</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967087</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828834.98133929</fme:EASTING>
<fme:NORTHING>823573.79809289</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278578</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823580.99317 828869.89419</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id11aa6bec-4ca5-4354-bb63-9c8855ce84bf">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cheung Ching
Estate</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7.00000000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967073</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829297.512</fme:EASTING>
<fme:NORTHING>823295.539</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310016511</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823295.53854 829297.51165</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id0ae3191c-31b1-4e17-9ad5-8f360e407543">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Serene Garden</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000967071</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829165.384</fme:EASTING>
<fme:NORTHING>823860.304</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279102</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823860.30385 829165.38396</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9afe3302-6568-4e63-9ce0-14348e158079">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Goodman 
Interlink</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001242</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829235.918</fme:EASTING>
<fme:NORTHING>821431.554</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821431.51507 829235.91810</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id019b4bc7-5436-4639-ad88-23765f7fc16b">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001502</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829491.286</fme:EASTING>
<fme:NORTHING>821159.797</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821159.79747 829491.28646</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idd69d5463-7931-45ba-b064-92df38d57d2e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Greenview Villa</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004463</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828760.756</fme:EASTING>
<fme:NORTHING>823767.16</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210004224</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823767.15986 828760.75616</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="idddf819d7-2d16-4381-8680-f96216f82855">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006169</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829264.643</fme:EASTING>
<fme:NORTHING>821801.704</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821801.70372 829264.64304</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id26fdc807-e864-4c3d-961d-bbc39a660a94">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Yi Industrial Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.5520010941611</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007051</fme:FEATURE_ID>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:EASTING>829440.697</fme:EASTING>
<fme:NORTHING>823384.034</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823384.03371 829440.69719</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id8282d609-6eae-45c3-a5c1-c037bb983ec3">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>China Merchants Logistics Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-2.99998755580804</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010299</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829415.693</fme:EASTING>
<fme:NORTHING>821649.006</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82522</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007147</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821649.00645 829415.69262</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id4e87cb0e-9841-4e4c-8de8-6f150713f0a9">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Asia Logistics Hub - SF Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010300</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829406.162</fme:EASTING>
<fme:NORTHING>821770.734</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82173</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007146</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821770.73437 829406.16155</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id38ea29e1-c737-496e-9665-6c73ba70dabf">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210013239</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829477.851</fme:EASTING>
<fme:NORTHING>821271.763</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821271.76321 829477.85057</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id873b733e-851e-4fc1-b9c9-eaec2e712f00">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Yi East Fresh Water
Service Reservoir</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210013260</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>829009.54</fme:EASTING>
<fme:NORTHING>823078.984</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71202</fme:ST_CODE>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823078.94513 829009.53971</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id1a94f67c-3312-45ba-ad67-bb66ad1a4f46">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Shell Tsing Yi Installation</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210013380</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827160.543</fme:EASTING>
<fme:NORTHING>822829.435</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70303</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001284140</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822943.56325 826855.68829</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id9e9e7350-c45b-49e8-9754-6be0161f44a9">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Bus Depot</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014859</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822311.70905 827790.22985</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id836a4fbc-74dc-401d-85fd-b5451f060223">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>The Grand Marine</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310016220</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828952.549</fme:EASTING>
<fme:NORTHING>822813.444</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015165</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822813.44405 828952.54875</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id7d1699ec-5173-438a-b5c0-0f56f92a1a1a">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Ching Fu
Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310016781</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829162.288</fme:EASTING>
<fme:NORTHING>822546.045</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210009897</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822546.04501 829162.28782</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id211fdd66-0fbc-419e-8530-67ce42d02cf1">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Cement Works</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310018480</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>826495.914</fme:EASTING>
<fme:NORTHING>823590.549</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823590.54892 826495.91436</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id446f0522-e9b7-4082-b99c-b9fde561d0f8">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Open Storage</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310018460</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829164.049</fme:EASTING>
<fme:NORTHING>821192.736</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821192.73587 829164.04907</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id89fc52e9-5ee0-41bb-8f3d-f07973839765">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Euroasia Dockyard</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810239542</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827320.523</fme:EASTING>
<fme:NORTHING>821401.454</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70268</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283468</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821401.45358 827320.52275</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id0616314a-1751-4e0e-a88c-aa4dd9fc2477">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Mapletree Logistics Hub</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>7</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810240183</fme:FEATURE_ID>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:EASTING>829169.659</fme:EASTING>
<fme:NORTHING>822117.757</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1420001861</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822117.75739 829169.65889</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id016e1b22-e2c6-49e4-a3a6-3659c2d8e596">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>CLP - Tsing Yi Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5.99999997764826</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810240222</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828289.055</fme:EASTING>
<fme:NORTHING>821245.325</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70070</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003953</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821245.32465 828289.05464</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_E gml:id="id652acf7f-0fe0-4e50-8806-fd4361cc4544">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>VSC Construction Steel Solutions</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810240182</fme:FEATURE_ID>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:EASTING>827461.993</fme:EASTING>
<fme:NORTHING>821081.186</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1420001156</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821081.18614 827461.99346</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
