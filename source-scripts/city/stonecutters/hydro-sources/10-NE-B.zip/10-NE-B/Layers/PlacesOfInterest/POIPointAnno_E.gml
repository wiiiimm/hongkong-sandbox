<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821718.84663 826713.23913</gml:lowerCorner>
<gml:upperCorner>823889.67279 829809.60396</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idcdda1087-6d8b-4b33-b962-54d8bccf06e8">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.0599934587869771</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000891</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>826714.428</fme:EASTING>
<fme:NORTHING>823086.784</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008000</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823086.78358 826714.42849</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id9938db04-3191-4ffa-b9ce-96e5f3cc01a7">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000892</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827259.081</fme:EASTING>
<fme:NORTHING>822665.688</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007900</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822665.68753 827259.08110</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id6f8f5967-f8a3-487f-9a67-e4d597134afb">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000893</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827350.961</fme:EASTING>
<fme:NORTHING>822640.818</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008051</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822640.81753 827350.96110</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id2f8b5496-798b-4113-9619-6b4eabe1eba8">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000925</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827120.951</fme:EASTING>
<fme:NORTHING>822675.738</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007955</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822675.73753 827120.95110</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idb767fdbc-1129-4eb6-8e1f-39684903ec92">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000953</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827173.846</fme:EASTING>
<fme:NORTHING>822213.667</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007997</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822213.66712 827173.84575</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id7f4eb53a-cc2c-4a2f-b910-eccb38e2f1a8">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000954</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>826920.123</fme:EASTING>
<fme:NORTHING>822620.299</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008093</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822620.29903 826920.12295</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idf42b0c75-5bb8-4d9f-a863-1c55245b3d07">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000965</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827194.281</fme:EASTING>
<fme:NORTHING>822676.368</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008087</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822676.36753 827194.28110</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idc72b2784-0492-488d-9990-011c7b1a0914">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000992</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827367.81</fme:EASTING>
<fme:NORTHING>822132.441</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008053</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822132.44061 827367.80988</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id96898be0-98d6-4f37-8e7c-4b9d467678ae">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000998</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>826713.239</fme:EASTING>
<fme:NORTHING>822951.834</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008050</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822951.83364 826713.23913</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idfa275821-869f-4014-a403-389cb79c2b5c">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pier</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001065</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827272.833</fme:EASTING>
<fme:NORTHING>822477.027</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007793</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822477.02663 827272.83306</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="idf3dcdcc3-65c8-4f56-b1eb-245ba01fb47a">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Yi
Ferry Terminus</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001133</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>829381.737</fme:EASTING>
<fme:NORTHING>823889.673</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007846</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823889.67279 829381.73723</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id7acaf7fb-e231-4770-80aa-88270a59ad64">
<fme:AnnotationClassID>7</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Occupational
Safety and
Health Academy</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002062</fme:FEATURE_ID>
<fme:FEATURECODE>VTI</fme:FEATURECODE>
<fme:EASTING>828651.236</fme:EASTING>
<fme:NORTHING>823607.988</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973737</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823607.91082 828651.23627</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id8b574177-7214-4d5d-a7c6-67f93ac35f14">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Yi Southwest
Sports Centre</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007968</fme:FEATURE_ID>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:EASTING>828566.634</fme:EASTING>
<fme:NORTHING>823586.063</fme:NORTHING>
<fme:LINKFEATURE_ID>1210035992</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823586.02407 828566.63442</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id4a1bf03d-50e0-4cac-8475-7a942efc3448">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 9</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008816</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>829644.963</fme:EASTING>
<fme:NORTHING>822443.3</fme:NORTHING>
<fme:LINKFEATURE_ID>1210040194</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822441.53011 829647.01700</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="ide30dad8b-61fd-4839-a33b-e9241321874d">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Container Terminal 9</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>6</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008817</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>829799.612</fme:EASTING>
<fme:NORTHING>821718.235</fme:NORTHING>
<fme:LINKFEATURE_ID>1210040194</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821718.84663 829809.60396</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id79878b13-e200-42c3-8094-7fb02ba7d8a7">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Tsing Yi Road West Park</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210011475</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>828247.94</fme:EASTING>
<fme:NORTHING>823663.237</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973690</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823663.23730 828247.94007</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_E gml:id="id30b16249-474c-4565-a8a5-5f7f77091ce9">
<fme:AnnotationClassID>7</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Hong Kong Institute
of Vocational Education
(Tsing Yi)</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012356</fme:FEATURE_ID>
<fme:FEATURECODE>VTI</fme:FEATURECODE>
<fme:EASTING>828962.237</fme:EASTING>
<fme:NORTHING>822599.747</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973747</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822599.66978 828962.23721</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
