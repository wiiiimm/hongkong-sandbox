<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821092.67536 826494.15921</gml:lowerCorner>
<gml:upperCorner>823976.45409 829923.94084</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id97e24b98-396f-42a8-bff7-6825bfaf3f65">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959294</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828097.67210423</fme:EASTING>
<fme:NORTHING>821195.1995945</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821198.06597 828116.67842</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id711f9cc3-911b-4bde-a1a3-ed0c00d15363">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>藍巴勒海峽
避風塘</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>9.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959303</fme:FEATURE_ID>
<fme:FEATURECODE>TYP</fme:FEATURECODE>
<fme:EASTING>829923.941</fme:EASTING>
<fme:NORTHING>823850.435</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>80015</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210006754</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823851.43484 829923.94084</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ided7ea345-ee83-447b-bc40-40ccf07b4bb3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>南環</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959236</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828067.819</fme:EASTING>
<fme:NORTHING>821499.144</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279480</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821499.14400 828067.81896</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id7aea2f4c-94b4-40dc-9df6-f1bf74771f81">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>新屋村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959265</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828333.85879</fme:EASTING>
<fme:NORTHING>823858.82919</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280815</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823859.12829 828334.24763</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id67105079-5be1-4a73-8765-01db3e90538e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣
信義新村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959258</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828984.616</fme:EASTING>
<fme:NORTHING>823637.651</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210000529</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823638.21135 828984.61559</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9eec0010-ffb7-4145-8f98-2f57e8626622">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>宏福花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959257</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829159.37</fme:EASTING>
<fme:NORTHING>823935.607</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280814</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823935.90588 829159.36983</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idf2001dcf-5fee-453f-bd6c-a3f5595316b5">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>鹽田角村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959264</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828298.74940366</fme:EASTING>
<fme:NORTHING>823760.17736672</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279943</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823760.17737 828298.74990</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idb6449202-2204-41b4-b639-93a2c43f516e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長青邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959256</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829274.245</fme:EASTING>
<fme:NORTHING>822909.868</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310016511</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260107</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822909.86799 829274.24511</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ida758a046-969e-476a-95d7-3fd4d444a0b0">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港聯合船塢有限公司</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959278</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>826723.07</fme:EASTING>
<fme:NORTHING>823516.308</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>78400</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310012215</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823516.52201 826723.80639</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idd0ff0637-48ec-419e-b724-cee13142a208">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>細山</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959241</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>829300.58</fme:EASTING>
<fme:NORTHING>822732.004</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278584</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822732.60178 829298.90084</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id499e12b4-c006-4b51-a886-5d2b4f04a0ad">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣基本污水處理廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959301</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829400.531</fme:EASTING>
<fme:NORTHING>822824.541</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>77858</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283334</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822824.75498 829400.53121</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id688f2906-feaf-4ac3-8ca2-b7fbddc7d56c">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>曉峰園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959259</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>827931.369</fme:EASTING>
<fme:NORTHING>823780.957</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280816</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823780.95681 827931.36940</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id18fc0634-cf57-4b2b-a395-789d0058d4d1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959246</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828659.40888321</fme:EASTING>
<fme:NORTHING>823926.60094769</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75418</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279830</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823926.60095 828659.40938</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idf4579507-c0a3-4211-8d75-1caca4df50c9">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大王下村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959262</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828355.68088</fme:EASTING>
<fme:NORTHING>823941.02782</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279777</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823941.02782 828355.68088</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9ed9d9ab-1152-4ad0-8739-bb2547251392">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>埃克森美孚青衣油庫(東)</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959287</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828379.166</fme:EASTING>
<fme:NORTHING>821157.144</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70069</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001284052</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821157.40014 828379.82141</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idd64452e4-9c00-49d8-9d14-bb1b24b58312">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>友聯船廠有限公司</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959274</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827492.342</fme:EASTING>
<fme:NORTHING>822264.173</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70305</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283469</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822264.17323 827492.34182</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id616653a6-83f2-4c37-8087-1d35f821d0e4">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>警察宿舍</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>35.1341930559771</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959281</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829086.711</fme:EASTING>
<fme:NORTHING>823608.769</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>78351</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310014680</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823609.07782 829086.77919</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idfa8a3f02-f80f-4d29-a1b4-12957fa19dc7">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海悅花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959255</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829161.59</fme:EASTING>
<fme:NORTHING>823875.296</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001279102</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823875.59551 829161.77537</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id0f4b6f20-b841-43bd-8bea-a7c21492b5fe">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海欣花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959247</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829323.028</fme:EASTING>
<fme:NORTHING>823709.719</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001280817</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823710.01788 829323.34895</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idd9d3f162-d157-488d-9440-2e976320b3fa">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>中石化香港油庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959299</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828836.039</fme:EASTING>
<fme:NORTHING>821092.419</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70071</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283329</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821092.67536 828836.34535</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9faed491-d9b8-4fca-8c95-fedb79cb9723">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>化學廢物處理設施</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>32.4179995556829</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959288</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829098.446</fme:EASTING>
<fme:NORTHING>821301.7</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>78851</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283467</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821302.55641 829099.39552</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idf19dd269-0704-4742-b19d-07c0eb0aca72">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>寮肚</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959261</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>827873.81886176</fme:EASTING>
<fme:NORTHING>823651.11958819</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64054</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278580</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823655.13251 827886.74044</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9d85d9e1-0f4d-4d95-9dc1-320700a9e629">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959298</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829370.551</fme:EASTING>
<fme:NORTHING>821885.785</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821885.99883 829370.83335</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id7e774dcd-f9a3-4eb8-b433-5a19ee1df3ec">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>20.0001000018626</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959304</fme:FEATURE_ID>
<fme:FEATURECODE>ISL</fme:FEATURECODE>
<fme:EASTING>828472.49450969</fme:EASTING>
<fme:NORTHING>822729.62825194</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001277511</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822729.62825 828472.49501</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id0639315a-1788-4393-a9a4-53383e082f93">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>雪佛龍香港有限公司青衣油庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959285</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827400.364</fme:EASTING>
<fme:NORTHING>822363.389</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70304</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001284141</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822363.60312 827401.05630</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idd3164afd-31bf-47e4-916d-02d9f9aae18f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>藍巴勒海峽</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>15.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-66.6362702700466</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959302</fme:FEATURE_ID>
<fme:FEATURECODE>BAY</fme:FEATURECODE>
<fme:EASTING>829614.023</fme:EASTING>
<fme:NORTHING>823611.827</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001281817</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823611.81618 829614.02781</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ide2197414-def4-4c77-95e5-a3a48ee6818c">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>南灣</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959237</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828001.969</fme:EASTING>
<fme:NORTHING>822303.977</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279479</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822303.97655 828001.96933</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id4664e819-4095-4350-83b7-12875310d8b0">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959269</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827471.11061262</fme:EASTING>
<fme:NORTHING>821336.51951707</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821336.51952 827471.11111</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id394a52dc-ffb1-454d-9012-d53ea3e76acd">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>春花落</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959243</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828901.835</fme:EASTING>
<fme:NORTHING>822118.849</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279201</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822118.84884 828901.83494</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id595b6fea-37e4-4390-a8ff-4bab573762d1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>藍田村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959263</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828469.74248696</fme:EASTING>
<fme:NORTHING>823609.74370855</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278581</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823609.74371 828469.74299</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id64bce95a-9c3d-4435-bb26-da72b5d3aed3">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>污水處理廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-47.0287886312641</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959270</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829854.33662684</fme:EASTING>
<fme:NORTHING>823497.21067807</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823481.51150 829872.87906</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1e6b36d7-84ec-47a6-87c3-56f719acc33d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>涌美老屋村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.295337471944819</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959266</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828845.35511325</fme:EASTING>
<fme:NORTHING>823592.99290895</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278578</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823595.98225 828869.20155</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1a663d64-2f2a-4e98-9fd2-016a51a52964">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>防波堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-59.6887630493491</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959268</fme:FEATURE_ID>
<fme:FEATURECODE>TYP</fme:FEATURECODE>
<fme:EASTING>829797.92339358</fme:EASTING>
<fme:NORTHING>823987.15170829</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823976.45409 829807.49766</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idedb7440d-409f-4dfa-8377-984ce24f5c17">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>下高灘</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>9.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959238</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>829050.312</fme:EASTING>
<fme:NORTHING>823572.122</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278577</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823572.50604 829050.01764</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id3c93c43a-bb04-48d1-bbb1-ea219849f3ad">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>南灣角</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959305</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828876.089</fme:EASTING>
<fme:NORTHING>821540.528</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279481</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821540.52831 828876.08903</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id59b35df7-3b3b-405b-a77a-a9ef697e1912">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長康邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959248</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828396.906</fme:EASTING>
<fme:NORTHING>823467.628</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278583</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823467.62847 828396.90612</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id25e4b418-2d4b-4ce7-bf37-f4f5caaeaaee">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>盛禧奧（香港）有限公司青衣廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959275</fme:FEATURE_ID>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:EASTING>829073.001</fme:EASTING>
<fme:NORTHING>821474.722</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70073</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210010287</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821474.93523 829068.19874</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id225a3837-2fad-4047-be59-6e006f140371">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長康邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959252</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828808.279</fme:EASTING>
<fme:NORTHING>823462.107</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278583</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823462.10652 828808.27895</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2076ee17-8f66-4e92-b5c4-ad063e3591ad">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長青邨</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.00010000186265</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959250</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829298.01</fme:EASTING>
<fme:NORTHING>823320.042</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310016511</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823320.04187 829298.00984</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idbb297b95-5162-4261-97a6-42c673111c23">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>水泥廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959291</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>826892.878</fme:EASTING>
<fme:NORTHING>823345.259</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823345.47298 826893.09876</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id4e811855-8773-4e7c-b7d8-9b912e18cb96">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青華苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959253</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828286.972</fme:EASTING>
<fme:NORTHING>823335.092</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278582</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823335.09203 828286.97166</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="iddf871d98-7ba6-496c-91da-4ec5d53e762b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青怡花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959245</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828879.281</fme:EASTING>
<fme:NORTHING>823853.478</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278569</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823853.47757 828879.28112</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ida95daaef-2a5c-4df0-80de-4f19950a43a3">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>金竹角</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959240</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>827423.904</fme:EASTING>
<fme:NORTHING>823196.745</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279287</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823196.74499 827423.90450</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id0365412a-1adb-4422-8362-97d09b86cdd4">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青輝新村</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0.295345364109425</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959267</fme:FEATURE_ID>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:EASTING>828645.201</fme:EASTING>
<fme:NORTHING>823715.911</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281672</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823716.12609 828645.54824</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id31da565d-1921-4d57-ae87-38ecd124d0aa">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>上高灘</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>9.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959239</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>828627.902</fme:EASTING>
<fme:NORTHING>823664.508</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278576</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823664.50782 828627.90219</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id3b375280-6920-4791-b98c-444657a238df">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>翠怡花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959251</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829198.209</fme:EASTING>
<fme:NORTHING>823691.712</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278573</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823692.01074 829198.20267</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id4d0d5fe9-e4d7-4120-ad10-3ba20c029f42">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>藍澄灣</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959260</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829407.018</fme:EASTING>
<fme:NORTHING>822674.215</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001281470</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822674.51375 829407.38190</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id73e7d075-e47a-4b90-b068-db78e0fe19f9">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>政府爛船
處理中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-54.1888382670395</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959292</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829863.36752164</fme:EASTING>
<fme:NORTHING>823639.21495302</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823628.23901 829880.72203</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id6426a8ae-3e38-4741-861c-fd1df99c682c">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>石環</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959242</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>827163.818</fme:EASTING>
<fme:NORTHING>823724.393</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001278949</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823724.39263 827163.81770</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id3520cdf9-e09c-4564-a30e-415ed9ed82f8">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港聯集貨運</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959296</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827547.798</fme:EASTING>
<fme:NORTHING>822567.071</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1210010963</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822567.07112 827547.79762</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id9afaffd2-796a-48bf-b68a-a3451fee3c40">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>西草灣</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>14.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959244</fme:FEATURE_ID>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:EASTING>827691.845</fme:EASTING>
<fme:NORTHING>822600.54</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1001279574</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822600.53969 827691.84511</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id544afd2f-a201-46fb-a28e-53007e802964">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>美景花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959254</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829095.633</fme:EASTING>
<fme:NORTHING>822793.732</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001278579</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822794.03145 829095.68241</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idcc8d344c-c769-44fc-9dd7-f492a13f6aeb">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>天廚(青衣)
工業中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959282</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828826.715</fme:EASTING>
<fme:NORTHING>821295.099</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>79097</fme:ST_CODE>
<fme:LINKFEATURE_ID>1310014672</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821295.65993 828826.71496</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idf2379d95-afa0-4503-89bc-82a68fb76d0e">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>嘉民領達中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001242</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829232.661</fme:EASTING>
<fme:NORTHING>821448.742</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821448.95580 829232.55073</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id52bb6347-8a55-4ecb-9979-cd7f3db530fa">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001522</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829475.054</fme:EASTING>
<fme:NORTHING>821285.751</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821285.96425 829475.33606</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idf6235d0c-d0bf-4b48-86da-e8a1755f5cdd">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>綠悠雅苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005645</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828757.611</fme:EASTING>
<fme:NORTHING>823782.298</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210004224</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823782.59685 828757.61134</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1d9d9ecc-a09b-4901-9e0a-187e842c4c0f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣南
食水配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007494</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>827994.96</fme:EASTING>
<fme:NORTHING>821366.15</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71220</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002397</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821366.70998 827994.95959</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id7e2c9695-05ba-4c1c-8dd8-2a62a69d9e9d">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007615</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829264.668</fme:EASTING>
<fme:NORTHING>821814.701</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821814.91495 829264.95060</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id6686d40e-a73c-465b-95c3-0eed78ec61ba">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007616</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829436.586</fme:EASTING>
<fme:NORTHING>821561.368</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821561.58144 829436.86841</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idd4e0db8a-6c85-45ee-9e15-cb5deb3cf3e3">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣工業中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.5522549679403</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008696</fme:FEATURE_ID>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:EASTING>829450.754</fme:EASTING>
<fme:NORTHING>823393.516</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823393.98968 829450.84385</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id60c692f2-0d24-4c41-b783-70385615c065">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青俊苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010771</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829226.278</fme:EASTING>
<fme:NORTHING>823061.611</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82439</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210005866</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260107</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823061.82505 829226.27763</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id20295426-d80e-49bd-998e-7890b48fa07c">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>招商局物流中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-2.99999934599618</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012110</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829412.527</fme:EASTING>
<fme:NORTHING>821661.506</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82522</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007147</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821661.72484 829412.43710</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idf25ee839-61d3-4a92-8075-86b6907f68e0">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>亞洲物流中心－順豐大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-6.47929672419713e-6</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210012111</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829400.349</fme:EASTING>
<fme:NORTHING>821783.823</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>82173</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210007146</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821784.03699 829400.51646</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idda1c3c30-33d0-4777-a4b1-5593d44e4549">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210016030</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829489.789</fme:EASTING>
<fme:NORTHING>821173.731</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821173.94477 829490.07071</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id24098da2-e93d-4944-a2e8-8314df8514c9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣東二號
食水配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210016050</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>828847.84</fme:EASTING>
<fme:NORTHING>823174.107</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71203</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002330</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823174.66779 828848.36869</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idde4e256d-d2a5-4a76-a666-0e1fe41fa091">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣東食水配水庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210016051</fme:FEATURE_ID>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:EASTING>829005.802</fme:EASTING>
<fme:NORTHING>823095.703</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>71202</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210002364</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823095.91630 829006.63054</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id490f50e4-415a-4237-bf91-e2a22ccd0c59">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>蜆殼公司青衣油庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210016151</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827156.831</fme:EASTING>
<fme:NORTHING>822842.959</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70303</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001284140</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822957.30121 826852.21786</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id314c671e-da56-49b2-a7d5-ac5c27a75cd9">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>巴士廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210017810</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822325.16157 827790.72780</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id1dee5779-fa4e-4070-8a34-758e53b76c4f">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青年發展及
國民教育基地</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310019771</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829342.547</fme:EASTING>
<fme:NORTHING>822118.046</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310016868</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250307</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822118.82883 829342.54745</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="ide42ce8b4-dad9-47af-8340-c885490190df">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>明翹匯</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310019990</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>828950.059</fme:EASTING>
<fme:NORTHING>822825.648</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1310015165</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822825.90437 828950.05901</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="iddb150876-0d2b-4d91-bb54-de3cfb16f956">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青富苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310020891</fme:FEATURE_ID>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:EASTING>829162.134</fme:EASTING>
<fme:NORTHING>822570.145</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210009897</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822570.44402 829161.70792</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idb257c7d6-ff93-4d2d-aae3-8b2ddc95dabe">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>水泥廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310023830</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>826493.939</fme:EASTING>
<fme:NORTHING>823601.707</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823601.92089 826494.15921</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id3064a3fc-b803-4c6b-a8db-397334dbec23">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>露天貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310023810</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829163.099</fme:EASTING>
<fme:NORTHING>821208.603</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821208.81664 829163.38167</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id2a24ecf6-2af8-4b49-b72e-0605c3330ad1">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>歐亞船廠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810045142</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827319.654</fme:EASTING>
<fme:NORTHING>821417.982</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70268</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283468</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821418.19580 827320.05125</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id81b389de-84e6-4ae5-9c2e-6b4159fb02de">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>萬順昌建築鋼鐵工程</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810046402</fme:FEATURE_ID>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:EASTING>827456.534</fme:EASTING>
<fme:NORTHING>821098.826</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1420001156</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821099.03962 827457.42435</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id97f0b614-cb93-4551-b026-c7c83f384472">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>中華電力－青衣中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009997764826</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810046542</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828285.681</fme:EASTING>
<fme:NORTHING>821267.17</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70070</fme:ST_CODE>
<fme:LINKFEATURE_ID>1210003953</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821267.42615 828283.91816</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id147db68d-9a9d-41f9-81e2-512ca1b5a0e1">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>豐樹物流中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>7.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1810046406</fme:FEATURE_ID>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:EASTING>829197.597</fme:EASTING>
<fme:NORTHING>822135.87</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID>1420001861</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822136.16940 829197.67715</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
