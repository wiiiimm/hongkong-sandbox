<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821735.19891 826711.87555</gml:lowerCorner>
<gml:upperCorner>823948.35139 829944.10830</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id0350dc8b-3e69-4e60-96b3-ab54b8e15851">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001171</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>826713.088</fme:EASTING>
<fme:NORTHING>823098.164</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008000</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823098.37809 826713.17133</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="ide5f2592e-9994-47ad-8327-faf78b05ddf1">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001173</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827349.558</fme:EASTING>
<fme:NORTHING>822651.979</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008051</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822652.19299 827349.64191</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id0ec0df7d-6c70-4395-aee4-b9b81aa3fe55">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001174</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827173.541</fme:EASTING>
<fme:NORTHING>822224.913</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007997</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822225.12694 827173.62517</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id2bc965b7-1c86-4cfd-987d-857d8713f6ab">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001229</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827368.043</fme:EASTING>
<fme:NORTHING>822143.78</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008053</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822143.99413 827368.12709</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="ided256ab1-f93f-4bff-bcf1-e8da4d1f7f4c">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001240</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>829381.248</fme:EASTING>
<fme:NORTHING>823908.452</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007846</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823908.45203 829381.24771</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id19cf6da1-c37b-46f7-ac21-d0a107a74d9b">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001267</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827257.785</fme:EASTING>
<fme:NORTHING>822676.71</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007900</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822676.92380 827257.86874</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id00d874a0-d429-4b0b-b861-06375b78bd56">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001345</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827193.471</fme:EASTING>
<fme:NORTHING>822687.261</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008087</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822687.47475 827193.55480</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id39099ae6-fb3f-473d-9043-9f5370399103">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001373</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827272.825</fme:EASTING>
<fme:NORTHING>822488.357</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007793</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822488.57084 827272.90840</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idcb247ad4-be97-4cc0-a941-45bc59370ba8">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001379</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827119.743</fme:EASTING>
<fme:NORTHING>822686.261</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007955</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822686.47475 827119.82675</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id752a6d99-4d6a-4701-a361-6083086fb0f0">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001416</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>826919.066</fme:EASTING>
<fme:NORTHING>822630.964</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008093</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822631.17741 826919.15005</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id01e553ab-b8e6-45a6-9fde-9b22c0192a0b">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001417</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>826711.792</fme:EASTING>
<fme:NORTHING>822964.701</fme:NORTHING>
<fme:LINKFEATURE_ID>1210008050</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822964.91456 826711.87555</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idaa7a9599-e849-49f4-a090-3103b11621d1">
<fme:AnnotationClassID>7</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>職安健學院</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001922</fme:FEATURE_ID>
<fme:FEATURECODE>VTI</fme:FEATURECODE>
<fme:EASTING>828638.675</fme:EASTING>
<fme:NORTHING>823628.242</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973737</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823628.45593 828638.67496</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="ide22266f7-5503-4436-8e7b-7ca3d834c8c3">
<fme:AnnotationClassID>7</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港高等教育
科技學院</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001924</fme:FEATURE_ID>
<fme:FEATURECODE>TEI</fme:FEATURECODE>
<fme:EASTING>829006.531</fme:EASTING>
<fme:NORTHING>822467.411</fme:NORTHING>
<fme:LINKFEATURE_ID>1310051716</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822467.97139 829006.53147</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id93c504bd-c88b-4fe8-a2ec-bc74d6154ddb">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青綠街花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-26.6872176476391</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004870</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>828817.261</fme:EASTING>
<fme:NORTHING>823802.304</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973681</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823802.39229 828817.56190</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id7c8b2bc7-d43b-4ded-972a-da5041ee53e6">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣
市政大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004872</fme:FEATURE_ID>
<fme:FEATURECODE>CSC</fme:FEATURECODE>
<fme:EASTING>829021.284</fme:EASTING>
<fme:NORTHING>823894.331</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973609</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823894.89106 829021.28416</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id19475959-1885-4600-8c61-a79ca66777a0">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長環街休憩花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007596</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>829277.986</fme:EASTING>
<fme:NORTHING>823637.962</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973680</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823638.17609 829279.00890</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id14efde4d-bf38-48ba-9c75-38290d459a27">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>長輝路海濱花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.3231445841932</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007597</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>829526.533</fme:EASTING>
<fme:NORTHING>823398.869</fme:NORTHING>
<fme:LINKFEATURE_ID>1310057428</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823398.25289 829527.05150</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idbcdcd692-2de9-4e61-8b69-7e6c84c47d12">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>清譽街花園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007598</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>828483.053</fme:EASTING>
<fme:NORTHING>823931.607</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973683</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823931.82065 828483.49825</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idfde5417c-59e8-4644-823a-089f0053c6d3">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣西南體育館</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008857</fme:FEATURE_ID>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:EASTING>828566.419</fme:EASTING>
<fme:NORTHING>823599.445</fme:NORTHING>
<fme:LINKFEATURE_ID>1210035992</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823599.65880 828566.41880</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id6ff9aee4-30c7-4d8e-ab54-0f387a19a09b">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010403</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>829644.127</fme:EASTING>
<fme:NORTHING>822457.02</fme:NORTHING>
<fme:LINKFEATURE_ID>1210040194</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822457.80731 829650.85945</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idf3a5e40d-6c35-41c9-9baf-ed8eaf1fcc61">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>九號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210010404</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>829805.212</fme:EASTING>
<fme:NORTHING>821734.412</fme:NORTHING>
<fme:LINKFEATURE_ID>1210040194</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821735.19891 829805.42087</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id81864264-e3f6-4922-a182-9854cda20d0f">
<fme:AnnotationClassID>4</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣南消防局</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014510</fme:FEATURE_ID>
<fme:FEATURECODE>FSN</fme:FEATURECODE>
<fme:EASTING>827737.901</fme:EASTING>
<fme:NORTHING>821970.984</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973654</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821971.19753 827737.86594</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id570fb841-e886-4419-a531-9d2ada5e3996">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣西路公園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014650</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>828247.616</fme:EASTING>
<fme:NORTHING>823675.029</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973690</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823675.24279 828247.69986</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id20c0765d-2a5e-48c3-b0e8-b29482fc0c4b">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大王下遊樂場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014651</fme:FEATURE_ID>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:EASTING>828556.035</fme:EASTING>
<fme:NORTHING>823820.485</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973719</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823820.69867 828556.40978</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id06c1a2f5-630e-40ff-abde-e228e132495d">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>美景遊樂場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210014652</fme:FEATURE_ID>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:EASTING>829163.263</fme:EASTING>
<fme:NORTHING>822751.084</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973713</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822751.29736 829163.91975</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idb71d6f4a-e179-4d82-b115-1511103671c5">
<fme:AnnotationClassID>7</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>香港專業教育學院(青衣)</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015931</fme:FEATURE_ID>
<fme:FEATURECODE>VTI</fme:FEATURECODE>
<fme:EASTING>828962.083</fme:EASTING>
<fme:NORTHING>822622.389</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973747</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822622.60246 828962.08302</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id083dc937-c169-4500-9818-e609036a8698">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>涌美路休憩處</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310018973</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>828729.44</fme:EASTING>
<fme:NORTHING>823575.783</fme:NORTHING>
<fme:LINKFEATURE_ID>1000973686</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823575.99667 828730.27333</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="ide64dc933-7e7c-41a2-bb94-b355be6c609e">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>五號貨櫃碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.00009952316284</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000862</fme:FEATURE_ID>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:EASTING>829943.22</fme:EASTING>
<fme:NORTHING>823371.838</fme:NORTHING>
<fme:LINKFEATURE_ID>1210034872</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823372.09421 829944.10830</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id98195b68-7632-44a9-a897-47f645c945ed">
<fme:AnnotationClassID>5</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青衣海濱公園</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420001882</fme:FEATURE_ID>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:EASTING>829286.03</fme:EASTING>
<fme:NORTHING>823948.138</fme:NORTHING>
<fme:LINKFEATURE_ID>1000990043</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823948.35139 829286.20205</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
