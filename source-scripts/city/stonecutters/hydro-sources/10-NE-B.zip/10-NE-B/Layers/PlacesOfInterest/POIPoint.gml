<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821017.90700 826530.75324 0.00000</gml:lowerCorner>
<gml:upperCorner>823988.75037 829929.59000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPoint gml:id="idf4c0de9d-41d1-4dae-8f34-32ad2c775b53">
<fme:FEATURE_ID>1210035257</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829905.54</fme:EASTING>
<fme:NORTHING>821017.91</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821017.90700 829905.54400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id88682c14-2e0b-439f-b842-4aa36b67090a">
<fme:FEATURE_ID>1210035098</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829929.59</fme:EASTING>
<fme:NORTHING>821045.58</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821045.58000 829929.59000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id17ed6ba9-d434-441a-bbd0-53d7588b3e1a">
<fme:FEATURE_ID>1310066192</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829322.06</fme:EASTING>
<fme:NORTHING>821078.45</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821078.44788 829322.06246 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idfda821f6-4e02-455d-a962-e1080cddb337">
<fme:FEATURE_ID>1000973633</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829425.89</fme:EASTING>
<fme:NORTHING>821084.35</fme:NORTHING>
<fme:ENGLISHNAME>Chemical Waste Treat C Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>衡和化學處理廠Ｃ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821084.34976 829425.88492 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id58fd64e2-5ad5-45a9-b29e-0627704d160f">
<fme:FEATURE_ID>1210013681</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829679.44</fme:EASTING>
<fme:NORTHING>821109.05</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821109.04866 829679.43643 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idfe11083e-c29a-4501-8505-6116c5aef6dc">
<fme:FEATURE_ID>1210025023</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829569.59</fme:EASTING>
<fme:NORTHING>821138.95</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821138.95134 829569.59340 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idabcb60fd-0f94-43b0-9e62-207c134d04e7">
<fme:FEATURE_ID>1210026915</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829813.4</fme:EASTING>
<fme:NORTHING>821158.55</fme:NORTHING>
<fme:ENGLISHNAME>TSING KO ROAD (STT 3818)</fme:ENGLISHNAME>
<fme:CHINESENAME>青高路 (STT 3818)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821158.55415 829813.39962 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7e425feb-a677-4849-ab7c-6df693c9ac8c">
<fme:FEATURE_ID>1000973706</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828955.66</fme:EASTING>
<fme:NORTHING>821226.82</fme:NORTHING>
<fme:ENGLISHNAME>Sinopec-Tsing Yi Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>中國石化-青衣加油站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821226.82086 828955.65455 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0bb5995b-5649-4f4d-a584-72db40d293f3">
<fme:FEATURE_ID>1210012234</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>LPG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828947.51</fme:EASTING>
<fme:NORTHING>821239.28</fme:NORTHING>
<fme:ENGLISHNAME>Sinopec Liquefied Petroleum Gas Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>中國石化加氣站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250327</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821239.27715 828947.50497 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd2d57f78-3908-446c-9861-67ca003ae15d">
<fme:FEATURE_ID>1000973605</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828006.78</fme:EASTING>
<fme:NORTHING>821260.29</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ROAD (STT 3753)</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路 (STT 3753)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821260.28994 828006.78423 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id74327b4f-4386-4e97-8101-14973c454908">
<fme:FEATURE_ID>1000973643</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828785.93</fme:EASTING>
<fme:NORTHING>821294.66</fme:NORTHING>
<fme:ENGLISHNAME>Tien Chu (Tsing Yi) Industrial Centre Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>天廚(青衣)工業中心電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821294.65598 828785.92944 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3e74a5e7-1393-41b2-8b2f-d39ae34ce222">
<fme:FEATURE_ID>1210016040</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827835.43</fme:EASTING>
<fme:NORTHING>821331.02</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821331.01679 827835.42821 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5c52ca5d-1ae9-4323-aaae-87de5e600a16">
<fme:FEATURE_ID>1000973644</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828322.86</fme:EASTING>
<fme:NORTHING>821370.56</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821370.55760 828322.86337 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8a13fb92-a704-4f35-9477-49f1df1ca417">
<fme:FEATURE_ID>1210033212</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829651.61</fme:EASTING>
<fme:NORTHING>821475.17</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821475.16544 829651.60651 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4001c6ee-530a-45fb-8bdb-45bd54ccd7cb">
<fme:FEATURE_ID>1000973640</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827440.79</fme:EASTING>
<fme:NORTHING>821681.58</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821681.58028 827440.78650 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6a6fa389-bd87-4e39-a84f-2b44de6a6311">
<fme:FEATURE_ID>1210033210</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829705.04</fme:EASTING>
<fme:NORTHING>821791.89</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821791.89260 829705.04123 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0e38672c-b8a7-47f5-b730-ec6ab529b676">
<fme:FEATURE_ID>1210033218</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829242.74</fme:EASTING>
<fme:NORTHING>821855.87</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Road Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821855.87001 829242.73509 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8649c6f3-73a8-42e5-82fa-3f1bbcbb819d">
<fme:FEATURE_ID>1210033021</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829488.84</fme:EASTING>
<fme:NORTHING>821944.25</fme:NORTHING>
<fme:ENGLISHNAME>Terminal 9 South A Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣九號貨櫃碼頭南Ａ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821944.24981 829488.84346 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3b388683-182c-4b06-9c5d-5fba701c0799">
<fme:FEATURE_ID>1210040194</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PIE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829750</fme:EASTING>
<fme:NORTHING>821947</fme:NORTHING>
<fme:ENGLISHNAME>CONTAINER TERMINAL 9</fme:ENGLISHNAME>
<fme:CHINESENAME>九號貨櫃碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821947.00000 829750.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd48d5973-1eee-4978-8058-b0da1bab0d4c">
<fme:FEATURE_ID>1000973654</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827710.13</fme:EASTING>
<fme:NORTHING>821985.24</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi South Fire Station</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣南消防局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821985.24181 827710.13144 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3deb7073-c133-433a-9a99-8c0e6724a495">
<fme:FEATURE_ID>1000973541</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>AER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828422.2</fme:EASTING>
<fme:NORTHING>821987.04</fme:NORTHING>
<fme:ENGLISHNAME>Aeronautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航空)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821987.03656 828422.20068 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7abc797c-1008-4a12-a9fa-9328cf50f3af">
<fme:FEATURE_ID>1000973620</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827725.7</fme:EASTING>
<fme:NORTHING>822008.09</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi South Fire Station Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣南消防局電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822008.08590 827725.69495 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="iddd7a2465-deb8-4033-a90b-170c4b1f98ca">
<fme:FEATURE_ID>1210008053</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827393.33</fme:EASTING>
<fme:NORTHING>822167.06</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822167.06100 827393.32900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcb320f5a-e6c0-4fde-b7d2-5d648bc44ac0">
<fme:FEATURE_ID>1210033211</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829468.75</fme:EASTING>
<fme:NORTHING>822193.69</fme:NORTHING>
<fme:ENGLISHNAME>Terminal 9 North Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣九號貨櫃碼頭北變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822193.68520 829468.74676 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id49030fc5-2734-42fe-be66-2be4c330241d">
<fme:FEATURE_ID>1210006869</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829117.86</fme:EASTING>
<fme:NORTHING>822202.93</fme:NORTHING>
<fme:ENGLISHNAME>TSING HUNG ROAD (STT 3791)</fme:ENGLISHNAME>
<fme:CHINESENAME>青鴻路 (STT 3791)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822202.92559 829117.86035 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idece2e579-db2a-4359-bbd6-4a1cf97b0ed8">
<fme:FEATURE_ID>1210007997</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827204</fme:EASTING>
<fme:NORTHING>822237</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822237.00000 827204.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idab273e24-afcc-4f01-9770-0123220a8c23">
<fme:FEATURE_ID>1210035039</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>REA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829068.68</fme:EASTING>
<fme:NORTHING>822380.79</fme:NORTHING>
<fme:ENGLISHNAME>Restricted Access</fme:ENGLISHNAME>
<fme:CHINESENAME>限制通道</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822380.79164 829068.68334 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6c8c80f3-2c4e-464e-827f-ff2f795a1419">
<fme:FEATURE_ID>1000973542</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>AER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828351.81</fme:EASTING>
<fme:NORTHING>822407.65</fme:NORTHING>
<fme:ENGLISHNAME>Aeronautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航空)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822407.64555 828351.80866 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida660242e-c903-47f7-87e9-42cbf51bec5b">
<fme:FEATURE_ID>1210007793</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827301</fme:EASTING>
<fme:NORTHING>822467</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822467.00000 827301.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida1c817a6-dfaa-479f-af98-f66075d6d361">
<fme:FEATURE_ID>1210025068</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827793.4</fme:EASTING>
<fme:NORTHING>822469.75</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822469.75087 827793.40107 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="iddf83680e-b58e-410a-84d7-fd84d050ab6b">
<fme:FEATURE_ID>1310051716</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TEI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829035</fme:EASTING>
<fme:NORTHING>822476</fme:NORTHING>
<fme:ENGLISHNAME>Technological and Higher Education Institute of Hong Kong (Tsing Yi Campus)</fme:ENGLISHNAME>
<fme:CHINESENAME>香港高等教育科技學院 (青衣校園)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230925</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822476.00000 829035.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8246c810-5d52-4cf7-b876-8c86cc3e5a39">
<fme:FEATURE_ID>1310066483</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829160.72</fme:EASTING>
<fme:NORTHING>822558.7</fme:NORTHING>
<fme:ENGLISHNAME>Ching Fu Court</fme:ENGLISHNAME>
<fme:CHINESENAME>青富苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822523.24376 829158.20645 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idfaa18e3f-bd4e-47dd-b379-d6ca2ff4e2e8">
<fme:FEATURE_ID>1000973659</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HTL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829385.12</fme:EASTING>
<fme:NORTHING>822546.95</fme:NORTHING>
<fme:ENGLISHNAME>RAMBLER OASIS HOTEL</fme:ENGLISHNAME>
<fme:CHINESENAME>青逸酒店</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822546.94782 829385.11775 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6a5708e4-11ce-4e88-b9a8-8cab20461a87">
<fme:FEATURE_ID>1310063267</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829078</fme:EASTING>
<fme:NORTHING>822555</fme:NORTHING>
<fme:ENGLISHNAME>CHING FU COURT(Alighting stop)</fme:ENGLISHNAME>
<fme:CHINESENAME>青富苑(落客站)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230925</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822555.00000 829078.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id12fb3032-e44c-4be1-971e-98e59a51b3bb">
<fme:FEATURE_ID>1000973747</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VTI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828951.58</fme:EASTING>
<fme:NORTHING>822595.23</fme:NORTHING>
<fme:ENGLISHNAME>Hong Kong Institute of Vocational Education (Tsing Yi)</fme:ENGLISHNAME>
<fme:CHINESENAME>香港專業教育學院 (青衣)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822595.23076 828951.57610 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf1ccc834-5fe4-4a95-bebe-f0492207eee5">
<fme:FEATURE_ID>1310064987</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829147.44</fme:EASTING>
<fme:NORTHING>822613.24</fme:NORTHING>
<fme:ENGLISHNAME>Ching Fu Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>青富商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822613.24379 829147.43760 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8aa427c5-c812-4bac-85aa-d245c3a3f175">
<fme:FEATURE_ID>1000973601</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827692.97</fme:EASTING>
<fme:NORTHING>822630.17</fme:NORTHING>
<fme:ENGLISHNAME>SAI TSO WAN ROAD (STT 3778)</fme:ENGLISHNAME>
<fme:CHINESENAME>西草灣路 (STT 3778)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822630.16839 827692.97158 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida04db7b0-0282-4494-928b-34e145c6d8df">
<fme:FEATURE_ID>1310061927</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829360.41</fme:EASTING>
<fme:NORTHING>822631.2</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Crest Tower 3</fme:ENGLISHNAME>
<fme:CHINESENAME>藍澄灣第三座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822631.19526 829360.40884 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbda7cc60-35aa-4030-b490-09149a64b093">
<fme:FEATURE_ID>1210031222</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HTL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829434.71</fme:EASTING>
<fme:NORTHING>822645.24</fme:NORTHING>
<fme:ENGLISHNAME>飛悅居</fme:ENGLISHNAME>
<fme:CHINESENAME>HKIA COMMUNITY LODGE</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260625</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822645.24129 829434.71269 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idca0500c9-acc3-4dd2-89bb-a3d8a5ca3beb">
<fme:FEATURE_ID>1210008093</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826904</fme:EASTING>
<fme:NORTHING>822648</fme:NORTHING>
<fme:ENGLISHNAME>Shell Tsing Yi Installation Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>蜆殼公司青衣油庫碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822648.00000 826904.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3e51bf1a-9017-418f-9505-3b188792f74c">
<fme:FEATURE_ID>1210017095</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829345</fme:EASTING>
<fme:NORTHING>822653</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822653.00000 829345.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id22ba3c55-cd27-4f27-bd79-b9157a00a6d1">
<fme:FEATURE_ID>1210016859</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829333.92</fme:EASTING>
<fme:NORTHING>822662.42</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Hung Road Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>青鴻路遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822662.41524 829333.91762 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8515f6a4-6e10-4b37-846f-5f3d54525afd">
<fme:FEATURE_ID>1210008051</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827344</fme:EASTING>
<fme:NORTHING>822684</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822684.00000 827344.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc7506d94-4560-4076-a0d0-1e504eb1b489">
<fme:FEATURE_ID>1000973771</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829099.04</fme:EASTING>
<fme:NORTHING>822686.82</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822686.81634 829099.04311 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1b9dec6c-761f-47e4-8667-0c8d1f788efc">
<fme:FEATURE_ID>1210007900</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827242</fme:EASTING>
<fme:NORTHING>822702</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822702.00000 827242.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6bf34115-4085-4876-835a-d68ba84de8cf">
<fme:FEATURE_ID>1000973770</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829121.53</fme:EASTING>
<fme:NORTHING>822710.14</fme:NORTHING>
<fme:ENGLISHNAME>Tennis Court</fme:ENGLISHNAME>
<fme:CHINESENAME>網球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822710.14431 829121.53385 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6e3bfd4a-a40a-44ec-83cd-077394b3c243">
<fme:FEATURE_ID>1210008087</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827179</fme:EASTING>
<fme:NORTHING>822719</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822719.00000 827179.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide897ed43-3299-4d5b-86f1-a23b5272d4e3">
<fme:FEATURE_ID>1210007955</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827103</fme:EASTING>
<fme:NORTHING>822721</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822721.00000 827103.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5f016091-3c34-4a51-8a9e-dfddad5b87c2">
<fme:FEATURE_ID>1000973658</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HTL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829464.51</fme:EASTING>
<fme:NORTHING>822737.83</fme:NORTHING>
<fme:ENGLISHNAME>RAMBLER GARDEN HOTEL</fme:ENGLISHNAME>
<fme:CHINESENAME>華逸酒店</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822737.82853 829464.51422 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9a287723-4fd4-432b-ad9c-976ec4d0dbee">
<fme:FEATURE_ID>1000973574</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829025.55</fme:EASTING>
<fme:NORTHING>822743.25</fme:NORTHING>
<fme:ENGLISHNAME>MAYFAIR GARDEN BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園巴士總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822743.24478 829025.55251 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id038fa5e7-2717-4fa6-80b8-e3f19d7e4cae">
<fme:FEATURE_ID>1000973678</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829446.34</fme:EASTING>
<fme:NORTHING>822757.05</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Plaza</fme:ENGLISHNAME>
<fme:CHINESENAME>藍澄灣商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822757.05312 829446.33585 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id03ef90f4-69c8-457a-a563-284cf0da6ae8">
<fme:FEATURE_ID>1310061934</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829064</fme:EASTING>
<fme:NORTHING>822763</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Minibus Terminus</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園小巴總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822763.00000 829064.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id49499e80-4ac3-459d-a618-97c3abc5a9c3">
<fme:FEATURE_ID>1000973713</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829177.77</fme:EASTING>
<fme:NORTHING>822765.73</fme:NORTHING>
<fme:ENGLISHNAME>Mei King Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>美景遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822765.72958 829177.76783 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id72c4f85e-06bb-4217-9257-0c75f3479984">
<fme:FEATURE_ID>1000973694</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828365.74</fme:EASTING>
<fme:NORTHING>822768.02</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822768.01542 828365.73512 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf1ad4bc8-3342-4d33-a80d-980b0be16ab2">
<fme:FEATURE_ID>1000973708</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829265.78</fme:EASTING>
<fme:NORTHING>822769.05</fme:NORTHING>
<fme:ENGLISHNAME>Esso-Tsing Yi South Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>埃索-青衣南加油站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822769.05293 829265.78235 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2b4f6230-725e-4ddc-96d4-e2a66020985a">
<fme:FEATURE_ID>1210010075</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829093.84</fme:EASTING>
<fme:NORTHING>822820.78</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Shopping Arcade</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822820.78063 829093.84186 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5c89d87c-bf55-461b-afbc-b76dbbab5866">
<fme:FEATURE_ID>1000973618</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826815.55</fme:EASTING>
<fme:NORTHING>822873.89</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822873.88756 826815.55291 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id90592cef-3b7c-4e7f-9026-145c1f2f70e1">
<fme:FEATURE_ID>1000973617</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829489.3</fme:EASTING>
<fme:NORTHING>822881.3</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Preliminary Treatment Works Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣基本污水處理廠電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822881.30354 829489.29989 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id54f5c0c1-e43f-4df4-8c1f-8e60988556a4">
<fme:FEATURE_ID>1210011024</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829611</fme:EASTING>
<fme:NORTHING>822883</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG FAI ROAD (STT 3812)</fme:ENGLISHNAME>
<fme:CHINESENAME>長輝路 (STT 3812)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822883.00000 829611.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbadc5eaa-a8b1-4241-880c-14bff21c26af">
<fme:FEATURE_ID>1210049256</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829201.49</fme:EASTING>
<fme:NORTHING>822887.5</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822887.50183 829201.49190 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id37917afe-d547-4ce1-a708-a2371817b14f">
<fme:FEATURE_ID>1000973677</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829295.59</fme:EASTING>
<fme:NORTHING>822891.61</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>長青商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822891.61125 829295.58775 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf297d7e8-bd16-401f-bdd0-f147f77ed403">
<fme:FEATURE_ID>1310065012</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829230.09</fme:EASTING>
<fme:NORTHING>822896.24</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Estate Car Park</fme:ENGLISHNAME>
<fme:CHINESENAME>長青邨停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822896.23607 829230.08748 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7dd8fa36-8947-4e69-91cb-4f2e26d39952">
<fme:FEATURE_ID>1000973669</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829314.58</fme:EASTING>
<fme:NORTHING>822898.88</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Estate Market</fme:ENGLISHNAME>
<fme:CHINESENAME>長青邨街市</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822898.88449 829314.57764 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0e1d9e33-ba4c-4934-8bb8-fbc53994b428">
<fme:FEATURE_ID>1000973701</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829067.77</fme:EASTING>
<fme:NORTHING>822917.87</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822917.87278 829067.76810 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id74906370-4368-4c1e-92d6-32f4de74c1e3">
<fme:FEATURE_ID>1310065038</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829320.3</fme:EASTING>
<fme:NORTHING>822931.28</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Shopping Centre Car Park</fme:ENGLISHNAME>
<fme:CHINESENAME>長青商場停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822931.27840 829320.30275 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9170a540-9d1e-409e-9c7e-2abf690ac4e9">
<fme:FEATURE_ID>1210008050</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826743</fme:EASTING>
<fme:NORTHING>822952</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822952.00000 826743.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id53f3673d-04ec-4165-bc07-dead9fb41287">
<fme:FEATURE_ID>1000973624</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829471.61</fme:EASTING>
<fme:NORTHING>822986.42</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822986.41984 829471.61247 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1e89baae-b0ab-405d-a8dc-05e3de245fcb">
<fme:FEATURE_ID>1000973751</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829203.08</fme:EASTING>
<fme:NORTHING>823025.08</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823025.08235 829203.08247 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id77423bc9-ce81-40d0-b26f-c4c70385050c">
<fme:FEATURE_ID>1210013678</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828667</fme:EASTING>
<fme:NORTHING>823032</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823032.00000 828667.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd39fa401-a5e0-4ff4-8b94-62020ddbdd60">
<fme:FEATURE_ID>1000973689</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828820.26</fme:EASTING>
<fme:NORTHING>823046.31</fme:NORTHING>
<fme:ENGLISHNAME>Ching Hong Road Hill Top Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>青康路山頂休憩處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823032.12843 828826.39563 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3d7c3113-6d0b-4d95-9d0e-adfc882537f1">
<fme:FEATURE_ID>1210013679</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828527</fme:EASTING>
<fme:NORTHING>823054</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823054.00000 828527.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida5b8e45c-e9c7-4a06-8b64-50074ca8c09f">
<fme:FEATURE_ID>1210008000</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826748</fme:EASTING>
<fme:NORTHING>823082</fme:NORTHING>
<fme:ENGLISHNAME>Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823082.00000 826748.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7b59c247-450d-4acc-8569-e86afbc73071">
<fme:FEATURE_ID>1210021070</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828979.68</fme:EASTING>
<fme:NORTHING>823113.26</fme:NORTHING>
<fme:ENGLISHNAME>7-a-side Hard-surfaced Soccer Pitch</fme:ENGLISHNAME>
<fme:CHINESENAME>7人硬地足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823113.25502 828979.68250 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id35400a62-ea74-4d09-9ad1-40b52e270259">
<fme:FEATURE_ID>1000973699</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828736.51</fme:EASTING>
<fme:NORTHING>823124.08</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823124.08144 828736.51018 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id43cce7bb-a3f1-4e9d-9f5d-e6dfaf7bcc7e">
<fme:FEATURE_ID>1000973712</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828998.66</fme:EASTING>
<fme:NORTHING>823129.62</fme:NORTHING>
<fme:ENGLISHNAME>Ching Hong Road Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>青康路遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823129.61604 828998.65998 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3fbc649d-bfc3-41f6-99be-4c618a434f6b">
<fme:FEATURE_ID>1420003344</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829241.37</fme:EASTING>
<fme:NORTHING>823137.79</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260107</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823137.78575 829241.36885 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6b22b7ef-cf4b-4af4-b614-be8b0c82c1fe">
<fme:FEATURE_ID>1000973603</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829548.09</fme:EASTING>
<fme:NORTHING>823154.85</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG FAI ROAD (STT 3747)</fme:ENGLISHNAME>
<fme:CHINESENAME>長輝路 (STT 3747)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823154.85032 829548.08788 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0ea7651e-374f-4e29-9899-8ad7516bad2a">
<fme:FEATURE_ID>1000973722</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828952.72</fme:EASTING>
<fme:NORTHING>823170.08</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823170.07800 828952.71834 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5490f430-c609-45de-8401-826a2d6846f4">
<fme:FEATURE_ID>1000973646</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829467.33</fme:EASTING>
<fme:NORTHING>823179</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Bridge West Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣橋西變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823179.00196 829467.33074 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id38a846f0-a6fa-46d0-9866-db0f1f23b5fc">
<fme:FEATURE_ID>1210035127</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829669.19</fme:EASTING>
<fme:NORTHING>823187.88</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823187.87507 829669.19191 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idffb33821-06e0-43d6-b589-31a79d6c9360">
<fme:FEATURE_ID>1210035131</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829787.55</fme:EASTING>
<fme:NORTHING>823219.3</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823219.30427 829787.54695 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7640a5b9-2352-4dfc-bd01-24f83d4d8eed">
<fme:FEATURE_ID>1000973679</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828054.14</fme:EASTING>
<fme:NORTHING>823221.04</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Wah Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>青華花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823221.03574 828054.13913 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3f858ab5-b8e1-4c55-b087-a54d9f47d98c">
<fme:FEATURE_ID>1210033726</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829132.18</fme:EASTING>
<fme:NORTHING>823236.75</fme:NORTHING>
<fme:ENGLISHNAME>FR. CUCCHIARA MEMORIAL SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>郭怡雅神父紀念學校</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823236.74910 829132.17778 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf58e8c7b-2d95-4367-8d0e-0020679d85be">
<fme:FEATURE_ID>1210050354</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829025.82</fme:EASTING>
<fme:NORTHING>823245.64</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Bus Terminus Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長青巴士站公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823245.64041 829025.82028 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id487348ee-9960-4ca0-a545-0cf8dcab60bd">
<fme:FEATURE_ID>1000973570</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829058.82</fme:EASTING>
<fme:NORTHING>823253.96</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG CHING BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>長青巴士總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823253.95975 829058.82050 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idabbdf8b0-34c2-47bc-8b60-e55279b27215">
<fme:FEATURE_ID>1210035128</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829803.79</fme:EASTING>
<fme:NORTHING>823255.46</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823255.45987 829803.79061 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd85aa157-4fcc-4aeb-b517-5bd8e7548ba6">
<fme:FEATURE_ID>1000973647</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829546.99</fme:EASTING>
<fme:NORTHING>823257.96</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823257.95537 829546.98677 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id530c05f0-a568-4de0-a11b-17f5e236250b">
<fme:FEATURE_ID>1310061929</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829036</fme:EASTING>
<fme:NORTHING>823271</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Bus Terminus</fme:ENGLISHNAME>
<fme:CHINESENAME>長青巴士總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823264.16454 829036.29071 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id733586ae-c85c-477c-b738-a5297df6fbb1">
<fme:FEATURE_ID>1210035129</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829837.79</fme:EASTING>
<fme:NORTHING>823265.87</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823265.86600 829837.78800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id4ab0645a-126b-4054-8480-5a884d7e73bf">
<fme:FEATURE_ID>1210035241</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829681.63</fme:EASTING>
<fme:NORTHING>823267.54</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823267.53700 829681.62900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc9ee6402-3ff9-4ab3-bcec-55a49afb7ba7">
<fme:FEATURE_ID>1000973716</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828080.61</fme:EASTING>
<fme:NORTHING>823273.92</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Wah Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>青華遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823273.92233 828080.61366 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id07c3758b-41d8-43ae-94a5-39074c4e192f">
<fme:FEATURE_ID>1000973765</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828113.53</fme:EASTING>
<fme:NORTHING>823274.44</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823274.44090 828113.52935 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id621a9b80-fb09-4e00-81e6-ade61f88bf8a">
<fme:FEATURE_ID>1210035130</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829872.13</fme:EASTING>
<fme:NORTHING>823275.08</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823275.07600 829872.12500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idce39fdbc-39c7-483c-aa7a-739b8800b93f">
<fme:FEATURE_ID>1210035242</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829709.03</fme:EASTING>
<fme:NORTHING>823275.14</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823275.14400 829709.03200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id64c18113-220f-430c-ac03-f1f58b2a7ced">
<fme:FEATURE_ID>1000973742</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SEC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828747.24</fme:EASTING>
<fme:NORTHING>823276.49</fme:NORTHING>
<fme:ENGLISHNAME>PO LEUNG KUK MR. &amp; MRS. CHAN PAK KEUNG TSING YI SCHOOL (PRIMARY SECTION)</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局陳百強伉儷青衣學校(小學部)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823276.48885 828747.23668 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id35f3d944-9fc9-4663-b98d-7f830f9f81a9">
<fme:FEATURE_ID>1210035126</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829738.23</fme:EASTING>
<fme:NORTHING>823282.51</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823282.50700 829738.22800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id98a5c4b5-5461-4926-9937-86edb69859e2">
<fme:FEATURE_ID>1210033477</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828602.1</fme:EASTING>
<fme:NORTHING>823291.99</fme:NORTHING>
<fme:ENGLISHNAME>TUNG WAH GROUP OF HOSPITALS CHOW YIN SUM PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>東華三院周演森小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823291.98680 828602.09860 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcb261da0-7229-4899-a505-ef7a561dcb07">
<fme:FEATURE_ID>1000973670</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828959.5</fme:EASTING>
<fme:NORTHING>823306.54</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hong Commercial Centre No 1</fme:ENGLISHNAME>
<fme:CHINESENAME>長康第一商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250327</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823306.53721 828959.50309 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc0123429-d662-49e7-90c5-38fcbfbac881">
<fme:FEATURE_ID>1000973720</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>POF</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828928.04</fme:EASTING>
<fme:NORTHING>823310.02</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Post Office</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣郵政局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823310.01764 828928.04465 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9bd90ab6-7d79-4a74-af71-512769dfd3e5">
<fme:FEATURE_ID>1000973746</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829198.5</fme:EASTING>
<fme:NORTHING>823317.96</fme:NORTHING>
<fme:ENGLISHNAME>BUDDHIST YIP KEI NAM MEMORIAL COLLEGE</fme:ENGLISHNAME>
<fme:CHINESENAME>佛教葉紀南紀念中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823317.96362 829198.49801 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd3313031-85b7-4c7c-af8e-658ada46bcbc">
<fme:FEATURE_ID>1420001880</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CLI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828966.15</fme:EASTING>
<fme:NORTHING>823320.87</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Cheung Hong Family Medicine Clinic</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣長康家庭醫學診所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260401</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823320.86595 828966.14616 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3bc4fb6f-82f5-4791-a1f3-e2837e11e698">
<fme:FEATURE_ID>1310052967</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CLI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828966.15</fme:EASTING>
<fme:NORTHING>823320.87</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Maternal &amp; Child Health Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣母嬰健康院</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823320.86595 828966.14616 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9dbae81d-646c-493c-8a6e-0caf0790c648">
<fme:FEATURE_ID>1210021145</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CLI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828966.15</fme:EASTING>
<fme:NORTHING>823320.87</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Cheung Hong Family Medicine Clinic</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣長康家庭醫學診所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260224</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823320.86595 828966.14616 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbf63da60-646f-4d3e-a390-de314eca7525">
<fme:FEATURE_ID>1000973703</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827472.74</fme:EASTING>
<fme:NORTHING>823329.69</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823329.68721 827472.74209 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8bdf4a6c-e126-4e56-871d-85df4d78ac24">
<fme:FEATURE_ID>1000973595</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPM</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828254.73</fme:EASTING>
<fme:NORTHING>823332</fme:NORTHING>
<fme:ENGLISHNAME>Ching Wah Car Park</fme:ENGLISHNAME>
<fme:CHINESENAME>青華停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250916</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823331.99505 828254.73156 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0a5f6168-d075-40f2-b82d-c45cd76a3972">
<fme:FEATURE_ID>1310061878</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828969.51</fme:EASTING>
<fme:NORTHING>823335.48</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG HONG ESTATE</fme:ENGLISHNAME>
<fme:CHINESENAME>長康邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823335.47802 828969.50515 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide9b552d5-dc3b-48bf-9e48-35f59d350341">
<fme:FEATURE_ID>1000973688</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829402.98</fme:EASTING>
<fme:NORTHING>823336</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Tat Road Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>長達路休憩處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823336.00026 829402.97771 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5c0a8e15-0cab-4bd6-901c-62405201d93f">
<fme:FEATURE_ID>1210035132</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829648.98</fme:EASTING>
<fme:NORTHING>823345.3</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823345.29800 829648.97800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc5a811f4-c80c-4aac-9214-69ed57265c6a">
<fme:FEATURE_ID>1210035133</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829674.72</fme:EASTING>
<fme:NORTHING>823356.36</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823356.36100 829674.72400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7b6227b7-4224-44ba-beb3-674817b76fdf">
<fme:FEATURE_ID>1210033402</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828769.73</fme:EASTING>
<fme:NORTHING>823360.94</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI TRADE ASSOCIATION PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣商會小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823360.93476 828769.72741 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1c077a57-d8b3-4365-b875-546334094c62">
<fme:FEATURE_ID>1210035134</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829772.58</fme:EASTING>
<fme:NORTHING>823363.7</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823363.69500 829772.58400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc0eaa4b6-f134-46df-9804-d0f40cf33f0e">
<fme:FEATURE_ID>1210017632</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828889</fme:EASTING>
<fme:NORTHING>823364</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823364.00000 828889.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id212779d9-d889-4f7c-82dc-3a3357cc9fdf">
<fme:FEATURE_ID>1000973745</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828687.85</fme:EASTING>
<fme:NORTHING>823367.33</fme:NORTHING>
<fme:ENGLISHNAME>PO LEUNG KUK LO KIT SING (1983) COLLEGE</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局羅傑承(一九八三)中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823367.33094 828687.85235 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id97f9dce3-19ba-4445-9042-20e1f318a974">
<fme:FEATURE_ID>1210035239</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829702.2</fme:EASTING>
<fme:NORTHING>823367.42</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823367.42300 829702.20000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3dbc2248-5e6c-4bd8-a5e4-bc7a2b346832">
<fme:FEATURE_ID>1210010226</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829382.83</fme:EASTING>
<fme:NORTHING>823368.18</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG TAT ROAD COOKED FOOD MARKET</fme:ENGLISHNAME>
<fme:CHINESENAME>長達路熟食市場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823368.17645 829382.83194 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd2e670bd-f04f-4528-a911-af616a68586d">
<fme:FEATURE_ID>1210035135</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829798.35</fme:EASTING>
<fme:NORTHING>823372.92</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823372.91900 829798.35000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1c791c4e-dbd1-4d54-8172-2a522f486510">
<fme:FEATURE_ID>1310064516</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CMC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829143.71</fme:EASTING>
<fme:NORTHING>823375.92</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Community Hall</fme:ENGLISHNAME>
<fme:CHINESENAME>長青社區會堂</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823375.91838 829143.71340 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id751b3c45-70cb-4a7c-81eb-decf78c11c69">
<fme:FEATURE_ID>1210035240</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829825.82</fme:EASTING>
<fme:NORTHING>823383.98</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823383.98100 829825.81600 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3f61bb08-ae1a-49dc-9ed3-38508302c816">
<fme:FEATURE_ID>1210040132</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828474</fme:EASTING>
<fme:NORTHING>823386</fme:NORTHING>
<fme:ENGLISHNAME>HONG CHEUNG HOUSE CHEUNG HONG ESTATE</fme:ENGLISHNAME>
<fme:CHINESENAME>長康邨康祥樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823386.00000 828474.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idaeb9df06-c2ca-4cc8-9a65-202b57dc222b">
<fme:FEATURE_ID>1000973777</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829361.47</fme:EASTING>
<fme:NORTHING>823390.79</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823390.78631 829361.47393 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc76f01eb-fce0-4405-bd76-5923e0e44d97">
<fme:FEATURE_ID>1000973733</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829360.74</fme:EASTING>
<fme:NORTHING>823405.13</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Tat Road Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長達路公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823405.13160 829360.73771 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide524426f-1486-4c02-9093-4370a7dab233">
<fme:FEATURE_ID>1000973573</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828215.84</fme:EASTING>
<fme:NORTHING>823412.24</fme:NORTHING>
<fme:ENGLISHNAME>CHEUNG HONG BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>長康巴士總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823412.23918 828215.83912 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6bf6d7f7-093c-4158-adb7-bc54c38f83b6">
<fme:FEATURE_ID>1000973672</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828194.27</fme:EASTING>
<fme:NORTHING>823413.21</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hong Estate Commercial Centre No.2</fme:ENGLISHNAME>
<fme:CHINESENAME>長康邨第二商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823413.20906 828194.26507 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id01ad6be3-df6a-44dd-b4b4-6fe0cc28ed7c">
<fme:FEATURE_ID>1210018273</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828430.29</fme:EASTING>
<fme:NORTHING>823427.59</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hong Estate Cooked Food Stall</fme:ENGLISHNAME>
<fme:CHINESENAME>長康邨熟食檔</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823427.59000 828430.29000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0a3b0c6a-40f3-4f09-a802-e0b478b7e8f2">
<fme:FEATURE_ID>1000973664</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828300.98</fme:EASTING>
<fme:NORTHING>823440.17</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hong Estate Market No.2</fme:ENGLISHNAME>
<fme:CHINESENAME>長康邨第二街市</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823440.17438 828300.98039 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id80942313-e9fc-4985-abd2-15bbfec7f088">
<fme:FEATURE_ID>1310057428</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829503.11</fme:EASTING>
<fme:NORTHING>823450.44</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Fai Road Promenade</fme:ENGLISHNAME>
<fme:CHINESENAME>長輝路海濱花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823450.43495 829503.10935 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9ba1aa54-936c-4364-866b-c91fd9f5fad0">
<fme:FEATURE_ID>1000973750</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828857.16</fme:EASTING>
<fme:NORTHING>823455.89</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823455.88589 828857.15606 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2e42d7ec-7197-40a8-b291-4d6cb1bdb4f0">
<fme:FEATURE_ID>1000973613</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828154.73</fme:EASTING>
<fme:NORTHING>823455.89</fme:NORTHING>
<fme:ENGLISHNAME>Leung Chik Wai Mem Sch Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>樂善堂粱植偉紀念中學變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823455.88664 828154.72961 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id27c34ef9-eed9-45c9-bb24-4ff203d70f58">
<fme:FEATURE_ID>1000973612</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828947.37</fme:EASTING>
<fme:NORTHING>823468.01</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi North Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣北變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823468.01236 828947.37277 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idebfde56f-2368-4324-94f8-17e316258450">
<fme:FEATURE_ID>1000973756</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828490.2</fme:EASTING>
<fme:NORTHING>823481.86</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823481.86192 828490.20204 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9b132173-aba3-4999-afea-00b02d01ebc3">
<fme:FEATURE_ID>1000973760</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829176.56</fme:EASTING>
<fme:NORTHING>823482.49</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823482.48739 829176.55787 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide2688b0e-e956-4247-bae1-c5ade275746d">
<fme:FEATURE_ID>1210033480</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828222.06</fme:EASTING>
<fme:NORTHING>823485.17</fme:NORTHING>
<fme:ENGLISHNAME>PO LEUNG KUK CHAN YAT PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局陳溢小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823485.17137 828222.06362 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida6c4f163-b6ec-4ed6-9235-ac1bd6d6eac2">
<fme:FEATURE_ID>1000973744</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828131.62</fme:EASTING>
<fme:NORTHING>823485.8</fme:NORTHING>
<fme:ENGLISHNAME>LOK SIN TONG LEUNG CHIK WAI MEMORIAL SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>樂善堂梁植偉紀念中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823485.79602 828131.62450 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7fb2432e-4794-4880-b628-8b33a38fe533">
<fme:FEATURE_ID>1000973711</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829204.1</fme:EASTING>
<fme:NORTHING>823486.23</fme:NORTHING>
<fme:ENGLISHNAME>Chung Mei Road Temporary Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>涌美路臨時遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823486.23089 829204.10286 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id39e08868-1326-47c0-9487-adeb1eb6b8b9">
<fme:FEATURE_ID>1000973691</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828995.03</fme:EASTING>
<fme:NORTHING>823497.34</fme:NORTHING>
<fme:ENGLISHNAME>Sheung Ko Tan Street Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>上高灘街休憩處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823497.33674 828995.03255 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id522e0b1f-00a9-4af6-a626-315cece9e89e">
<fme:FEATURE_ID>1000973764</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828643.24</fme:EASTING>
<fme:NORTHING>823499.2</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823499.19567 828643.24155 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9478283f-931a-46a4-bed3-e2164b27f6d3">
<fme:FEATURE_ID>1000973704</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829193.67</fme:EASTING>
<fme:NORTHING>823509.68</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823509.67769 829193.67389 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd474bd35-1ca2-47d4-85f1-b79385a3b6fa">
<fme:FEATURE_ID>1000973655</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829473.83</fme:EASTING>
<fme:NORTHING>823512.33</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Fireboat Station</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣滅火輪消防局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823512.32963 829473.82874 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id0197419c-617b-46a4-8387-5224276ed454">
<fme:FEATURE_ID>1000973728</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829456.3</fme:EASTING>
<fme:NORTHING>823527.11</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Fai Road Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長輝路公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823527.11161 829456.30230 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9d85e065-01e2-49ca-a88b-8f2320ef3e87">
<fme:FEATURE_ID>1000973700</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827247.35</fme:EASTING>
<fme:NORTHING>823533.39</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823533.38744 827247.35122 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id36bfa940-cb09-4ace-bd8c-127e85a903f8">
<fme:FEATURE_ID>1000973792</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TTH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828840.51</fme:EASTING>
<fme:NORTHING>823539.3</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823539.29905 828840.51012 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id35abf043-6d34-4307-89d5-500e87b4993d">
<fme:FEATURE_ID>1000973653</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829166.95</fme:EASTING>
<fme:NORTHING>823539.75</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Fire Station</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣消防局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823539.74981 829166.95223 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3c9a3683-293e-4674-92fa-b2bf2885c538">
<fme:FEATURE_ID>1210017447</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828663.18</fme:EASTING>
<fme:NORTHING>823566.13</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823566.13229 828663.17916 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5c048786-962e-4a20-8ac7-baa73ec79dc1">
<fme:FEATURE_ID>1310061930</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826772.33</fme:EASTING>
<fme:NORTHING>823569.95</fme:NORTHING>
<fme:ENGLISHNAME>Hong Kong United Dockyard Minibus Terminus</fme:ENGLISHNAME>
<fme:CHINESENAME>香港聯合船塢小巴總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823569.95000 826772.33000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3e95caf0-d0f8-405f-abd5-f4fd01ad00e0">
<fme:FEATURE_ID>1000973721</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829126.33</fme:EASTING>
<fme:NORTHING>823574.5</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI POLICE STATION</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣警署</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823574.49457 829126.33218 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id57fc35c8-32e6-4262-987e-5b46aeb7ed44">
<fme:FEATURE_ID>1210032687</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>6</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PSN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829126.33</fme:EASTING>
<fme:NORTHING>823574.5</fme:NORTHING>
<fme:ENGLISHNAME>KWAI TSING DISTRICT HEADQUARTERS</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青區總部</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823574.49457 829126.33218 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id29d15fae-f657-4f9f-8541-a7a8b8dbb832">
<fme:FEATURE_ID>1000973639</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828919.47</fme:EASTING>
<fme:NORTHING>823580.64</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823580.63899 828919.47009 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id183ff5e1-9cf9-4042-a865-767d920e1be1">
<fme:FEATURE_ID>1000973737</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VTI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828631.16</fme:EASTING>
<fme:NORTHING>823581.41</fme:NORTHING>
<fme:ENGLISHNAME>Occupational Safety and Health Council Occupational Safety and Health Academy</fme:ENGLISHNAME>
<fme:CHINESENAME>職業安全健康局職安健學院</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823581.40542 828631.15459 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc6e33303-f153-4b28-b4d8-510a3a8be12e">
<fme:FEATURE_ID>1000973686</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828730.38</fme:EASTING>
<fme:NORTHING>823594.85</fme:NORTHING>
<fme:ENGLISHNAME>Chung Mei Road Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>涌美路休憩處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823594.84944 828730.37950 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide1aec486-9ea4-467f-8745-dc65c1b4e47f">
<fme:FEATURE_ID>1000973787</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TMP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829024.33</fme:EASTING>
<fme:NORTHING>823606.7</fme:NORTHING>
<fme:ENGLISHNAME>Ching Tak Tong Tat Mor Cho Sze Temple</fme:ENGLISHNAME>
<fme:CHINESENAME>清德堂達摩祖師廟</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823606.69742 829024.32995 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idac913f9b-1e77-4011-8e38-542a1d5d8ee3">
<fme:FEATURE_ID>1210037664</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828566.3</fme:EASTING>
<fme:NORTHING>823611.52</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Southwest Sports Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣西南體育館</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823611.51921 828566.29990 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id29ccb617-e22f-42db-9314-1256edc72018">
<fme:FEATURE_ID>1000973692</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828992.77</fme:EASTING>
<fme:NORTHING>823616.08</fme:NORTHING>
<fme:ENGLISHNAME>Sheung Ko Tan Street Sitting-out Area</fme:ENGLISHNAME>
<fme:CHINESENAME>上高灘街休憩處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823616.07940 828992.77279 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ideb1ec400-0457-401e-9852-f4dbd1cc4c0f">
<fme:FEATURE_ID>1210029372</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829151.23</fme:EASTING>
<fme:NORTHING>823624.41</fme:NORTHING>
<fme:ENGLISHNAME>GREENFIELD GARDEN</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823624.41187 829151.23323 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5f7e6c76-37ff-4350-b32c-b136065425b2">
<fme:FEATURE_ID>1000973619</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826724.15</fme:EASTING>
<fme:NORTHING>823628.94</fme:NORTHING>
<fme:ENGLISHNAME>HUD Development B Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>聯合船塢Ｂ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823628.94479 826724.15229 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3c0ef89e-b7db-40c5-8976-bfae32de34af">
<fme:FEATURE_ID>1210015729</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828215</fme:EASTING>
<fme:NORTHING>823629</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823629.00000 828215.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idac244ac3-d5c9-4561-863d-414b9e326c35">
<fme:FEATURE_ID>1000973724</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829048.37</fme:EASTING>
<fme:NORTHING>823643.67</fme:NORTHING>
<fme:ENGLISHNAME>Lutheran Village Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>信義村公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823643.66631 829048.37325 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id827f9078-5d3d-4faa-b624-e732857d65cb">
<fme:FEATURE_ID>1000973675</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829207.92</fme:EASTING>
<fme:NORTHING>823650.21</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Shopping Arcade</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823650.21100 829207.91500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idab97116d-8cc8-4fc3-8c12-63f1eba355b2">
<fme:FEATURE_ID>1000973680</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829256.87</fme:EASTING>
<fme:NORTHING>823650.26</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Wan Street Rest Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>長環街休憩花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823650.25704 829256.87075 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id85013bdd-62a9-49c5-8021-95e2b09b1946">
<fme:FEATURE_ID>1000973629</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826530.75</fme:EASTING>
<fme:NORTHING>823654.49</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823654.49114 826530.75324 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5ba4a07d-cc05-443f-bde2-408d627956ba">
<fme:FEATURE_ID>1210040155</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829073</fme:EASTING>
<fme:NORTHING>823661</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>青衣真君古廟旁休憩處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823661.00000 829073.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide638d74b-97ad-4426-8824-be202bccb4f6">
<fme:FEATURE_ID>1210020673</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TTH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828363.89</fme:EASTING>
<fme:NORTHING>823664.68</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>鄧氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823664.68308 828363.89267 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idc7927674-fd90-4454-84e7-75d92a9df33c">
<fme:FEATURE_ID>1000973785</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TMP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829053.11</fme:EASTING>
<fme:NORTHING>823669.73</fme:NORTHING>
<fme:ENGLISHNAME>Chun Kwan Temple</fme:ENGLISHNAME>
<fme:CHINESENAME>真君大帝廟</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823669.73372 829053.10569 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5c6453ed-9eb6-4e49-9826-c1351364130e">
<fme:FEATURE_ID>1000973755</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828465.83</fme:EASTING>
<fme:NORTHING>823670.13</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Four Village Playground Basketball Court No.2</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣四村遊樂場2號籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823670.13188 828465.83166 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idaa658551-45ad-4257-a272-60208a0b4e35">
<fme:FEATURE_ID>1000973784</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TMP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829003.94</fme:EASTING>
<fme:NORTHING>823672</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>廟宇</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823671.99666 829003.93459 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idac6abad3-f169-43a5-b845-a5f1ebe77ed1">
<fme:FEATURE_ID>1000973690</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828247.32</fme:EASTING>
<fme:NORTHING>823691.6</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Road West Park</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣西路公園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823691.60061 828247.31604 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd1d241d2-d33a-4e80-84d5-17f8cdd06f1e">
<fme:FEATURE_ID>1420006552</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828455.37</fme:EASTING>
<fme:NORTHING>823695.99</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260616</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823695.98563 828455.36490 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1c7853be-a93e-4b10-b485-0ce9512dc9ff">
<fme:FEATURE_ID>1210013788</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829383</fme:EASTING>
<fme:NORTHING>823696</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823696.00000 829383.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id81a2b470-a048-467e-8f8a-81008bc2a34f">
<fme:FEATURE_ID>1000973635</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828434.92</fme:EASTING>
<fme:NORTHING>823701.35</fme:NORTHING>
<fme:ENGLISHNAME>Lam Tin Resite Village Phase 1 Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>藍田村第1期電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823701.34541 828434.91732 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf3d08277-c3c6-4852-8015-53e0ae494604">
<fme:FEATURE_ID>1210020010</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828107.69</fme:EASTING>
<fme:NORTHING>823714.41</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823714.41346 828107.68942 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id25e19dc3-5a79-493e-8e9a-c711b69f35a6">
<fme:FEATURE_ID>1210019978</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828122.92</fme:EASTING>
<fme:NORTHING>823721.85</fme:NORTHING>
<fme:ENGLISHNAME>Liu To Road Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>寮肚路花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823721.84786 828122.91785 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbcc01612-e389-4703-98c0-86972d9ae87b">
<fme:FEATURE_ID>1000973743</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828505.51</fme:EASTING>
<fme:NORTHING>823723.46</fme:NORTHING>
<fme:ENGLISHNAME>TUNG WAH GROUP OF HOSPITALS S.C. GAW MEMORIAL COLLEGE</fme:ENGLISHNAME>
<fme:CHINESENAME>東華三院吳祥川紀念中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823723.45691 828505.51173 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="iddc8b67cb-7f25-49cf-9af6-e06ab9ae15e9">
<fme:FEATURE_ID>1310052776</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829375.86</fme:EASTING>
<fme:NORTHING>823733.39</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Promenade-Grand Horizon Portion</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣海濱公園—海欣花園段</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823733.39336 829375.86165 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb890a950-bea0-449a-9809-97028b9ffe51">
<fme:FEATURE_ID>1000973789</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TTH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828355.75</fme:EASTING>
<fme:NORTHING>823740.93</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823740.92835 828355.75013 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8e1a3a5c-e928-44ff-93ad-7b1ed119ce59">
<fme:FEATURE_ID>1000973656</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HLP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826721.78</fme:EASTING>
<fme:NORTHING>823748.38</fme:NORTHING>
<fme:ENGLISHNAME>Helicopter Landing Site - KL20  - TSING YI WEST</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823748.38457 826721.78373 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb48b26e4-5cbe-423f-961b-775f314d3acd">
<fme:FEATURE_ID>1000973628</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829090.26</fme:EASTING>
<fme:NORTHING>823751.08</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823751.08467 829090.26031 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf25086c8-6ac9-48da-bf7b-3992c1b7b3fb">
<fme:FEATURE_ID>1000973587</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPO</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828439.71</fme:EASTING>
<fme:NORTHING>823767.81</fme:NORTHING>
<fme:ENGLISHNAME>4 Tsing Yi Resite Village (Tai Mong Ha, San Uk, Yim Tin Kok, Lam Tin)</fme:ENGLISHNAME>
<fme:CHINESENAME>4 青衣屋村 (大王下村, 新屋村, 鹽田角村, 藍田村)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823767.80974 828439.70602 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id23c37828-a6a3-44ec-b770-f4a5526edfd9">
<fme:FEATURE_ID>1000973753</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828667.74</fme:EASTING>
<fme:NORTHING>823769.52</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823769.51765 828667.74120 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3a25cf3f-e1b1-4abd-ab88-3575f9478dd2">
<fme:FEATURE_ID>1210035324</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829830.35</fme:EASTING>
<fme:NORTHING>823770.59</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823770.59016 829830.34650 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide5c9f54e-65a4-4164-a1f3-a7254a78d63d">
<fme:FEATURE_ID>1310055188</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829207.38</fme:EASTING>
<fme:NORTHING>823772.92</fme:NORTHING>
<fme:ENGLISHNAME>FUNG SHUE WO ROAD</fme:ENGLISHNAME>
<fme:CHINESENAME>楓樹窩路</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823772.92000 829207.38000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id08d38089-0cf9-4ad7-9c12-ea5c9c9de291">
<fme:FEATURE_ID>1000973623</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828463.83</fme:EASTING>
<fme:NORTHING>823777.26</fme:NORTHING>
<fme:ENGLISHNAME>Lam Tin Resite Village Phase 2 Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>藍田村第2期電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823777.26405 828463.82856 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1960b471-e14f-49f8-871c-5d6ffe0e8d4e">
<fme:FEATURE_ID>1000973718</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828484.46</fme:EASTING>
<fme:NORTHING>823782.7</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Four Village Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣四村遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823782.69729 828484.46202 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide9157675-f5ec-4900-8746-f35957080ff2">
<fme:FEATURE_ID>1210050625</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828858.38</fme:EASTING>
<fme:NORTHING>823784.82</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823784.81800 828858.38400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7c455829-c35a-48c0-8a6b-332a0581da99">
<fme:FEATURE_ID>1210013784</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829352</fme:EASTING>
<fme:NORTHING>823789</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823789.00000 829352.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id9398868a-6a25-4a4e-b3bd-0a7a6c362893">
<fme:FEATURE_ID>1000973684</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829157.5</fme:EASTING>
<fme:NORTHING>823790.26</fme:NORTHING>
<fme:ENGLISHNAME>Tsing King Road Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>青敬路花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823790.26265 829157.49949 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1af7fd23-1712-4cc2-8486-959319429c9f">
<fme:FEATURE_ID>1000973788</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TTH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828389.9</fme:EASTING>
<fme:NORTHING>823802.16</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823802.15738 828389.90361 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idb15d37ce-f7a5-4f7f-9c1d-6cb770070346">
<fme:FEATURE_ID>1000973761</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828461.88</fme:EASTING>
<fme:NORTHING>823803.07</fme:NORTHING>
<fme:ENGLISHNAME>Basketball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>籃球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823803.06506 828461.87987 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id315b7932-b1d5-48d7-bf54-825e8af66743">
<fme:FEATURE_ID>1210015569</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829137.03</fme:EASTING>
<fme:NORTHING>823805.09</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823805.08500 829137.03214 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idbf92dfa2-bfd7-42b1-90f7-f3e73fcc323d">
<fme:FEATURE_ID>1210050624</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828944.83</fme:EASTING>
<fme:NORTHING>823809.39</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823809.38700 828944.82900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2db5a836-89f4-4668-988c-3ad7cdc330c3">
<fme:FEATURE_ID>1210050976</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829046.66</fme:EASTING>
<fme:NORTHING>823811.37</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823811.37400 829046.65800 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id745446b9-f2d0-4d38-85de-1348d0ba956d">
<fme:FEATURE_ID>1000973676</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828921.72</fme:EASTING>
<fme:NORTHING>823814.95</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Square</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡薈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823814.95371 828921.72279 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id8d502d33-4e66-4392-8d77-0a4e26b2d537">
<fme:FEATURE_ID>1000973696</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828304.06</fme:EASTING>
<fme:NORTHING>823815.7</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823815.69632 828304.05923 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idab96d5ad-1011-478a-9f96-7d39abaf9e7d">
<fme:FEATURE_ID>1000973681</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828788.77</fme:EASTING>
<fme:NORTHING>823821.5</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Luk Street Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>青綠街花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823821.49629 828788.77444 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id959100ac-db3e-4d81-99ed-4eee6afc1590">
<fme:FEATURE_ID>1210050623</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828959.51</fme:EASTING>
<fme:NORTHING>823832.17</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823832.16800 828959.51300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id1c214c57-a391-4926-8e73-90b3f79f00c3">
<fme:FEATURE_ID>1210031879</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829203.04</fme:EASTING>
<fme:NORTHING>823841.73</fme:NORTHING>
<fme:ENGLISHNAME>Serene Garden Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>海悅花園商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823841.73275 829203.03859 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id03bd769f-cc4f-4251-b8bf-d38f10469c81">
<fme:FEATURE_ID>1000973572</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829257.77</fme:EASTING>
<fme:NORTHING>823844.95</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI FERRY BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣碼頭總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823844.94952 829257.77364 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ida29de8cf-c9ee-4fad-af01-54ee3683cea5">
<fme:FEATURE_ID>1310055186</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828699.5</fme:EASTING>
<fme:NORTHING>823847.37</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Estate Minibus Terminus</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣邨小巴總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240926</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823847.36754 828699.49677 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id13e9994e-6681-4836-bbeb-bbb78dc9f55a">
<fme:FEATURE_ID>1000973719</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PLG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828548.28</fme:EASTING>
<fme:NORTHING>823852.77</fme:NORTHING>
<fme:ENGLISHNAME>Tai Wong Ha Playground</fme:ENGLISHNAME>
<fme:CHINESENAME>大王下遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823852.76723 828548.27698 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide90bcb76-3bc2-434f-855f-d8818f4a8cd4">
<fme:FEATURE_ID>1310055321</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829308.48</fme:EASTING>
<fme:NORTHING>823867.15</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Ferry Pier Terminus</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣碼頭總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823867.15000 829308.48000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6536189e-c6ed-4ed5-95f1-b5ba7ce9bf87">
<fme:FEATURE_ID>1000973790</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TTH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828379.5</fme:EASTING>
<fme:NORTHING>823868.36</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823868.36333 828379.49904 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3ae2021d-b787-4d82-b963-a1586de2e3ac">
<fme:FEATURE_ID>1000973571</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BUS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828730.01</fme:EASTING>
<fme:NORTHING>823871.75</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI ESTATE BUS TERMINUS</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣邨巴士總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823871.75297 828730.01178 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6c36c347-8d9b-4d21-887f-3d6e0d9630c6">
<fme:FEATURE_ID>1210035321</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829846.08</fme:EASTING>
<fme:NORTHING>823872.62</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823872.61700 829846.07500 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2c0877df-30c4-40a5-a174-404c73469af1">
<fme:FEATURE_ID>1210010286</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>LIB</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829021.38</fme:EASTING>
<fme:NORTHING>823873.87</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Public Library</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣公共圖書館</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823873.87174 829021.38289 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3d139573-e800-4958-8e7f-d27498310357">
<fme:FEATURE_ID>1210010285</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829006.23</fme:EASTING>
<fme:NORTHING>823874.14</fme:NORTHING>
<fme:ENGLISHNAME>TSING YI MARKET</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣街市</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823874.13534 829006.23142 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3b53cbe5-85c0-4582-b925-19553495fd6f">
<fme:FEATURE_ID>1210033504</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828629.86</fme:EASTING>
<fme:NORTHING>823874.44</fme:NORTHING>
<fme:ENGLISHNAME>TSUEN WAN TRADE ASSOCIATION PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>荃灣商會學校</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823874.43531 828629.85883 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idd46a8ce9-c662-4811-a468-dcc64937380e">
<fme:FEATURE_ID>1210010283</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>IGH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829037.12</fme:EASTING>
<fme:NORTHING>823875.2</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Sports Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣體育館</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823875.20226 829037.12445 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3755469d-0d8f-451f-a9ba-eb880f94e8e1">
<fme:FEATURE_ID>1310054528</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL> </fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828744.66</fme:EASTING>
<fme:NORTHING>823884.28</fme:NORTHING>
<fme:ENGLISHNAME>TSING LUK STREET</fme:ENGLISHNAME>
<fme:CHINESENAME>青綠街</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240926</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823884.27606 828744.66146 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2ad658bd-754d-429f-aef6-384ace3c354c">
<fme:FEATURE_ID>1000973727</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829282.75</fme:EASTING>
<fme:NORTHING>823885.03</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi New Ferry Terminus Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣新碼頭公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823885.02868 829282.75133 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idaf51c040-43f0-4f05-9eda-c104e96dcba4">
<fme:FEATURE_ID>1000973615</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826670.16</fme:EASTING>
<fme:NORTHING>823885.21</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823885.21234 826670.15753 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2f815fa7-89d9-42cd-8956-10a65768cf4d">
<fme:FEATURE_ID>1000973791</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TTH</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828388.05</fme:EASTING>
<fme:NORTHING>823892.29</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>張氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823892.28574 828388.04765 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id799c2721-f719-4928-93c4-56b7c1d2a738">
<fme:FEATURE_ID>1210007846</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829332</fme:EASTING>
<fme:NORTHING>823900</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Public Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣公眾碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823900.00000 829332.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3b812b84-10fd-4501-9cc9-4d706e2e9d00">
<fme:FEATURE_ID>1210018572</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828872.8</fme:EASTING>
<fme:NORTHING>823905.29</fme:NORTHING>
<fme:ENGLISHNAME>Tennis Court</fme:ENGLISHNAME>
<fme:CHINESENAME>網球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240926</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823905.28562 828872.80156 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id7c230c94-85b8-44a9-bbcd-ad30f49e0dec">
<fme:FEATURE_ID>1000973609</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CSC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829019.92</fme:EASTING>
<fme:NORTHING>823913.31</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Municipal Services Building</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣市政大廈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823913.30564 829019.91943 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id84f849ac-da49-4cf7-9c89-912ce9b5c7fb">
<fme:FEATURE_ID>1000973776</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828178.93</fme:EASTING>
<fme:NORTHING>823919.52</fme:NORTHING>
<fme:ENGLISHNAME>Volleyball Court</fme:ENGLISHNAME>
<fme:CHINESENAME>排球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823919.52190 828178.92905 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idcdb1625c-4ab2-4480-979f-8099c56a3e88">
<fme:FEATURE_ID>1000973674</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828698.72</fme:EASTING>
<fme:NORTHING>823926.6</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823926.60332 828698.71848 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6cf672d1-4c05-4df8-b861-97e94b06cbac">
<fme:FEATURE_ID>1310057481</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MIN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829114</fme:EASTING>
<fme:NORTHING>823929</fme:NORTHING>
<fme:ENGLISHNAME>Tivoli Garden Minibus Terminus</fme:ENGLISHNAME>
<fme:CHINESENAME>宏福花園小巴總站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823929.00000 829114.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id48fe6e2b-111e-4639-b494-e53b2bc428aa">
<fme:FEATURE_ID>1000973665</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MKT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828118.15</fme:EASTING>
<fme:NORTHING>823931.99</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hang Market</fme:ENGLISHNAME>
<fme:CHINESENAME>長亨街市</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823931.99442 828118.15147 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id60846ee1-9f33-4ef1-a33a-f97d28149c3f">
<fme:FEATURE_ID>1000973607</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>5</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CLI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828951.81</fme:EASTING>
<fme:NORTHING>823933.58</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Town Family Medicine Clinic</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣市區家庭醫學診所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260224</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823933.58010 828951.81256 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6f7a8c8e-8c46-43fe-b3cb-248c42617fce">
<fme:FEATURE_ID>1420003644</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829318.13</fme:EASTING>
<fme:NORTHING>823938.02</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823938.01689 829318.12934 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id2c485c0f-6ce0-4a7e-88cf-d81f8ee45d8c">
<fme:FEATURE_ID>1000973683</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828500.46</fme:EASTING>
<fme:NORTHING>823943.43</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yu Street Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>清譽街花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823943.43298 828500.46161 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idab048afa-34da-43d7-b158-5d015292b962">
<fme:FEATURE_ID>1000973769</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828914.83</fme:EASTING>
<fme:NORTHING>823944.12</fme:NORTHING>
<fme:ENGLISHNAME>Football Field</fme:ENGLISHNAME>
<fme:CHINESENAME>足球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823944.11847 828914.83212 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id278ac07e-d961-417a-aa3d-559bd179741a">
<fme:FEATURE_ID>1000973606</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>8</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CHU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828783.22</fme:EASTING>
<fme:NORTHING>823944.21</fme:NORTHING>
<fme:ENGLISHNAME>St. Thomas The Apostle Church</fme:ENGLISHNAME>
<fme:CHINESENAME>聖多默宗徒堂</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823944.20780 828783.21604 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id76d3c95e-99b5-4565-a50a-75b802f3e5a7">
<fme:FEATURE_ID>1000973759</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>7</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SGD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828853.77</fme:EASTING>
<fme:NORTHING>823947.04</fme:NORTHING>
<fme:ENGLISHNAME>Tennis Court</fme:ENGLISHNAME>
<fme:CHINESENAME>網球場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823947.03939 828853.76539 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id86a1dc76-9901-4acf-8481-52228a984474">
<fme:FEATURE_ID>1000973695</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAV</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828523.15</fme:EASTING>
<fme:NORTHING>823948.09</fme:NORTHING>
<fme:ENGLISHNAME>Pavilion</fme:ENGLISHNAME>
<fme:CHINESENAME>亭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823948.09279 828523.14572 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id57d5d137-86fd-4a23-ae0b-c98f932f1dcf">
<fme:FEATURE_ID>1210011667</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828714.19</fme:EASTING>
<fme:NORTHING>823949.12</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Estate Cooked Food Stalls</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣邨熟食檔</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823949.12051 828714.18930 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3f456bff-e524-4b25-81cb-e7b7f19f0229">
<fme:FEATURE_ID>1000973673</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>MAL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828117.42</fme:EASTING>
<fme:NORTHING>823949.2</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hang Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>長亨商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823949.20263 828117.42175 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id48421a36-e63b-438e-bf48-b5fd63dbeb14">
<fme:FEATURE_ID>1000973583</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CPM</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829123.6</fme:EASTING>
<fme:NORTHING>823955.36</fme:NORTHING>
<fme:ENGLISHNAME>TIVOLI GARDEN</fme:ENGLISHNAME>
<fme:CHINESENAME>宏福花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823955.35492 829123.59884 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="ide58a4665-5af5-4a0d-a4ca-3bb6d5b640f0">
<fme:FEATURE_ID>1000973621</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828066.08</fme:EASTING>
<fme:NORTHING>823958.8</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi North High Level Fresh Water and Salt Water Pumping Station Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣北高地食水及海水抽水站電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823958.80450 828066.08183 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id6304f892-2257-404d-8d11-6ab631071298">
<fme:FEATURE_ID>1210026342</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PFS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828265.64</fme:EASTING>
<fme:NORTHING>823975.89</fme:NORTHING>
<fme:ENGLISHNAME>Caltex-Tsing Yi Petrol Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>加德士-青衣加油站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823975.88851 828265.64206 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id64485edc-ee2f-458f-8b1a-f76f5270c027">
<fme:FEATURE_ID>1000973735</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>9</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PRS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829029.15</fme:EASTING>
<fme:NORTHING>823982.39</fme:NORTHING>
<fme:ENGLISHNAME>PO LEUNG KUK CASTAR PRIMARY SCHOOL</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局世德小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823982.39229 829029.15095 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id23994b2e-54d7-4879-8389-da808cdb0f5a">
<fme:FEATURE_ID>1000973725</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>TOI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828866.82</fme:EASTING>
<fme:NORTHING>823985.97</fme:NORTHING>
<fme:ENGLISHNAME>Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>廁所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823985.96497 828866.82089 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id5764edc6-fe65-4909-99ff-7cb4ff86dfd3">
<fme:FEATURE_ID>1210027905</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>LPG</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828270.88</fme:EASTING>
<fme:NORTHING>823988.75</fme:NORTHING>
<fme:ENGLISHNAME>Caltex Liquefied Petroleum Gas Filling Station</fme:ENGLISHNAME>
<fme:CHINESENAME>加德士加氣站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250327</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823988.75037 828270.88046 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
</gml:FeatureCollection>
