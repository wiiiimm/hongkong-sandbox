<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821060.00062 826491.99641 0.00000</gml:lowerCorner>
<gml:upperCorner>823991.25920 829729.99670 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePoint gml:id="ida056e739-5395-413e-bcf9-2ba3885e3133">
<fme:FEATURE_ID>1001283329</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829030</fme:EASTING>
<fme:NORTHING>821060</fme:NORTHING>
<fme:ST_CODE>70071</fme:ST_CODE>
<fme:ENGLISHNAME>Sinopec Hong Kong Oil Terminal</fme:ENGLISHNAME>
<fme:CHINESENAME>中石化香港油庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821060.00062 829030.00380 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id57f14e71-a12e-4da7-87a5-b4c425c9091e">
<fme:FEATURE_ID>1420001156</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827468.46</fme:EASTING>
<fme:NORTHING>821081.21</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>VSC Construction Steel Solutions Limited</fme:ENGLISHNAME>
<fme:CHINESENAME>萬順昌建築鋼鐵工程有限公司</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821081.20800 827468.46100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idfab5b208-d26a-4cd9-9f53-7fff84b0933c">
<fme:FEATURE_ID>1001284052</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828606</fme:EASTING>
<fme:NORTHING>821140</fme:NORTHING>
<fme:ST_CODE>70069</fme:ST_CODE>
<fme:ENGLISHNAME>EXXONMOBIL HONG KONG LIMITED TSING YI TERMINAL (EAST)</fme:ENGLISHNAME>
<fme:CHINESENAME>埃克森美孚香港有限公司青衣油庫（東）</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821139.99906 828605.99630 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ida0a4f353-a638-4562-a415-4ece8e84acac">
<fme:FEATURE_ID>1210003953</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828247</fme:EASTING>
<fme:NORTHING>821268</fme:NORTHING>
<fme:ST_CODE>70070</fme:ST_CODE>
<fme:ENGLISHNAME>CLP - Tsing Yi Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>中華電力－青衣中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821267.99892 828247.00349 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id437af22a-5ce6-48e4-a05b-7a64c81b9032">
<fme:FEATURE_ID>1310014672</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828876</fme:EASTING>
<fme:NORTHING>821281</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Tien Chu (Tsing Yi) Industrial Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>天廚(青衣)工業中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821281.00000 828876.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idff7dea9c-7699-4b5b-8ab8-566d078a715b">
<fme:FEATURE_ID>1001283467</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829203.53</fme:EASTING>
<fme:NORTHING>821282</fme:NORTHING>
<fme:ST_CODE>78851</fme:ST_CODE>
<fme:ENGLISHNAME>Environmental Protection Department Chemical Waste Treatment Facilities</fme:ENGLISHNAME>
<fme:CHINESENAME>環境保護署化學廢物處理設施</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821281.99800 829203.53400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0060b2ac-1b1c-495a-9814-e2fd73d65fc4">
<fme:FEATURE_ID>1001283468</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827340</fme:EASTING>
<fme:NORTHING>821368</fme:NORTHING>
<fme:ST_CODE>70268</fme:ST_CODE>
<fme:ENGLISHNAME>Euroasia Dockyard</fme:ENGLISHNAME>
<fme:CHINESENAME>歐亞船廠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20241218</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821367.99537 827339.99608 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc86ea3e8-29cc-4667-b15b-06700a8c7116">
<fme:FEATURE_ID>1210002397</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827994.56</fme:EASTING>
<fme:NORTHING>821382.67</fme:NORTHING>
<fme:ST_CODE>71220</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Yi South Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣南食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821382.66811 827994.56075 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ida630f36d-4e68-4a5c-8154-3a9e276e7ce9">
<fme:FEATURE_ID>1001279480</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828044</fme:EASTING>
<fme:NORTHING>821453</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Nam Wan</fme:ENGLISHNAME>
<fme:CHINESENAME>南環</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821452.99602 828043.99963 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id0691c938-4205-44ca-b47d-571ce0e3dfd5">
<fme:FEATURE_ID>1001279481</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828871</fme:EASTING>
<fme:NORTHING>821458</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Nam Wan Kok</fme:ENGLISHNAME>
<fme:CHINESENAME>南灣角</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821458.00222 828871.00077 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id1e2b6580-adf9-44c5-ac18-08195cd191de">
<fme:FEATURE_ID>1210010287</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829080</fme:EASTING>
<fme:NORTHING>821467</fme:NORTHING>
<fme:ST_CODE>70073</fme:ST_CODE>
<fme:ENGLISHNAME>Trinseo (Hong Kong) Limited Tsing Yi Site</fme:ENGLISHNAME>
<fme:CHINESENAME>盛禧奧（香港）有限公司青衣廠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821466.99568 829079.99475 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id8112217d-a179-4479-aae0-55eb374a9956">
<fme:FEATURE_ID>1210007147</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829440.15</fme:EASTING>
<fme:NORTHING>821651.78</fme:NORTHING>
<fme:ST_CODE>82522</fme:ST_CODE>
<fme:ENGLISHNAME>China Merchants Logistics Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>招商局物流中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821651.77638 829440.14705 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ide6bd7d01-fbf8-414c-9eb6-d230de56c782">
<fme:FEATURE_ID>1210007146</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829393.23</fme:EASTING>
<fme:NORTHING>821774.93</fme:NORTHING>
<fme:ST_CODE>82173</fme:ST_CODE>
<fme:ENGLISHNAME>Asia Logistics Hub - SF Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>亞洲物流中心　－　順豐大廈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821774.92474 829393.22483 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idd80c7512-3b42-4550-b007-e8439cc7e776">
<fme:FEATURE_ID>1310016868</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829365</fme:EASTING>
<fme:NORTHING>822111.15</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>青年發展及國民教育基地</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20241218</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822111.14600 829364.99900 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id1f9bfb8d-2da0-4354-b60d-5e24c11f91a6">
<fme:FEATURE_ID>1420001861</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>IST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829178.4</fme:EASTING>
<fme:NORTHING>822130.2</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Mapletree Logistics Hub - Tsing Yi</fme:ENGLISHNAME>
<fme:CHINESENAME>豐樹青衣物流中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822130.19855 829178.39636 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id6e4eb833-016c-4173-a726-9181e463ef2c">
<fme:FEATURE_ID>1001279201</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828960</fme:EASTING>
<fme:NORTHING>822174</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Chun Fa Lok</fme:ENGLISHNAME>
<fme:CHINESENAME>春花落</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822173.99990 828960.00281 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idb283d38d-ef88-479d-9cb9-38cfebeb6545">
<fme:FEATURE_ID>1001279479</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827983</fme:EASTING>
<fme:NORTHING>822244</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Nam Wan</fme:ENGLISHNAME>
<fme:CHINESENAME>南灣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822244.00314 827983.00055 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idcc4d6794-e2f5-41be-ac12-22b55613aa9c">
<fme:FEATURE_ID>1001283469</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827489</fme:EASTING>
<fme:NORTHING>822267</fme:NORTHING>
<fme:ST_CODE>70305</fme:ST_CODE>
<fme:ENGLISHNAME>Yiu Lian Dockyards Limited</fme:ENGLISHNAME>
<fme:CHINESENAME>友聯船廠有限公司</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822266.99470 827488.99508 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ide0f2b889-1a7a-49b3-af0b-86a38f424e04">
<fme:FEATURE_ID>1001284141</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827485</fme:EASTING>
<fme:NORTHING>822436</fme:NORTHING>
<fme:ST_CODE>70304</fme:ST_CODE>
<fme:ENGLISHNAME>Chevron Hong Kong Limited Tsing Yi Terminal</fme:ENGLISHNAME>
<fme:CHINESENAME>雪佛龍香港有限公司青衣油庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822435.99687 827485.00154 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ida11ce973-83f1-48e1-b493-3b597d59a002">
<fme:FEATURE_ID>1001279574</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827615</fme:EASTING>
<fme:NORTHING>822445</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Sai Tso Wan</fme:ENGLISHNAME>
<fme:CHINESENAME>西草灣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822445.00427 827615.00425 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idf074b0ac-6130-4eed-a303-bf44d02d8c37">
<fme:FEATURE_ID>1210010963</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827548</fme:EASTING>
<fme:NORTHING>822529</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>DSL</fme:ENGLISHNAME>
<fme:CHINESENAME>香港聯集貨運</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822529.00000 827548.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idfb70c48d-0261-419d-84a9-091f7c760e9b">
<fme:FEATURE_ID>1210009897</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829169</fme:EASTING>
<fme:NORTHING>822582</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Ching Fu Court</fme:ENGLISHNAME>
<fme:CHINESENAME>青富苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20231128</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822581.99767 829168.99514 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idda2bc3e3-1569-4763-bf4b-b7202550ec45">
<fme:FEATURE_ID>1001278584</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829156</fme:EASTING>
<fme:NORTHING>822625</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Sai Shan</fme:ENGLISHNAME>
<fme:CHINESENAME>細山</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822625.00133 829155.99665 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idd52f9b6e-dd06-42d5-98bf-294357fdb171">
<fme:FEATURE_ID>1001281470</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829424</fme:EASTING>
<fme:NORTHING>822679</fme:NORTHING>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:ENGLISHNAME>Rambler Crest</fme:ENGLISHNAME>
<fme:CHINESENAME>藍澄灣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822678.99814 829424.00275 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id56809163-411f-415d-9d39-b8fcc590e2cc">
<fme:FEATURE_ID>1310015165</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828948</fme:EASTING>
<fme:NORTHING>822789</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>The Grand Marine</fme:ENGLISHNAME>
<fme:CHINESENAME>明翹匯</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822789.00000 828948.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc10d88c0-1030-4067-923f-bb48f8d2b0cd">
<fme:FEATURE_ID>1001278579</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829108</fme:EASTING>
<fme:NORTHING>822833</fme:NORTHING>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:ENGLISHNAME>Mayfair Gardens</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822833.00425 829108.00417 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id7d33c11e-3eb0-4332-9c74-002cc184b906">
<fme:FEATURE_ID>1001283334</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829491</fme:EASTING>
<fme:NORTHING>822835</fme:NORTHING>
<fme:ST_CODE>77858</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Yi Preliminary Treatment Works</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣基本污水處理廠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822834.99732 829490.99545 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idb299255b-4506-4009-85d5-7c157acf1331">
<fme:FEATURE_ID>1001284140</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827085</fme:EASTING>
<fme:NORTHING>822835</fme:NORTHING>
<fme:ST_CODE>70303</fme:ST_CODE>
<fme:ENGLISHNAME>Shell Tsing Yi Installation</fme:ENGLISHNAME>
<fme:CHINESENAME>蜆殼公司青衣油庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822835.00173 827084.99480 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idbdebb6bf-4444-4e71-98a1-7a36be076134">
<fme:FEATURE_ID>1001277511</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ISL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828200</fme:EASTING>
<fme:NORTHING>822900</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Tsing Yi</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822900.00027 828200.00454 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="iddbf6f77d-e9ab-4529-b4dc-78ea8577f3bb">
<fme:FEATURE_ID>1001279287</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827090</fme:EASTING>
<fme:NORTHING>823016</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Kam Chuk Kok</fme:ENGLISHNAME>
<fme:CHINESENAME>金竹角</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823016.00309 827090.00218 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id22e8a8f4-9b7d-4c59-ad1e-68493a7c680b">
<fme:FEATURE_ID>1210005866</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829223</fme:EASTING>
<fme:NORTHING>823051</fme:NORTHING>
<fme:ST_CODE>82439</fme:ST_CODE>
<fme:ENGLISHNAME>Ching Chun Court</fme:ENGLISHNAME>
<fme:CHINESENAME>青俊苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823050.99628 829223.00124 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id164a0d04-0b8c-4674-8575-962465e1e71e">
<fme:FEATURE_ID>1210002364</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829023.71</fme:EASTING>
<fme:NORTHING>823120.44</fme:NORTHING>
<fme:ST_CODE>71202</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Yi East Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣東食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823120.44313 829023.70834 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id22fc360d-67f8-447f-80c3-63bf28f4398c">
<fme:FEATURE_ID>1210002447</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829065.82</fme:EASTING>
<fme:NORTHING>823131.55</fme:NORTHING>
<fme:ST_CODE>71204</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Yi East Salt Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣東海水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823131.54661 829065.81725 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idccd388dd-ea0a-4610-97ed-9b0d7561296b">
<fme:FEATURE_ID>1210002330</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828894.85</fme:EASTING>
<fme:NORTHING>823174.84</fme:NORTHING>
<fme:ST_CODE>71203</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Yi East No.2 Fresh Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣東二號食水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823174.83765 828894.84720 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id2be0fd83-ffaf-48e7-81c3-76ccb65f9df1">
<fme:FEATURE_ID>1310016511</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829254.09</fme:EASTING>
<fme:NORTHING>823192.7</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>CHEUNG CHING ESTATE</fme:ENGLISHNAME>
<fme:CHINESENAME>長青邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20241023</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823192.69768 829254.09281 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id13a3faea-4960-46e9-b7e8-46fa49c5ab20">
<fme:FEATURE_ID>1001278582</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828528</fme:EASTING>
<fme:NORTHING>823300</fme:NORTHING>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:ENGLISHNAME>Ching Wah Court</fme:ENGLISHNAME>
<fme:CHINESENAME>青華苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823300.00056 828527.99787 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id4a016e7c-4957-40db-8fbe-9c8284d7401b">
<fme:FEATURE_ID>1001281817</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BAY</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829730</fme:EASTING>
<fme:NORTHING>823310</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Rambler Channel</fme:ENGLISHNAME>
<fme:CHINESENAME>藍巴勒海峽</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823309.99729 829729.99670 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id057f6326-032c-4eea-816e-5b1d34d4bbe6">
<fme:FEATURE_ID>1001278583</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828367.09</fme:EASTING>
<fme:NORTHING>823462.03</fme:NORTHING>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:ENGLISHNAME>CHEUNG HONG ESTATE</fme:ENGLISHNAME>
<fme:CHINESENAME>長康邨</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20250415</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823462.03095 828367.08735 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idc1b0d022-245e-4a6b-b660-8af804bda691">
<fme:FEATURE_ID>1310012215</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826709.54</fme:EASTING>
<fme:NORTHING>823523.41</fme:NORTHING>
<fme:ST_CODE>78400</fme:ST_CODE>
<fme:ENGLISHNAME>Hongkong United Dockyards Limited</fme:ENGLISHNAME>
<fme:CHINESENAME>香港聯合船塢集團有限公司</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823523.41300 826709.54200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idea1e78c4-67f5-4e43-ae87-84b3ad8efc0e">
<fme:FEATURE_ID>1001278577</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829049</fme:EASTING>
<fme:NORTHING>823586</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Ha Ko Tan</fme:ENGLISHNAME>
<fme:CHINESENAME>下高灘</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823586.00423 829048.99740 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idec4a4aa3-15ee-452f-b51e-92d2ac4a8549">
<fme:FEATURE_ID>1001278578</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828855</fme:EASTING>
<fme:NORTHING>823603</fme:NORTHING>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:ENGLISHNAME>Chung Mei Lo Uk Village</fme:ENGLISHNAME>
<fme:CHINESENAME>涌美老屋村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823602.99729 828855.00291 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id244b2dd4-a6fa-48f3-910b-74116bf274f3">
<fme:FEATURE_ID>1310014680</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829076.84</fme:EASTING>
<fme:NORTHING>823613.38</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Tsing Yi Police Married Quarters</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣已婚警察宿舍</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823613.38300 829076.84300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id33f811ef-00ae-47b4-8817-bbc831dd28c5">
<fme:FEATURE_ID>1210003951</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>826492</fme:EASTING>
<fme:NORTHING>823622</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Cement Works</fme:ENGLISHNAME>
<fme:CHINESENAME>水泥廠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823621.99987 826491.99641 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id584344cc-9cf8-4709-b33b-43e3f8cf6587">
<fme:FEATURE_ID>1001278576</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828642</fme:EASTING>
<fme:NORTHING>823628</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Sheung Ko Tan</fme:ENGLISHNAME>
<fme:CHINESENAME>上高灘</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823628.00130 828642.00100 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id6699c5f2-509a-4534-b69e-a8435f4016f0">
<fme:FEATURE_ID>1001278581</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828404</fme:EASTING>
<fme:NORTHING>823639</fme:NORTHING>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:ENGLISHNAME>Lam Tin Resite Village</fme:ENGLISHNAME>
<fme:CHINESENAME>藍田村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823639.00293 828404.00276 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id8e53f277-c91b-4b3f-95ec-a6c239ac8fd8">
<fme:FEATURE_ID>1210000529</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829016</fme:EASTING>
<fme:NORTHING>823649</fme:NORTHING>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Yi Lutheran New Village</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣信義新村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823649.00000 829016.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id93288f64-a2bb-49a4-8798-5a107eeab18f">
<fme:FEATURE_ID>1001278573</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829181</fme:EASTING>
<fme:NORTHING>823675</fme:NORTHING>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:ENGLISHNAME>Greenfield Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823674.99737 829181.00339 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ida08c1111-26cb-48e2-a76b-cb27c1aeff92">
<fme:FEATURE_ID>1001278580</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827951</fme:EASTING>
<fme:NORTHING>823675</fme:NORTHING>
<fme:ST_CODE>64054</fme:ST_CODE>
<fme:ENGLISHNAME>Liu To</fme:ENGLISHNAME>
<fme:CHINESENAME>寮肚</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823675.00115 827950.99888 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id57934e5a-dc6d-4a80-a2f2-cb27d5420b22">
<fme:FEATURE_ID>1001278949</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>DIS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827116</fme:EASTING>
<fme:NORTHING>823688</fme:NORTHING>
<fme:ST_CODE/>
<fme:ENGLISHNAME>Shek Wan</fme:ENGLISHNAME>
<fme:CHINESENAME>石環</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823688.00302 827115.99571 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id9b75ed0c-6431-4247-b4ca-02707869892c">
<fme:FEATURE_ID>1001281672</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828660</fme:EASTING>
<fme:NORTHING>823690</fme:NORTHING>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Fai San Tsuen</fme:ENGLISHNAME>
<fme:CHINESENAME>青輝新村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823689.99852 828659.99770 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="iddd0bcedb-8e3c-475b-9419-612a9f288b0f">
<fme:FEATURE_ID>1001280817</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829337</fme:EASTING>
<fme:NORTHING>823698</fme:NORTHING>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:ENGLISHNAME>Grand Horizon</fme:ENGLISHNAME>
<fme:CHINESENAME>海欣花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823697.99751 829337.00335 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="ide047732c-cdc2-48fa-b0dc-fb40dc6fe194">
<fme:FEATURE_ID>1210004224</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828810</fme:EASTING>
<fme:NORTHING>823745</fme:NORTHING>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:ENGLISHNAME>Greenview Villa</fme:ENGLISHNAME>
<fme:CHINESENAME>綠悠雅苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823744.99987 828809.99724 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idb09f6c7e-6c3a-45d2-811a-f8cb924a752c">
<fme:FEATURE_ID>1001280816</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827902</fme:EASTING>
<fme:NORTHING>823749</fme:NORTHING>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:ENGLISHNAME>Mount Haven</fme:ENGLISHNAME>
<fme:CHINESENAME>曉峰園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823749.00251 827902.00052 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id81e63f54-768d-4094-9047-baea5c8ad068">
<fme:FEATURE_ID>1001279943</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828382</fme:EASTING>
<fme:NORTHING>823752</fme:NORTHING>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:ENGLISHNAME>Yim Tin Kok Resite Village</fme:ENGLISHNAME>
<fme:CHINESENAME>鹽田角村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823751.99744 828382.00133 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id97fb214d-457c-4faa-9c5b-40edfa6081ac">
<fme:FEATURE_ID>1001280815</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828418</fme:EASTING>
<fme:NORTHING>823808</fme:NORTHING>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:ENGLISHNAME>San Uk Resite Village</fme:ENGLISHNAME>
<fme:CHINESENAME>新屋村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823807.99827 828418.00398 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="idb214d267-d3e9-4f5b-a598-6f378fe0efe4">
<fme:FEATURE_ID>1001278569</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828882</fme:EASTING>
<fme:NORTHING>823838</fme:NORTHING>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Yi Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823837.99503 828882.00137 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id7f12c753-859b-4934-9809-ffdf4731d625">
<fme:FEATURE_ID>1001279102</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829160</fme:EASTING>
<fme:NORTHING>823865</fme:NORTHING>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:ENGLISHNAME>Serene Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>海悅花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823864.99634 829160.00400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id516ba370-60df-4b38-bf7d-d825f6a62cd6">
<fme:FEATURE_ID>1001279777</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>VIL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828458</fme:EASTING>
<fme:NORTHING>823870</fme:NORTHING>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:ENGLISHNAME>Tai Wong Ha Resite Village</fme:ENGLISHNAME>
<fme:CHINESENAME>大王下村</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823869.99837 828457.99588 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id87da827d-f164-470b-baf7-6a3483c4b142">
<fme:FEATURE_ID>1001280814</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EST</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829155</fme:EASTING>
<fme:NORTHING>823948</fme:NORTHING>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:ENGLISHNAME>Tivoli Garden</fme:ENGLISHNAME>
<fme:CHINESENAME>宏福花園</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823948.00145 829154.99902 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePoint gml:id="id9bf64122-2272-4373-8b90-f2338d364248">
<fme:FEATURE_ID>1210002452</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SRC</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828012.42</fme:EASTING>
<fme:NORTHING>823991.26</fme:NORTHING>
<fme:ST_CODE>71082</fme:ST_CODE>
<fme:ENGLISHNAME>Tsing Yi North Low Level Salt Water Service Reservoir</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣北下海水配水庫</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823991.25920 828012.42431 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
</gml:FeatureCollection>
