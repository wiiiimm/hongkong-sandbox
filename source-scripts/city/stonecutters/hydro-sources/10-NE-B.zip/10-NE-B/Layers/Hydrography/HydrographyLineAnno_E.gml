<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyLineAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821013.74087 826301.49906</gml:lowerCorner>
<gml:upperCorner>823855.51454 829986.86719</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id33246a0c-6397-428b-91c9-f17ef59e9d5b">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>^</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>39.4237179533241</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001273226</fme:FEATURE_ID>
<fme:FEATURECODE>DAS</fme:FEATURECODE>
<fme:EASTING>827753.885</fme:EASTING>
<fme:NORTHING>821959.419</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821959.41912 827753.88469</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id50d31543-b486-4e8d-9df2-a8dba78e59e2">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.308435990615</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831871</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829785.45176094</fme:EASTING>
<fme:NORTHING>822569.69114339</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822552.75104 829790.85529</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id15c042d9-1c47-4acd-9e81-518520bf2a5b">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831862</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>826289.99377497</fme:EASTING>
<fme:NORTHING>823718.69240702</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823696.30147 826301.49906</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id18c3144c-1887-410a-986f-6ad41b047a2b">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>81.1381338107827</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831863</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829987.14900349</fme:EASTING>
<fme:NORTHING>823640.9070849</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823658.94687 829986.86719</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id458692ce-3e49-48c6-8d83-8bc6dd260946">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>70.3462399499027</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831861</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>827291.11793076</fme:EASTING>
<fme:NORTHING>821502.04531073</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821529.89362 827298.66989</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id90c15065-4834-4e2a-9efe-bb173a071a5c">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-8.99712982392427</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831859</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>827015.2060661</fme:EASTING>
<fme:NORTHING>822777.8580985</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822774.82127 827034.38611</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id71761e75-41b3-4e04-b17c-d8324f947f1c">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.308435990615</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831869</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829912.58473828</fme:EASTING>
<fme:NORTHING>823262.17528218</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823245.23518 829917.98827</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="ide69845e2-a5a7-4348-910a-6b1c653f51c4">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-83.0250547148995</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831870</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829396.63549093</fme:EASTING>
<fme:NORTHING>823723.22265055</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823705.94450 829401.82963</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id943fb594-2eff-4f08-85bb-052819a90fe7">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.5457047232578</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831866</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>826648.68306715</fme:EASTING>
<fme:NORTHING>823429.77175118</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823447.79918 826647.95821</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id0a3a29ca-5bef-4ae6-b9a7-03c2e9d4a2cb">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>89.8900010067424</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831865</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>827281.50632548</fme:EASTING>
<fme:NORTHING>822347.86153387</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822365.64841 827278.48294</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="idcdbaeca8-67a3-44c6-b9ef-ca70a1ac0976">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>50.9925321327533</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831868</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829960.76462061</fme:EASTING>
<fme:NORTHING>821067.48319094</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821083.22466 829969.58049</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="ide9eb04db-7595-449a-a6f2-3dc2e1ad304c">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-34.9299928805517</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831860</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>827537.10998258</fme:EASTING>
<fme:NORTHING>822178.99024039</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822171.31598 827553.43847</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id9d3a09dd-2484-4830-b41c-06a0e00af80d">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>7.87394560125832</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831864</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>828645.96368277</fme:EASTING>
<fme:NORTHING>821009.20039976</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821014.66500 828663.15821</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id1903f391-ac67-4e7e-a228-bce311e8e663">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-85.6012983715043</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831867</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829667.65910109</fme:EASTING>
<fme:NORTHING>821079.00241447</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821061.50826 829672.07137</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id33a316d6-c83c-4ff8-949d-a0402c1b44fb">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>^</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-7.20444042238629</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001273274</fme:FEATURE_ID>
<fme:FEATURECODE>DAS</fme:FEATURECODE>
<fme:EASTING>828022.259</fme:EASTING>
<fme:NORTHING>823514.737</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823514.73700 828022.25900</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="idc637469d-c3c4-4a7e-9bd1-cc7ae4aa1a3e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>^</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>156.16195145233</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001273267</fme:FEATURE_ID>
<fme:FEATURECODE>DAS</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823189.25244 827163.56517</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id872febe6-3a32-41bc-a161-4f9164b5c5a4">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>^</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>45.3451444739413</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001273287</fme:FEATURE_ID>
<fme:FEATURECODE>DAS</fme:FEATURECODE>
<fme:EASTING>828371.851</fme:EASTING>
<fme:NORTHING>823855.515</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20250726</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823855.51454 828371.85055</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id3ed7ce63-382a-42bb-8103-033bf2b30246">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>^</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>157.183697938793</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001273254</fme:FEATURE_ID>
<fme:FEATURECODE>DAS</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822842.61862 829022.00844</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id55b8326e-aba3-4c3f-a267-2ce979796f70">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HWM</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>51.7304612576305</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000580</fme:FEATURE_ID>
<fme:FEATURECODE>HWM</fme:FEATURECODE>
<fme:EASTING>829874.841</fme:EASTING>
<fme:NORTHING>821013.741</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821013.74087 829874.84123</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
