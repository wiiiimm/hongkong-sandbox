<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyLineAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821012.89601 826290.70813</gml:lowerCorner>
<gml:upperCorner>823984.67256 829979.66481</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id20dcd3b1-2b37-4af3-929c-2036f7db07e7">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.4075634255544</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831356</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829358.0566925</fme:EASTING>
<fme:NORTHING>823806.56991336</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823798.64658 829363.57599</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id2a16fb08-65ff-4d7f-a81e-96a0d232f592">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>51.3401760485429</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831349</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>826281.8051449</fme:EASTING>
<fme:NORTHING>823806.60269748</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823817.73143 826290.70813</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id45b3ab52-9d05-499d-8a95-023f1f9f8c7d">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-8.38326111539976</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831346</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>826949.83411374</fme:EASTING>
<fme:NORTHING>822787.12845997</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822784.89079 826965.01831</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="idb33b6c7b-a136-48a8-996f-ea7174716b1a">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.8380734159066</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831355</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829865.85756373</fme:EASTING>
<fme:NORTHING>823373.75605051</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823364.94569 829868.57841</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="ideca4faa4-4f4d-45e9-9596-206e90f98f4c">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.6139548109085</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831353</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>826637.39263328</fme:EASTING>
<fme:NORTHING>823346.98616848</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823356.49908 826635.73542</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="ideffb051d-47e6-4605-a610-7597b4c3a291">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>90</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831351</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>827280.50899298</fme:EASTING>
<fme:NORTHING>822312.85377845</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822322.07471 827277.64261</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id133182b4-f1a0-4dba-a85f-7366e703c52f">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-86.0817403399799</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831354</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829408.92410124</fme:EASTING>
<fme:NORTHING>821039.4771848</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821030.47367 829412.41388</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id7c3efb7a-1d55-48b4-9cfe-366e2355c5e4">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-34.1861221888365</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831350</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>828784.36171942</fme:EASTING>
<fme:NORTHING>821015.70597273</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821012.89601 828793.60000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id3c9d2582-5873-440c-9af8-cc5e0239e60a">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.6459763149926</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831357</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829761.34367978</fme:EASTING>
<fme:NORTHING>822638.27683891</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822630.33061 829766.82996</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id59f39f84-fbe5-436c-b58f-7f66fd63811a">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>59.0362194599849</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831347</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>827537.2776905</fme:EASTING>
<fme:NORTHING>822041.80033981</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822055.83954 827545.70122</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id56115b09-ad24-40c0-a28f-f38393e59c28">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>70.9533757022871</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831348</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>827254.36092264</fme:EASTING>
<fme:NORTHING>821401.591842</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821417.18806 827258.55891</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id7756463e-274c-48b0-becb-a63c8001fd15">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-30.4933593135601</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831345</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829971.71924083</fme:EASTING>
<fme:NORTHING>823989.35160557</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823984.67256 829979.66481</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_C gml:id="id137d94fb-5804-4720-8cdd-71b3b22054cc">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>海堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>18.6989798213183</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831352</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829932.91619053</fme:EASTING>
<fme:NORTHING>823610.72112551</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823616.39241 829940.73146</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
