<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyPolyAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821161.03450 827276.19576</gml:lowerCorner>
<gml:upperCorner>823869.39301 829280.98956</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyPolyAnno_C gml:id="id38a94984-49f0-4469-9ba8-44274288de76">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>噴水池</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000847640</fme:FEATURE_ID>
<fme:FEATURECODE>FOU</fme:FEATURECODE>
<fme:EASTING>828824.46806936</fme:EASTING>
<fme:NORTHING>823866.52663372</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823869.39301 828838.43397</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_C gml:id="id31961171-a492-4fae-b050-546783e29d00">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-81.8698796633542</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000847642</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>828743.473</fme:EASTING>
<fme:NORTHING>821161.034</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821161.03450 828743.47314</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_C gml:id="id8330424e-db2c-4ba1-82c5-6b4e4a39e9f2">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>1.58929432086011e-5</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000683</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>829117.003</fme:EASTING>
<fme:NORTHING>822025.112</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822025.11196 829117.00303</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_C gml:id="id93d07e8a-9d69-4e2e-b450-41d3e72218f2">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-29.2488848738804</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000847645</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>829276.04154794</fme:EASTING>
<fme:NORTHING>822621.56962162</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822622.08396 829280.98956</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_C gml:id="idef1b60f1-dda4-4178-9780-9defb367b66d">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-54.0902983584628</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000847644</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>827271.48948552</fme:EASTING>
<fme:NORTHING>823110.64828917</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823109.03634 827276.19576</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_C gml:id="id952d09c2-7de0-4c3a-8e7e-96fb655960c1">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>渠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>26.0954246549512</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000847641</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>828101.821</fme:EASTING>
<fme:NORTHING>821294.622</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821294.62207 828101.82066</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
