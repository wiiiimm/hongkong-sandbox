<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyPolyAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821081.88604 826586.46599</gml:lowerCorner>
<gml:upperCorner>823957.11978 829325.22785</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idc7f9c25c-0f11-4a92-a6fd-df41428193c6">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-118.657100865232</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274552</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823653.61909 828080.39890</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idfb15cb1f-8caf-4a87-8ebf-7ecd964e622a">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-130.883253719007</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274551</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822634.52719 829260.54551</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id5c372bcc-113d-4581-b32a-552d5c21a9e8">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-63.0596470288877</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274553</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING>828131.459</fme:EASTING>
<fme:NORTHING>821307.772</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821307.77220 828131.45892</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="iddb82555a-7220-477d-ba24-820fccac535c">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Nullah</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>27.0215926779476</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000848213</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>828164.997</fme:EASTING>
<fme:NORTHING>821325.972</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821325.97203 828164.99652</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idd2109a6f-67aa-4394-b2d3-a22a5a7367cc">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Nullah</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-81.3326800847853</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000848214</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>828748.734</fme:EASTING>
<fme:NORTHING>821121.145</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821121.14503 828748.73357</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id27839e2f-6810-41f1-aea7-52a478eacc3c">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Nullah</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-74.7836710038401</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000848216</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>827246.75726799</fme:EASTING>
<fme:NORTHING>823165.92171135</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823152.78075 827253.50023</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idebfeb542-5aae-4725-861c-91544b3d685a">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Nullah</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-61.0202844967978</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000848217</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>829233.16903208</fme:EASTING>
<fme:NORTHING>822668.93683677</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822657.77744 829242.84478</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id1473f248-2fd0-42da-bf70-29e935baf600">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-130.758175446609</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274541</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822791.58069 829325.22785</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="ida7303408-ff67-4a5b-8d19-73fdab3163f2">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-81.9642991405831</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274540</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823583.19576 829028.04516</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id181740c6-1c7c-4fc1-973d-5616dcf88bac">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-54.5487190392681</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274547</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823611.89632 828256.05823</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id1d224108-553d-4c94-a510-8df2ef181303">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-119.369560153336</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274543</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING>828645.265</fme:EASTING>
<fme:NORTHING>821266.979</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821266.97903 828645.26510</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idc7e81ed1-8034-4a2f-9a63-2ca19d8c3631">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>95.3569277296773</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274550</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823060.86830 827322.13010</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id966933f2-e10e-45cc-96e8-bc10c4361a45">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>118.072471633449</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274545</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823698.52665 827048.54206</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id2afeff70-4e7c-4fe3-9f60-52393ccfee13">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>72.7108020897974</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274548</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821787.83766 827495.42249</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id38c55001-9fd4-455f-8839-0e54ab1d0a43">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>58.3311981729305</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274546</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823957.11978 826586.46599</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id093a6bd7-a12f-42ee-b907-e33b20efc8b5">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-144.055825644962</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274549</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823106.42446 827265.66920</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id40459051-0aed-4608-8df5-da190e2ac251">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>68.1985542895952</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274544</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822062.07364 827696.13732</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id7433148c-a128-4d11-bc9e-642b3e2897df">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-172.568642491668</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274542</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING>828754.288</fme:EASTING>
<fme:NORTHING>821081.886</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821081.88604 828754.28834</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id90d51fa5-8c52-4dfe-89df-77ca5ff21adf">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-90</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002187</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING>829137.12</fme:EASTING>
<fme:NORTHING>822021.748</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822021.74838 829137.12040</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id6cb1517d-9821-4cc8-a4ca-b5c1d1df75ef">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-142.370285592549</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210003827</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING>829143.134</fme:EASTING>
<fme:NORTHING>821809.933</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821809.93293 829143.13432</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
