<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BoulderLine.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821340.12000 827403.88000 0.00000</gml:lowerCorner>
<gml:upperCorner>823216.79926 829347.82000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BoulderLine gml:id="id66f8a1d1-240c-42b1-9d5a-c91d8128ad99">
<fme:FEATURE_ID>1000857965</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823197.83960 829028.87604 0.00000 823201.96705 829031.48285 0.00000 823205.94968 829030.83115 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id95649321-aeea-4d79-99bd-a11d9785c031">
<fme:FEATURE_ID>1000858801</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821815.64200 828315.46100 0.00000 821817.85500 828317.37500 0.00000 821818.98000 828318.64500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idcab1f70c-0e02-4cd2-ada4-72d409aaa334">
<fme:FEATURE_ID>1000858901</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882087</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821550.02139 828632.13316 0.00000 821552.16434 828634.54397 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id549e7296-42a4-4719-8744-ea68548760c5">
<fme:FEATURE_ID>1000858894</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882089</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821597.68000 828920.91000 0.00000 821599.14000 828919.85000 0.00000 821599.26000 828919.47000 0.00000 821599.92000 828919.38000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7d41c609-21f8-445f-9f9f-69573b4501d1">
<fme:FEATURE_ID>1000858009</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823141.85481 829129.34973 0.00000 823144.86986 829131.32836 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7640f7c2-5824-4bed-84f7-d879119cff2f">
<fme:FEATURE_ID>1000858351</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882216</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822773.01000 828537.06000 0.00000 822777.81000 828541.31000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id155ee22e-57eb-493d-9751-5fd436dc3d5d">
<fme:FEATURE_ID>1000858100</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823045.27892 829137.26426 0.00000 823042.45232 829139.43132 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idcb5f6478-4bf9-40af-a44e-e081aad91d74">
<fme:FEATURE_ID>1000857935</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823214.12919 828891.86980 0.00000 823213.16700 828893.07253 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7d713a23-c420-4cf9-b620-62b4586b4f16">
<fme:FEATURE_ID>1000857941</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823208.54850 828888.26160 0.00000 823209.60691 828891.29249 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id265fd3d7-ddb3-45e6-80ad-afc5b248e940">
<fme:FEATURE_ID>1000858096</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823051.63880 829142.63482 0.00000 823050.88504 829144.23657 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide853831f-cc20-4a6c-977b-853f666472f4">
<fme:FEATURE_ID>1000858925</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882081</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821470.03900 828572.39000 0.00000 821472.17300 828572.37300 0.00000 821472.73400 828572.59800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide1d36463-58ef-4751-81ed-b21087073ee9">
<fme:FEATURE_ID>1000858337</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882213</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822783.50000 828512.08000 0.00000 822778.43000 828516.07000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc6828de2-54a7-48a4-aaab-5628e186ebd4">
<fme:FEATURE_ID>1000858526</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882176</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822514.47100 828233.01700 0.00000 822515.40400 828230.95500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id39d5189f-0d87-476c-b746-10582555cf71">
<fme:FEATURE_ID>1000858891</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882091</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821621.49700 828789.33200 0.00000 821620.61400 828789.04000 0.00000 821619.52100 828789.10500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idcd223fd9-bd26-467d-8b72-c223cec44513">
<fme:FEATURE_ID>1000858804</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821813.26206 828318.08901 0.00000 821816.42157 828324.60550 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id973f01fe-72c1-49d1-b93c-5a95cadec5f0">
<fme:FEATURE_ID>1000858047</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823105.06176 829144.14234 0.00000 823104.68487 829145.55564 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id031d16a2-acb7-402f-88d7-059ec74edd1e">
<fme:FEATURE_ID>1000858895</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882089</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821597.52000 828924.37000 0.00000 821601.01000 828924.06000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id14b15a01-3c31-4943-a249-ab4d6b7aeee2">
<fme:FEATURE_ID>1000858790</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882118</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821907.93000 828612.88000 0.00000 821905.44000 828612.33000 0.00000 821904.51000 828612.53000 0.00000 821903.78000 828611.63000 0.00000 821904.16000 828610.03000 0.00000 821903.46000 828609.08000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idcbc65fa2-db4f-4ddd-a9e2-5d3a38af4f64">
<fme:FEATURE_ID>1000858869</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882095</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821695.08000 828835.96000 0.00000 821693.33000 828834.83000 0.00000 821692.20000 828834.80000 0.00000 821689.29000 828835.11000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd375c262-2889-4d09-b62f-58a22168b76c">
<fme:FEATURE_ID>1000858900</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882087</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821553.04900 828634.78600 0.00000 821552.66100 828633.92500 0.00000 821551.48300 828632.79100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1292c092-5bed-406c-b640-90707f574062">
<fme:FEATURE_ID>1000858803</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821813.40200 828316.26000 0.00000 821814.01900 828318.20900 0.00000 821814.44500 828319.04400 0.00000 821815.75100 828320.85700 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd9fc9cfe-e8d7-456d-a423-caf7965a882a">
<fme:FEATURE_ID>1000858420</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882197</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822704.49502 828556.09865 0.00000 822705.26730 828557.12837 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb9ee899d-35eb-4290-8084-09d71ccd57f9">
<fme:FEATURE_ID>1000858512</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882178</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822534.58000 828157.77000 0.00000 822534.68000 828156.53000 0.00000 822533.88000 828154.78000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id16aff2b7-ffbf-4159-be7f-78f67d5e9198">
<fme:FEATURE_ID>1000858103</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823037.08176 829137.73536 0.00000 823036.70487 829141.40996 0.00000 823038.30662 829145.17877 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id010a2f00-c6fb-430b-aba1-83259ae470ea">
<fme:FEATURE_ID>1000858903</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882087</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821546.39300 828635.06800 0.00000 821548.24900 828635.23100 0.00000 821550.92700 828636.32800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id04592636-da5c-46a2-98c2-76a4aac8d19f">
<fme:FEATURE_ID>1000858826</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882106</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821747.20858 828376.34249 0.00000 821740.88956 828381.27922 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6e13b19e-0297-4efd-b9e8-322c619ac420">
<fme:FEATURE_ID>1000858517</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882177</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822528.99200 828221.60700 0.00000 822529.34600 828220.99600 0.00000 822529.69700 828219.87700 0.00000 822529.62000 828219.69900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3d45f030-9ab7-4f89-9640-6666619b2b5d">
<fme:FEATURE_ID>1000858927</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882081</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821467.96200 828576.57500 0.00000 821469.05500 828576.59200 0.00000 821471.54100 828575.98700 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id42275d5a-fb7a-4b49-8c51-ef87623fd1fb">
<fme:FEATURE_ID>1000858890</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882091</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821620.89800 828790.22300 0.00000 821620.32300 828791.45400 0.00000 821620.43600 828793.43800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id86c63fd6-1877-4cf0-8c98-a52ca660b461">
<fme:FEATURE_ID>1000858070</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823075.28811 829134.90874 0.00000 823073.87481 829139.61976 0.00000 823075.00545 829144.51922 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfefce74f-837a-4b9d-bce4-b08b7ff0a767">
<fme:FEATURE_ID>1000858878</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882094</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821647.29900 829015.86700 0.00000 821646.54000 829016.82400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id39a624b9-3621-49ba-840f-87d705095646">
<fme:FEATURE_ID>1000858911</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882084</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821504.81700 827714.15000 0.00000 821502.22400 827714.23900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id12b1dee6-922f-4fe6-a9d6-664c70982519">
<fme:FEATURE_ID>1000858097</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823047.30466 829139.71399 0.00000 823048.52953 829143.67124 0.00000 823052.39256 829147.06317 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7618600e-5027-439a-936c-7a0304ee16ea">
<fme:FEATURE_ID>1000857938</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823211.33885 828891.67736 0.00000 823210.56910 828893.16875 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idaa017e78-7cd1-4f82-9ddd-032382bf5ff7">
<fme:FEATURE_ID>1000858043</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823112.83493 829133.68387 0.00000 823114.15402 829140.09086 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4c9a3434-8ad4-454f-99ff-a99e8e7961f4">
<fme:FEATURE_ID>1000857984</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823190.09158 829039.95498 0.00000 823193.85697 829040.09981 0.00000 823196.89825 829038.36193 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idbc8ad1fc-7f69-49f6-90ac-e2c5d768a6d4">
<fme:FEATURE_ID>1000858802</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821818.83870 828315.32047 0.00000 821814.29691 828312.75337 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0343d427-ff6f-48a3-b1cb-69846adf782a">
<fme:FEATURE_ID>1000858099</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823045.27892 829143.20014 0.00000 823044.33672 829145.93253 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2ea47101-f4e3-41a8-ac27-53884b32d955">
<fme:FEATURE_ID>1000858106</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823027.75394 829140.56197 0.00000 823030.01523 829141.59839 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfd024875-f1e2-40eb-89e6-f5f74885fb26">
<fme:FEATURE_ID>1000858808</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821807.53545 828332.30681 0.00000 821809.80635 828335.17011 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0d440aa6-e94f-42b3-a1d0-f2ec0aa4dd79">
<fme:FEATURE_ID>1000858094</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823057.05647 829139.33710 0.00000 823055.73739 829142.06949 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc0e0c88b-8294-45b3-8fad-ac5e5e63f10c">
<fme:FEATURE_ID>1000858033</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823123.05785 829128.97285 0.00000 823125.79024 829135.19139 0.00000 823130.87814 829137.45269 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id96958533-2130-4eb2-ab9f-315aa5617513">
<fme:FEATURE_ID>1000858066</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882263</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823079.67000 827406.90000 0.00000 823077.88000 827405.03000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1e1d1a7b-1db1-46ff-b6bd-cf88e515c506">
<fme:FEATURE_ID>1000858060</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823088.90296 829139.43132 0.00000 823088.24342 829144.99032 0.00000 823089.93939 829146.96895 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id39143617-de5c-4840-9367-035d9cda1ed8">
<fme:FEATURE_ID>1000858364</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884066</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822756.72000 829347.82000 0.00000 822756.81000 829346.65000 0.00000 822756.49000 829345.02000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id852e786c-e6d6-4b90-af7b-258f112b22ed">
<fme:FEATURE_ID>1000858823</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882106</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821744.04907 828378.11971 0.00000 821742.66678 828378.11971 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6b50072d-38ed-4694-a3fb-1bbd7e752988">
<fme:FEATURE_ID>1000858018</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823136.76691 829126.52312 0.00000 823137.89756 829131.70524 0.00000 823141.76059 829133.58965 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7165db2e-e0bc-4669-b5cb-765eea027574">
<fme:FEATURE_ID>1000858874</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882094</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821654.55700 829014.08600 0.00000 821656.07368 829014.72180 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id12712b33-9e1b-4a48-a869-2f0246e081b9">
<fme:FEATURE_ID>1000858942</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884051</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821446.57400 828623.35800 0.00000 821445.12478 828622.82547 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="iddfe900b8-2c7c-41bd-a812-d36e97ca8f7f">
<fme:FEATURE_ID>1000858888</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882090</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821621.57000 828800.86500 0.00000 821621.01100 828801.71500 0.00000 821621.25400 828803.28600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb25168a2-f49d-4b6e-82b9-02efd8bcf2e3">
<fme:FEATURE_ID>1000858944</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884051</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821445.41880 828623.69528 0.00000 821443.36514 828622.53451 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5f5b0dd9-d8da-41df-80d2-963d8cd43ef7">
<fme:FEATURE_ID>1000858363</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884066</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822757.18000 829342.73000 0.00000 822757.12000 829342.07000 0.00000 822757.64000 829343.15000 0.00000 822758.06000 829342.10000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idee1bc55c-fe12-4b55-a654-22cd82be0a3b">
<fme:FEATURE_ID>1000858798</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882115</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821863.38000 828722.35000 0.00000 821861.87000 828720.90000 0.00000 821861.45000 828720.07000 0.00000 821860.69000 828716.89000 0.00000 821860.21000 828715.51000 0.00000 821859.10000 828715.65000 0.00000 821858.48000 828716.68000 0.00000 821857.72000 828717.17000 0.00000 821856.75000 828716.89000 0.00000 821854.95000 828716.68000 0.00000 821854.19000 828717.58000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id84c01d83-de2f-4bab-be39-5408599a917b">
<fme:FEATURE_ID>1000858946</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884051</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821440.76900 828628.43700 0.00000 821441.95900 828627.84300 0.00000 821442.34100 828627.96700 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idaa479375-e81b-4723-896d-246a23d2ff3d">
<fme:FEATURE_ID>1000858789</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882118</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821906.53000 828601.77000 0.00000 821907.29000 828602.57000 0.00000 821907.90000 828604.39000 0.00000 821908.38000 828605.18000 0.00000 821909.84000 828606.81000 0.00000 821909.91000 828607.93000 0.00000 821910.54000 828609.75000 0.00000 821910.32000 828610.61000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1fa36652-67bb-4f23-b0da-7c88cac448bb">
<fme:FEATURE_ID>1000858045</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823108.97190 829135.85094 0.00000 823111.70429 829140.84462 0.00000 823116.50953 829142.63481 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1733a268-789e-4774-ae36-8d3fa1e67207">
<fme:FEATURE_ID>1000858556</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882170</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822424.14000 828507.29000 0.00000 822420.57000 828509.87000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id50ab8ec2-87b5-48ac-ade7-125aac018f0e">
<fme:FEATURE_ID>1000857951</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823203.12563 829023.95206 0.00000 823207.54273 829024.31412 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3239e8f3-cb24-4e49-a253-10fd4f01790a">
<fme:FEATURE_ID>1000858818</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882109</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821756.72000 828683.13000 0.00000 821756.27000 828685.16000 0.00000 821756.72000 828687.17000 0.00000 821756.34000 828688.59000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id49266a4d-b581-4063-9db6-003c97ab7040">
<fme:FEATURE_ID>1000858923</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882082</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821483.42200 828545.16500 0.00000 821483.72600 828545.01000 0.00000 821485.28000 828545.50600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id206c9225-acdb-4cae-8500-94e389683533">
<fme:FEATURE_ID>1000858089</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823063.36924 829138.48912 0.00000 823063.27502 829142.91748 0.00000 823066.94961 829144.99033 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2f55097e-5d21-483b-8790-76dfc1c42054">
<fme:FEATURE_ID>1000858524</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882176</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822520.29800 828235.05300 0.00000 822519.80600 828232.59000 0.00000 822519.16600 828231.22100 0.00000 822518.80900 828230.79000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4e18fad7-e187-4b8d-b315-924896eaeee8">
<fme:FEATURE_ID>1000858050</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823100.63340 829138.96021 0.00000 823100.06808 829143.85968 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf26ed455-0017-46e1-90c2-064c7aba53b7">
<fme:FEATURE_ID>1000858868</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882095</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821700.83000 828838.21000 0.00000 821700.88000 828837.29000 0.00000 821700.18000 828835.90000 0.00000 821698.65000 828835.26000 0.00000 821696.74000 828833.51000 0.00000 821695.08000 828832.90000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id36a45851-8177-4b2d-bf8c-2047edf9f164">
<fme:FEATURE_ID>1000858421</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882197</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822706.29701 828555.06895 0.00000 822704.49502 828561.24723 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id657c6012-7f1e-4ceb-aa7e-7e1d2b036c35">
<fme:FEATURE_ID>1000858819</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882109</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821761.58000 828690.23000 0.00000 821760.08000 828690.83000 0.00000 821759.41000 828691.65000 0.00000 821757.61000 828692.25000 0.00000 821756.12000 828691.88000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8a8722fe-41ea-4d51-b40d-f3ca1533a934">
<fme:FEATURE_ID>1000858343</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882213</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822780.05231 828511.76607 0.00000 822776.19089 828507.38979 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idebedd697-7e17-4c89-97c6-b96bc43042b0">
<fme:FEATURE_ID>1000858528</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882176</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822513.88200 828231.79900 0.00000 822514.66500 828230.34800 0.00000 822514.99400 828230.04200 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide38ac07b-b702-4bc4-8724-c64402674aa6">
<fme:FEATURE_ID>1000857963</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823198.42148 828893.93850 0.00000 823200.05720 828896.77695 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4d5886c2-2030-404b-94c8-b6fcd4ae2cf7">
<fme:FEATURE_ID>1000858073</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823072.74416 829145.08454 0.00000 823072.46150 829147.91115 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1308110f-5386-4a02-8706-0490c5b7a006">
<fme:FEATURE_ID>1000858896</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882089</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821596.10000 828930.59000 0.00000 821596.59000 828928.88000 0.00000 821596.46000 828927.26000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb84e2bbe-5bf0-4d3d-9e1c-04e319dd0fd6">
<fme:FEATURE_ID>1000858025</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823130.64259 829128.12487 0.00000 823135.35361 829131.32836 0.00000 823136.10737 829135.28562 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id65629dd9-204f-4b3f-be3b-39be55184754">
<fme:FEATURE_ID>1000857937</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823211.33885 828889.89732 0.00000 823211.77183 828893.21686 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id664c90b4-dbc3-4eb1-b129-3cbc9c84ddfe">
<fme:FEATURE_ID>1000858048</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823104.30799 829137.64113 0.00000 823104.96753 829143.01169 0.00000 823108.54791 829144.99032 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3d57be0a-8bd9-4034-b58d-61383f48678d">
<fme:FEATURE_ID>1000858926</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882081</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821470.01802 828574.89860 0.00000 821468.50010 828574.54144 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ida27fc1ee-dbf4-482c-be43-a0784472a04f">
<fme:FEATURE_ID>1000858836</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882101</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821732.52000 828696.21000 0.00000 821732.06000 828698.07000 0.00000 821732.22000 828700.39000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id164e0dee-ca06-403d-aed5-eac43993f3f8">
<fme:FEATURE_ID>1000858884</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882091</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821623.58700 828791.47000 0.00000 821622.77700 828792.79800 0.00000 821622.80900 828793.60000 0.00000 821622.55000 828795.20400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7e86cfdb-45d5-4092-962f-732845756b05">
<fme:FEATURE_ID>1000858910</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882084</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821504.13800 827708.54300 0.00000 821503.17300 827708.30900 0.00000 821502.40500 827709.29800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd76e2e9f-8be7-4e50-a698-ba5f8b195846">
<fme:FEATURE_ID>1000858833</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882101</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821734.98000 828694.87000 0.00000 821735.21000 828696.73000 0.00000 821734.53000 828697.48000 0.00000 821734.38000 828698.00000 0.00000 821734.01000 828698.45000 0.00000 821733.33000 828700.39000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0b87476b-843a-4e90-be33-fe21b827e533">
<fme:FEATURE_ID>1000858805</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821812.09600 828329.76300 0.00000 821811.62500 828328.78400 0.00000 821811.33500 828327.41400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfce1e1b2-1766-4cb8-97fa-66f0dd7cc063">
<fme:FEATURE_ID>1000858897</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882089</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821589.68000 828931.08000 0.00000 821590.19000 828929.37000 0.00000 821590.74000 828928.52000 0.00000 821591.29000 828928.19000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id613c70d9-0dc4-4901-b2be-6ecf51a33567">
<fme:FEATURE_ID>1000858355</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882211</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822771.03000 828559.44000 0.00000 822770.49900 828560.17900 0.00000 822769.81600 828560.69100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idea0d28c1-1083-42a6-87f4-31a8cf4a7099">
<fme:FEATURE_ID>1000858860</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882097</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821716.94000 829124.94000 0.00000 821715.69000 829124.51000 0.00000 821713.89000 829124.62000 0.00000 821712.67000 829125.04000 0.00000 821710.87000 829126.65000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0260e875-ed85-406a-a795-cf64cf861b60">
<fme:FEATURE_ID>1000857942</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823208.93338 828890.23408 0.00000 823208.16363 828893.79417 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id73d3755d-ebf5-4365-a6a0-de122b6904fd">
<fme:FEATURE_ID>1000858013</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823141.47793 829126.71156 0.00000 823140.44151 829130.85726 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3e4996a6-d0ee-44f3-a885-249cb607392e">
<fme:FEATURE_ID>1000857970</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823195.19816 828898.98998 0.00000 823196.54522 828900.14461 0.00000 823198.51770 828899.85595 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id337eb3c5-c101-4f55-a345-f1d6f6f93121">
<fme:FEATURE_ID>1000858800</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821819.52400 828313.14000 0.00000 821819.85000 828312.23300 0.00000 821821.58300 828311.07200 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id01c5addc-3e0a-49ff-9c7d-47bcb4b09e15">
<fme:FEATURE_ID>1000858356</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882211</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822769.34600 828563.54000 0.00000 822768.99400 828564.43100 0.00000 822767.44700 828565.20000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7ad40cbe-d62f-4b86-9e27-8e429d4abba9">
<fme:FEATURE_ID>1000858063</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823082.07198 829137.82957 0.00000 823079.90491 829143.29435 0.00000 823080.84712 829147.72271 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf3cf54d6-51ae-44b6-97a3-a79fbc3570d5">
<fme:FEATURE_ID>1000858109</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823023.13714 829139.52555 0.00000 823023.13714 829141.97528 0.00000 823024.92733 829143.85968 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id887ab677-6ccc-486f-830d-8ed585a22a1c">
<fme:FEATURE_ID>1000858520</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882177</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822528.37900 828220.79600 0.00000 822527.82400 828221.78900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfe234d59-dac0-4c9d-8243-471864dbaa2a">
<fme:FEATURE_ID>1000858950</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882078</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821433.97000 827829.06000 0.00000 821430.72000 827828.53000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1775d3b2-b38b-434b-a592-0e811b96972a">
<fme:FEATURE_ID>1000858829</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882105</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821739.01000 828710.48000 0.00000 821740.58000 828712.27000 0.00000 821740.96000 828713.02000 0.00000 821742.30000 828713.99000 0.00000 821747.75000 828714.96000 0.00000 821749.18000 828716.01000 0.00000 821748.35000 828717.05000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0b32f505-9fbb-47f6-b9c2-f991484f786d">
<fme:FEATURE_ID>1000857946</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823205.73244 829023.30036 0.00000 823208.19443 829020.47631 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id54e630b8-2701-44d9-96eb-d2223911ed3e">
<fme:FEATURE_ID>1000858101</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823041.79278 829136.98160 0.00000 823041.22745 829142.16371 0.00000 823042.73498 829146.02675 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id56b0a689-f6f9-4571-ae0b-1988b2159560">
<fme:FEATURE_ID>1000858948</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882078</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821437.46000 827827.43000 0.00000 821435.89000 827827.24000 0.00000 821434.44000 827826.85000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc6672c99-93e7-433e-87c9-17e221243bdb">
<fme:FEATURE_ID>1000858904</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882087</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821543.30100 828636.16000 0.00000 821543.14500 828635.72900 0.00000 821541.89100 828634.59600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id13dbf138-baa9-49b4-b413-96f8df26495e">
<fme:FEATURE_ID>1000858360</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882209</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822759.57000 829308.86000 0.00000 822759.32000 829307.41000 0.00000 822759.46000 829306.16000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idcc55eb2b-8587-4a19-b780-ce29fdcdbac3">
<fme:FEATURE_ID>1000858633</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882151</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822226.81000 828553.12000 0.00000 822224.76000 828556.13000 0.00000 822225.43000 828558.49000 0.00000 822226.81000 828558.99000 0.00000 822230.46000 828557.17000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7709efb8-6fa4-4a81-b998-d37f004c6986">
<fme:FEATURE_ID>1000857956</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823200.80847 829038.36193 0.00000 823202.54634 829041.11357 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide989f76c-384a-4aef-ba3e-2550917af9fc">
<fme:FEATURE_ID>1000858745</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882130</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822106.07000 828865.94000 0.00000 822105.29000 828866.02000 0.00000 822104.51000 828866.45000 0.00000 822104.39000 828868.04000 0.00000 822103.77000 828868.82000 0.00000 822102.02000 828869.44000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9b2e64dc-cfaa-4db2-90ff-d49be50079b9">
<fme:FEATURE_ID>1000858820</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882110</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821759.66000 828827.24000 0.00000 821757.96000 828826.90000 0.00000 821756.17000 828827.68000 0.00000 821755.57000 828828.19000 0.00000 821754.46000 828830.85000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id194ef1e9-42c1-4ec6-8560-ac961cada7cf">
<fme:FEATURE_ID>1000858336</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882216</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822790.61500 828523.54000 0.00000 822790.78500 828527.42800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb5a36854-b389-4437-82f5-be49f5473809">
<fme:FEATURE_ID>1000857955</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823201.31535 829027.57263 0.00000 823203.05322 829030.10703 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id57c3c816-1d9a-47ac-b9d9-285e048a2c35">
<fme:FEATURE_ID>1000858893</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882090</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821618.48400 828807.58700 0.00000 821618.33900 828806.94700 0.00000 821618.56500 828805.51400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9ddc200d-7562-43de-9ce6-c5f2e5445976">
<fme:FEATURE_ID>1000858873</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882094</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821656.80000 829013.62400 0.00000 821656.07368 829014.72180 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7aec708f-4824-4bfb-bb2f-3434532f4bc8">
<fme:FEATURE_ID>1000858882</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882091</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821625.68400 828793.36500 0.00000 821624.96300 828793.61600 0.00000 821623.87800 828792.66100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0926ffa9-eb6a-469d-b1a3-3361899b31e1">
<fme:FEATURE_ID>1000857980</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823192.11910 829034.66895 0.00000 823198.63612 829035.03101 0.00000 823203.34287 829038.07229 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc44a2040-8cb6-4100-9735-0354513ad62b">
<fme:FEATURE_ID>1000858922</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882082</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821483.57900 828552.22900 0.00000 821486.12500 828552.87000 0.00000 821487.16600 828552.70900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id896b7d26-36b7-458f-bbf7-ec512a9bc768">
<fme:FEATURE_ID>1000858087</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823067.42071 829148.75914 0.00000 823064.59410 829144.61344 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc0246e69-5086-44d0-9eb1-f596fd7b8b56">
<fme:FEATURE_ID>1000858799</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821820.82100 828313.97400 0.00000 821821.87300 828313.10300 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4c79d7cd-094b-41a0-8723-5e045ce84667">
<fme:FEATURE_ID>1000858887</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882090</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821623.91100 828801.02700 0.00000 821623.78100 828801.86100 0.00000 821622.99500 828802.64700 0.00000 821621.17300 828805.19000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idec28bd37-987c-4e63-b6de-9b9638d478f0">
<fme:FEATURE_ID>1000858084</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823066.71406 829136.60471 0.00000 823070.67132 829142.82325 0.00000 823077.54940 829147.06317 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id72861cbc-750b-475d-9d4c-4e7cf890e891">
<fme:FEATURE_ID>1000858541</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882173</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822466.64000 828157.70000 0.00000 822466.04000 828161.60000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9aae01de-f39a-4461-98b6-1f69e7a3fc02">
<fme:FEATURE_ID>1000858924</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882082</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821486.53656 828552.12980 0.00000 821482.96499 828551.41549 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id386e01cd-148e-4bc4-95c4-babe22cd6b0d">
<fme:FEATURE_ID>1000857947</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823205.56572 828887.63618 0.00000 823206.72035 828891.62925 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2101502d-48ea-430f-9fcd-23c48792303b">
<fme:FEATURE_ID>1000858947</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884051</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821440.41500 828625.46600 0.00000 821440.49800 828623.05100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id81bb8eca-054a-41c7-b4e1-16a43ae6426a">
<fme:FEATURE_ID>1000858514</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882177</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822531.02000 828213.29200 0.00000 822532.70200 828214.35300 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2b6ed553-9160-4b3e-8d4b-c569247ab9d5">
<fme:FEATURE_ID>1000858332</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882216</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822783.03500 828533.58800 0.00000 822780.89500 828537.99500 0.00000 822785.09800 828539.90800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide0871577-592d-4700-b82a-b989421eee52">
<fme:FEATURE_ID>1000858909</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882084</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821506.57400 827709.19300 0.00000 821504.84300 827709.54000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ida29f6586-3342-447b-9633-2b6fcaeead37">
<fme:FEATURE_ID>1000858042</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823114.81356 829136.60470 0.00000 823121.31477 829140.75040 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc08b4725-b830-49c8-b9cd-101a741d838b">
<fme:FEATURE_ID>1000858753</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882130</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822096.57000 828869.44000 0.00000 822094.20000 828869.99000 0.00000 822094.04000 828870.81000 0.00000 822094.16000 828871.58000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ideab80c20-1a79-4224-89d1-09248289d1dc">
<fme:FEATURE_ID>1000858027</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823129.04084 829128.78441 0.00000 823129.04084 829135.00295 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5df077b2-dbef-4035-8ad1-c5871d120def">
<fme:FEATURE_ID>1000858917</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882082</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821488.63900 828546.01300 0.00000 821489.60500 828546.15800 0.00000 821490.04100 828546.63700 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfd8600ad-08ad-442e-8578-e59fd3102033">
<fme:FEATURE_ID>1000857949</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823204.79597 828893.31308 0.00000 823203.68946 828895.52611 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="iddf9c8628-7b35-45ad-aedd-e5bd118cc2a2">
<fme:FEATURE_ID>1000858525</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882176</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822517.02200 828228.71400 0.00000 822515.26800 828228.49200 0.00000 822514.86200 828228.72200 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id54ac5505-be52-4e68-87b4-5858dc9bc529">
<fme:FEATURE_ID>1000858069</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823075.09968 829136.98159 0.00000 823077.64362 829139.99664 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id93123863-4b81-4536-818c-f722eae22612">
<fme:FEATURE_ID>1000858095</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823052.53390 829138.30068 0.00000 823055.45473 829143.95390 0.00000 823060.63685 829148.09959 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id39e0e8b8-ea05-4d4d-ace0-b810560a158d">
<fme:FEATURE_ID>1000858059</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823091.63535 829141.31573 0.00000 823089.56250 829142.44637 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc5f39520-1fb2-4772-81ec-a6df45c30ea3">
<fme:FEATURE_ID>1000858037</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823118.95926 829139.99663 0.00000 823118.95926 829142.44636 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id652bb2d6-3115-4ebf-be45-b410c75a7c43">
<fme:FEATURE_ID>1000858527</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882176</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822514.07800 828236.82900 0.00000 822513.91900 828234.87300 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide0d93de9-efc4-4b62-8664-df608a3e296e">
<fme:FEATURE_ID>1000858558</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882169</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822375.46000 828145.91000 0.00000 822376.70000 828148.56000 0.00000 822377.82000 828150.05000 0.00000 822380.01000 828151.55000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide27d05f1-a086-4b09-bcce-d713dbc87ce4">
<fme:FEATURE_ID>1000857971</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823195.05383 828902.55007 0.00000 823196.88198 828901.97276 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1bdaeb2d-daf2-42d3-a1ee-b4add79a13c4">
<fme:FEATURE_ID>1000858748</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882131</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822106.30000 828850.81000 0.00000 822106.30000 828851.58000 0.00000 822105.41000 828853.22000 0.00000 822105.02000 828854.85000 0.00000 822104.43000 828855.63000 0.00000 822103.61000 828855.94000 0.00000 822102.84000 828855.94000 0.00000 822102.02000 828855.05000 0.00000 822101.75000 828854.27000 0.00000 822100.97000 828854.00000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6b549b3b-bc62-4574-bd12-7c5b3829a70d">
<fme:FEATURE_ID>1000858064</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882263</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823082.51000 827407.20000 0.00000 823082.10000 827405.93000 0.00000 823081.56000 827405.24000 0.00000 823080.78000 827404.53000 0.00000 823079.71000 827403.88000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id86b0a7db-690f-4b64-afe9-669aa23b6043">
<fme:FEATURE_ID>1000858913</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882084</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821498.73500 827711.01100 0.00000 821497.64200 827710.98000 0.00000 821496.90700 827710.67100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id237cc9ac-adf4-45af-a20b-046f06f51641">
<fme:FEATURE_ID>1000858830</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882106</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821736.73300 828378.33700 0.00000 821740.82300 828377.92900 0.00000 821742.86400 828377.40300 0.00000 821743.75200 828376.95800 0.00000 821745.35800 828375.39800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id55330fa6-481d-4e3c-88c0-6d8340198a7e">
<fme:FEATURE_ID>1000858929</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882081</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821465.89800 828572.62700 0.00000 821468.28200 828571.99800 0.00000 821468.76500 828571.99400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id16f6d70d-5f9f-4eb8-930b-f45484e9af76">
<fme:FEATURE_ID>1000858098</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823048.38820 829137.82958 0.00000 823044.99627 829140.75041 0.00000 823046.78645 829146.12097 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id32a3aa6e-2b07-4311-b1c8-b7a14cb01bcd">
<fme:FEATURE_ID>1000857957</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823200.37400 829026.34164 0.00000 823203.56010 829027.71745 0.00000 823206.60138 829027.42781 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ided9698dd-d61d-43a0-8fed-401a5972ef55">
<fme:FEATURE_ID>1000858806</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821810.75400 828333.24600 0.00000 821810.31900 828331.83100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1222f0c1-21c6-430b-93e3-2587fff515e0">
<fme:FEATURE_ID>1000858943</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884051</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821443.78900 828627.95500 0.00000 821445.73900 828627.07600 0.00000 821446.16800 828626.61500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ida8babce5-6aa4-477a-b04d-04f344a01a8c">
<fme:FEATURE_ID>1000858870</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882095</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821694.41000 828841.18000 0.00000 821692.53000 828840.91000 0.00000 821689.19000 828839.12000 0.00000 821686.95000 828838.79000 0.00000 821685.72000 828838.24000 0.00000 821685.66000 828835.81000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide4c39a78-64cf-4582-bc35-00a7e7fea0f5">
<fme:FEATURE_ID>1000857953</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823202.40152 829035.97236 0.00000 823204.50145 829034.30689 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id144820d8-8adc-4cd2-a5c9-b56f7cba65d5">
<fme:FEATURE_ID>1000857978</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823193.46622 828902.16520 0.00000 823196.06413 828903.60848 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idbda52310-52e9-480c-8073-924f2579c880">
<fme:FEATURE_ID>1000858414</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882197</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822708.35644 828558.93037 0.00000 822707.58416 828560.47494 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6ac54761-8b97-49ec-adbf-e3e488490490">
<fme:FEATURE_ID>1000858034</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823122.49253 829131.42258 0.00000 823120.79656 829133.68387 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id25127d36-c845-41b9-b4e0-1a59d02b31c1">
<fme:FEATURE_ID>1000858323</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882216</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822788.96000 828517.47000 0.00000 822787.20000 828522.51000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3d3c27f7-11f0-41b3-948e-1861338d9a7f">
<fme:FEATURE_ID>1000858492</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882185</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822559.65000 828063.15000 0.00000 822560.65000 828064.57000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id266a3c8b-b4fa-484b-8518-8fa7368246ec">
<fme:FEATURE_ID>1000858102</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823037.36442 829139.33711 0.00000 823039.24882 829140.93885 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ideaf9aadb-718f-4ae7-926e-f0ec38cd0786">
<fme:FEATURE_ID>1000857979</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823193.22567 828906.15828 0.00000 823195.29438 828904.95554 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1b4d65e7-a969-4782-a1df-def3d2408857">
<fme:FEATURE_ID>1000858892</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882090</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821619.97400 828807.81400 0.00000 821619.35100 828807.12500 0.00000 821619.30200 828805.66700 0.00000 821619.60200 828804.43600 0.00000 821619.60200 828803.51300 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id491530c3-0f67-416e-b283-8614959e9641">
<fme:FEATURE_ID>1000858515</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882177</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822530.99600 828220.60900 0.00000 822531.95700 828219.15700 0.00000 822531.77600 828218.49700 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id52679ad9-ec02-4abb-b8d4-d74e0ff0de33">
<fme:FEATURE_ID>1000857934</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823214.32163 828891.00383 0.00000 823214.41785 828892.88009 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id13a4609d-d17c-4c64-8ad9-5eb22f8cd924">
<fme:FEATURE_ID>1000858778</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882125</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821999.58800 828376.13600 0.00000 821995.08700 828378.71300 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id45efea25-c90c-4b0e-a8c2-6197fcebdde7">
<fme:FEATURE_ID>1000858945</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884051</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821444.61519 828626.82040 0.00000 821441.04362 828627.35614 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf498dba2-9d27-4f93-b46c-742cdf0248df">
<fme:FEATURE_ID>1000858872</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884050</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821668.01000 829020.71000 0.00000 821670.55000 829020.81000 0.00000 821672.33000 829021.30000 0.00000 821672.63000 829023.41000 0.00000 821673.19000 829025.69000 0.00000 821676.03000 829026.55000 0.00000 821680.31000 829027.51000 0.00000 821682.39000 829028.40000 0.00000 821683.02000 829030.74000 0.00000 821682.49000 829033.61000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id06a17838-f664-4ae9-82ee-663038012b51">
<fme:FEATURE_ID>1000858931</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882081</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821468.05366 828572.75565 0.00000 821464.57137 828573.29140 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7d173030-c114-43cf-943a-c71bd9b08d5c">
<fme:FEATURE_ID>1000858918</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882082</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821488.45400 828551.60600 0.00000 821488.97200 828549.69600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3c48d30a-9258-4d5c-a7a4-65b8d68f8a12">
<fme:FEATURE_ID>1000858104</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823031.33431 829138.48912 0.00000 823033.78405 829140.84463 0.00000 823033.21872 829144.70767 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0a082511-5e37-49e8-be5f-4937d009a999">
<fme:FEATURE_ID>1000858902</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882087</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821549.57494 828636.59763 0.00000 821547.16413 828635.61544 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5c8ab30c-cab6-4347-8b1d-99eac446d8d8">
<fme:FEATURE_ID>1000857967</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823196.49711 828896.92128 0.00000 823199.81666 828898.26834 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idda346982-9b8e-46fc-8f2a-1751edf22027">
<fme:FEATURE_ID>1000858825</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882105</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821745.43000 828716.90000 0.00000 821744.46000 828717.05000 0.00000 821743.87000 828716.98000 0.00000 821741.56000 828715.56000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id80d164e5-cc3f-4c2f-8d41-6f7dd988caea">
<fme:FEATURE_ID>1000858470</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882191</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822625.75000 828561.50000 0.00000 822627.12000 828565.41000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3d13890e-fd64-41b5-a102-8b6c9fdb5c43">
<fme:FEATURE_ID>1000857974</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823194.72591 829034.16207 0.00000 823196.60860 829033.07590 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id62c8332a-8ee3-421b-a382-6d5b2b994f6b">
<fme:FEATURE_ID>1000858362</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882209</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822757.59000 829302.68000 0.00000 822757.18000 829301.97000 0.00000 822757.12000 829301.44000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id812351d1-51ab-4f1a-bb2f-bac7d08eb54a">
<fme:FEATURE_ID>1000858352</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882213</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822774.29643 828501.30178 0.00000 822779.29600 828505.23800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9e294f27-c1d8-4ea3-9037-092d677a434e">
<fme:FEATURE_ID>1000858542</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882173</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822462.40000 828166.70000 0.00000 822462.50000 828166.49000 0.00000 822463.42000 828165.94000 0.00000 822465.22000 828163.42000 0.00000 822465.48000 828162.83000 0.00000 822465.07000 828163.09000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id50a799f6-28dd-4b27-ae0b-c64928fb99dd">
<fme:FEATURE_ID>1000858907</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882085</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821529.43000 827708.62000 0.00000 821530.07000 827711.28000 0.00000 821531.23000 827712.89000 0.00000 821532.57000 827713.58000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9c2fac9c-70b0-461b-9795-c493835df2fe">
<fme:FEATURE_ID>1000858831</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882106</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821733.84000 828381.71000 0.00000 821736.15300 828381.00300 0.00000 821738.23800 828380.60400 0.00000 821739.12700 828380.20500 0.00000 821740.10700 828379.22600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id27c392f0-0b0d-42f6-b090-662cc510f4b6">
<fme:FEATURE_ID>1000858052</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823095.82816 829139.90242 0.00000 823097.90101 829143.67123 0.00000 823101.85826 829145.83830 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3ead5164-9511-4731-b7e3-9609b195b8fd">
<fme:FEATURE_ID>1000858496</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882185</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822555.81000 828062.60000 0.00000 822553.19000 828060.30000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id881fe9d5-2e36-4534-825c-468eb082934f">
<fme:FEATURE_ID>1000858792</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882117</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821880.08000 828173.38000 0.00000 821881.55000 828173.48000 0.00000 821882.68000 828173.82000 0.00000 821884.63000 828174.94000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id85de679c-d85b-402a-8e9b-63d38ef56555">
<fme:FEATURE_ID>1000857972</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823195.01555 829031.26562 0.00000 823200.22918 829033.00348 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8a47f6df-bb50-480f-bd91-721480b29c9d">
<fme:FEATURE_ID>1000858021</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823135.25939 829134.15497 0.00000 823133.28076 829136.22782 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idac8fb6ee-6780-49dc-8718-d4b0fbf43fe3">
<fme:FEATURE_ID>1000858058</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823092.29489 829145.17876 0.00000 823091.54113 829146.59206 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id0470da6e-ecac-4efa-8521-3407ec251410">
<fme:FEATURE_ID>1000858908</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882085</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821528.04000 827702.99000 0.00000 821528.62000 827703.45000 0.00000 821529.94000 827704.07000 0.00000 821530.04000 827704.45000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id3d44289c-fa06-4abc-9934-7984178d7b5a">
<fme:FEATURE_ID>1000858092</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823060.82529 829140.27930 0.00000 823059.12932 829144.89610 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id59528a9f-50bb-4c62-85d1-95a1d08ee772">
<fme:FEATURE_ID>1000858357</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822770.62192 829310.44064 0.00000 822769.76000 829308.67000 0.00000 822767.27000 829310.40000 0.00000 822766.24000 829314.20000 0.00000 822765.66000 829314.81000 0.00000 822764.85000 829315.08000 0.00000 822763.77000 829315.73000 0.00000 822762.74000 829316.91000 0.00000 822763.18000 829317.97000 0.00000 822762.75000 829318.46000 0.00000 822762.74960 829319.77194 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id80e41e1c-1330-4995-baaf-05349efd61bb">
<fme:FEATURE_ID>1000858041</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823115.70866 829132.27057 0.00000 823121.83298 829136.13360 0.00000 823123.71739 829140.27929 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id84057abb-3c51-40ef-9714-2d8fa707498a">
<fme:FEATURE_ID>1000858629</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882151</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822240.23000 828548.23000 0.00000 822238.19000 828552.87000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id13c38a7b-da29-4028-9596-54397d4426f2">
<fme:FEATURE_ID>1000858875</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882094</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821655.41500 829010.91800 0.00000 821654.52400 829012.23800 0.00000 821653.86400 829014.81100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id28608b4c-1ff9-4e27-abb0-a581a845f339">
<fme:FEATURE_ID>1000858862</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882097</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821714.16000 829129.44000 0.00000 821713.91000 829130.41000 0.00000 821713.93000 829131.11000 0.00000 821710.43000 829132.16000 0.00000 821710.48000 829132.43000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id6e1aa43b-9e9a-405f-945c-c16dbf16d9a8">
<fme:FEATURE_ID>1000857961</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823200.63451 828893.12064 0.00000 823199.23934 828892.97631 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf85e9316-4623-4f95-b025-32aeb11c64fc">
<fme:FEATURE_ID>1000857969</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823195.43870 828900.00028 0.00000 823195.63114 828901.05869 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id8104aa26-2984-4c92-ae4d-a706e006b663">
<fme:FEATURE_ID>1000858365</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884065</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822755.43000 829322.51000 0.00000 822756.89000 829321.60000 0.00000 822757.34000 829320.66000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1ed931a4-abb5-4320-824c-2a596898d8bf">
<fme:FEATURE_ID>1000857981</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823194.36385 829038.50676 0.00000 823191.68463 829036.33441 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2799fa8d-b8f5-4bf1-b68a-8ca0e549451a">
<fme:FEATURE_ID>1000858557</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882169</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822379.35000 828144.68000 0.00000 822380.24000 828147.11000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfde43473-827b-4fd4-a5cd-f567699b828e">
<fme:FEATURE_ID>1000858516</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882177</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822531.87000 828216.31200 0.00000 822531.20500 828215.27300 0.00000 822530.08300 828214.23600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc1105a16-b3a8-490c-83ce-3cd1b6dc9aaf">
<fme:FEATURE_ID>1000858920</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882082</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821485.55438 828547.30818 0.00000 821487.16159 828548.82610 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5190a867-2a69-4a37-b6f4-07510eb55ea9">
<fme:FEATURE_ID>1000858353</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882211</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822771.63800 828564.67300 0.00000 822771.19600 828562.41300 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf95b685a-c56a-46ec-aac3-7f0309ad3e43">
<fme:FEATURE_ID>1000858078</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823072.46150 829133.11856 0.00000 823069.82333 829139.33710 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id24983a14-2402-4dbc-8a41-60e72630d36a">
<fme:FEATURE_ID>1000858422</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882197</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822704.91000 828551.34000 0.00000 822705.45000 828553.15000 0.00000 822704.17000 828556.23000 0.00000 822703.99000 828557.63000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id894e8041-b4dd-4aba-8b74-f73f6470ed1b">
<fme:FEATURE_ID>1000858932</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882081</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821464.94300 828577.23500 0.00000 821464.78100 828576.06700 0.00000 821463.80200 828574.34600 0.00000 821463.87300 828573.63400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id5173a29f-d0db-41af-bad3-879daf52eb34">
<fme:FEATURE_ID>1000858346</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882216</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822770.35000 828533.08500 0.00000 822770.91100 828539.00500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idee667230-d5e5-4e9d-919e-d264445166b0">
<fme:FEATURE_ID>1000858938</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884051</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821448.22100 828625.98900 0.00000 821446.91500 828624.65200 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id406815d4-4f58-4442-b97a-ba2b582a7563">
<fme:FEATURE_ID>1000858921</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882082</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821486.35798 828548.73681 0.00000 821484.39362 828547.21889 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc0187695-0db4-4f2a-913a-d782186eeab6">
<fme:FEATURE_ID>1000857954</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823201.90941 828889.51244 0.00000 823203.59324 828890.95572 0.00000 823202.87160 828894.22716 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id53719891-629f-4537-a314-693be6a50142">
<fme:FEATURE_ID>1000857958</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823200.00909 828891.72547 0.00000 823201.59670 828893.64985 0.00000 823202.17401 828896.15153 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd027126d-293a-4f2d-b129-2b8561ef2a15">
<fme:FEATURE_ID>1000857982</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823191.01264 828906.30261 0.00000 823194.47652 828906.97614 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd3c414fb-a8f0-4943-a6e0-ebfde49229ff">
<fme:FEATURE_ID>1000858062</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823084.71015 829143.29435 0.00000 823082.82574 829147.34583 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9c2e62e8-ad12-45e5-ade2-4bb18279687a">
<fme:FEATURE_ID>1000858791</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882117</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821882.51000 828176.21000 0.00000 821885.02000 828177.53000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id4d88ddbf-0747-43d4-a297-4baeb3c13131">
<fme:FEATURE_ID>1000858797</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882115</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821857.58000 828718.69000 0.00000 821857.16000 828721.94000 0.00000 821857.44000 828723.05000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb1580c72-e08d-4696-829b-3ea7bc04beea">
<fme:FEATURE_ID>1000858752</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882131</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822096.18000 828843.72000 0.00000 822095.72000 828844.58000 0.00000 822095.64000 828846.29000 0.00000 822096.18000 828847.30000 0.00000 822096.65000 828848.90000 0.00000 822097.27000 828849.87000 0.00000 822098.05000 828850.49000 0.00000 822098.87000 828850.69000 0.00000 822099.65000 828850.57000 0.00000 822101.32000 828851.35000 0.00000 822102.10000 828850.96000 0.00000 822103.77000 828849.60000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idf804b497-04f9-4e08-a947-b2c50b4a1f63">
<fme:FEATURE_ID>1000858970</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882074</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821342.42000 828742.37000 0.00000 821341.72000 828740.85000 0.00000 821340.12000 828738.17000 0.00000 821340.27000 828737.38000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id325cffc5-12b3-4f3b-84f9-e76d8f463c9b">
<fme:FEATURE_ID>1000858057</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823092.38911 829139.71398 0.00000 823092.38911 829143.76545 0.00000 823094.83884 829146.59206 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idca5d1ca4-ec8c-443b-81fc-21d16170b330">
<fme:FEATURE_ID>1000858912</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882084</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821503.05600 827710.93200 0.00000 821502.72600 827710.90500 0.00000 821502.24100 827711.20800 0.00000 821500.87000 827711.04800 0.00000 821500.38400 827711.60600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id954f096c-6aeb-49bc-b2fd-e68eb22841a3">
<fme:FEATURE_ID>1000858543</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882173</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822463.31000 828159.48000 0.00000 822462.57000 828160.91000 0.00000 822460.58000 828162.50000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id53d07b07-1396-416a-9e4e-782d365b3322">
<fme:FEATURE_ID>1000858886</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882090</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821625.66800 828801.61800 0.00000 821625.17400 828802.93000 0.00000 821623.66800 828803.65100 0.00000 821622.84100 828804.97900 0.00000 821622.76100 828805.95900 0.00000 821622.27500 828806.94700 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id59bc2c8b-d84e-48c9-b001-d0f6a51b5aad">
<fme:FEATURE_ID>1000858889</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882091</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821626.47000 828795.60100 0.00000 821625.97600 828796.50000 0.00000 821623.23800 828796.35400 0.00000 821622.00700 828796.02200 0.00000 821620.64700 828795.20400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id7cbd15c0-7af7-4d4c-a746-d2261c583b2d">
<fme:FEATURE_ID>1000858338</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882216</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822779.40000 828544.48000 0.00000 822777.48000 828548.07000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb2d88b3d-f4cb-4fc5-948e-b069efec97f5">
<fme:FEATURE_ID>1000858930</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882081</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821468.53425 828576.08071 0.00000 821464.83924 828576.23794 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb39e716b-ae7c-442d-bf0f-56c357505a38">
<fme:FEATURE_ID>1000858807</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882113</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821809.90639 828331.62901 0.00000 821809.10839 828331.01201 0.00000 821808.79039 828329.99601 0.00000 821808.85439 828328.29101 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ideff613bf-73ab-40e3-9bf4-19389ff2eab2">
<fme:FEATURE_ID>1000858551</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882170</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822430.37000 828506.93000 0.00000 822426.08000 828509.23000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfa0d2b44-8dda-444e-a1cf-f5cebfdf236c">
<fme:FEATURE_ID>1000858775</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882125</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822007.45700 828382.60300 0.00000 822008.12600 828383.46300 0.00000 822008.98600 828385.37500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idb384791f-bb83-441e-b566-1a32c0320d30">
<fme:FEATURE_ID>1000858876</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882094</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821656.07368 829014.72180 0.00000 821655.31600 829015.86700 0.00000 821654.45800 829016.75800 0.00000 821652.28100 829017.02200 0.00000 821650.10300 829017.81400 0.00000 821649.80600 829018.14300 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide24f6d02-dba8-4687-94d5-ccc2cc34a075">
<fme:FEATURE_ID>1000858031</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823127.29776 829136.88736 0.00000 823126.16712 829139.43131 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idc734efe7-9f6b-490e-8bd6-44bb6b46e961">
<fme:FEATURE_ID>1000858877</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882094</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821653.07200 829012.40300 0.00000 821651.42300 829015.10800 0.00000 821650.66400 829015.90000 0.00000 821647.72800 829017.38500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ide59d4f24-48b5-495c-8df3-f783b3d4d66b">
<fme:FEATURE_ID>1000858105</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823032.18230 829140.56197 0.00000 823030.67477 829142.35216 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idd7206f7a-f302-483f-b29a-a9013eaadaa6">
<fme:FEATURE_ID>1000858871</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000884050</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821673.06000 829028.33000 0.00000 821669.76000 829027.57000 0.00000 821668.93000 829024.64000 0.00000 821668.90000 829024.04000 0.00000 821669.63000 829023.31000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ida750bda9-32d5-4c5e-a729-dcd87cb92461">
<fme:FEATURE_ID>1000858090</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823063.93456 829145.74409 0.00000 823062.99236 829148.38226 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfc1dec28-c530-428a-962d-93a20aa9cda8">
<fme:FEATURE_ID>1000858471</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882191</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>822624.76000 828565.93000 0.00000 822626.37000 828568.41000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id9c41d8b3-7917-477e-8802-5bc385b77e31">
<fme:FEATURE_ID>1000857948</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823205.90249 828890.52274 0.00000 823204.98841 828895.23745 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2fe60ad1-3d91-4939-9386-ccac44cdae4a">
<fme:FEATURE_ID>1000857962</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823198.99880 828897.40237 0.00000 823201.01939 828897.25805 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id37a41bab-97b4-43c7-82c4-2871b69eb7a8">
<fme:FEATURE_ID>1000858814</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882110</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821765.94000 828826.06000 0.00000 821763.10000 828828.15000 0.00000 821762.86000 828829.47000 0.00000 821763.67000 828832.01000 0.00000 821764.18000 828832.88000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id1250c0b0-8349-40f3-9d3a-1e7b2361200e">
<fme:FEATURE_ID>1000857932</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823215.98140 828892.11034 0.00000 823216.79926 828893.36119 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idbedba4cd-4353-493c-9828-6496e79a8959">
<fme:FEATURE_ID>1000858968</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882074</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821350.71000 828749.12000 0.00000 821350.21000 828747.82000 0.00000 821348.80000 828745.65000 0.00000 821348.72000 828745.09000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="idfb6f4fdd-46f4-46d3-86ec-fc3088005752">
<fme:FEATURE_ID>1000858107</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823027.28284 829139.52555 0.00000 823027.56550 829144.14234 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="ided7cc065-a30a-4d74-9fb7-ea9db0c187f5">
<fme:FEATURE_ID>1000858969</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000882074</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821345.89000 828738.38000 0.00000 821345.61000 828737.36000 0.00000 821343.43000 828735.27000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
<gml:featureMember>
<fme:BoulderLine gml:id="id2d28b692-7d9f-46b3-952e-9d3417e485f9">
<fme:FEATURE_ID>1000858061</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BOL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>823085.08703 829138.96021 0.00000 823085.18125 829144.51922 0.00000 823087.06566 829147.34583 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BoulderLine>
</gml:featureMember>
</gml:FeatureCollection>
