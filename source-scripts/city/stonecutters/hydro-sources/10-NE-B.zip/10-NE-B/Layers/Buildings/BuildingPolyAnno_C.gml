<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingPolyAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821118.96112 826606.11328</gml:lowerCorner>
<gml:upperCorner>823957.84662 829700.89626</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id03a9d933-9be0-465b-9705-2551cdbb3e81">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>行政大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-65.7804973246519</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743213</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826701.75906469</fme:EASTING>
<fme:NORTHING>823974.04434143</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823957.84662 826712.18827</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idcde37559-8edf-4d75-8394-a9aedb40ce30">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>18.4349459284255</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743212</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>829693.27667066</fme:EASTING>
<fme:NORTHING>821393.55342425</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821399.11471 829700.89626</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id701818c9-8263-4dff-9788-f511c4c0f4a9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>行政大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-86.4096743586432</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743216</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>829037.00237907</fme:EASTING>
<fme:NORTHING>821137.79465309</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821118.96112 829041.05611</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id36fff3f8-747b-4587-acc7-49191dce4c86">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-64.8721627677142</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743222</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>829574.81970195</fme:EASTING>
<fme:NORTHING>823271.47805483</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823259.98715 829583.37525</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id530ff106-8800-4784-be76-c75b4b652507">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-33.5627474889527</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743207</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827635.83689623</fme:EASTING>
<fme:NORTHING>822225.93582468</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822223.35574 827644.91045</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idcdec886f-f659-40b0-80a2-72ac81908240">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743223</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826821.26543968</fme:EASTING>
<fme:NORTHING>823133.76580726</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823133.76581 826828.83535</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id5ef177c7-1bd0-4318-b8b9-03c20082b4b1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-33.5627579136688</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743208</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827694.18523798</fme:EASTING>
<fme:NORTHING>822172.35809581</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822169.77802 827703.25879</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ide96c0563-c977-42b6-9680-dc5ad26b2b8a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.1722665625142</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743218</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>829456.67589106</fme:EASTING>
<fme:NORTHING>822828.91357302</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822843.22026 829456.24515</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idc2718c79-c956-4383-9c7c-4776644cdc61">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743203</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826594.1677407</fme:EASTING>
<fme:NORTHING>823630.27766965</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823631.28743 826606.11328</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id4baf72e0-ffc2-4fd0-b4c0-6b194d683e6d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743217</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>828988.78347031</fme:EASTING>
<fme:NORTHING>821491.13902179</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821494.00540 829002.80670</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="iddf19e4d9-0608-4fa2-bd31-4f7fd0b59f5d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-27.9853259283407</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743220</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>828628.41382941</fme:EASTING>
<fme:NORTHING>821305.08434957</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821301.03522 828642.14233</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="iddd614d3c-4dba-47ff-85dd-72080b186bb1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743204</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826686.071</fme:EASTING>
<fme:NORTHING>823636.204</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823636.41767 826685.87717</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ida840cc73-c338-4b95-b62c-ccd0c2cb5e17">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-33.5627474895968</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743206</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827571.61702546</fme:EASTING>
<fme:NORTHING>822270.33928326</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822267.75920 827580.69058</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id0a36bc4c-b0e0-4b18-a5ff-55b8401cebc1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743210</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827542.65976839</fme:EASTING>
<fme:NORTHING>822593.47283931</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822593.47284 827550.22968</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id769e55c8-0c1d-43b5-b1d7-7645c6bc73f3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>56.4271242788026</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743219</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827317.14722648</fme:EASTING>
<fme:NORTHING>822412.07916133</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822425.34818 827322.51381</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ide8295511-77c5-4611-87b9-8e4aff323bfe">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>行政大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-72.216103936505</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743214</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>829621.7300766</fme:EASTING>
<fme:NORTHING>821576.56861014</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821559.30399 829630.27802</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id71f10f86-a73e-4f4a-b47a-7c2819c2c8eb">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>工場</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743205</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826909.25243141</fme:EASTING>
<fme:NORTHING>823140.44022861</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823140.44023 826916.82234</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id91a28db4-eb83-40e9-8f8a-943bd2228c08">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>89.1696987357807</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743225</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827524.56014021</fme:EASTING>
<fme:NORTHING>822636.4413469</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822645.57498 827521.82582</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id05045693-731b-4b2f-901a-1a8d669db043">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>82.0928338126609</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743224</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826899.97503628</fme:EASTING>
<fme:NORTHING>822889.22227013</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822898.62319 826898.38683</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id5393522e-e098-407b-8eb8-284189bc62d7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>70.6556866369749</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743227</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827596.58121331</fme:EASTING>
<fme:NORTHING>822425.84243207</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822435.37160 827596.88867</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idf4bbdfc6-c9b4-4367-9257-50ccc22144d2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-84.7661409441156</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743228</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>829021.8022917</fme:EASTING>
<fme:NORTHING>821410.32163769</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821401.52798 829025.48620</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id83535212-aa3a-4bbc-835f-f1f3f037fc17">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>電話機房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-59.5344481274293</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743230</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>829133.19382731</fme:EASTING>
<fme:NORTHING>823489.62710366</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823474.73243 829145.28093</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id3cfa8bc8-3c1b-4e4d-a67c-1bdf2bf32a2b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>通風機樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-60.5674304857911</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743229</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826859.58179255</fme:EASTING>
<fme:NORTHING>823941.18132556</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823925.68327 826871.61727</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id88e492a2-5658-46a1-8875-260ec3430c8d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>貨倉</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743226</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827592.27033708</fme:EASTING>
<fme:NORTHING>822507.26912218</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822510.13550 827601.36339</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idab323dbd-9a4f-43d1-91d4-b7f141bb46ab">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>看台</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743245</fme:FEATURE_ID>
<fme:FEATURECODE>USN</fme:FEATURECODE>
<fme:EASTING>828155.05613477</fme:EASTING>
<fme:NORTHING>823860.29845831</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823863.16484 828163.62441</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ide580f818-6635-4d91-ad87-965f1cc23e00">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>煙囱</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743246</fme:FEATURE_ID>
<fme:FEATURECODE>CHN</fme:FEATURECODE>
<fme:EASTING>828416.706</fme:EASTING>
<fme:NORTHING>821289.649</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20241028</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821289.64895 828416.70630</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id2c1e1618-d748-4e1c-93fd-0eb53ef92efd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>行政
大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006830</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826912.65806949</fme:EASTING>
<fme:NORTHING>823073.2144471</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823074.97838 826920.41363</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ide7c1e93c-4d76-4c4e-abcb-23ee294d75dc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>行政
大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008187</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>826716.58629808</fme:EASTING>
<fme:NORTHING>823597.47269126</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823601.92932 826723.66869</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id00b738e3-b315-4196-961b-6db4b03e83ce">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310026568</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>828962.329</fme:EASTING>
<fme:NORTHING>822719.014</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822719.22718 828962.32882</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="ida178bae6-9fd8-480a-bc9e-8d80bfc231ff">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030731</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>829050.017</fme:EASTING>
<fme:NORTHING>823316.165</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823316.37817 829049.45668</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idbbd7adca-7213-473f-a5ac-ed7123c39d96">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310031371</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>829240.852</fme:EASTING>
<fme:NORTHING>821896.386</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20250307</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821896.59962 829240.29149</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idf30c16a8-4404-4662-a752-f1e16947bd4e">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>施工中</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002181</fme:FEATURE_ID>
<fme:FEATURECODE>WIP</fme:FEATURECODE>
<fme:EASTING>828052.651</fme:EASTING>
<fme:NORTHING>823574.534</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823574.74742 828052.09132</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
