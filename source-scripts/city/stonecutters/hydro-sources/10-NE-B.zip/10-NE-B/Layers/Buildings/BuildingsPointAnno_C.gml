<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingsPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>821188.62151 827383.29605</gml:lowerCorner>
<gml:upperCorner>823952.29524 829585.14121</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idceb8a48e-9584-4bcd-8f43-09f72b8caf96">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>偉力工業大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-52.7248379062268</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000030</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829257.51452827</fme:EASTING>
<fme:NORTHING>823537.15029243</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006826</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823516.27045 829277.00858</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5ef7b428-065d-4083-86d6-959e29d80c5f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>污水
泵房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001035</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829065.722</fme:EASTING>
<fme:NORTHING>823738.355</fme:NORTHING>
<fme:LINKFEATURE_ID>1210019244</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823738.36146 829065.72158</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id36290a9e-7b77-4e1a-8a66-5be00881db3c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>時力</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-63.8689948214215</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001038</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829271.22030993</fme:EASTING>
<fme:NORTHING>823580.5634637</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001048</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823574.03836 829277.61402</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide09bce58-6fcf-46f0-9810-fdcc477bb701">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>立信大廈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.3944754274956</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001031</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829346.154</fme:EASTING>
<fme:NORTHING>823432.044</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006827</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823432.12275 829346.35232</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id6cdec2be-79f9-4b23-ab5e-c104a858d5bf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>招商局
貨櫃服務</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>32.5740562801151</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001032</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>827369.57958322</fme:EASTING>
<fme:NORTHING>821168.98869696</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001009</fme:LINKFEATURE_ID>
<fme:ST_CODE>70268</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821188.62151 827383.29605</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id62586d17-9a90-46b2-aae5-b224950fedca">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004929</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828028.038</fme:EASTING>
<fme:NORTHING>823948.995</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000623</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823949.20900 828028.12218</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ida4664893-cb6f-4095-a565-2e15e01b969a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>橋滙</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-67.7837477184337</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210004931</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829379.631</fme:EASTING>
<fme:NORTHING>823568.397</fme:NORTHING>
<fme:LINKFEATURE_ID>1210168899</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823568.44518 829379.84200</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id34881647-26e6-497a-81ae-3d50d11a2ce1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>金源中心</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-67.7895955256441</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210005854</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829294.28558627</fme:EASTING>
<fme:NORTHING>823579.49891884</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001044</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823563.54975 829303.89381</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf2057961-dbe3-4b30-abca-cccea7b549f2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康美</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007852</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828281.554</fme:EASTING>
<fme:NORTHING>823479.553</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000803</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823479.76622 828281.54917</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id88548416-eee3-49e6-b822-29199869d4d2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康豐</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007911</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828543.135</fme:EASTING>
<fme:NORTHING>823469.193</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001017</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823469.40673 828543.01626</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id2a990688-2d75-4b9b-83d3-d9c4a4b672b9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華豐</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007913</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828411.085</fme:EASTING>
<fme:NORTHING>823296.304</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000954</fme:LINKFEATURE_ID>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823296.51718 828410.78467</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ided8155fb-1874-40db-b7cc-29da39c218cc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>亨麗</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007936</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828192.77</fme:EASTING>
<fme:NORTHING>823894.353</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000998</fme:LINKFEATURE_ID>
<fme:ST_CODE>75567</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823894.56627 828192.53593</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb582385b-ba7c-4211-8845-a65b7725d72a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>宜業</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007937</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828641.588</fme:EASTING>
<fme:NORTHING>823952.082</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000780</fme:LINKFEATURE_ID>
<fme:ST_CODE>75418</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823952.29524 828641.41649</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id2574435a-e307-46fe-b364-0943b51f801a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華欣</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007940</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828452.479</fme:EASTING>
<fme:NORTHING>823299.945</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000681</fme:LINKFEATURE_ID>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823300.15868 828452.40829</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idca243b7e-e1fb-42dd-b049-f53881899509">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>亨翠</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007966</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828157.865</fme:EASTING>
<fme:NORTHING>823797.485</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000620</fme:LINKFEATURE_ID>
<fme:ST_CODE>75567</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823797.69897 828157.41128</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idd5b5d848-b9f0-4f59-b239-1e076f4f0097">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康祥</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007970</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828477.014</fme:EASTING>
<fme:NORTHING>823430.086</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000994</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823430.29917 828476.99628</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc1c097de-f4b3-4147-a405-b24114218ab7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華璇</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007971</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828200.312</fme:EASTING>
<fme:NORTHING>823310.199</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001965</fme:LINKFEATURE_ID>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823310.41298 828200.18396</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id09901137-aadb-46ee-8127-42686ea39ee4">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華碧</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008000</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828366.655</fme:EASTING>
<fme:NORTHING>823315.293</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001010</fme:LINKFEATURE_ID>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823315.50698 828366.46061</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc374d814-8d75-4263-a7e9-6f901a41a451">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>大同工業</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>80.1524455669005</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210006832</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829241.75662482</fme:EASTING>
<fme:NORTHING>821684.07045753</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003349</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>821702.79167 829242.09709</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id67d988da-8377-4e4f-9fa9-8521d7bd14d8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華奐</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007774</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828137.319</fme:EASTING>
<fme:NORTHING>823318.808</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001056</fme:LINKFEATURE_ID>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823319.02208 828137.11168</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id64ba9b8c-6bb1-4e77-bfd9-738cc1b254ac">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>宜居</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007806</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828671.524</fme:EASTING>
<fme:NORTHING>823804.94</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000919</fme:LINKFEATURE_ID>
<fme:ST_CODE>75418</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823805.15357 828671.32979</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id766a56d7-566d-4844-bb97-4ef17fdcaedd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康順</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210007810</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828355.155</fme:EASTING>
<fme:NORTHING>823431.769</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000981</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823431.98223 828355.31779</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="iddce7b08d-ca25-4ee2-9fb1-9dfe3018fe40">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>華翔</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210008945</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828497.505</fme:EASTING>
<fme:NORTHING>823275.289</fme:NORTHING>
<fme:LINKFEATURE_ID>1210004950</fme:LINKFEATURE_ID>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823275.50278 828497.32885</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idaaac4899-b206-487d-bee9-0a5c25a384ca">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青盛苑</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-0.687520826371605</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210015793</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828608.651</fme:EASTING>
<fme:NORTHING>823416.094</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000641</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823416.30803 828608.64522</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idcf71f517-383c-44ac-89eb-b6a851d689f6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青葵</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018482</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829322.23</fme:EASTING>
<fme:NORTHING>822970.569</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000682</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822966.27498 829324.71008</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id31f49d8d-95bd-455e-87e0-6212cd322957">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青槐</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018483</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829218.774</fme:EASTING>
<fme:NORTHING>822952.884</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000841</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822953.09794 829218.65931</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id013f84e6-88cb-482a-a995-a5b35785f13c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青榕</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018484</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829242.511</fme:EASTING>
<fme:NORTHING>822850.208</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000962</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822850.42191 829242.38771</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5051b5f3-00fb-4fae-9ab6-496097b297bf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青桃</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>90</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018485</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829368.084</fme:EASTING>
<fme:NORTHING>823034.585</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001819</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823034.45683 829367.87062</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5dc80c11-5ffd-47b4-8684-08a7a0963ee7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青松</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018502</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829221.247</fme:EASTING>
<fme:NORTHING>823198.386</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003291</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823198.59983 829221.00865</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id4e22d638-ed2e-4f63-ab2f-8369130b4f28">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青柏</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018503</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829309.608</fme:EASTING>
<fme:NORTHING>823252.528</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000771</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823252.74160 829309.18872</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idf698e946-73b9-4967-a30e-0dcb16c0df9c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青梅</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018504</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829058.38</fme:EASTING>
<fme:NORTHING>823399.903</fme:NORTHING>
<fme:LINKFEATURE_ID>1210003288</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823400.11704 829058.15929</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id443e6e5d-6217-4c3a-a1d6-609bc9921298">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青楊</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018505</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829196.369</fme:EASTING>
<fme:NORTHING>823403.468</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000781</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823403.68189 829196.18774</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id0b72cc38-7e71-42e6-a307-ab4a46341dc1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>俊軒</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018522</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829265.162</fme:EASTING>
<fme:NORTHING>823018.726</fme:NORTHING>
<fme:LINKFEATURE_ID>1210184911</fme:LINKFEATURE_ID>
<fme:ST_CODE>82439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823018.93992 829265.19774</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idc6b6951b-2ed2-4e59-a18f-3c85364b943b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>俊豪</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018523</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829288.97</fme:EASTING>
<fme:NORTHING>823018.302</fme:NORTHING>
<fme:LINKFEATURE_ID>1210184912</fme:LINKFEATURE_ID>
<fme:ST_CODE>82439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823018.51599 829288.84180</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id331cf365-f93b-45b4-b5a2-d4721fd5add5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康榮</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018524</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828966.535</fme:EASTING>
<fme:NORTHING>823390.435</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001051</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823390.64897 828966.47726</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id76199374-b7c1-4e13-9f59-db322382f8e0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康華</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018525</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828897.168</fme:EASTING>
<fme:NORTHING>823401.545</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000883</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823401.75864 828897.00091</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id6137ddeb-ad42-46f7-bf51-4375cc802e22">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康富</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018526</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828928.409</fme:EASTING>
<fme:NORTHING>823439.648</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000679</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823439.86178 828928.05659</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idbc94f80e-5525-49f4-ba23-d21ec20bafd9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康貴</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018527</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828891.972</fme:EASTING>
<fme:NORTHING>823320.514</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000953</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823320.72815 828891.82176</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5f0280e3-a9fc-4fff-88ce-6e31cf972089">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康和</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-78.0000029358319</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018528</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828844.441</fme:EASTING>
<fme:NORTHING>823380.295</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000782</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823380.50315 828844.61482</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id53eb074e-7055-434a-82a5-9178b84e77cc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康泰</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018529</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828845.284</fme:EASTING>
<fme:NORTHING>823475.918</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000890</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823476.13173 828845.23952</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id75516dd6-d822-4d37-809d-9e7a3dfbca08">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康安</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018530</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828721.237</fme:EASTING>
<fme:NORTHING>823453.796</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007449</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823454.00938 828720.94571</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id3b075d16-178c-4f2b-a9ec-43a7caed3808">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康盛</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018531</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828689.656</fme:EASTING>
<fme:NORTHING>823493.721</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007448</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823493.93513 828689.59888</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5eb4a330-a8a8-4429-be09-e8646d164961">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>康平</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210018532</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828773.677</fme:EASTING>
<fme:NORTHING>823470.649</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001031</fme:LINKFEATURE_ID>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823470.86288 828773.46057</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id23f7619a-9f80-4879-b389-c16996dc5af0">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>救護站</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210020125</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829019.301</fme:EASTING>
<fme:NORTHING>823507.576</fme:NORTHING>
<fme:LINKFEATURE_ID>1210180997</fme:LINKFEATURE_ID>
<fme:ST_CODE>73970</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823507.79009 829019.57030</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id03271021-1601-4110-bc5a-6f8601a7961d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>和記電訊</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>16.9426098503799</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210024045</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829585.149</fme:EASTING>
<fme:NORTHING>822805.932</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000798</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822806.15336 829585.14121</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idced759e4-5e4b-4483-a547-2d83d524cec5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>運輸署車輛檢驗綜合大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID/>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>827855.451</fme:EASTING>
<fme:NORTHING>822748.411</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE/>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822748.62466 827855.45072</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idb0bad835-1679-45f7-9d31-6540230c1c9f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>愛護動物協會</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310027968</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829528.524</fme:EASTING>
<fme:NORTHING>823093.851</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206570</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823094.06485 829528.52399</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="ide622ccb5-4c51-41a9-bd53-18b3b4d1b262">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青盈</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028128</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829112.371</fme:EASTING>
<fme:NORTHING>822530.582</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206850</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822530.79530 829112.18570</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idaf47bc10-90e8-4b63-8203-338b2cfce0ac">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青隆</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310028129</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829180.369</fme:EASTING>
<fme:NORTHING>822598.051</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206851</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822598.26418 829180.05587</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id15cc3047-e440-4263-b17b-f372de820caa">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青荷</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029988</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829120.04</fme:EASTING>
<fme:NORTHING>823362.591</fme:NORTHING>
<fme:LINKFEATURE_ID>1310209849</fme:LINKFEATURE_ID>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823362.80483 829119.85006</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="idbed0a85c-8f3f-4777-a709-b2b710240ffa">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>青蘭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>11.0853596135722</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310030348</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829362.167</fme:EASTING>
<fme:NORTHING>823099.217</fme:NORTHING>
<fme:LINKFEATURE_ID>1310210377</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823099.36720 829361.82274</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_C gml:id="id5219ff78-f0c6-4269-9988-a2e0398c0166">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>南灣行政大樓</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>77.2624020791013</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420002320</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>827891.077</fme:EASTING>
<fme:NORTHING>822521.978</fme:NORTHING>
<fme:LINKFEATURE_ID>1210169799</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822522.60127 827890.99862</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
