<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingsPointAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>822572.63945 827876.51728</gml:lowerCorner>
<gml:upperCorner>823984.32222 829542.11619</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id4c9b1830-8170-4bc5-b80d-02e907599c91">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Gateway TS</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-68.4592690653037</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000035</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829368.158</fme:EASTING>
<fme:NORTHING>823561.328</fme:NORTHING>
<fme:LINKFEATURE_ID>1210168899</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823561.32799 829368.15755</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idd6469763-f3ad-40fb-87e0-57b4605ad31d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Vigor Industrial Building</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-52.900784214142</fme:Angle>
<fme:FontLeading>-1</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000686</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829268.230945</fme:EASTING>
<fme:NORTHING>823507.79661</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006826</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823507.79661 829268.23095</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id357d897a-4fd0-4320-8e57-99e4fac2aacc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001938</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829124.209</fme:EASTING>
<fme:NORTHING>823832.354</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001050</fme:LINKFEATURE_ID>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823832.35412 829124.20928</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idb8d022d0-2928-499a-b673-70071e2d296e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001940</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829171.52</fme:EASTING>
<fme:NORTHING>823834.979</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000960</fme:LINKFEATURE_ID>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823834.97942 829171.52028</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id49fc2d38-edb4-44c1-8621-b45d6430666c">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001942</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>827996.904</fme:EASTING>
<fme:NORTHING>823747.601</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000653</fme:LINKFEATURE_ID>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823747.60093 827996.90419</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id6f26159e-05ee-401b-a6fb-c2f60330c42f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001943</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>827876.517</fme:EASTING>
<fme:NORTHING>823745.783</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000813</fme:LINKFEATURE_ID>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823745.78339 827876.51728</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idf5968ca7-ee28-4e44-9033-b7fbd1d66e00">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001944</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829177.735</fme:EASTING>
<fme:NORTHING>823636.227</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000900</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823636.22692 829177.73528</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idd7392766-08c2-473c-81a0-eab0484d274e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001945</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829299.3</fme:EASTING>
<fme:NORTHING>823721.866</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001045</fme:LINKFEATURE_ID>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823721.86642 829299.29958</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id10214d86-9859-45b5-b3a1-bff2905634f7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001984</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829321.923</fme:EASTING>
<fme:NORTHING>823805.292</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000621</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823805.29188 829321.92328</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id95bc332b-2e05-488b-b2d2-3738db9f01fd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001986</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828925.523</fme:EASTING>
<fme:NORTHING>823881.443</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000886</fme:LINKFEATURE_ID>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823881.44292 828925.52338</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id19d09c33-1ab2-4978-990e-0550be5dd710">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001988</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829153.144</fme:EASTING>
<fme:NORTHING>823984.322</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000699</fme:LINKFEATURE_ID>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823984.32222 829153.14438</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id29ac83f0-a51e-4c86-b8a7-c02a8c6fd3ce">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>7</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001989</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829204.266</fme:EASTING>
<fme:NORTHING>823744.968</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000709</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823744.96772 829204.26558</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idfa81ea88-055a-475f-b83c-b891263e9a7d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001996</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829351.41</fme:EASTING>
<fme:NORTHING>823720.475</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000950</fme:LINKFEATURE_ID>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823720.47492 829351.41015</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ideb97c355-bda6-4cf5-ab77-eb8355cd0a09">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>4</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002018</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828891.104</fme:EASTING>
<fme:NORTHING>823812.931</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000807</fme:LINKFEATURE_ID>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823812.93062 828891.10398</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id7a04c417-5f79-4223-88e2-0fb316ecee1d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>4</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002019</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829197.292</fme:EASTING>
<fme:NORTHING>823931.252</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000594</fme:LINKFEATURE_ID>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823931.25222 829197.29218</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id3a8fd82e-80af-4526-ad26-6dfc7f4d89ff">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002021</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>827977.819</fme:EASTING>
<fme:NORTHING>823793.027</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000878</fme:LINKFEATURE_ID>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823793.02718 827977.81918</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id281c1a69-97e5-4bda-b1a3-c142b9445223">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>8</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002023</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829230.817</fme:EASTING>
<fme:NORTHING>823755.941</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000920</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823755.94092 829230.81658</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide430a062-fbb0-480c-9ce6-e566485c8562">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002026</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>827890.839</fme:EASTING>
<fme:NORTHING>823812.755</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000582</fme:LINKFEATURE_ID>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823812.75522 827890.83918</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide71cc9a2-4035-4d61-b11e-1481333faef6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002027</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829182.731</fme:EASTING>
<fme:NORTHING>823961.364</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000744</fme:LINKFEATURE_ID>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823961.36392 829182.73148</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida5d8a0fa-989b-45d5-9fc5-050a609d8c68">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002028</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829361.609</fme:EASTING>
<fme:NORTHING>823686.116</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001029</fme:LINKFEATURE_ID>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823686.11610 829361.60901</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id2a5dce89-231a-4cc9-b803-b87e187fe07f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002062</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828941.548</fme:EASTING>
<fme:NORTHING>823849.96</fme:NORTHING>
<fme:LINKFEATURE_ID>1210002380</fme:LINKFEATURE_ID>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823849.95952 828941.54828</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id01f603fb-4597-4427-bfdc-3f8ee7a60620">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002064</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828823.16</fme:EASTING>
<fme:NORTHING>823823.358</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000958</fme:LINKFEATURE_ID>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823823.35842 828823.15968</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id662b8dd4-a86d-43d8-a3f5-4352758dd4de">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002066</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829157.053</fme:EASTING>
<fme:NORTHING>823697.463</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000581</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823697.46342 829157.05288</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0540d27e-9cd0-4b1d-8ad5-c08edce93b69">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002068</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829317.977</fme:EASTING>
<fme:NORTHING>823675.581</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000642</fme:LINKFEATURE_ID>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823675.58142 829317.97718</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id446a011d-7763-4767-989c-8b168096caaf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002107</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829198.066</fme:EASTING>
<fme:NORTHING>823881.557</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000915</fme:LINKFEATURE_ID>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823881.55732 829198.06648</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idaaf150f1-de5f-45c5-8416-6859016d1418">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>7</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002108</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828890.576</fme:EASTING>
<fme:NORTHING>823875.158</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000971</fme:LINKFEATURE_ID>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823875.15782 828890.57608</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idab168ccf-a4f0-4621-be61-ca78d619ede7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002111</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829212.505</fme:EASTING>
<fme:NORTHING>823589.847</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000617</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823589.84662 829212.50498</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id02fad8bc-21a5-4a5a-bb78-3d090313e8ff">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002149</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828803.569</fme:EASTING>
<fme:NORTHING>823856.366</fme:NORTHING>
<fme:LINKFEATURE_ID>1210002602</fme:LINKFEATURE_ID>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823856.36592 828803.56858</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id5861cd14-10c1-43df-91a6-416c90174794">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002157</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828852.779</fme:EASTING>
<fme:NORTHING>823808.484</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000731</fme:LINKFEATURE_ID>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823808.48412 828852.77948</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idbbe2d160-645f-4e18-89fe-48c0bb0f0be3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>4</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002158</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829160.349</fme:EASTING>
<fme:NORTHING>823659.57</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001087</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823659.56962 829160.34858</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idb659e79f-b4be-48eb-a72b-c94b3e9d171f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002160</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>827939.053</fme:EASTING>
<fme:NORTHING>823820.359</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000973</fme:LINKFEATURE_ID>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823820.35907 827939.05343</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id1325b83a-7668-4d86-a0f3-05ad391f1010">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002161</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829341.594</fme:EASTING>
<fme:NORTHING>823744.369</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000579</fme:LINKFEATURE_ID>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823744.36922 829341.59368</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idfe80a76a-882d-4e1c-b803-14aa54099908">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>9</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002228</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829257.247</fme:EASTING>
<fme:NORTHING>823766.808</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000776</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823766.80782 829257.24658</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide8c02ea1-6dbd-47fd-9ea4-6e2f3fb42bef">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>11</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002276</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829332.783</fme:EASTING>
<fme:NORTHING>823778.673</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000980</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823778.67318 829332.78299</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id85cbe726-539f-49a7-9949-b7ebef061c4f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002277</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829169.066</fme:EASTING>
<fme:NORTHING>823723.837</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001041</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823723.83742 829169.06578</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idc78cf23a-ad31-4039-aa63-4ef057583529">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210002280</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829195.062</fme:EASTING>
<fme:NORTHING>823613.068</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001816</fme:LINKFEATURE_ID>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823613.06822 829195.06208</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id6c96c4e6-fc94-48d7-8d7a-8782b15fe132">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Ching Shing
Court</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210019172</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828609.259</fme:EASTING>
<fme:NORTHING>823402.272</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000641</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823402.23285 828609.25915</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id83454f4e-5103-45d3-abfa-8f4e05ada916">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021593</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829145.333</fme:EASTING>
<fme:NORTHING>822805.7</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000660</fme:LINKFEATURE_ID>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822805.69994 829145.33253</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id614a78c3-c7c5-4e6e-bab2-0497c4a1e5e7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>7</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021594</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829124.852</fme:EASTING>
<fme:NORTHING>822824.605</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000689</fme:LINKFEATURE_ID>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822824.60502 829124.85203</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id944bfe4c-0078-48c5-bfcf-57aa47886df5">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>9</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021595</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829103.294</fme:EASTING>
<fme:NORTHING>822844.579</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000578</fme:LINKFEATURE_ID>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822844.57881 829103.29360</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id631870b4-2f0d-4e0d-8482-23c568083b37">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>11</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021596</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829057.901</fme:EASTING>
<fme:NORTHING>822829.838</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000772</fme:LINKFEATURE_ID>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822829.83801 829057.90093</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id446ed893-4965-45c6-b088-26d194970d9a">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>12</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021597</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829036.117</fme:EASTING>
<fme:NORTHING>822808.169</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000777</fme:LINKFEATURE_ID>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822808.16904 829036.11700</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idbdbcd3c2-1830-43e5-9bcd-30300620b706">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>10</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021598</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829026.02</fme:EASTING>
<fme:NORTHING>822762.988</fme:NORTHING>
<fme:LINKFEATURE_ID>1210006999</fme:LINKFEATURE_ID>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822762.98848 829026.01956</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id1746d527-94c4-4a62-8284-5be3f0c9d4ff">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>8</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021599</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829046.311</fme:EASTING>
<fme:NORTHING>822743.503</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007001</fme:LINKFEATURE_ID>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822743.50298 829046.31119</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide24c36ce-5ea7-4925-af94-97990a40ca72">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021600</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829066.571</fme:EASTING>
<fme:NORTHING>822724.515</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007000</fme:LINKFEATURE_ID>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822724.51498 829066.57058</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ida9a199ec-394a-4a50-b708-2d50a9448912">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>6</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021601</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829416.541</fme:EASTING>
<fme:NORTHING>822751.888</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001068</fme:LINKFEATURE_ID>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822751.88760 829416.54109</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0c5fe560-0b5c-408a-abcf-ee0b245ac393">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>5</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021602</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829403.176</fme:EASTING>
<fme:NORTHING>822716.772</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000943</fme:LINKFEATURE_ID>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822716.77174 829403.17610</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idbb633686-8538-4506-9c97-633403250f21">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021603</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829377.986</fme:EASTING>
<fme:NORTHING>822643.543</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001028</fme:LINKFEATURE_ID>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822643.54271 829377.98570</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id4088a1b8-d590-4e6e-92da-8769a6062c76">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021604</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829365.161</fme:EASTING>
<fme:NORTHING>822608.017</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000793</fme:LINKFEATURE_ID>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822608.01738 829365.16121</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0480583d-6896-462a-8d26-81d0adca76a1">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210021605</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829351.157</fme:EASTING>
<fme:NORTHING>822572.639</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000555</fme:LINKFEATURE_ID>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822572.63945 829351.15744</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0dd5d213-1c7c-4d36-ac78-b687fe9f6ecc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026693</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828774.716</fme:EASTING>
<fme:NORTHING>823745.449</fme:NORTHING>
<fme:LINKFEATURE_ID>1210178057</fme:LINKFEATURE_ID>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823745.44851 828774.71629</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id0f7831f0-a68a-4376-8d5c-0615d785ce70">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>3</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-1.24533850119939</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026694</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828828.168</fme:EASTING>
<fme:NORTHING>823743.967</fme:NORTHING>
<fme:LINKFEATURE_ID>1210178058</fme:LINKFEATURE_ID>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823743.96672 828828.16850</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id4a7fc4b2-3c15-4236-b7b8-bf72905d8e82">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026695</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828721.569</fme:EASTING>
<fme:NORTHING>823750.553</fme:NORTHING>
<fme:LINKFEATURE_ID>1210178056</fme:LINKFEATURE_ID>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823750.55309 828721.56895</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id5d81d6c4-7670-4172-88c3-9305b507bb43">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>C</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026813</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829465.296</fme:EASTING>
<fme:NORTHING>823404.92</fme:NORTHING>
<fme:LINKFEATURE_ID>1210169195</fme:LINKFEATURE_ID>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823404.91952 829465.29577</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idbf972dba-705e-4cee-888b-92d90fbc53cc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>E</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026814</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829476.141</fme:EASTING>
<fme:NORTHING>823337.875</fme:NORTHING>
<fme:LINKFEATURE_ID>1210000804</fme:LINKFEATURE_ID>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823337.87530 829476.14100</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idebb447a2-8f55-40c7-a42d-35e7e6252e15">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>D</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026815</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829423.827</fme:EASTING>
<fme:NORTHING>823391.448</fme:NORTHING>
<fme:LINKFEATURE_ID>1210169196</fme:LINKFEATURE_ID>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823391.44773 829423.82709</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idf131b985-7381-4a35-aee0-80e4a2424ae6">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>B</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026816</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829397.405</fme:EASTING>
<fme:NORTHING>823461.469</fme:NORTHING>
<fme:LINKFEATURE_ID>1210169194</fme:LINKFEATURE_ID>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823461.46945 829397.40481</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="idfe80ebc8-423a-47b3-9c96-8c375098b446">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210026817</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829434.426</fme:EASTING>
<fme:NORTHING>823474.292</fme:NORTHING>
<fme:LINKFEATURE_ID>1210001013</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823474.29203 829434.42577</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide819a57e-4bfb-4a9e-a982-3d4e40732f66">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029578</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828913.237</fme:EASTING>
<fme:NORTHING>822792.862</fme:NORTHING>
<fme:LINKFEATURE_ID>1310204494</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822792.86188 828913.23687</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="ide585a3fe-cbfe-43d4-bee1-122f8e107638">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2A</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029579</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828987.167</fme:EASTING>
<fme:NORTHING>822789.044</fme:NORTHING>
<fme:LINKFEATURE_ID>1310204493</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822789.04387 828987.16737</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id24c877af-bbf0-457c-8cc3-38384a0efeec">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>1</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029580</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828931.58</fme:EASTING>
<fme:NORTHING>822779.781</fme:NORTHING>
<fme:LINKFEATURE_ID>1310204491</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822779.78116 828931.58031</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id14884be9-ad96-4f29-82b0-6a5163a1bb9e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>2</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029581</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>828965.87</fme:EASTING>
<fme:NORTHING>822780.575</fme:NORTHING>
<fme:LINKFEATURE_ID>1310204492</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>822780.57491 828965.87038</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPointAnno_E gml:id="id2cbc3b01-ee75-4fb5-a412-b5569f07edfd">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>SPCA</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1310029941</fme:FEATURE_ID>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:EASTING>829542.116</fme:EASTING>
<fme:NORTHING>823081.354</fme:NORTHING>
<fme:LINKFEATURE_ID>1310206570</fme:LINKFEATURE_ID>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>823081.35400 829542.11619</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPointAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
