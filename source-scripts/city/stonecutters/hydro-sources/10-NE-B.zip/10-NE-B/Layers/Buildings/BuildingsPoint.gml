<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingsPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>821086.00000 826720.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>823998.00000 829872.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id22b32bfc-5cd7-45f0-8a05-83e431b35201">
<fme:FEATURE_ID>1310200508</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310100287</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829330</fme:EASTING>
<fme:NORTHING>821086</fme:NORTHING>
<fme:ENGLISHNAME>Able Rich Container Yard Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>富裕貨櫃場變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821086.00000 829330.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id008c89d2-1328-4465-b878-e363655483f8">
<fme:FEATURE_ID>1210182308</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000984</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829410</fme:EASTING>
<fme:NORTHING>821090</fme:NORTHING>
<fme:ENGLISHNAME>Chemical Waste Treat C Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>衡和化學處理廠Ｃ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821090.00000 829410.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id85a0cf3e-df09-4214-8817-b4fae2a3da27">
<fme:FEATURE_ID>1210182306</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210013411</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829666</fme:EASTING>
<fme:NORTHING>821115</fme:NORTHING>
<fme:ENGLISHNAME>Shine Logistics B Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>光輝物流Ｂ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821115.00000 829666.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9c532b32-5ceb-4248-a6bc-05ca7fa45356">
<fme:FEATURE_ID>1210182307</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210013315</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829673</fme:EASTING>
<fme:NORTHING>821115</fme:NORTHING>
<fme:ENGLISHNAME>Shine Logistics A Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>光輝物流Ａ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821115.00000 829673.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id90327e69-ca0c-440b-8a3a-40a92f39f699">
<fme:FEATURE_ID>1210182309</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210029760</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829576</fme:EASTING>
<fme:NORTHING>821133</fme:NORTHING>
<fme:ENGLISHNAME>Ocean First Container Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>海暉貨櫃場變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821133.00000 829576.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf9747b64-fd1e-441b-94e8-ae0ec9596919">
<fme:FEATURE_ID>1210001009</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000975</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827418</fme:EASTING>
<fme:NORTHING>821186</fme:NORTHING>
<fme:ENGLISHNAME>China Merchants Container Services Ltd.</fme:ENGLISHNAME>
<fme:CHINESENAME>招商局貨櫃服務有限公司</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>70268</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821186.00000 827418.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide949ff15-71be-4ad7-9b0f-259cf749a220">
<fme:FEATURE_ID>1210004662</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210029755</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828829</fme:EASTING>
<fme:NORTHING>821283</fme:NORTHING>
<fme:ENGLISHNAME>Tien Chu (Tsing Yi) Industrial Centre Block M</fme:ENGLISHNAME>
<fme:CHINESENAME>天廚（青衣）工業中心Ｍ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821283.00000 828829.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc7a98ba7-623a-46fd-9968-1d5116a0cb50">
<fme:FEATURE_ID>1210067273</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000959</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828750</fme:EASTING>
<fme:NORTHING>821301</fme:NORTHING>
<fme:ENGLISHNAME>52</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653774</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821301.00000 828750.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaf485114-c6ea-4e3b-bf84-faa5efea687a">
<fme:FEATURE_ID>1210000792</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000959</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828750</fme:EASTING>
<fme:NORTHING>821301</fme:NORTHING>
<fme:ENGLISHNAME>Tien Chu (Tsing Yi) Industrial Centre Block D</fme:ENGLISHNAME>
<fme:CHINESENAME>天廚（青衣）工業中心Ｄ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821301.00000 828750.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd24716cc-0a55-4567-b892-10d2a9ef9358">
<fme:FEATURE_ID>1210071219</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000960</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828976</fme:EASTING>
<fme:NORTHING>821302</fme:NORTHING>
<fme:ENGLISHNAME>52</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654276</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821302.00000 828976.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9a12200b-bddd-43cf-8907-3f931cebcd06">
<fme:FEATURE_ID>1210000796</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000960</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828976</fme:EASTING>
<fme:NORTHING>821302</fme:NORTHING>
<fme:ENGLISHNAME>Tien Chu (Tsing Yi) Industrial Centre Block A</fme:ENGLISHNAME>
<fme:CHINESENAME>天廚（青衣）工業中心Ａ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821302.00000 828976.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id427f35e1-7cdb-46df-996c-5f562670107d">
<fme:FEATURE_ID>1210062894</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000955</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828896</fme:EASTING>
<fme:NORTHING>821309</fme:NORTHING>
<fme:ENGLISHNAME>52</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654217</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821309.00000 828896.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf0349416-7c3c-4dea-a6bc-c5986f878fcf">
<fme:FEATURE_ID>1210004661</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000955</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828896</fme:EASTING>
<fme:NORTHING>821309</fme:NORTHING>
<fme:ENGLISHNAME>Tien Chu (Tsing Yi) Industrial Centre Block B</fme:ENGLISHNAME>
<fme:CHINESENAME>天廚（青衣）工業中心Ｂ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821309.00000 828896.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1272b9b4-0479-45ca-9326-8e6673fd1317">
<fme:FEATURE_ID>1210000815</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000953</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828673</fme:EASTING>
<fme:NORTHING>821317</fme:NORTHING>
<fme:ENGLISHNAME>Tien Chu (Tsing Yi) Industrial Centre Block E</fme:ENGLISHNAME>
<fme:CHINESENAME>天廚（青衣）工業中心Ｅ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79097</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821317.00000 828673.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id41ed6bed-1a07-4746-97b5-7a8c9d71f09f">
<fme:FEATURE_ID>1210067281</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000953</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828673</fme:EASTING>
<fme:NORTHING>821317</fme:NORTHING>
<fme:ENGLISHNAME>52</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653748</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821317.00000 828673.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf333334c-030b-4e54-aff1-9a8d79f24d19">
<fme:FEATURE_ID>1210188427</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210066171</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829424</fme:EASTING>
<fme:NORTHING>821650</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810058253</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14171</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821650.00000 829424.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id748d328e-751a-4f8a-9439-9257f53f7821">
<fme:FEATURE_ID>1210003349</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000923</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829220</fme:EASTING>
<fme:NORTHING>821703</fme:NORTHING>
<fme:ENGLISHNAME>Tai Tung Industrial Building</fme:ENGLISHNAME>
<fme:CHINESENAME>大同工業大廈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821703.00000 829220.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id38a25603-1e49-4d97-bcc6-eed6cb405805">
<fme:FEATURE_ID>1210064573</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000923</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829220</fme:EASTING>
<fme:NORTHING>821703</fme:NORTHING>
<fme:ENGLISHNAME>29</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654453</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821703.00000 829220.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcf59551c-c0c1-4463-8998-00fd3f87b3b8">
<fme:FEATURE_ID>1210177936</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210047365</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829418</fme:EASTING>
<fme:NORTHING>821776</fme:NORTHING>
<fme:ENGLISHNAME>36</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810046155</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>14171</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821776.00000 829418.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id36063a8f-8d68-4a9f-a445-4b97ac54c907">
<fme:FEATURE_ID>1210064552</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000919</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829253</fme:EASTING>
<fme:NORTHING>821846</fme:NORTHING>
<fme:ENGLISHNAME>23</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654476</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821846.00000 829253.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide1dfe590-f2df-4925-aaa7-c525cbf5ba9b">
<fme:FEATURE_ID>1210004951</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000919</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829253</fme:EASTING>
<fme:NORTHING>821846</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Road Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣路變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821846.00000 829253.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb6e375fe-f48d-4d5b-a084-35843255ebda">
<fme:FEATURE_ID>1210000825</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034622</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829495</fme:EASTING>
<fme:NORTHING>821872</fme:NORTHING>
<fme:ENGLISHNAME>Drainage Services Department Container Terminal 9 Sewage Pumping Station No.2</fme:ENGLISHNAME>
<fme:CHINESENAME>渠務署九號貨櫃碼頭二號污水泵房</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821872.00000 829495.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6712591c-7dd3-4549-a168-4e0c8088ab77">
<fme:FEATURE_ID>1210001011</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000916</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829492</fme:EASTING>
<fme:NORTHING>821930</fme:NORTHING>
<fme:ENGLISHNAME>Terminal 9 South A Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣九號貨櫃碼頭南Ａ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>70638</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821930.00000 829492.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idedfa05a9-0fb5-4ef6-a6e2-056a0b450264">
<fme:FEATURE_ID>1210000595</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000912</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827709</fme:EASTING>
<fme:NORTHING>821984</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi South Fire Station</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣南消防局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821984.00000 827709.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id432299c9-5365-47cd-a2c8-a3d9d14e0d7f">
<fme:FEATURE_ID>1210066163</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000912</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827709</fme:EASTING>
<fme:NORTHING>821984</fme:NORTHING>
<fme:ENGLISHNAME>100</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653595</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>821984.00000 827709.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id738f4922-c4d1-41f2-8770-4c973f8910cd">
<fme:FEATURE_ID>1210169474</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000911</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827720</fme:EASTING>
<fme:NORTHING>822000</fme:NORTHING>
<fme:ENGLISHNAME>TY SUB DIV FIRE STATION SUBSTATION</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣消防局變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822000.00000 827720.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2aafb572-904c-4233-ab8b-bec02444f14b">
<fme:FEATURE_ID>1210000961</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000903</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829472</fme:EASTING>
<fme:NORTHING>822195</fme:NORTHING>
<fme:ENGLISHNAME>Terminal 9 North Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣九號貨櫃碼頭北變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>70638</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822195.00000 829472.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaca2992c-bd0d-4901-9e16-889339bfd904">
<fme:FEATURE_ID>1210181178</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210055872</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829000.944</fme:EASTING>
<fme:NORTHING>822287.565</fme:NORTHING>
<fme:ENGLISHNAME>20B</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810050270</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822287.56482 829000.94369 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida24fd71b-f9bb-490f-8003-187618832200">
<fme:FEATURE_ID>1210189345</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210055872</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829003</fme:EASTING>
<fme:NORTHING>822292</fme:NORTHING>
<fme:ENGLISHNAME>VTC Tsing Yi Halls of Residence</fme:ENGLISHNAME>
<fme:CHINESENAME>ＶＴＣ青衣學生舍堂</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822292.00000 829003.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7c0025f2-f094-4179-bcd7-99dd1d372573">
<fme:FEATURE_ID>1210189346</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000876</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829022</fme:EASTING>
<fme:NORTHING>822435</fme:NORTHING>
<fme:ENGLISHNAME>Assembly Hall</fme:ENGLISHNAME>
<fme:CHINESENAME>禮堂</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822435.00000 829022.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcfb871f1-d0a1-4adc-9c62-594f8afa6cfd">
<fme:FEATURE_ID>1210161212</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001078</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829008.591</fme:EASTING>
<fme:NORTHING>822454.636</fme:NORTHING>
<fme:ENGLISHNAME>20A</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654308</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822454.63568 829008.59108 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id305abce8-51b8-4f00-b016-1efb260e0e47">
<fme:FEATURE_ID>1310206850</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090492</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829101</fme:EASTING>
<fme:NORTHING>822529</fme:NORTHING>
<fme:ENGLISHNAME>Ching Ying House (Block A)</fme:ENGLISHNAME>
<fme:CHINESENAME>青盈閣 (A座)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>83138</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822529.00000 829101.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id68beca79-cd93-484c-8ae6-5a5f699064c3">
<fme:FEATURE_ID>1310206866</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090492</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829101</fme:EASTING>
<fme:NORTHING>822529</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1910087711</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822529.00000 829101.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id18d97518-e8d7-4b84-9ecd-12f01ab67e4e">
<fme:FEATURE_ID>1210162791</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000869</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827541</fme:EASTING>
<fme:NORTHING>822536</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653564</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12441</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822536.00000 827541.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id32a9f4c3-e7c2-4afe-bbfd-4fe3767efef7">
<fme:FEATURE_ID>1210169799</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001056</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827904</fme:EASTING>
<fme:NORTHING>822545</fme:NORTHING>
<fme:ENGLISHNAME>Nam Wan Administration Building</fme:ENGLISHNAME>
<fme:CHINESENAME>南灣行政大樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822545.00000 827904.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id14c34260-c5e9-490d-8111-4249bd7a912e">
<fme:FEATURE_ID>1210066193</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001056</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827904</fme:EASTING>
<fme:NORTHING>822545</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653604</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11854</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822545.00000 827904.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb1644a20-e492-4d83-a21c-6947bd5b17f3">
<fme:FEATURE_ID>1210000637</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000847</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829389</fme:EASTING>
<fme:NORTHING>822547</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Oasis Hotel</fme:ENGLISHNAME>
<fme:CHINESENAME>青逸酒店</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822547.00000 829389.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfb85a802-14fa-4883-82a1-79c4936d33d5">
<fme:FEATURE_ID>1210005840</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210013311</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829030</fme:EASTING>
<fme:NORTHING>822554</fme:NORTHING>
<fme:ENGLISHNAME>The Jockey Club Heavy Vehicle Emissions Testing and Research Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>賽馬會重型車輛排放測試及研究中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>71741</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822554.00000 829030.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida08532fe-978c-42ed-b90a-b7fd0ffcdf85">
<fme:FEATURE_ID>1210000555</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000867</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829351</fme:EASTING>
<fme:NORTHING>822573</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Crest Tower 1</fme:ENGLISHNAME>
<fme:CHINESENAME>藍澄灣第一座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822573.00000 829351.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd1f56594-dd4b-4918-bc05-c844e12229a1">
<fme:FEATURE_ID>1310206851</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090491</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829192</fme:EASTING>
<fme:NORTHING>822577</fme:NORTHING>
<fme:ENGLISHNAME>Ching Lung House (Block B)</fme:ENGLISHNAME>
<fme:CHINESENAME>青隆閣 (B座)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>83138</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822577.00000 829192.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6fb68a16-5b8e-4ac0-bd33-fb1c15cdf1ea">
<fme:FEATURE_ID>1310206867</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090491</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829192</fme:EASTING>
<fme:NORTHING>822577</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1910087712</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822577.00000 829192.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7a7a7b17-e415-42d3-b05f-e3dc692ee3ba">
<fme:FEATURE_ID>1210000793</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000864</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829364</fme:EASTING>
<fme:NORTHING>822608</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Crest Tower 2</fme:ENGLISHNAME>
<fme:CHINESENAME>藍澄灣第二座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822608.00000 829364.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id583cf549-9080-4f54-ba35-ac05ba370c48">
<fme:FEATURE_ID>1210162145</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001078</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828990</fme:EASTING>
<fme:NORTHING>822616</fme:NORTHING>
<fme:ENGLISHNAME>20</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810024899</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822616.00000 828990.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id42cb14bc-e764-4da3-8f55-de48bdef18cd">
<fme:FEATURE_ID>1210191690</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000847</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829433</fme:EASTING>
<fme:NORTHING>822642</fme:NORTHING>
<fme:ENGLISHNAME>Winland 800 Hotel</fme:ENGLISHNAME>
<fme:CHINESENAME>永倫８００酒店</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822642.00000 829433.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id667967e0-39c4-4e3c-9ffd-813334ca1ae5">
<fme:FEATURE_ID>1210001028</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000863</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829378</fme:EASTING>
<fme:NORTHING>822644</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Crest Tower 3</fme:ENGLISHNAME>
<fme:CHINESENAME>藍澄灣第三座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822644.00000 829378.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id95846f55-aa6c-48e6-ba0c-08dc330a9cf4">
<fme:FEATURE_ID>1210066165</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000862</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827513</fme:EASTING>
<fme:NORTHING>822646</fme:NORTHING>
<fme:ENGLISHNAME>4</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653560</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12441</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822646.00000 827513.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd1b4eaec-d910-4469-a117-a61798ae02e9">
<fme:FEATURE_ID>1210161358</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001077</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829411</fme:EASTING>
<fme:NORTHING>822658</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810025473</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822658.00000 829411.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9ab67c60-2a21-400d-adb2-8440fc568deb">
<fme:FEATURE_ID>1310199984</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310085823</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827710</fme:EASTING>
<fme:NORTHING>822691</fme:NORTHING>
<fme:ENGLISHNAME>Dynamometer Room 1</fme:ENGLISHNAME>
<fme:CHINESENAME>底盤功率測試房</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822691.00000 827710.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id517e00ce-5036-4452-8584-06b98aeb6ae3">
<fme:FEATURE_ID>1210000943</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000855</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829404</fme:EASTING>
<fme:NORTHING>822716</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Crest Tower 5</fme:ENGLISHNAME>
<fme:CHINESENAME>藍澄灣第五座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822716.00000 829404.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4558e644-0eac-47d2-beea-bd45c8062d46">
<fme:FEATURE_ID>1210007000</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000849</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829066</fme:EASTING>
<fme:NORTHING>822719</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Block 6</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園第六座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822719.00000 829066.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5dd8b4fa-c067-425e-b39b-d276f9a16a2f">
<fme:FEATURE_ID>1210184509</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000853</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829220</fme:EASTING>
<fme:NORTHING>822733</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810054834</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12449</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822733.00000 829220.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaa1fd3eb-c7f0-4cc7-90f3-0044778d3b3a">
<fme:FEATURE_ID>1210007001</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000849</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829044</fme:EASTING>
<fme:NORTHING>822741</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Block 8</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園第八座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822741.00000 829044.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id844d24ee-54b5-4126-ba33-0899395bd81c">
<fme:FEATURE_ID>1210000933</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000847</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829468</fme:EASTING>
<fme:NORTHING>822741</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Garden Hotel</fme:ENGLISHNAME>
<fme:CHINESENAME>華逸酒店</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822741.00000 829468.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id309117f9-e1f8-4eee-adb5-22b866b21366">
<fme:FEATURE_ID>1210001068</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000850</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829417</fme:EASTING>
<fme:NORTHING>822750</fme:NORTHING>
<fme:ENGLISHNAME>Rambler Crest Tower 6</fme:ENGLISHNAME>
<fme:CHINESENAME>藍澄灣第六座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>79330</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822750.00000 829417.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc69e8185-37e9-4cf6-9ab8-8c37f7abf6ee">
<fme:FEATURE_ID>1210006999</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000849</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829023</fme:EASTING>
<fme:NORTHING>822761</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Block 10</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園第十座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822761.00000 829023.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfe341910-f1ff-4937-8eb0-aa9236e0c2e8">
<fme:FEATURE_ID>1310204527</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828952</fme:EASTING>
<fme:NORTHING>822777</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1910085486</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11851</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822777.00000 828952.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0a25fe69-749b-4db2-984e-f6fff5263bf1">
<fme:FEATURE_ID>1310204491</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310087655</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828932</fme:EASTING>
<fme:NORTHING>822780</fme:NORTHING>
<fme:ENGLISHNAME>The Grand Marine Tower 1</fme:ENGLISHNAME>
<fme:CHINESENAME>明翹匯第１座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>83139</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822780.00000 828932.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfb8da623-5782-4c26-a987-7e0d601c2365">
<fme:FEATURE_ID>1310204492</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310087655</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828966</fme:EASTING>
<fme:NORTHING>822781</fme:NORTHING>
<fme:ENGLISHNAME>The Grand Marine Tower 2</fme:ENGLISHNAME>
<fme:CHINESENAME>明翹匯第２座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>83139</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822781.00000 828966.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id88cada1c-9253-4d6d-b7ed-faab039e8ab8">
<fme:FEATURE_ID>1310204493</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310087655</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828987</fme:EASTING>
<fme:NORTHING>822790</fme:NORTHING>
<fme:ENGLISHNAME>The Grand Marine Tower 2A</fme:ENGLISHNAME>
<fme:CHINESENAME>明翹匯第２Ａ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>83139</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822790.00000 828987.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idea358cc2-0764-4c49-841e-3b598244f3b1">
<fme:FEATURE_ID>1310204494</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310087655</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828914</fme:EASTING>
<fme:NORTHING>822794</fme:NORTHING>
<fme:ENGLISHNAME>The Grand Marine Tower 1A</fme:ENGLISHNAME>
<fme:CHINESENAME>明翹匯第１Ａ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>83139</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822794.00000 828914.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb58797a5-4c9d-4e1f-b2f0-f23f5d833730">
<fme:FEATURE_ID>1210000660</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000843</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829145</fme:EASTING>
<fme:NORTHING>822807</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Block 5</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園第五座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822807.00000 829145.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id464d2bbf-b380-4406-baca-0020f5d1fedd">
<fme:FEATURE_ID>1210067334</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000842</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829590</fme:EASTING>
<fme:NORTHING>822812</fme:NORTHING>
<fme:ENGLISHNAME>99</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654716</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822812.00000 829590.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id38169944-b593-4b53-ac2b-1602ee27eb0c">
<fme:FEATURE_ID>1210000798</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000842</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829590</fme:EASTING>
<fme:NORTHING>822812</fme:NORTHING>
<fme:ENGLISHNAME>Hutchison Telecom Tower</fme:ENGLISHNAME>
<fme:CHINESENAME>和記電訊大廈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822812.00000 829590.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb249ff88-3c2c-4652-aa66-464e832293d0">
<fme:FEATURE_ID>1210000777</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000839</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829037</fme:EASTING>
<fme:NORTHING>822815</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Block 12</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園第十二座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822815.00000 829037.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide0aaae72-6ab3-4e8b-9cc8-5046071b45d8">
<fme:FEATURE_ID>1210000689</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000841</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829123</fme:EASTING>
<fme:NORTHING>822827</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Block 7</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園第七座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822827.00000 829123.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id08feacfb-6a55-4330-8fe1-1e54dd47747a">
<fme:FEATURE_ID>1210000772</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000839</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829056</fme:EASTING>
<fme:NORTHING>822831</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Block 11</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園第十一座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822831.00000 829056.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id07532612-bc21-437f-ad97-ae7f51f2420c">
<fme:FEATURE_ID>1210162714</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001076</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829106.227</fme:EASTING>
<fme:NORTHING>822835.66</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654381</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11851</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822835.65986 829106.22676 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd3881b61-1a61-4527-a71c-1f4dfd424b23">
<fme:FEATURE_ID>1210000578</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000838</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829102</fme:EASTING>
<fme:NORTHING>822847</fme:NORTHING>
<fme:ENGLISHNAME>Mayfair Gardens Block 9</fme:ENGLISHNAME>
<fme:CHINESENAME>美景花園第九座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75575</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822847.00000 829102.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7e19a207-b384-49f9-ba11-194b5b6d1639">
<fme:FEATURE_ID>1210000962</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000833</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829236</fme:EASTING>
<fme:NORTHING>822850</fme:NORTHING>
<fme:ENGLISHNAME>Ching Yung House</fme:ENGLISHNAME>
<fme:CHINESENAME>青榕樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822850.00000 829236.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide908464b-ea55-4f25-b829-e19fd6d3a09e">
<fme:FEATURE_ID>1210000975</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000825</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829305</fme:EASTING>
<fme:NORTHING>822893</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>長青商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822893.00000 829305.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idea22dd19-05fd-464f-bd77-64143aa42b1f">
<fme:FEATURE_ID>1210000841</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000821</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829216</fme:EASTING>
<fme:NORTHING>822946</fme:NORTHING>
<fme:ENGLISHNAME>Ching Wai House</fme:ENGLISHNAME>
<fme:CHINESENAME>青槐樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822946.00000 829216.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idef0f6981-154c-457e-9631-c7d7fa4eb90e">
<fme:FEATURE_ID>1210000682</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000818</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829345</fme:EASTING>
<fme:NORTHING>822982</fme:NORTHING>
<fme:ENGLISHNAME>Ching Kwai House</fme:ENGLISHNAME>
<fme:CHINESENAME>青葵樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822982.00000 829345.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf923426f-0059-47cf-91d4-d3fb223e19d3">
<fme:FEATURE_ID>1210184912</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210061543</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829296</fme:EASTING>
<fme:NORTHING>822994</fme:NORTHING>
<fme:ENGLISHNAME>Chun Ho House</fme:ENGLISHNAME>
<fme:CHINESENAME>俊豪閣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>822994.00000 829296.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb969c807-57d4-44e1-baeb-469a89c14ed5">
<fme:FEATURE_ID>1210184911</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210061541</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829262</fme:EASTING>
<fme:NORTHING>823017</fme:NORTHING>
<fme:ENGLISHNAME>Chun Hin House</fme:ENGLISHNAME>
<fme:CHINESENAME>俊軒閣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823017.00000 829262.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb1de2438-9845-4ba2-89f1-278450e00f84">
<fme:FEATURE_ID>1210184947</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210061540</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829248</fme:EASTING>
<fme:NORTHING>823025</fme:NORTHING>
<fme:ENGLISHNAME>2B</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810054970</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10248</fme:ST_CODE>
<fme:LASTUPDATEDATE>20250429</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823025.00000 829248.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id396c912c-abd5-4c55-8e68-4b89053312be">
<fme:FEATURE_ID>1210001819</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000812</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829369</fme:EASTING>
<fme:NORTHING>823057</fme:NORTHING>
<fme:ENGLISHNAME>Ching Tao House</fme:ENGLISHNAME>
<fme:CHINESENAME>青桃樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823057.00000 829369.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1a998232-d20b-487f-a8cf-fb5f464b57bd">
<fme:FEATURE_ID>1310210298</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310100092</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829341</fme:EASTING>
<fme:NORTHING>823073</fme:NORTHING>
<fme:ENGLISHNAME>Lift</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20241029</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823073.00000 829341.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc445ca8b-7372-49ba-a0df-4f405a95547d">
<fme:FEATURE_ID>1310206570</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090014</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829543</fme:EASTING>
<fme:NORTHING>823092</fme:NORTHING>
<fme:ENGLISHNAME>SPCA Jockey Club Centennial Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>愛護動物協會賽馬會百周年中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823092.00000 829543.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id13d71552-eedb-41f4-af8a-d018aabcf3a9">
<fme:FEATURE_ID>1310206591</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310090014</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829543</fme:EASTING>
<fme:NORTHING>823092</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1910087709</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823092.00000 829543.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3b680152-389b-4138-829b-d7e17aeaa1ca">
<fme:FEATURE_ID>1310210377</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310098687</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829356</fme:EASTING>
<fme:NORTHING>823099</fme:NORTHING>
<fme:ENGLISHNAME>Ching Lan House</fme:ENGLISHNAME>
<fme:CHINESENAME>青蘭樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823099.00000 829356.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7b5e5ef7-7bb0-4d68-b04b-a2c9277a8d46">
<fme:FEATURE_ID>1420003052</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310098686</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829264</fme:EASTING>
<fme:NORTHING>823125</fme:NORTHING>
<fme:ENGLISHNAME>Estate Management Office</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823125.00000 829264.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id97d3efbe-186c-49b7-8ca3-1df80ee52d5e">
<fme:FEATURE_ID>1210000945</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000801</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829469</fme:EASTING>
<fme:NORTHING>823185</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Bridge West Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣橋西變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823185.00000 829469.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide8409c86-9e9b-48f9-ae0b-1798d1a1180b">
<fme:FEATURE_ID>1210003291</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000798</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829212</fme:EASTING>
<fme:NORTHING>823188</fme:NORTHING>
<fme:ENGLISHNAME>Ching Chung House</fme:ENGLISHNAME>
<fme:CHINESENAME>青松樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823188.00000 829212.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id063dd2c7-51c5-41ed-8020-11f436636ae3">
<fme:FEATURE_ID>1210005056</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000795</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829128</fme:EASTING>
<fme:NORTHING>823234</fme:NORTHING>
<fme:ENGLISHNAME>Father Cucchiara Memorial School</fme:ENGLISHNAME>
<fme:CHINESENAME>郭怡雅神父紀念學校</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>70849</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823234.00000 829128.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id26286517-fd06-4f2a-a2e1-85f317f9437f">
<fme:FEATURE_ID>1210000771</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000787</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829302</fme:EASTING>
<fme:NORTHING>823243</fme:NORTHING>
<fme:ENGLISHNAME>Ching Pak House</fme:ENGLISHNAME>
<fme:CHINESENAME>青柏樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823243.00000 829302.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd738ebfc-c9ec-4dba-bc4b-6f72166aee84">
<fme:FEATURE_ID>1210001069</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000794</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829545</fme:EASTING>
<fme:NORTHING>823244</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Salt Water Pumping Station Staff Quarters</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣海水抽水站員工宿舍</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823244.00000 829545.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf11e5d66-1f86-485b-ab5f-fb6e52b61dc7">
<fme:FEATURE_ID>1210009229</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210080741</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829021</fme:EASTING>
<fme:NORTHING>823249</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Bus Terminus Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長青巴士總站公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823249.00000 829021.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7a062202-b1d1-4416-a7e4-48a5c12d54b6">
<fme:FEATURE_ID>1210000816</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001055</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829586</fme:EASTING>
<fme:NORTHING>823252</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Salt Water Pumping House</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣海水抽水房</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823252.00000 829586.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9cfe63a1-0c5e-4e76-89b4-31db1896620f">
<fme:FEATURE_ID>1210180798</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000792</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829544</fme:EASTING>
<fme:NORTHING>823255</fme:NORTHING>
<fme:ENGLISHNAME>Customs Exam Facilities Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>海關驗貨設施變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823255.00000 829544.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id79238cd2-e25d-4e20-8739-224b8c5a3cc6">
<fme:FEATURE_ID>1210066768</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000784</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828714</fme:EASTING>
<fme:NORTHING>823273</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653761</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12414</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823273.00000 828714.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3c0c3c68-4638-417b-b218-ca3910ff1b8d">
<fme:FEATURE_ID>1210009398</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000784</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828714</fme:EASTING>
<fme:NORTHING>823273</fme:NORTHING>
<fme:ENGLISHNAME>Po Leung Kuk Mr &amp; Mrs Chan Pak Keung Tsing Yi School</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局陳百強伉儷青衣學校</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231012</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823273.00000 828714.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id39a54442-845b-43d2-b12b-3096dce3b311">
<fme:FEATURE_ID>1210000954</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000780</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828412</fme:EASTING>
<fme:NORTHING>823285</fme:NORTHING>
<fme:ENGLISHNAME>Wah Fung House</fme:ENGLISHNAME>
<fme:CHINESENAME>華豐閣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823285.00000 828412.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida77ad72a-be31-4c74-a7fe-23bfa6a8397f">
<fme:FEATURE_ID>1210000681</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000780</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828453</fme:EASTING>
<fme:NORTHING>823288</fme:NORTHING>
<fme:ENGLISHNAME>Wah Yan House</fme:ENGLISHNAME>
<fme:CHINESENAME>華欣閣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823288.00000 828453.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id051104ff-6b2a-4e4b-919c-91cbcbf155ce">
<fme:FEATURE_ID>1210004950</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000785</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828495</fme:EASTING>
<fme:NORTHING>823288</fme:NORTHING>
<fme:ENGLISHNAME>Wah Cheung House</fme:ENGLISHNAME>
<fme:CHINESENAME>華翔閣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823288.00000 828495.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbc20c32f-1b01-4fbd-9700-e3501edd3682">
<fme:FEATURE_ID>1210009397</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000783</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828597</fme:EASTING>
<fme:NORTHING>823302</fme:NORTHING>
<fme:ENGLISHNAME>Tung Wah Group of Hospitals Chow Yin Sum Primary School</fme:ENGLISHNAME>
<fme:CHINESENAME>東華三院周演森小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>73968</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823302.00000 828597.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id72d6093d-7043-45a2-bc03-d2e40e1db465">
<fme:FEATURE_ID>1210070653</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000783</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828597</fme:EASTING>
<fme:NORTHING>823302</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654161</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12414</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823302.00000 828597.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id328462c2-22fa-4757-be33-f6cf4b64ca6a">
<fme:FEATURE_ID>1210001010</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000777</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828366</fme:EASTING>
<fme:NORTHING>823307</fme:NORTHING>
<fme:ENGLISHNAME>Wah Pik House</fme:ENGLISHNAME>
<fme:CHINESENAME>華碧閣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823307.00000 828366.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida2e91996-4708-4e66-b3ff-fe13ceef7c21">
<fme:FEATURE_ID>1210001965</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000776</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828190</fme:EASTING>
<fme:NORTHING>823308</fme:NORTHING>
<fme:ENGLISHNAME>Wah Suen House</fme:ENGLISHNAME>
<fme:CHINESENAME>華璇閣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823308.00000 828190.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id876f598f-be5e-4a97-ac91-c2b1316756c6">
<fme:FEATURE_ID>1210000953</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000752</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828912</fme:EASTING>
<fme:NORTHING>823312</fme:NORTHING>
<fme:ENGLISHNAME>Hong Kwai House</fme:ENGLISHNAME>
<fme:CHINESENAME>康貴樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823312.00000 828912.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idce46627c-8a44-4b39-8a14-4dbec9c44952">
<fme:FEATURE_ID>1210009396</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000771</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829206</fme:EASTING>
<fme:NORTHING>823312</fme:NORTHING>
<fme:ENGLISHNAME>Buddhist Yip Kei Nam Memorial College</fme:ENGLISHNAME>
<fme:CHINESENAME>佛教葉紀南紀念中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>73985</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823312.00000 829206.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4b92527c-9be0-40d1-ba44-727bb28c2850">
<fme:FEATURE_ID>1420000903</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000752</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828961</fme:EASTING>
<fme:NORTHING>823314</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1910098418</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10248</fme:ST_CODE>
<fme:LASTUPDATEDATE>20250322</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823314.00000 828961.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id472a6807-04c2-4789-90de-83dd2fde02c4">
<fme:FEATURE_ID>1210007656</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000752</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828961</fme:EASTING>
<fme:NORTHING>823314</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hong Commercial Centre No1</fme:ENGLISHNAME>
<fme:CHINESENAME>長康第一商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20250318</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823314.00000 828961.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3f97657b-4ceb-4c9f-bbea-3e8285f19c19">
<fme:FEATURE_ID>1210192805</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000778</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829163</fme:EASTING>
<fme:NORTHING>823319</fme:NORTHING>
<fme:ENGLISHNAME>Yip Kei Nam Memorial School Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>葉紀南紀念中學變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823319.00000 829163.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4cda7747-451f-4a3c-9895-faf8a606ce18">
<fme:FEATURE_ID>1210001056</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000775</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828135</fme:EASTING>
<fme:NORTHING>823321</fme:NORTHING>
<fme:ENGLISHNAME>Wah Woon House</fme:ENGLISHNAME>
<fme:CHINESENAME>華奐閣</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75569</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823321.00000 828135.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idde920bc8-4bff-41a5-b7b7-daed02cbc314">
<fme:FEATURE_ID>1210180400</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000773</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828757</fme:EASTING>
<fme:NORTHING>823339</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Association Primary School Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣商會小學變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823339.00000 828757.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id36db0193-fdfd-49d6-8f0c-fe3f310ae58f">
<fme:FEATURE_ID>1210065090</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034524</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829486.09</fme:EASTING>
<fme:NORTHING>823347.087</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654581</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823347.08706 829486.08997 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id30a6095e-3e2c-40a0-b174-e56ae033cee1">
<fme:FEATURE_ID>1210000804</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034524</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829479.661</fme:EASTING>
<fme:NORTHING>823348.776</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Industrial Centre Phase II Block E</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣工業中心第二期Ｅ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823348.77625 829479.66070 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb1c5aefa-5a92-4390-a5f5-891a7d93bf11">
<fme:FEATURE_ID>1310209849</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310098645</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829116</fme:EASTING>
<fme:NORTHING>823349</fme:NORTHING>
<fme:ENGLISHNAME>Ching Ho House</fme:ENGLISHNAME>
<fme:CHINESENAME>青荷樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823349.00000 829116.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf0e1c695-63fd-40f6-a574-0f59ffde1d73">
<fme:FEATURE_ID>1210003289</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000765</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828724</fme:EASTING>
<fme:NORTHING>823355</fme:NORTHING>
<fme:ENGLISHNAME>Po Leung Kuk Lo Kit Sing (1983) College</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局羅傑承（一九八三）中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823355.00000 828724.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2a740426-f390-4838-8d6a-f3f4d9fc3378">
<fme:FEATURE_ID>1210180399</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000769</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828745</fme:EASTING>
<fme:NORTHING>823356</fme:NORTHING>
<fme:ENGLISHNAME>Po Leung Kuk 1983 Board of Directors' College Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局一九八三年總理中學變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823356.00000 828745.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida4e83558-ef6c-4e74-bdbd-8b75c994d906">
<fme:FEATURE_ID>1210009395</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000762</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828763</fme:EASTING>
<fme:NORTHING>823356</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Trade Association Primary School</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣商會小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823356.00000 828763.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0bee83c4-cf1c-4b4c-b714-594debce8c9d">
<fme:FEATURE_ID>1210000782</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000752</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828848</fme:EASTING>
<fme:NORTHING>823364</fme:NORTHING>
<fme:ENGLISHNAME>Hong Wo House</fme:ENGLISHNAME>
<fme:CHINESENAME>康和樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823364.00000 828848.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb99bea8c-74e7-42dd-b6de-9858bbbba4dd">
<fme:FEATURE_ID>1210000728</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000766</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829383</fme:EASTING>
<fme:NORTHING>823367</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Tat Road Cooked Food Market</fme:ENGLISHNAME>
<fme:CHINESENAME>長達路熟食市場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823367.00000 829383.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2724a4a3-0f1e-405f-90ae-2e65d9dae897">
<fme:FEATURE_ID>1210065137</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000766</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829383</fme:EASTING>
<fme:NORTHING>823367</fme:NORTHING>
<fme:ENGLISHNAME>32</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654550</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823367.00000 829383.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3db1b085-16d3-4fdc-b38b-23c46d79c95a">
<fme:FEATURE_ID>1210000641</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000744</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828606</fme:EASTING>
<fme:NORTHING>823376</fme:NORTHING>
<fme:ENGLISHNAME>Ching Shing Court</fme:ENGLISHNAME>
<fme:CHINESENAME>青盛苑</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823376.00000 828606.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7c3c934f-0d2d-4d6d-8e0e-2453355c4830">
<fme:FEATURE_ID>1210067301</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000744</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828606</fme:EASTING>
<fme:NORTHING>823376</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653726</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10248</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823376.00000 828606.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida85f54fc-3d1d-4554-8702-cb59549dc0af">
<fme:FEATURE_ID>1310209850</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310098644</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829139</fme:EASTING>
<fme:NORTHING>823379</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Ching Community Hall</fme:ENGLISHNAME>
<fme:CHINESENAME>長青社區會堂</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823379.00000 829139.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id47a3e051-33b0-4b24-99bf-77181fe833c6">
<fme:FEATURE_ID>1210001051</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000760</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828966</fme:EASTING>
<fme:NORTHING>823380</fme:NORTHING>
<fme:ENGLISHNAME>Hong Wing House</fme:ENGLISHNAME>
<fme:CHINESENAME>康榮樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823380.00000 828966.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd541dd0c-d92a-4fb2-b900-5b14a19e82f8">
<fme:FEATURE_ID>1210169200</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034522</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829426</fme:EASTING>
<fme:NORTHING>823393</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810032241</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823393.00000 829426.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id98754891-df38-41b2-b579-124c021eb726">
<fme:FEATURE_ID>1210169196</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034522</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829426</fme:EASTING>
<fme:NORTHING>823393</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Industrial Centre Phase II Block D</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣工業中心第二期Ｄ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823393.00000 829426.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida11bbb33-75ce-43ee-b228-6838b8f90c2b">
<fme:FEATURE_ID>1210169201</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000715</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829448</fme:EASTING>
<fme:NORTHING>823396</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810032244</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823396.00000 829448.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide8bffedc-ebf9-4708-a0ae-e018bf37fe29">
<fme:FEATURE_ID>1210003288</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000749</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829051</fme:EASTING>
<fme:NORTHING>823408</fme:NORTHING>
<fme:ENGLISHNAME>Ching Mui House</fme:ENGLISHNAME>
<fme:CHINESENAME>青梅樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823408.00000 829051.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id33553624-d3a3-4fab-9610-caa242a7d05d">
<fme:FEATURE_ID>1210009174</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000753</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829356</fme:EASTING>
<fme:NORTHING>823408</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Tat Road Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長達路公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823408.00000 829356.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2daaed0a-5151-47c0-881c-b89d8e99ee64">
<fme:FEATURE_ID>1210169199</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034523</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829462</fme:EASTING>
<fme:NORTHING>823408</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810032240</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823408.00000 829462.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8cf95030-4c1c-4853-944c-2793466f0782">
<fme:FEATURE_ID>1210169195</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034523</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829462</fme:EASTING>
<fme:NORTHING>823408</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Industrial Centre Phase II Block C</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣工業中心第二期Ｃ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823408.00000 829462.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id373dfd57-2d1b-471a-b58b-dae0469623ba">
<fme:FEATURE_ID>1210000883</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000740</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828896</fme:EASTING>
<fme:NORTHING>823409</fme:NORTHING>
<fme:ENGLISHNAME>Hong Wah House</fme:ENGLISHNAME>
<fme:CHINESENAME>康華樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823409.00000 828896.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8a0d7a68-8a14-4869-bd90-230f8ce5bc9d">
<fme:FEATURE_ID>1210001032</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000753</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829368</fme:EASTING>
<fme:NORTHING>823410</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Tat Road Refuse Collection Point</fme:ENGLISHNAME>
<fme:CHINESENAME>長達路垃圾收集站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>73930</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823410.00000 829368.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaf3df6a2-ad09-4b41-a01a-c769a98de56f">
<fme:FEATURE_ID>1210000781</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000747</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829168</fme:EASTING>
<fme:NORTHING>823413</fme:NORTHING>
<fme:ENGLISHNAME>Ching Yeung House</fme:ENGLISHNAME>
<fme:CHINESENAME>青楊樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75574</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823413.00000 829168.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2279de52-2e0f-4052-8c9d-ea7d42f122b5">
<fme:FEATURE_ID>1210007653</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000745</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828195</fme:EASTING>
<fme:NORTHING>823425</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hong Commercial Centre No 2</fme:ENGLISHNAME>
<fme:CHINESENAME>長康第二商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20250318</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823425.00000 828195.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1716fd35-e7ca-4b84-aa61-9a0a2d18cc08">
<fme:FEATURE_ID>1210000679</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000740</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828928</fme:EASTING>
<fme:NORTHING>823434</fme:NORTHING>
<fme:ENGLISHNAME>Hong Fu House</fme:ENGLISHNAME>
<fme:CHINESENAME>康富樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823434.00000 828928.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc74b49bf-663c-465f-a90a-68d71c573094">
<fme:FEATURE_ID>1210000994</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000734</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828482</fme:EASTING>
<fme:NORTHING>823436</fme:NORTHING>
<fme:ENGLISHNAME>Hong Cheung House</fme:ENGLISHNAME>
<fme:CHINESENAME>康祥樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823436.00000 828482.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id01d214da-2f86-4ca0-8412-7d014981c54d">
<fme:FEATURE_ID>1210000981</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000733</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828346</fme:EASTING>
<fme:NORTHING>823438</fme:NORTHING>
<fme:ENGLISHNAME>Hong Shun House</fme:ENGLISHNAME>
<fme:CHINESENAME>康順樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823438.00000 828346.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id92142f1d-5dec-455a-8b9f-eb969c285333">
<fme:FEATURE_ID>1210006827</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310098783</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829360</fme:EASTING>
<fme:NORTHING>823446</fme:NORTHING>
<fme:ENGLISHNAME>Fong's Building</fme:ENGLISHNAME>
<fme:CHINESENAME>立信大廈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823446.00000 829360.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ideb68f5df-325b-42d1-8a9c-1280fc5e6a8e">
<fme:FEATURE_ID>1210065651</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310098783</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829360</fme:EASTING>
<fme:NORTHING>823446</fme:NORTHING>
<fme:ENGLISHNAME>22</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654539</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20240830</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823446.00000 829360.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id782461e2-4427-4c38-97ea-03e20050d260">
<fme:FEATURE_ID>1210168658</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000737</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828160</fme:EASTING>
<fme:NORTHING>823452</fme:NORTHING>
<fme:ENGLISHNAME>Leung Chik Wai Mem Sch Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>樂善堂粱植偉紀念中學變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823452.00000 828160.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaf7f4d95-1401-4d1d-af17-9b62bf194005">
<fme:FEATURE_ID>1210007654</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000736</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828301.296</fme:EASTING>
<fme:NORTHING>823454.907</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Hong Estate Market No.2 and Covered Games Area</fme:ENGLISHNAME>
<fme:CHINESENAME>長康邨第二街市及有蓋遊樂場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823454.90705 828301.29554 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf78fec6c-802e-4e85-81a4-49fb20d6768a">
<fme:FEATURE_ID>1210007449</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000716</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828719</fme:EASTING>
<fme:NORTHING>823458</fme:NORTHING>
<fme:ENGLISHNAME>Hong On House</fme:ENGLISHNAME>
<fme:CHINESENAME>康安樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823458.00000 828719.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6effd911-1287-456c-b226-ed378fb5fbd5">
<fme:FEATURE_ID>1210064029</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000720</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829153</fme:EASTING>
<fme:NORTHING>823459</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654399</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823459.00000 829153.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida9e6ba4f-8003-4bda-a161-37a90d99153b">
<fme:FEATURE_ID>1210169198</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034521</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829398</fme:EASTING>
<fme:NORTHING>823459</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810032200</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823459.00000 829398.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id528be9aa-2019-42a3-af5a-b9cbc069678d">
<fme:FEATURE_ID>1210169194</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034521</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829398</fme:EASTING>
<fme:NORTHING>823459</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Industrial Centre Phase I Block B</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣工業中心第一期Ｂ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75738</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823459.00000 829398.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id616eff5a-3fe5-43c8-842f-be6ab0b8c35a">
<fme:FEATURE_ID>1210063452</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000728</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829096</fme:EASTING>
<fme:NORTHING>823463</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654373</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823463.00000 829096.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id98a230a8-5110-4b5c-9345-bac34a0ba577">
<fme:FEATURE_ID>1210001064</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000730</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828946</fme:EASTING>
<fme:NORTHING>823464</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi North Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣北變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823464.00000 828946.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc443da35-8e4e-464e-b35d-c5d9b0abebe2">
<fme:FEATURE_ID>1210063984</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000728</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829090</fme:EASTING>
<fme:NORTHING>823464</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654368</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823464.00000 829090.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0c0d3fe6-fc9a-47b5-bd88-4ea565182af4">
<fme:FEATURE_ID>1210064015</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000728</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829085</fme:EASTING>
<fme:NORTHING>823466</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654365</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823466.00000 829085.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id286beb34-c617-4090-b715-e126c2c45d3a">
<fme:FEATURE_ID>1210197007</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000725</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828780</fme:EASTING>
<fme:NORTHING>823467</fme:NORTHING>
<fme:ENGLISHNAME>Housing Department Cheung Hong Estate Office</fme:ENGLISHNAME>
<fme:CHINESENAME>房屋署長康邨辦事處</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823467.00000 828780.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7460819b-990b-4ed0-8d75-7ef2d00b950f">
<fme:FEATURE_ID>1210001013</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034520</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829421.012</fme:EASTING>
<fme:NORTHING>823467.316</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Industrial Centre Phase I Block A</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣工業中心第一期Ａ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823467.31612 829421.01174 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6f0a071c-451c-498e-8c15-5534c62ce57f">
<fme:FEATURE_ID>1210065640</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210034520</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829420.703</fme:EASTING>
<fme:NORTHING>823467.933</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654569</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823467.93271 829420.70344 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7c512456-110b-429d-825c-27ebd421ee3e">
<fme:FEATURE_ID>1210064011</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000728</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829079</fme:EASTING>
<fme:NORTHING>823468</fme:NORTHING>
<fme:ENGLISHNAME>20</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654362</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823468.00000 829079.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3a1da524-78c4-48a9-8cc9-e7878e572c5b">
<fme:FEATURE_ID>1210001017</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000714</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828549</fme:EASTING>
<fme:NORTHING>823470</fme:NORTHING>
<fme:ENGLISHNAME>Hong Fung House</fme:ENGLISHNAME>
<fme:CHINESENAME>康豐樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823470.00000 828549.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idce3820fa-5f27-4a6b-8869-992d7c2b2a3f">
<fme:FEATURE_ID>1210063990</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000723</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829064</fme:EASTING>
<fme:NORTHING>823472</fme:NORTHING>
<fme:ENGLISHNAME>22</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654348</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823472.00000 829064.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id31367b3c-6309-4f1c-add0-785662968257">
<fme:FEATURE_ID>1210001031</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000725</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828767</fme:EASTING>
<fme:NORTHING>823473</fme:NORTHING>
<fme:ENGLISHNAME>Hong Ping House</fme:ENGLISHNAME>
<fme:CHINESENAME>康平樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823473.00000 828767.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2dac8852-7a2b-4c29-b2dc-91f5e85e5b25">
<fme:FEATURE_ID>1210063476</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000723</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829058</fme:EASTING>
<fme:NORTHING>823474</fme:NORTHING>
<fme:ENGLISHNAME>24</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654343</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823474.00000 829058.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7a7699ff-12be-45c4-81af-e4393e7848b9">
<fme:FEATURE_ID>1210000890</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000722</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828852</fme:EASTING>
<fme:NORTHING>823475</fme:NORTHING>
<fme:ENGLISHNAME>Hong Tai House</fme:ENGLISHNAME>
<fme:CHINESENAME>康泰樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823475.00000 828852.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id76d6680c-f284-4ee7-817a-dc0ffac0ff33">
<fme:FEATURE_ID>1210063453</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000723</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829052</fme:EASTING>
<fme:NORTHING>823476</fme:NORTHING>
<fme:ENGLISHNAME>26</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654339</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823476.00000 829052.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6d9b018f-fc2e-4551-97f1-81ac63bb48b4">
<fme:FEATURE_ID>1210063475</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000723</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829046</fme:EASTING>
<fme:NORTHING>823477</fme:NORTHING>
<fme:ENGLISHNAME>28</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654334</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823477.00000 829046.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddad00a2b-db1a-4bb6-8ccd-989720ed9688">
<fme:FEATURE_ID>1210001667</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000708</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829872</fme:EASTING>
<fme:NORTHING>823477</fme:NORTHING>
<fme:ENGLISHNAME>Drainage Services Department Kwai Chung Preliminary Treatment Works</fme:ENGLISHNAME>
<fme:CHINESENAME>渠務署葵涌基本污水處理廠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20231004</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823477.00000 829872.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6dfcb263-78f8-4205-bfe3-53eddd0f0c36">
<fme:FEATURE_ID>1210000803</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000707</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828274</fme:EASTING>
<fme:NORTHING>823479</fme:NORTHING>
<fme:ENGLISHNAME>Hong Mei House</fme:ENGLISHNAME>
<fme:CHINESENAME>康美樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823479.00000 828274.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6acb5c31-84d4-4deb-bda0-88d84b1aec4c">
<fme:FEATURE_ID>1210000881</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000719</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828131</fme:EASTING>
<fme:NORTHING>823486</fme:NORTHING>
<fme:ENGLISHNAME>Lok Sin Tong Leung Chik Wai Memorial School</fme:ENGLISHNAME>
<fme:CHINESENAME>樂善堂梁植偉紀念中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823486.00000 828131.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id19774213-ac42-4a0f-92ea-e72168e5b00d">
<fme:FEATURE_ID>1210006826</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000681</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829341</fme:EASTING>
<fme:NORTHING>823487</fme:NORTHING>
<fme:ENGLISHNAME>Vigor Industrial Building</fme:ENGLISHNAME>
<fme:CHINESENAME>偉力工業大廈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823487.00000 829341.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbbda9bf1-ce61-4b82-95c3-349ae0623206">
<fme:FEATURE_ID>1210065123</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000681</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829341</fme:EASTING>
<fme:NORTHING>823487</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654531</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823487.00000 829341.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id27778f7f-4fb1-4f4b-935d-494dfb991ad7">
<fme:FEATURE_ID>1210064009</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000717</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829064</fme:EASTING>
<fme:NORTHING>823490</fme:NORTHING>
<fme:ENGLISHNAME>155</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654349</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823490.00000 829064.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfb0b9732-69ea-4140-a495-8de72fc5d5f2">
<fme:FEATURE_ID>1210007448</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000716</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828689</fme:EASTING>
<fme:NORTHING>823491</fme:NORTHING>
<fme:ENGLISHNAME>Hong Shing House</fme:ENGLISHNAME>
<fme:CHINESENAME>康盛樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823491.00000 828689.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4ca0693f-50af-41d0-91a0-d41928d22278">
<fme:FEATURE_ID>1210064004</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000717</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829071</fme:EASTING>
<fme:NORTHING>823493</fme:NORTHING>
<fme:ENGLISHNAME>156</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654355</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823493.00000 829071.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd7703fcc-2e72-4461-9276-0a9958e895d4">
<fme:FEATURE_ID>1210063997</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000717</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829052</fme:EASTING>
<fme:NORTHING>823494</fme:NORTHING>
<fme:ENGLISHNAME>153</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654340</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823494.00000 829052.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf10af334-6705-4403-8758-b2a57374875c">
<fme:FEATURE_ID>1210000583</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000711</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828214</fme:EASTING>
<fme:NORTHING>823497</fme:NORTHING>
<fme:ENGLISHNAME>Po Leung Kuk Chan Yat Primary School</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局陳溢小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75568</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823497.00000 828214.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc1f4bd85-82c4-4e87-bf55-a38c57a34817">
<fme:FEATURE_ID>1210063483</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000717</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829059</fme:EASTING>
<fme:NORTHING>823497</fme:NORTHING>
<fme:ENGLISHNAME>154</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654345</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823497.00000 829059.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id69603919-1612-4e55-a6cc-50cef081b5a8">
<fme:FEATURE_ID>1210063446</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000706</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829068</fme:EASTING>
<fme:NORTHING>823505</fme:NORTHING>
<fme:ENGLISHNAME>151</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654351</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823505.00000 829068.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2eda9f16-007d-48b1-ae73-cb9ed5c1e0d9">
<fme:FEATURE_ID>1210063987</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000705</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829026</fme:EASTING>
<fme:NORTHING>823507</fme:NORTHING>
<fme:ENGLISHNAME>30</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654325</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823507.00000 829026.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id448fdb36-8cee-4763-bc9b-af29176f78d4">
<fme:FEATURE_ID>1210180997</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000705</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829026</fme:EASTING>
<fme:NORTHING>823507</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Ambulance Depot</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣救護站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>73970</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823507.00000 829026.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide42d6b74-c332-4329-a673-614378deb7e6">
<fme:FEATURE_ID>1210063985</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000706</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829075</fme:EASTING>
<fme:NORTHING>823509</fme:NORTHING>
<fme:ENGLISHNAME>152</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654360</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823509.00000 829075.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8143db03-cc79-482c-ae58-3421fce56933">
<fme:FEATURE_ID>1210063474</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000706</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829057</fme:EASTING>
<fme:NORTHING>823510</fme:NORTHING>
<fme:ENGLISHNAME>149</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654342</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823510.00000 829057.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3bb01eb5-dec8-4e9d-8d38-8ccbe16853e4">
<fme:FEATURE_ID>1210063484</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000706</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829064</fme:EASTING>
<fme:NORTHING>823512</fme:NORTHING>
<fme:ENGLISHNAME>150</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654350</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823512.00000 829064.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida0b50e47-46b8-42d2-8ba3-bf59099227d2">
<fme:FEATURE_ID>1210065698</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000704</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829473</fme:EASTING>
<fme:NORTHING>823513</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654601</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823513.00000 829473.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1b1ce291-596b-4076-90c7-d8b7b026b06f">
<fme:FEATURE_ID>1210000786</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000704</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829473</fme:EASTING>
<fme:NORTHING>823513</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Fireboat Fire Station</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣滅火輪消防局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823513.00000 829473.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id64e45e06-9a53-4c24-a3f4-c64a73a08015">
<fme:FEATURE_ID>1210063436</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000703</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828988</fme:EASTING>
<fme:NORTHING>823517</fme:NORTHING>
<fme:ENGLISHNAME>137</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654292</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823517.00000 828988.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id38cc75cb-a4f3-4973-b37e-e46d3c24adcb">
<fme:FEATURE_ID>1210062939</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000703</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828982</fme:EASTING>
<fme:NORTHING>823519</fme:NORTHING>
<fme:ENGLISHNAME>138</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654286</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823519.00000 828982.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0d7f0464-a6a9-4ef6-aef2-fb804dafa39a">
<fme:FEATURE_ID>1210062926</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000703</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828976</fme:EASTING>
<fme:NORTHING>823520</fme:NORTHING>
<fme:ENGLISHNAME>139</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654277</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823520.00000 828976.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5baa57f2-8ccf-4c98-89dc-71b44e958788">
<fme:FEATURE_ID>1210063995</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000701</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829073</fme:EASTING>
<fme:NORTHING>823520</fme:NORTHING>
<fme:ENGLISHNAME>147</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654358</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823520.00000 829073.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1f9c0454-a2a2-4939-b36f-e633d0603b30">
<fme:FEATURE_ID>1210062914</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000703</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828970</fme:EASTING>
<fme:NORTHING>823522</fme:NORTHING>
<fme:ENGLISHNAME>140</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654267</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823522.00000 828970.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id34e6f462-a13e-44ca-af65-9d0b91070629">
<fme:FEATURE_ID>1210064000</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000701</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829080</fme:EASTING>
<fme:NORTHING>823523</fme:NORTHING>
<fme:ENGLISHNAME>148</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654363</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823523.00000 829080.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6e2dc039-1ac3-458e-9790-916195b86c8c">
<fme:FEATURE_ID>1210009228</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000702</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829465</fme:EASTING>
<fme:NORTHING>823523</fme:NORTHING>
<fme:ENGLISHNAME>Cheung Fai Road Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>長輝路公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823523.00000 829465.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc6b7cc27-0ef5-43bb-ae4e-8c244b924fcc">
<fme:FEATURE_ID>1210063982</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000701</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829068</fme:EASTING>
<fme:NORTHING>823525</fme:NORTHING>
<fme:ENGLISHNAME>146</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654352</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823525.00000 829068.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idac1ad2d9-4715-486c-b52b-16a793d3ae78">
<fme:FEATURE_ID>1210063471</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000701</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829061</fme:EASTING>
<fme:NORTHING>823526</fme:NORTHING>
<fme:ENGLISHNAME>145</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654346</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823526.00000 829061.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ideac9aa50-1cc6-431a-afb8-5d19a002ce8a">
<fme:FEATURE_ID>1210062929</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000699</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828906</fme:EASTING>
<fme:NORTHING>823530</fme:NORTHING>
<fme:ENGLISHNAME>91</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654227</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823530.00000 828906.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id97c84c55-b718-4cfe-b975-d664aea9fa2b">
<fme:FEATURE_ID>1210062937</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000699</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828900</fme:EASTING>
<fme:NORTHING>823532</fme:NORTHING>
<fme:ENGLISHNAME>92</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654221</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823532.00000 828900.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb47a3ad6-5fda-47dd-92f4-1d2ed382a4f2">
<fme:FEATURE_ID>1210071223</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000698</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828992</fme:EASTING>
<fme:NORTHING>823532</fme:NORTHING>
<fme:ENGLISHNAME>131</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654295</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823532.00000 828992.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc1f169c7-8542-4478-becf-0e663a6b3e62">
<fme:FEATURE_ID>1210071214</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000698</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828985</fme:EASTING>
<fme:NORTHING>823533</fme:NORTHING>
<fme:ENGLISHNAME>132</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654288</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823533.00000 828985.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4011e116-4a3f-47de-bb4d-4fe33a1b72a0">
<fme:FEATURE_ID>1210062912</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000699</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828894</fme:EASTING>
<fme:NORTHING>823534</fme:NORTHING>
<fme:ENGLISHNAME>93</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654215</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823534.00000 828894.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idba07c9d0-816d-4edf-9d43-a58fa897ab84">
<fme:FEATURE_ID>1210062919</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000699</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828888</fme:EASTING>
<fme:NORTHING>823535</fme:NORTHING>
<fme:ENGLISHNAME>94</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654210</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823535.00000 828888.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfd68fed3-f249-4685-a6b6-cbd255e46730">
<fme:FEATURE_ID>1210063437</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000698</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828980</fme:EASTING>
<fme:NORTHING>823535</fme:NORTHING>
<fme:ENGLISHNAME>133</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654281</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823535.00000 828980.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide452488f-d24f-42a5-a717-a59cde7196c5">
<fme:FEATURE_ID>1210063981</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000696</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829054</fme:EASTING>
<fme:NORTHING>823536</fme:NORTHING>
<fme:ENGLISHNAME>144</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654341</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823536.00000 829054.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id00637ed2-d6c5-4494-ac6f-218ce8e11183">
<fme:FEATURE_ID>1210063443</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000698</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828974</fme:EASTING>
<fme:NORTHING>823537</fme:NORTHING>
<fme:ENGLISHNAME>134</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654273</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823537.00000 828974.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide2d347a9-9d49-417d-ac6f-c84942852a6c">
<fme:FEATURE_ID>1210071224</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000697</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828877</fme:EASTING>
<fme:NORTHING>823538</fme:NORTHING>
<fme:ENGLISHNAME>95</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654200</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823538.00000 828877.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5f3c72ae-abbd-4bbf-87b8-500a4751856f">
<fme:FEATURE_ID>1210062913</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000698</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828968</fme:EASTING>
<fme:NORTHING>823538</fme:NORTHING>
<fme:ENGLISHNAME>135</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654264</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823538.00000 828968.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4d625a78-8902-4229-ae03-bc767b84fe3c">
<fme:FEATURE_ID>1210063993</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000696</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829049</fme:EASTING>
<fme:NORTHING>823538</fme:NORTHING>
<fme:ENGLISHNAME>143</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654336</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823538.00000 829049.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id891d47a4-2a5d-4081-a5d0-f58a1c8972aa">
<fme:FEATURE_ID>1210071186</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000697</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828872</fme:EASTING>
<fme:NORTHING>823539</fme:NORTHING>
<fme:ENGLISHNAME>96</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654193</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823539.00000 828872.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0f859d33-fb4e-4207-a896-2cc594b44053">
<fme:FEATURE_ID>1210071221</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000698</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828962</fme:EASTING>
<fme:NORTHING>823540</fme:NORTHING>
<fme:ENGLISHNAME>136</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654259</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823540.00000 828962.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idda9ad358-5a89-48f4-b829-d032e0611016">
<fme:FEATURE_ID>1210071195</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000697</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828866</fme:EASTING>
<fme:NORTHING>823541</fme:NORTHING>
<fme:ENGLISHNAME>97</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654186</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823541.00000 828866.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idef3dc87a-76df-4b62-8e37-26b77bfebf97">
<fme:FEATURE_ID>1210064002</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000696</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829044</fme:EASTING>
<fme:NORTHING>823541</fme:NORTHING>
<fme:ENGLISHNAME>142</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654333</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823541.00000 829044.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1a29d7cf-a7a5-4c20-b2e1-e1ad13794141">
<fme:FEATURE_ID>1210070668</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000697</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828860</fme:EASTING>
<fme:NORTHING>823543</fme:NORTHING>
<fme:ENGLISHNAME>98</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654180</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823543.00000 828860.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idacbc4cd4-426e-485a-986d-5df44b65474a">
<fme:FEATURE_ID>1210063461</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000696</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829037</fme:EASTING>
<fme:NORTHING>823543</fme:NORTHING>
<fme:ENGLISHNAME>141</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654330</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823543.00000 829037.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ided8bd657-88e4-48a9-929c-fd0ab87fd924">
<fme:FEATURE_ID>1210064542</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000690</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829170</fme:EASTING>
<fme:NORTHING>823544</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654407</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823544.00000 829170.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd486b5dd-92b0-4f60-a136-ca02bd8b41aa">
<fme:FEATURE_ID>1210000547</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000690</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829170</fme:EASTING>
<fme:NORTHING>823544</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Fire Station</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣消防局</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823544.00000 829170.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9b51759d-b935-4cef-8de5-d7d155498702">
<fme:FEATURE_ID>1210062928</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000693</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828995</fme:EASTING>
<fme:NORTHING>823546</fme:NORTHING>
<fme:ENGLISHNAME>125</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654297</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823546.00000 828995.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3a86c624-f18f-4c7d-8dae-a7fd5f2301fc">
<fme:FEATURE_ID>1210071180</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000695</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828846</fme:EASTING>
<fme:NORTHING>823548</fme:NORTHING>
<fme:ENGLISHNAME>99</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654168</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823548.00000 828846.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5ccf10c4-dab5-40e7-a95b-81354af125bc">
<fme:FEATURE_ID>1210000711</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000695</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828846</fme:EASTING>
<fme:NORTHING>823548</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823548.00000 828846.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf82cf4f7-54a8-478c-a25c-edcd452df901">
<fme:FEATURE_ID>1210062932</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000693</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828989</fme:EASTING>
<fme:NORTHING>823548</fme:NORTHING>
<fme:ENGLISHNAME>126</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654294</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823548.00000 828989.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idade5f050-bc40-441e-8c53-9ac6bed64b7f">
<fme:FEATURE_ID>1210068466</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000692</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828817</fme:EASTING>
<fme:NORTHING>823550</fme:NORTHING>
<fme:ENGLISHNAME>102</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653822</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823550.00000 828817.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6839eb90-3fcb-4316-8947-dec845dc6fbe">
<fme:FEATURE_ID>1210068420</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000692</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828824</fme:EASTING>
<fme:NORTHING>823550</fme:NORTHING>
<fme:ENGLISHNAME>101</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653830</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823550.00000 828824.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idca778f41-2626-49c7-9f8e-8147fcf5a1a6">
<fme:FEATURE_ID>1210068456</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000694</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828838</fme:EASTING>
<fme:NORTHING>823550</fme:NORTHING>
<fme:ENGLISHNAME>100</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653846</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823550.00000 828838.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3ff866cf-1ad7-4070-b80d-36d83b2d3e93">
<fme:FEATURE_ID>1210000727</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000694</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828838</fme:EASTING>
<fme:NORTHING>823550</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823550.00000 828838.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3ba44c2e-68d8-4276-a217-c6cc941c45cc">
<fme:FEATURE_ID>1210062911</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000693</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828983</fme:EASTING>
<fme:NORTHING>823550</fme:NORTHING>
<fme:ENGLISHNAME>127</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654287</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823550.00000 828983.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbcb18f7c-1de0-4e7d-9d3c-4a5f38032986">
<fme:FEATURE_ID>1210068435</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000692</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828806</fme:EASTING>
<fme:NORTHING>823551</fme:NORTHING>
<fme:ENGLISHNAME>104</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653811</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823551.00000 828806.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9e5df3e5-a74d-412b-b093-868ada160e71">
<fme:FEATURE_ID>1210068455</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000692</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828812</fme:EASTING>
<fme:NORTHING>823551</fme:NORTHING>
<fme:ENGLISHNAME>103</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653817</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823551.00000 828812.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide227d768-f6cd-4498-b7be-24d36d84bbde">
<fme:FEATURE_ID>1210067880</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000689</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828797</fme:EASTING>
<fme:NORTHING>823552</fme:NORTHING>
<fme:ENGLISHNAME>105</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653803</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823552.00000 828797.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4d386eea-4e6d-42cc-931e-b2a1cbb5b476">
<fme:FEATURE_ID>1210062930</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000688</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828975</fme:EASTING>
<fme:NORTHING>823552</fme:NORTHING>
<fme:ENGLISHNAME>128</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654275</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823552.00000 828975.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7cac3e40-e04a-4c8f-9525-d7ca8d6028bc">
<fme:FEATURE_ID>1210067296</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000689</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828785</fme:EASTING>
<fme:NORTHING>823553</fme:NORTHING>
<fme:ENGLISHNAME>107</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653790</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823553.00000 828785.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id82a5ddfe-163c-4fcd-9bd3-25af8274ec1e">
<fme:FEATURE_ID>1210067278</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000689</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828791</fme:EASTING>
<fme:NORTHING>823553</fme:NORTHING>
<fme:ENGLISHNAME>106</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653798</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823553.00000 828791.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6f8a0f5c-1123-46e8-922d-67b7be4bd7d7">
<fme:FEATURE_ID>1210071227</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000686</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828917</fme:EASTING>
<fme:NORTHING>823553</fme:NORTHING>
<fme:ENGLISHNAME>75</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654235</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823553.00000 828917.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf0aee9a1-6aef-4347-b608-1fa38316aa9b">
<fme:FEATURE_ID>1210062923</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000688</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828969</fme:EASTING>
<fme:NORTHING>823553</fme:NORTHING>
<fme:ENGLISHNAME>129</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654265</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823553.00000 828969.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id04c79801-a441-4e5c-8ebe-95e570e636fa">
<fme:FEATURE_ID>1210067875</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000689</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828778</fme:EASTING>
<fme:NORTHING>823554</fme:NORTHING>
<fme:ENGLISHNAME>108</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653785</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823554.00000 828778.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb0eabb46-e617-4f40-af9f-d7d1ff8a65a1">
<fme:FEATURE_ID>1210071230</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000686</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828911</fme:EASTING>
<fme:NORTHING>823555</fme:NORTHING>
<fme:ENGLISHNAME>76</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654232</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823555.00000 828911.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3195614c-dfa7-46f4-8955-0b83f04751b8">
<fme:FEATURE_ID>1210062915</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000688</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828963</fme:EASTING>
<fme:NORTHING>823555</fme:NORTHING>
<fme:ENGLISHNAME>130</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654260</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823555.00000 828963.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id238825ac-9595-47f8-9065-9d7ed93e4578">
<fme:FEATURE_ID>1210062907</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000686</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828905</fme:EASTING>
<fme:NORTHING>823557</fme:NORTHING>
<fme:ENGLISHNAME>77</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654225</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823557.00000 828905.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8c24f3c4-59f0-44fa-99c5-5ac9dc28a675">
<fme:FEATURE_ID>1210062898</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000686</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828899</fme:EASTING>
<fme:NORTHING>823558</fme:NORTHING>
<fme:ENGLISHNAME>78</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654219</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823558.00000 828899.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4582133a-79e5-426e-9316-9b6f5de670dd">
<fme:FEATURE_ID>1210180387</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000685</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828607</fme:EASTING>
<fme:NORTHING>823560</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Public School Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣公立學校變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823560.00000 828607.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id410ea097-5e70-4eae-b3a7-fc362b08c2e6">
<fme:FEATURE_ID>1210068437</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000677</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828394</fme:EASTING>
<fme:NORTHING>823561</fme:NORTHING>
<fme:ENGLISHNAME>58</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653877</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823561.00000 828394.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf4bbb029-b362-4c4f-9161-4f8106addf80">
<fme:FEATURE_ID>1210063440</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000684</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828889</fme:EASTING>
<fme:NORTHING>823561</fme:NORTHING>
<fme:ENGLISHNAME>79</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654211</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823561.00000 828889.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id13a1b2d8-7b5f-4216-b4ce-099d52728394">
<fme:FEATURE_ID>1210062888</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000684</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828884</fme:EASTING>
<fme:NORTHING>823562</fme:NORTHING>
<fme:ENGLISHNAME>80</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654206</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823562.00000 828884.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1d0ed5dc-1860-40aa-a3a5-eca9fc1804e4">
<fme:FEATURE_ID>1210062887</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000680</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828994</fme:EASTING>
<fme:NORTHING>823563</fme:NORTHING>
<fme:ENGLISHNAME>119</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654296</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823563.00000 828994.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id19701a57-3266-412e-a39d-b20e710a3acc">
<fme:FEATURE_ID>1210071225</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000684</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828878</fme:EASTING>
<fme:NORTHING>823564</fme:NORTHING>
<fme:ENGLISHNAME>81</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654201</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823564.00000 828878.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id98d7a477-84c9-44a7-9db6-db387c224dbe">
<fme:FEATURE_ID>1210062910</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000680</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828987</fme:EASTING>
<fme:NORTHING>823564</fme:NORTHING>
<fme:ENGLISHNAME>120</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654290</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823564.00000 828987.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id15c69157-5f64-48e4-965b-46791aa4d29b">
<fme:FEATURE_ID>1210068418</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000677</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828391</fme:EASTING>
<fme:NORTHING>823566</fme:NORTHING>
<fme:ENGLISHNAME>59</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653868</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823566.00000 828391.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaf7c1ece-9ce3-4eff-924c-02425f3c8378">
<fme:FEATURE_ID>1210180389</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000682</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828861</fme:EASTING>
<fme:NORTHING>823566</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>涌美上下村老屋村村公所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823566.00000 828861.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id52ec0eb2-c98d-4f8a-9d10-35085b8e2549">
<fme:FEATURE_ID>1210062658</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000682</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828861</fme:EASTING>
<fme:NORTHING>823566</fme:NORTHING>
<fme:ENGLISHNAME>82A</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810014736</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823566.00000 828861.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcfd932a2-4b43-43bd-a262-b2bb3922b144">
<fme:FEATURE_ID>1210071175</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000684</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828872</fme:EASTING>
<fme:NORTHING>823566</fme:NORTHING>
<fme:ENGLISHNAME>82</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654194</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823566.00000 828872.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id891e934d-e228-409c-8a4e-2926db1c3e55">
<fme:FEATURE_ID>1210063434</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000680</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828981</fme:EASTING>
<fme:NORTHING>823566</fme:NORTHING>
<fme:ENGLISHNAME>121</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654283</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823566.00000 828981.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id56a63e49-191c-4a43-aa54-15673b7356f6">
<fme:FEATURE_ID>1210071231</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000680</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828976</fme:EASTING>
<fme:NORTHING>823567</fme:NORTHING>
<fme:ENGLISHNAME>122</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654278</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823567.00000 828976.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7b17dd3f-7b1d-4deb-a7b5-aa3cbab97139">
<fme:FEATURE_ID>1210001044</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000667</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829312</fme:EASTING>
<fme:NORTHING>823568</fme:NORTHING>
<fme:ENGLISHNAME>Golden Resources Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>金源中心</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823568.00000 829312.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id67417f50-67ba-4e5f-9260-7fcf8eaa0770">
<fme:FEATURE_ID>1210065643</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000667</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829312</fme:EASTING>
<fme:NORTHING>823568</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654517</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10214</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823568.00000 829312.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3a11ec26-5741-47eb-9928-8dcf50f3b54b">
<fme:FEATURE_ID>1210062916</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000680</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828970</fme:EASTING>
<fme:NORTHING>823569</fme:NORTHING>
<fme:ENGLISHNAME>123</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654268</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823569.00000 828970.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd3a6f4b1-5896-446d-a171-484cdf4bf24b">
<fme:FEATURE_ID>1210071222</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000680</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828964</fme:EASTING>
<fme:NORTHING>823571</fme:NORTHING>
<fme:ENGLISHNAME>124</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654261</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823571.00000 828964.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id541fe809-543f-4e57-a190-7cd397051bff">
<fme:FEATURE_ID>1210067907</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000679</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828826</fme:EASTING>
<fme:NORTHING>823572</fme:NORTHING>
<fme:ENGLISHNAME>83</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653833</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823572.00000 828826.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7a282946-919c-4c0b-94ed-28ec8aca4acc">
<fme:FEATURE_ID>1210044719</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000674</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829277</fme:EASTING>
<fme:NORTHING>823572</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810022842</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10192</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823572.00000 829277.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf4b5b442-0821-429f-a445-302414a9a862">
<fme:FEATURE_ID>1210001048</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000674</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829277</fme:EASTING>
<fme:NORTHING>823572</fme:NORTHING>
<fme:ENGLISHNAME>Epoch Industrial Building</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823572.00000 829277.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5c3a0011-ef1e-4ac7-bfdd-59879a0df4e0">
<fme:FEATURE_ID>1210067900</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000677</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828390</fme:EASTING>
<fme:NORTHING>823573</fme:NORTHING>
<fme:ENGLISHNAME>60</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653867</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823573.00000 828390.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfa04f436-d90d-4388-ab7c-dcc40d50b600">
<fme:FEATURE_ID>1210068465</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000679</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828814</fme:EASTING>
<fme:NORTHING>823573</fme:NORTHING>
<fme:ENGLISHNAME>85</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653819</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823573.00000 828814.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id695fc928-95fe-410c-a2db-1710f8370c32">
<fme:FEATURE_ID>1210067888</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000679</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828820</fme:EASTING>
<fme:NORTHING>823573</fme:NORTHING>
<fme:ENGLISHNAME>84</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653826</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823573.00000 828820.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1b1cf655-eea0-4b63-8607-3e9f707caf58">
<fme:FEATURE_ID>1210068475</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000679</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828808</fme:EASTING>
<fme:NORTHING>823574</fme:NORTHING>
<fme:ENGLISHNAME>86</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653814</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823574.00000 828808.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf9c12f9b-ed1a-4092-a34d-ddc0604c422e">
<fme:FEATURE_ID>1210067876</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000678</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828792</fme:EASTING>
<fme:NORTHING>823575</fme:NORTHING>
<fme:ENGLISHNAME>88</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653800</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823575.00000 828792.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida8e0889b-60b7-41ba-8436-f7c204b2d806">
<fme:FEATURE_ID>1210067889</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000678</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828798</fme:EASTING>
<fme:NORTHING>823575</fme:NORTHING>
<fme:ENGLISHNAME>87</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653805</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823575.00000 828798.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3cb72d49-f557-4b4e-98ea-3e1e8c44b10f">
<fme:FEATURE_ID>1210067852</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000678</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828786</fme:EASTING>
<fme:NORTHING>823576</fme:NORTHING>
<fme:ENGLISHNAME>89</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653793</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823576.00000 828786.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2e50b786-5409-448f-ae54-8c1276b54436">
<fme:FEATURE_ID>1210068452</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000677</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828388</fme:EASTING>
<fme:NORTHING>823577</fme:NORTHING>
<fme:ENGLISHNAME>61</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653862</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823577.00000 828388.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id78e776fa-809a-422b-a9e1-ee4e1c8c738c">
<fme:FEATURE_ID>1210066769</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000678</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828780</fme:EASTING>
<fme:NORTHING>823577</fme:NORTHING>
<fme:ENGLISHNAME>90</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653786</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823577.00000 828780.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id121410ac-2f18-4b34-95de-4eb38e86b1e9">
<fme:FEATURE_ID>1210068966</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000661</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828406</fme:EASTING>
<fme:NORTHING>823582</fme:NORTHING>
<fme:ENGLISHNAME>45</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653907</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823582.00000 828406.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida2674392-5229-48d1-a68a-7795fd5c5e6f">
<fme:FEATURE_ID>1210168899</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000639</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829405</fme:EASTING>
<fme:NORTHING>823583</fme:NORTHING>
<fme:ENGLISHNAME>Gateway TS</fme:ENGLISHNAME>
<fme:CHINESENAME>橋滙</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>72133</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823583.00000 829405.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida35e3e82-5280-41df-be38-572358561be4">
<fme:FEATURE_ID>1210168903</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000639</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829405</fme:EASTING>
<fme:NORTHING>823583</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810031667</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10187</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823583.00000 829405.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idadfcb68c-e011-42de-9e37-6c161dcc367d">
<fme:FEATURE_ID>1210062893</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000673</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828885</fme:EASTING>
<fme:NORTHING>823584</fme:NORTHING>
<fme:ENGLISHNAME>59</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654207</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823584.00000 828885.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf41f7974-4146-42a7-aa5a-848b1211748d">
<fme:FEATURE_ID>1210062904</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000673</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828879</fme:EASTING>
<fme:NORTHING>823585</fme:NORTHING>
<fme:ENGLISHNAME>60</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654202</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823585.00000 828879.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id07a930f2-cc61-4254-87c4-5fa5f8ff9a5f">
<fme:FEATURE_ID>1210000617</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000658</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829212</fme:EASTING>
<fme:NORTHING>823585</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 1</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第一座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823585.00000 829212.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id63d4553d-617a-4870-8768-01881258c529">
<fme:FEATURE_ID>1210070691</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000673</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828873</fme:EASTING>
<fme:NORTHING>823586</fme:NORTHING>
<fme:ENGLISHNAME>61</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654195</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823586.00000 828873.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id31434248-52ac-49d0-bf51-e0da713f6ec0">
<fme:FEATURE_ID>1210070643</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000673</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828867</fme:EASTING>
<fme:NORTHING>823587</fme:NORTHING>
<fme:ENGLISHNAME>62</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654188</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823587.00000 828867.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd94ea243-d280-4293-a04e-31050f46ba7f">
<fme:FEATURE_ID>1210068453</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000670</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828383</fme:EASTING>
<fme:NORTHING>823588</fme:NORTHING>
<fme:ENGLISHNAME>62</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653849</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823588.00000 828383.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idce47268c-842d-4437-a4e1-506c61341084">
<fme:FEATURE_ID>1210068448</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000661</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828403</fme:EASTING>
<fme:NORTHING>823588</fme:NORTHING>
<fme:ENGLISHNAME>46</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653897</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823588.00000 828403.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6d760a81-9919-4f15-a3fc-f88f2af6eed5">
<fme:FEATURE_ID>1210000905</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000662</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829142</fme:EASTING>
<fme:NORTHING>823588</fme:NORTHING>
<fme:ENGLISHNAME>Kwai Tsing Police District Headquarters and Tsing Yi Police Station</fme:ENGLISHNAME>
<fme:CHINESENAME>葵青警區總部暨青衣分區警署</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823588.00000 829142.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id487bf124-1e65-4b0a-9dbb-7716285769b2">
<fme:FEATURE_ID>1210063467</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000662</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829142</fme:EASTING>
<fme:NORTHING>823588</fme:NORTHING>
<fme:ENGLISHNAME>13</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654395</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823588.00000 829142.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id46bc4259-5d6e-4a7d-bb4f-a4e029f559a7">
<fme:FEATURE_ID>1210070655</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000672</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828857</fme:EASTING>
<fme:NORTHING>823589</fme:NORTHING>
<fme:ENGLISHNAME>63</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654177</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823589.00000 828857.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id99c5f6df-d29f-4513-bee3-de5f61357eba">
<fme:FEATURE_ID>1210063432</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000669</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828985</fme:EASTING>
<fme:NORTHING>823589</fme:NORTHING>
<fme:ENGLISHNAME>115</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654289</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823589.00000 828985.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id699edfee-e5fe-4023-996f-88f20b0a9335">
<fme:FEATURE_ID>1210071179</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000672</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828851</fme:EASTING>
<fme:NORTHING>823590</fme:NORTHING>
<fme:ENGLISHNAME>64</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654174</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823590.00000 828851.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id22fe3718-fd3a-4a82-8523-44c37ff02e52">
<fme:FEATURE_ID>1210070692</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000672</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828845</fme:EASTING>
<fme:NORTHING>823591</fme:NORTHING>
<fme:ENGLISHNAME>65</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654167</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823591.00000 828845.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc2538f95-ccb0-4187-b89c-e8da9c6edbf6">
<fme:FEATURE_ID>1210071218</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000669</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828979</fme:EASTING>
<fme:NORTHING>823591</fme:NORTHING>
<fme:ENGLISHNAME>116</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654279</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823591.00000 828979.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idad58a7ca-9a6d-4b8f-810d-7a8aaab47105">
<fme:FEATURE_ID>1210064005</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000657</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829070</fme:EASTING>
<fme:NORTHING>823591</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654354</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823591.00000 829070.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id69e2ef78-17c0-4f15-ab3a-affbbf453f27">
<fme:FEATURE_ID>1210000644</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000657</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829070</fme:EASTING>
<fme:NORTHING>823591</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Police Married Quarters Block B</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣已婚警察宿舍Ｂ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>78351</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823591.00000 829070.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4b900bc4-c50c-47fa-8b8e-839b284936fc">
<fme:FEATURE_ID>1210068457</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000661</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828399</fme:EASTING>
<fme:NORTHING>823592</fme:NORTHING>
<fme:ENGLISHNAME>47</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653884</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823592.00000 828399.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcf2db4a2-5760-4a8a-9055-9627019b7769">
<fme:FEATURE_ID>1210068449</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000672</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828839</fme:EASTING>
<fme:NORTHING>823592</fme:NORTHING>
<fme:ENGLISHNAME>66</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653847</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823592.00000 828839.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7b4fd4d6-8798-413e-b548-879217d75682">
<fme:FEATURE_ID>1210062934</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000669</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828973</fme:EASTING>
<fme:NORTHING>823592</fme:NORTHING>
<fme:ENGLISHNAME>117</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654271</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823592.00000 828973.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddf8826a2-f671-4104-b169-f656988319c4">
<fme:FEATURE_ID>1210067856</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000670</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828380</fme:EASTING>
<fme:NORTHING>823593</fme:NORTHING>
<fme:ENGLISHNAME>63</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653717</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823593.00000 828380.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddb780400-faf1-4ce8-9ef1-6138fb16689f">
<fme:FEATURE_ID>1210068467</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000668</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828829</fme:EASTING>
<fme:NORTHING>823593</fme:NORTHING>
<fme:ENGLISHNAME>67</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653839</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823593.00000 828829.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idecc9b46d-f3cf-4924-9029-f0ef4367e83b">
<fme:FEATURE_ID>1210068422</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000668</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828822</fme:EASTING>
<fme:NORTHING>823594</fme:NORTHING>
<fme:ENGLISHNAME>68</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653828</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823594.00000 828822.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id95a368a8-3179-49b5-ac7a-bf74a5ee3f52">
<fme:FEATURE_ID>1210071220</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000669</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828967</fme:EASTING>
<fme:NORTHING>823594</fme:NORTHING>
<fme:ENGLISHNAME>118</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654263</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823594.00000 828967.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide45cd7f4-d6a0-4248-87b3-de9d1021fe23">
<fme:FEATURE_ID>1210068971</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000653</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828422</fme:EASTING>
<fme:NORTHING>823595</fme:NORTHING>
<fme:ENGLISHNAME>33</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653961</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823595.00000 828422.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id296b65e8-5b66-4aec-8c29-3b8c0f309890">
<fme:FEATURE_ID>1210183539</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210059986</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828565</fme:EASTING>
<fme:NORTHING>823595</fme:NORTHING>
<fme:ENGLISHNAME>70</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810053811</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10296</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823595.00000 828565.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id545bc649-fd55-449b-80fb-25eee6e8ad39">
<fme:FEATURE_ID>1210068470</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000665</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828799</fme:EASTING>
<fme:NORTHING>823595</fme:NORTHING>
<fme:ENGLISHNAME>71</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653806</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823595.00000 828799.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfcfe6aee-5188-4eeb-b5e8-abe262bf6b19">
<fme:FEATURE_ID>1210068424</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000668</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828810</fme:EASTING>
<fme:NORTHING>823595</fme:NORTHING>
<fme:ENGLISHNAME>70</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653816</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823595.00000 828810.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id313e7fe0-9448-4984-8343-0156639d79ff">
<fme:FEATURE_ID>1210068426</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000668</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828816</fme:EASTING>
<fme:NORTHING>823595</fme:NORTHING>
<fme:ENGLISHNAME>69</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653821</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823595.00000 828816.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id220ed18b-f801-4ec4-87b0-7572675db7c9">
<fme:FEATURE_ID>1210067871</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000665</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828787</fme:EASTING>
<fme:NORTHING>823596</fme:NORTHING>
<fme:ENGLISHNAME>73</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653794</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823596.00000 828787.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb8704c65-4901-4d86-94d0-b83081888c70">
<fme:FEATURE_ID>1210067893</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000665</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828793</fme:EASTING>
<fme:NORTHING>823596</fme:NORTHING>
<fme:ENGLISHNAME>72</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653801</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823596.00000 828793.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id84ce1edb-f64d-47f3-bcdf-1cacd69ac21e">
<fme:FEATURE_ID>1210062938</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000660</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828929</fme:EASTING>
<fme:NORTHING>823596</fme:NORTHING>
<fme:ENGLISHNAME>37</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654242</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823596.00000 828929.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id278beb2c-e456-4f30-80e3-59fcd74c7616">
<fme:FEATURE_ID>1210068439</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000661</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828397</fme:EASTING>
<fme:NORTHING>823597</fme:NORTHING>
<fme:ENGLISHNAME>48</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653880</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823597.00000 828397.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9397e2d0-d631-4851-8432-d06e3f085e7f">
<fme:FEATURE_ID>1210067268</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000665</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828782</fme:EASTING>
<fme:NORTHING>823597</fme:NORTHING>
<fme:ENGLISHNAME>74</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653788</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823597.00000 828782.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8bc9af96-a582-468f-bdd6-5725ba536b34">
<fme:FEATURE_ID>1210071226</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000660</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828922</fme:EASTING>
<fme:NORTHING>823597</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654239</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823597.00000 828922.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id08b4871b-512c-4904-a333-ac753be804cf">
<fme:FEATURE_ID>1210071228</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000660</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828917</fme:EASTING>
<fme:NORTHING>823599</fme:NORTHING>
<fme:ENGLISHNAME>39</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654236</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823599.00000 828917.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd988bf38-440a-46b3-b92e-1d31b599638e">
<fme:FEATURE_ID>1210068984</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000653</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828419</fme:EASTING>
<fme:NORTHING>823600</fme:NORTHING>
<fme:ENGLISHNAME>34</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653949</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823600.00000 828419.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1a4a19d5-c68f-40d6-8c17-bcbc861be861">
<fme:FEATURE_ID>1210067291</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000650</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828374</fme:EASTING>
<fme:NORTHING>823601</fme:NORTHING>
<fme:ENGLISHNAME>64</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653710</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823601.00000 828374.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id73dc5b66-9d0e-4ace-ad1c-2c61589a2647">
<fme:FEATURE_ID>1210062944</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000660</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828910</fme:EASTING>
<fme:NORTHING>823601</fme:NORTHING>
<fme:ENGLISHNAME>40</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654231</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823601.00000 828910.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id89ac6cf1-7d39-4234-b9f9-655622deda7f">
<fme:FEATURE_ID>1210062900</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000656</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828902</fme:EASTING>
<fme:NORTHING>823603</fme:NORTHING>
<fme:ENGLISHNAME>41</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654223</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823603.00000 828902.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbae09552-261a-4c10-86e1-6970371453f4">
<fme:FEATURE_ID>1210071229</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000656</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828895</fme:EASTING>
<fme:NORTHING>823604</fme:NORTHING>
<fme:ENGLISHNAME>42</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654216</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823604.00000 828895.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfbefbf3d-634a-4dfc-b39f-7c241e55bb1d">
<fme:FEATURE_ID>1210068978</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000653</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828415</fme:EASTING>
<fme:NORTHING>823605</fme:NORTHING>
<fme:ENGLISHNAME>35</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653935</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823605.00000 828415.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc8f639d7-c331-47ef-af27-ecffacee39a6">
<fme:FEATURE_ID>1210062942</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000655</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828987</fme:EASTING>
<fme:NORTHING>823605</fme:NORTHING>
<fme:ENGLISHNAME>111</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654291</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823605.00000 828987.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfa0854fd-8c4d-4c8b-85d1-bfe0e43805b9">
<fme:FEATURE_ID>1210067317</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000650</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828371</fme:EASTING>
<fme:NORTHING>823606</fme:NORTHING>
<fme:ENGLISHNAME>65</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653708</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823606.00000 828371.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc67e4d0d-fea0-48bf-a3c1-c215cdf30e44">
<fme:FEATURE_ID>1210062920</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000656</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828890</fme:EASTING>
<fme:NORTHING>823606</fme:NORTHING>
<fme:ENGLISHNAME>43</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654212</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823606.00000 828890.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide6c172e2-8127-4024-906c-76b9aa67cab4">
<fme:FEATURE_ID>1210062943</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000655</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828980</fme:EASTING>
<fme:NORTHING>823606</fme:NORTHING>
<fme:ENGLISHNAME>112</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654282</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823606.00000 828980.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id332b790c-1769-4588-a5f1-d0abdcbe7c03">
<fme:FEATURE_ID>1210062941</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000656</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828883</fme:EASTING>
<fme:NORTHING>823607</fme:NORTHING>
<fme:ENGLISHNAME>44</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654205</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823607.00000 828883.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id98b1c84b-ce8c-4fc4-99de-3492d6f3651c">
<fme:FEATURE_ID>1210063444</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000655</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828974</fme:EASTING>
<fme:NORTHING>823608</fme:NORTHING>
<fme:ENGLISHNAME>113</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654274</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823608.00000 828974.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id565f36c9-34e5-4467-8f41-856dbd314ce2">
<fme:FEATURE_ID>1210001816</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000640</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829195</fme:EASTING>
<fme:NORTHING>823608</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 2</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第二座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823608.00000 829195.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf6c1869b-5998-4aa2-bf69-a4d4f8aadf18">
<fme:FEATURE_ID>1210067891</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000643</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828391</fme:EASTING>
<fme:NORTHING>823609</fme:NORTHING>
<fme:ENGLISHNAME>49</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653869</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823609.00000 828391.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4a398ea0-3cda-48e8-a3df-6cfd2a0da2f7">
<fme:FEATURE_ID>1210071211</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000652</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828875</fme:EASTING>
<fme:NORTHING>823609</fme:NORTHING>
<fme:ENGLISHNAME>45</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654196</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823609.00000 828875.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaaabfc81-c5ab-4ecd-9d94-2fbcee4363f5">
<fme:FEATURE_ID>1210062908</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000655</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828969</fme:EASTING>
<fme:NORTHING>823609</fme:NORTHING>
<fme:ENGLISHNAME>114</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654266</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823609.00000 828969.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idba716d9c-112b-4864-9fac-e3542dbe4bf3">
<fme:FEATURE_ID>1210068993</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000653</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828412</fme:EASTING>
<fme:NORTHING>823610</fme:NORTHING>
<fme:ENGLISHNAME>36</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653926</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823610.00000 828412.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id59c043e7-fb47-4867-94f8-24bf558664bc">
<fme:FEATURE_ID>1210069550</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000642</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828433</fme:EASTING>
<fme:NORTHING>823610</fme:NORTHING>
<fme:ENGLISHNAME>21</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653992</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823610.00000 828433.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id834e9c3e-2a8e-4887-822b-b68d19cb9a37">
<fme:FEATURE_ID>1210067305</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000650</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828367</fme:EASTING>
<fme:NORTHING>823611</fme:NORTHING>
<fme:ENGLISHNAME>66</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653704</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823611.00000 828367.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4ec287ec-8c80-4bf0-9f44-15e0157baa4c">
<fme:FEATURE_ID>1210070681</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000652</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828868</fme:EASTING>
<fme:NORTHING>823611</fme:NORTHING>
<fme:ENGLISHNAME>46</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654189</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823611.00000 828868.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbace3547-c5f4-47f5-99d7-a8ef19607d58">
<fme:FEATURE_ID>1210191873</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000643</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828385</fme:EASTING>
<fme:NORTHING>823612</fme:NORTHING>
<fme:ENGLISHNAME>50</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810064226</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823612.00000 828385.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc6902305-a04e-4689-b95d-d03130d83b86">
<fme:FEATURE_ID>1210071188</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000652</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828862</fme:EASTING>
<fme:NORTHING>823612</fme:NORTHING>
<fme:ENGLISHNAME>47</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654181</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823612.00000 828862.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5acf18dd-9966-4a4c-9273-28bca0271bf5">
<fme:FEATURE_ID>1210071206</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000652</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828856</fme:EASTING>
<fme:NORTHING>823613</fme:NORTHING>
<fme:ENGLISHNAME>48</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654176</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823613.00000 828856.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbb2876fe-2b8e-46bd-afdd-e74b2c385be5">
<fme:FEATURE_ID>1210070663</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000648</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828847</fme:EASTING>
<fme:NORTHING>823614</fme:NORTHING>
<fme:ENGLISHNAME>49</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654169</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823614.00000 828847.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide827f72a-0acf-4ec9-bb9a-5cce6e8ec751">
<fme:FEATURE_ID>1210068977</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000642</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828430</fme:EASTING>
<fme:NORTHING>823615</fme:NORTHING>
<fme:ENGLISHNAME>22</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653987</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823615.00000 828430.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd9702195-bfec-4f98-89a9-08c1684133d9">
<fme:FEATURE_ID>1210068472</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000648</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828840</fme:EASTING>
<fme:NORTHING>823615</fme:NORTHING>
<fme:ENGLISHNAME>50</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653848</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823615.00000 828840.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id65fb49fd-686d-4c74-bc78-5420576e7ccc">
<fme:FEATURE_ID>1210197006</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000649</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829020</fme:EASTING>
<fme:NORTHING>823615</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810071638</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823615.00000 829020.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8a2df729-839c-4d68-a776-e0ae9b6dfe57">
<fme:FEATURE_ID>1210067298</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000650</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828363</fme:EASTING>
<fme:NORTHING>823616</fme:NORTHING>
<fme:ENGLISHNAME>67</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653701</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823616.00000 828363.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id63df4740-a17c-41db-902a-8aaefb2d76bf">
<fme:FEATURE_ID>1210067904</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000648</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828834</fme:EASTING>
<fme:NORTHING>823616</fme:NORTHING>
<fme:ENGLISHNAME>51</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653841</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823616.00000 828834.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6d68471f-6e33-45ad-b41c-9c0ee3d77caa">
<fme:FEATURE_ID>1210067902</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000648</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828828</fme:EASTING>
<fme:NORTHING>823617</fme:NORTHING>
<fme:ENGLISHNAME>52</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653837</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823617.00000 828828.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6c2364e0-c736-4751-a22a-c27774e2c763">
<fme:FEATURE_ID>1210067884</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000647</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828819</fme:EASTING>
<fme:NORTHING>823618</fme:NORTHING>
<fme:ENGLISHNAME>53</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653824</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823618.00000 828819.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id62c48b72-cdb4-49ae-8cb3-b2d8b26c9b61">
<fme:FEATURE_ID>1210063442</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000645</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828936</fme:EASTING>
<fme:NORTHING>823618</fme:NORTHING>
<fme:ENGLISHNAME>17</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654247</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823618.00000 828936.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0e90c6e4-533b-4b0e-ac3b-ff30a066ce24">
<fme:FEATURE_ID>1210068459</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000643</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828384</fme:EASTING>
<fme:NORTHING>823619</fme:NORTHING>
<fme:ENGLISHNAME>51</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653855</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823619.00000 828384.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id53e915af-cec3-4542-8324-6e02f70441d6">
<fme:FEATURE_ID>1210067887</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000647</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828813</fme:EASTING>
<fme:NORTHING>823619</fme:NORTHING>
<fme:ENGLISHNAME>54</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653818</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823619.00000 828813.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide76508ac-8042-4611-9100-6bb900d68ea5">
<fme:FEATURE_ID>1210062889</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000645</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828930</fme:EASTING>
<fme:NORTHING>823619</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654243</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823619.00000 828930.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7ffc0235-8bf9-44c3-9772-b34814e6ac5c">
<fme:FEATURE_ID>1210069008</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000642</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828426</fme:EASTING>
<fme:NORTHING>823620</fme:NORTHING>
<fme:ENGLISHNAME>23</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653974</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823620.00000 828426.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida60e0202-2375-45e6-8d26-f625891b3bbb">
<fme:FEATURE_ID>1210067897</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000646</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828791</fme:EASTING>
<fme:NORTHING>823620</fme:NORTHING>
<fme:ENGLISHNAME>57</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653799</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823620.00000 828791.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6d3d4d34-12b1-4d04-a6ff-c0857b6ba3ca">
<fme:FEATURE_ID>1210068417</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000647</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828807</fme:EASTING>
<fme:NORTHING>823620</fme:NORTHING>
<fme:ENGLISHNAME>55</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653812</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823620.00000 828807.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0cdf56eb-db00-4e63-941f-042a61dd021d">
<fme:FEATURE_ID>1210067310</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000646</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828785</fme:EASTING>
<fme:NORTHING>823621</fme:NORTHING>
<fme:ENGLISHNAME>58</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653791</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823621.00000 828785.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9d72ca26-2336-4f30-ac66-18a8ed0f6120">
<fme:FEATURE_ID>1210068421</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000647</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828801</fme:EASTING>
<fme:NORTHING>823621</fme:NORTHING>
<fme:ENGLISHNAME>56</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653808</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823621.00000 828801.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6646fc5f-349f-4a1e-98a5-d1052144aa43">
<fme:FEATURE_ID>1210062895</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000645</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828925</fme:EASTING>
<fme:NORTHING>823621</fme:NORTHING>
<fme:ENGLISHNAME>19</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654240</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823621.00000 828925.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id54ac9013-e0ea-4429-a1ab-b8dc526b67bf">
<fme:FEATURE_ID>1210067905</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000634</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828403</fme:EASTING>
<fme:NORTHING>823622</fme:NORTHING>
<fme:ENGLISHNAME>37</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653898</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823622.00000 828403.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf30f6554-552b-4310-8014-dbfefea68f91">
<fme:FEATURE_ID>1210062931</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000644</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828979</fme:EASTING>
<fme:NORTHING>823622</fme:NORTHING>
<fme:ENGLISHNAME>109</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654280</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823622.00000 828979.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8294c18c-2100-4166-8c0a-65c1881741e5">
<fme:FEATURE_ID>1210189747</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000638</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>826720</fme:EASTING>
<fme:NORTHING>823623</fme:NORTHING>
<fme:ENGLISHNAME>HUD Development B Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>聯合船塢Ｂ變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823623.00000 826720.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida3078206-2a29-48d4-85d8-472dfe7e7e93">
<fme:FEATURE_ID>1210070116</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000632</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828446</fme:EASTING>
<fme:NORTHING>823623</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654030</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823623.00000 828446.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbea44253-3f72-4715-84ef-b55d3037c866">
<fme:FEATURE_ID>1210062901</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000645</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828918</fme:EASTING>
<fme:NORTHING>823623</fme:NORTHING>
<fme:ENGLISHNAME>20</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654237</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823623.00000 828918.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idecd4515b-6172-4183-a6bd-aa6077360082">
<fme:FEATURE_ID>1210067288</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000643</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828380</fme:EASTING>
<fme:NORTHING>823624</fme:NORTHING>
<fme:ENGLISHNAME>52</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653718</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823624.00000 828380.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide46a5d13-2820-422c-bc2d-66a4f53d1be3">
<fme:FEATURE_ID>1210062945</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000644</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828973</fme:EASTING>
<fme:NORTHING>823624</fme:NORTHING>
<fme:ENGLISHNAME>110</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654272</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823624.00000 828973.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf1e348fc-2dde-4c44-8d7b-f4e651646dde">
<fme:FEATURE_ID>1210069553</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000642</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828423</fme:EASTING>
<fme:NORTHING>823625</fme:NORTHING>
<fme:ENGLISHNAME>24</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653964</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823625.00000 828423.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc952438d-7eac-4f18-b228-8bc05b4b1f11">
<fme:FEATURE_ID>1210063435</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000637</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828909</fme:EASTING>
<fme:NORTHING>823625</fme:NORTHING>
<fme:ENGLISHNAME>21</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654230</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823625.00000 828909.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8c79b035-3db9-48a9-b1fb-29b9580b499c">
<fme:FEATURE_ID>1210062890</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000637</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828903</fme:EASTING>
<fme:NORTHING>823626</fme:NORTHING>
<fme:ENGLISHNAME>22</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654224</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823626.00000 828903.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id44125864-9600-4a97-9279-48b1334e63bb">
<fme:FEATURE_ID>1210068431</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000634</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828400</fme:EASTING>
<fme:NORTHING>823627</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653892</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823627.00000 828400.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd6ca52a2-bab8-4ea0-8040-29a881cee1b0">
<fme:FEATURE_ID>1210063980</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000631</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829096</fme:EASTING>
<fme:NORTHING>823627</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654374</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12448</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823627.00000 829096.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6f81c289-8c02-4754-91d1-9f2f1a2fe5c8">
<fme:FEATURE_ID>1210000948</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000631</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829096</fme:EASTING>
<fme:NORTHING>823627</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Police Married Quarters Block A</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣已婚警察宿舍Ａ座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>78351</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823627.00000 829096.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3191be21-925e-497d-91a5-db73acee6d37">
<fme:FEATURE_ID>1210070118</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000632</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828442</fme:EASTING>
<fme:NORTHING>823628</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654020</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823628.00000 828442.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id234aff2e-db99-420b-9f0b-5158066ce39b">
<fme:FEATURE_ID>1210062918</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000637</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828897</fme:EASTING>
<fme:NORTHING>823628</fme:NORTHING>
<fme:ENGLISHNAME>23</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654218</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823628.00000 828897.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idadb4786c-5f36-437f-96ce-63b7644a1b13">
<fme:FEATURE_ID>1210062896</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000637</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828892</fme:EASTING>
<fme:NORTHING>823629</fme:NORTHING>
<fme:ENGLISHNAME>24</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654213</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823629.00000 828892.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5dbc331b-a81d-47e2-aa27-e1480bb6016d">
<fme:FEATURE_ID>1210003086</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000636</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829017</fme:EASTING>
<fme:NORTHING>823629</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>青衣島信義新村居民福利會</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823629.00000 829017.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1fc746cd-87e5-4b9f-8839-065467a002f5">
<fme:FEATURE_ID>1210062933</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000635</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828882</fme:EASTING>
<fme:NORTHING>823631</fme:NORTHING>
<fme:ENGLISHNAME>25</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654203</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823631.00000 828882.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1db74b02-5c34-4a2c-8d66-4d370f008a86">
<fme:FEATURE_ID>1210000900</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000624</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829177</fme:EASTING>
<fme:NORTHING>823631</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 3</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第三座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823631.00000 829177.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id18bb3e6c-fc2a-4289-b0b7-3664b65562fd">
<fme:FEATURE_ID>1210067886</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000634</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828396</fme:EASTING>
<fme:NORTHING>823632</fme:NORTHING>
<fme:ENGLISHNAME>39</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653879</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823632.00000 828396.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1d72890c-1851-477e-bd86-ba1f2202d7cb">
<fme:FEATURE_ID>1210069526</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000625</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828417</fme:EASTING>
<fme:NORTHING>823633</fme:NORTHING>
<fme:ENGLISHNAME>25</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653943</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823633.00000 828417.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf5e6eec8-5fd1-4996-b64b-7054802cb9da">
<fme:FEATURE_ID>1210070639</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000632</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828439</fme:EASTING>
<fme:NORTHING>823633</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654010</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823633.00000 828439.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida6f9db78-1a3f-475a-8acb-d1919346f818">
<fme:FEATURE_ID>1210070672</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000635</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828876</fme:EASTING>
<fme:NORTHING>823633</fme:NORTHING>
<fme:ENGLISHNAME>26</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654198</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823633.00000 828876.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf74fa702-2e19-4e96-8d54-a1aecbad6558">
<fme:FEATURE_ID>1210070652</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000635</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828870</fme:EASTING>
<fme:NORTHING>823634</fme:NORTHING>
<fme:ENGLISHNAME>27</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654190</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823634.00000 828870.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id68a773e5-f302-4c37-ac41-53fe49641906">
<fme:FEATURE_ID>1210063989</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000628</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829022</fme:EASTING>
<fme:NORTHING>823634</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654322</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823634.00000 829022.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida621f8cd-6f2f-48b7-bf97-08e3087f8446">
<fme:FEATURE_ID>1210071194</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000635</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828864</fme:EASTING>
<fme:NORTHING>823635</fme:NORTHING>
<fme:ENGLISHNAME>28</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654184</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823635.00000 828864.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc6fb8d44-5fca-4aad-9271-bd9589c58210">
<fme:FEATURE_ID>1210067858</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000622</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828372</fme:EASTING>
<fme:NORTHING>823636</fme:NORTHING>
<fme:ENGLISHNAME>53</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653709</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823636.00000 828372.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf2071e42-4ced-4152-9786-5ce3a1a75dcc">
<fme:FEATURE_ID>1210070676</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000633</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828854</fme:EASTING>
<fme:NORTHING>823636</fme:NORTHING>
<fme:ENGLISHNAME>29</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654175</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823636.00000 828854.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcfa1e6e0-9cb0-4b39-98b6-450427eb3fdf">
<fme:FEATURE_ID>1210063996</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000628</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829018</fme:EASTING>
<fme:NORTHING>823636</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654319</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823636.00000 829018.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb96b20ad-cfc3-47a0-93b8-584ce3a56a29">
<fme:FEATURE_ID>1210068447</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000634</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828392</fme:EASTING>
<fme:NORTHING>823637</fme:NORTHING>
<fme:ENGLISHNAME>40</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653871</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823637.00000 828392.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id84457dd1-0af5-4f8d-bb87-d7ecd1fe9488">
<fme:FEATURE_ID>1210068991</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000625</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828414</fme:EASTING>
<fme:NORTHING>823637</fme:NORTHING>
<fme:ENGLISHNAME>26</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653930</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823637.00000 828414.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id66b00e24-348b-46d6-bda2-de3e7249499c">
<fme:FEATURE_ID>1210070657</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000633</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828848</fme:EASTING>
<fme:NORTHING>823637</fme:NORTHING>
<fme:ENGLISHNAME>30</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654171</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823637.00000 828848.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida36cef00-d02b-4742-b402-3f297c99d8eb">
<fme:FEATURE_ID>1210069556</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000632</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828435</fme:EASTING>
<fme:NORTHING>823638</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653998</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823638.00000 828435.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfa1d23be-a7a1-49c4-bf0f-02ce6669d89e">
<fme:FEATURE_ID>1210071196</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000633</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828842</fme:EASTING>
<fme:NORTHING>823638</fme:NORTHING>
<fme:ENGLISHNAME>31</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654164</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823638.00000 828842.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id29d3040b-93ad-4414-b384-70753e22795f">
<fme:FEATURE_ID>1210063482</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000628</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829015</fme:EASTING>
<fme:NORTHING>823638</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654315</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823638.00000 829015.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id30d9d727-0d52-4f18-9f0c-8c6cd528d093">
<fme:FEATURE_ID>1210068423</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000633</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828835</fme:EASTING>
<fme:NORTHING>823639</fme:NORTHING>
<fme:ENGLISHNAME>32</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653842</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823639.00000 828835.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idddb55a60-9e68-47ca-bdc7-f55164763534">
<fme:FEATURE_ID>1210068436</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000630</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828826</fme:EASTING>
<fme:NORTHING>823640</fme:NORTHING>
<fme:ENGLISHNAME>33</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653834</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823640.00000 828826.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id65312df4-bc62-4189-b2ed-41bb382575a6">
<fme:FEATURE_ID>1210064008</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000628</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829011</fme:EASTING>
<fme:NORTHING>823640</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654311</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823640.00000 829011.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc4fc9444-d6f3-46f6-99e9-96d28e2cfe87">
<fme:FEATURE_ID>1210067277</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000622</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828368</fme:EASTING>
<fme:NORTHING>823641</fme:NORTHING>
<fme:ENGLISHNAME>54</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653706</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823641.00000 828368.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfe5d0216-fe26-41d5-8094-ec646279f9be">
<fme:FEATURE_ID>1210068451</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000630</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828814</fme:EASTING>
<fme:NORTHING>823641</fme:NORTHING>
<fme:ENGLISHNAME>35</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653820</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823641.00000 828814.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb8890416-a76e-4e91-8cf7-f7dfb1190945">
<fme:FEATURE_ID>1210068432</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000630</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828820</fme:EASTING>
<fme:NORTHING>823641</fme:NORTHING>
<fme:ENGLISHNAME>34</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653827</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823641.00000 828820.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb291b199-1358-46dc-b50c-14e387394c27">
<fme:FEATURE_ID>1210062922</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000627</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828933</fme:EASTING>
<fme:NORTHING>823641</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654246</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823641.00000 828933.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida5e4dfa4-b494-43f5-a273-9e64f5432b68">
<fme:FEATURE_ID>1210068956</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000625</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828410</fme:EASTING>
<fme:NORTHING>823642</fme:NORTHING>
<fme:ENGLISHNAME>27</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653919</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823642.00000 828410.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idecfd37a0-3405-47c4-9b2b-d2768852037b">
<fme:FEATURE_ID>1210067879</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000630</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828809</fme:EASTING>
<fme:NORTHING>823642</fme:NORTHING>
<fme:ENGLISHNAME>36</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653815</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823642.00000 828809.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcaaf0025-a994-4f8c-918d-b7c8df283cde">
<fme:FEATURE_ID>1210071212</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000627</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828927</fme:EASTING>
<fme:NORTHING>823643</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654241</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823643.00000 828927.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3c233b11-f61b-4e86-86c0-53069e4986f4">
<fme:FEATURE_ID>1210067899</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000614</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828387</fme:EASTING>
<fme:NORTHING>823644</fme:NORTHING>
<fme:ENGLISHNAME>41</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653859</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823644.00000 828387.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id71e1fed7-8479-47ee-9265-beca4d0d05d7">
<fme:FEATURE_ID>1210062924</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000627</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828921</fme:EASTING>
<fme:NORTHING>823644</fme:NORTHING>
<fme:ENGLISHNAME>3</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654238</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823644.00000 828921.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6d66abf9-4a93-4967-8e9a-fdd098b47073">
<fme:FEATURE_ID>1210063457</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000618</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829003</fme:EASTING>
<fme:NORTHING>823644</fme:NORTHING>
<fme:ENGLISHNAME>6</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654301</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823644.00000 829003.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id99398029-b425-410e-806c-a31fc7c68ddf">
<fme:FEATURE_ID>1210063986</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000618</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829008</fme:EASTING>
<fme:NORTHING>823644</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654309</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823644.00000 829008.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1d18b0ac-1076-4804-a058-1c3b33133750">
<fme:FEATURE_ID>1210009227</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000629</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828123</fme:EASTING>
<fme:NORTHING>823645</fme:NORTHING>
<fme:ENGLISHNAME>Liu To Village Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>寮肚村公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823645.00000 828123.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idae45190e-8352-44af-a275-21211983b06b">
<fme:FEATURE_ID>1210067304</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000622</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828365</fme:EASTING>
<fme:NORTHING>823646</fme:NORTHING>
<fme:ENGLISHNAME>55</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653702</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823646.00000 828365.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2f448e12-bac0-40fe-80ad-e329e6ee0b8f">
<fme:FEATURE_ID>1210063433</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000627</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828915</fme:EASTING>
<fme:NORTHING>823646</fme:NORTHING>
<fme:ENGLISHNAME>4</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654233</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823646.00000 828915.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id03819603-73bf-4948-9cac-ea1a9a5ae148">
<fme:FEATURE_ID>1210069540</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000625</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828407</fme:EASTING>
<fme:NORTHING>823647</fme:NORTHING>
<fme:ENGLISHNAME>28</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653912</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823647.00000 828407.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf299bdaf-8235-4139-a65d-ae9c78a535cb">
<fme:FEATURE_ID>1210063470</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000618</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829000</fme:EASTING>
<fme:NORTHING>823647</fme:NORTHING>
<fme:ENGLISHNAME>4</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654299</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823647.00000 829000.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6a2ddacb-e352-4f00-b221-dbeebb88146b">
<fme:FEATURE_ID>1210062903</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000619</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828905</fme:EASTING>
<fme:NORTHING>823648</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654226</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823648.00000 828905.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id83b6cbde-3a29-4cc7-841f-c9566d769edb">
<fme:FEATURE_ID>1210062892</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000618</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828995</fme:EASTING>
<fme:NORTHING>823648</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654298</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823648.00000 828995.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3a6bfdf3-a640-42dc-9043-ab22f639fba6">
<fme:FEATURE_ID>1210063463</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000617</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829029</fme:EASTING>
<fme:NORTHING>823648</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654326</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823648.00000 829029.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idee531f62-2019-47b3-94fa-46a2332ddcfb">
<fme:FEATURE_ID>1210067306</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000622</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828361</fme:EASTING>
<fme:NORTHING>823650</fme:NORTHING>
<fme:ENGLISHNAME>56</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653700</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823650.00000 828361.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id199cefcb-0306-4fb6-95a6-f1a0aae683e5">
<fme:FEATURE_ID>1210068461</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000614</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828383</fme:EASTING>
<fme:NORTHING>823650</fme:NORTHING>
<fme:ENGLISHNAME>42</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653850</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823650.00000 828383.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2deb5155-db02-4cdc-a720-fa346b38de6d">
<fme:FEATURE_ID>1210069536</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000604</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828427</fme:EASTING>
<fme:NORTHING>823650</fme:NORTHING>
<fme:ENGLISHNAME>13</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653979</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823650.00000 828427.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc644171d-2a1f-418b-9aa9-aced0a4b83b6">
<fme:FEATURE_ID>1210062917</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000619</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828899</fme:EASTING>
<fme:NORTHING>823650</fme:NORTHING>
<fme:ENGLISHNAME>6</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654220</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823650.00000 828899.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id58d01156-85a9-4b5c-aeda-2a1147d5cb40">
<fme:FEATURE_ID>1210063473</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000617</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829025</fme:EASTING>
<fme:NORTHING>823650</fme:NORTHING>
<fme:ENGLISHNAME>13</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654324</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823650.00000 829025.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0d77cb61-b591-43c2-b0b8-946ec5cf49e9">
<fme:FEATURE_ID>1210062902</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000619</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828892</fme:EASTING>
<fme:NORTHING>823651</fme:NORTHING>
<fme:ENGLISHNAME>7</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654214</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823651.00000 828892.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb6a6cd46-1442-416a-9cb2-4a74f0da1bd9">
<fme:FEATURE_ID>1210063472</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000617</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829022</fme:EASTING>
<fme:NORTHING>823651</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654323</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823651.00000 829022.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida194d3d8-879f-4d04-b44a-d3adab9f32aa">
<fme:FEATURE_ID>1210003085</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000621</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829051</fme:EASTING>
<fme:NORTHING>823651</fme:NORTHING>
<fme:ENGLISHNAME>Lutheran Village Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>信義村公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823651.00000 829051.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id26654c15-78d1-4be4-8c53-dc01a03cc74f">
<fme:FEATURE_ID>1210063439</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000619</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828887</fme:EASTING>
<fme:NORTHING>823652</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654209</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823652.00000 828887.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id35039c5b-184a-4d56-a679-42c81d55702e">
<fme:FEATURE_ID>1210063454</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000617</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829018</fme:EASTING>
<fme:NORTHING>823653</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654320</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823653.00000 829018.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id85075bf1-66b6-4a91-98a2-02b449bac97f">
<fme:FEATURE_ID>1210067270</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000614</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828380</fme:EASTING>
<fme:NORTHING>823654</fme:NORTHING>
<fme:ENGLISHNAME>43</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653719</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823654.00000 828380.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide6990a07-325a-4b0f-964b-25cfd0f70de2">
<fme:FEATURE_ID>1210068962</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000604</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828423</fme:EASTING>
<fme:NORTHING>823655</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653965</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823655.00000 828423.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd174f34e-feae-4bad-a6a6-7dc0cbf957b6">
<fme:FEATURE_ID>1210062940</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000615</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828876</fme:EASTING>
<fme:NORTHING>823655</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654199</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823655.00000 828876.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd20f438b-646b-409c-9209-77459a15c0a3">
<fme:FEATURE_ID>1210064003</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000611</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829013</fme:EASTING>
<fme:NORTHING>823655</fme:NORTHING>
<fme:ENGLISHNAME>7</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654313</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823655.00000 829013.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6112abd9-7e8a-4d36-a115-a05c594abd05">
<fme:FEATURE_ID>1210001087</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000598</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829160</fme:EASTING>
<fme:NORTHING>823655</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 4</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第四座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823655.00000 829160.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaa30e6a6-0943-4d27-aff9-3729694e8bc2">
<fme:FEATURE_ID>1210070677</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000615</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828871</fme:EASTING>
<fme:NORTHING>823656</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654192</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823656.00000 828871.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc93357c9-4c0e-4b8e-a6d6-d064b53218c8">
<fme:FEATURE_ID>1210070685</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000615</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828865</fme:EASTING>
<fme:NORTHING>823657</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654185</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823657.00000 828865.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5378324d-be62-49a4-b84e-4b457280329f">
<fme:FEATURE_ID>1210070678</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000615</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828858</fme:EASTING>
<fme:NORTHING>823658</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654179</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823658.00000 828858.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id22583fcd-2940-4200-a34e-a802c68f8d05">
<fme:FEATURE_ID>1210064013</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000611</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829009</fme:EASTING>
<fme:NORTHING>823658</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654310</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823658.00000 829009.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6f40ad39-3f2b-4680-8726-9c2dc60a07a2">
<fme:FEATURE_ID>1210067321</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000614</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828376</fme:EASTING>
<fme:NORTHING>823659</fme:NORTHING>
<fme:ENGLISHNAME>44</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653714</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823659.00000 828376.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfd2fac79-4de6-424c-adca-ec462f1048da">
<fme:FEATURE_ID>1210069528</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000604</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828420</fme:EASTING>
<fme:NORTHING>823660</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653953</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823660.00000 828420.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id238ad9d1-84e2-458b-88fd-91bc7350de35">
<fme:FEATURE_ID>1210069578</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000594</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828441</fme:EASTING>
<fme:NORTHING>823660</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654014</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823660.00000 828441.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8001dfca-3352-47bb-bbc9-1ad803d6f430">
<fme:FEATURE_ID>1210071205</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000608</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828848</fme:EASTING>
<fme:NORTHING>823660</fme:NORTHING>
<fme:ENGLISHNAME>13</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654172</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823660.00000 828848.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9829635c-2a61-4617-8ef6-59b4fd1bc960">
<fme:FEATURE_ID>1210063451</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000611</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829005</fme:EASTING>
<fme:NORTHING>823660</fme:NORTHING>
<fme:ENGLISHNAME>3</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654304</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823660.00000 829005.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id79aa7de7-cb10-4928-b8ac-6539ec474b3b">
<fme:FEATURE_ID>1210063465</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000611</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829002</fme:EASTING>
<fme:NORTHING>823661</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654300</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64215</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823661.00000 829002.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id96d6a84f-ba45-4d3f-b163-f926ad340efd">
<fme:FEATURE_ID>1210002385</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000605</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828356</fme:EASTING>
<fme:NORTHING>823662</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>鄧氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823662.00000 828356.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id791af24b-08f2-42e6-9de5-f7a6996f631c">
<fme:FEATURE_ID>1210070646</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000608</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828842</fme:EASTING>
<fme:NORTHING>823662</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654165</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823662.00000 828842.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfead2f1f-c3be-493b-9623-0ca8c0bab305">
<fme:FEATURE_ID>1210068474</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000591</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828395</fme:EASTING>
<fme:NORTHING>823663</fme:NORTHING>
<fme:ENGLISHNAME>29</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653878</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823663.00000 828395.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id454046da-84fc-47c6-943a-8ece8a3c3329">
<fme:FEATURE_ID>1210067895</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000608</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828835</fme:EASTING>
<fme:NORTHING>823663</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653843</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823663.00000 828835.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id22171fc0-82a6-46ee-8b0d-004cdb268a84">
<fme:FEATURE_ID>1210068477</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000608</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828829</fme:EASTING>
<fme:NORTHING>823664</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653840</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64055</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823664.00000 828829.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id81747995-f308-49a1-809b-9ba77fdc449a">
<fme:FEATURE_ID>1210069001</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000604</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828416</fme:EASTING>
<fme:NORTHING>823665</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653940</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823665.00000 828416.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf967f765-402e-4b5b-9932-45fd911398b9">
<fme:FEATURE_ID>1210069570</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000594</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828437</fme:EASTING>
<fme:NORTHING>823665</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654003</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823665.00000 828437.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcd2c8f81-6e56-457d-9063-bfd2a4401cf1">
<fme:FEATURE_ID>1210068441</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000591</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828392</fme:EASTING>
<fme:NORTHING>823668</fme:NORTHING>
<fme:ENGLISHNAME>30</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653872</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823668.00000 828392.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0761c26d-abeb-4cc5-a44b-61cf671de230">
<fme:FEATURE_ID>1210067299</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000599</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828711</fme:EASTING>
<fme:NORTHING>823668</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653760</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823668.00000 828711.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc22ab6d5-bd53-44ff-ba8d-86e4e519f250">
<fme:FEATURE_ID>1210069544</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000594</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828434</fme:EASTING>
<fme:NORTHING>823670</fme:NORTHING>
<fme:ENGLISHNAME>3</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653995</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823670.00000 828434.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id20fe601d-deed-44ff-9e3f-a50cbc448b8f">
<fme:FEATURE_ID>1210067297</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000596</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828701</fme:EASTING>
<fme:NORTHING>823670</fme:NORTHING>
<fme:ENGLISHNAME>19</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653758</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823670.00000 828701.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5609b7f4-0258-42a9-b42b-e1a437cd3198">
<fme:FEATURE_ID>1210067285</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000596</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828695</fme:EASTING>
<fme:NORTHING>823671</fme:NORTHING>
<fme:ENGLISHNAME>20</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653756</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823671.00000 828695.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf2d18666-39eb-4abd-9894-2c3224637cc4">
<fme:FEATURE_ID>1210067877</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000591</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828388</fme:EASTING>
<fme:NORTHING>823673</fme:NORTHING>
<fme:ENGLISHNAME>31</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653863</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823673.00000 828388.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc7cac1ce-5098-4fd2-8135-bfb9fe12bbe5">
<fme:FEATURE_ID>1210068985</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828410</fme:EASTING>
<fme:NORTHING>823673</fme:NORTHING>
<fme:ENGLISHNAME>17</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653920</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823673.00000 828410.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6268940f-a369-412a-9348-134c01a68576">
<fme:FEATURE_ID>1210067287</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000590</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828686</fme:EASTING>
<fme:NORTHING>823674</fme:NORTHING>
<fme:ENGLISHNAME>21</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653753</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823674.00000 828686.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfd2a3b2f-3a82-4634-b6b9-9190efd9e873">
<fme:FEATURE_ID>1210069014</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000594</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828430</fme:EASTING>
<fme:NORTHING>823675</fme:NORTHING>
<fme:ENGLISHNAME>4</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653988</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823675.00000 828430.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida40f7675-503a-4762-b1bc-b1f07dffc5ea">
<fme:FEATURE_ID>1210067271</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000590</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828680</fme:EASTING>
<fme:NORTHING>823675</fme:NORTHING>
<fme:ENGLISHNAME>22</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653752</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823675.00000 828680.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7478eb7f-6d6c-48da-91c9-6275cdb05b99">
<fme:FEATURE_ID>1210162716</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001067</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829181</fme:EASTING>
<fme:NORTHING>823675</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654415</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10582</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823675.00000 829181.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0121107b-166b-4327-9680-174cd0bebd2f">
<fme:FEATURE_ID>1210000642</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000542</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829317</fme:EASTING>
<fme:NORTHING>823675</fme:NORTHING>
<fme:ENGLISHNAME>Grand Horizon Block 1</fme:ENGLISHNAME>
<fme:CHINESENAME>海欣花園第一座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823675.00000 829317.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9215cf46-ddc9-4136-9050-26d66022b582">
<fme:FEATURE_ID>1210068454</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000591</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828385</fme:EASTING>
<fme:NORTHING>823678</fme:NORTHING>
<fme:ENGLISHNAME>32</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653856</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823678.00000 828385.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0e26d760-1330-4b0e-910e-fff33899cfff">
<fme:FEATURE_ID>1210067316</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000585</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828672</fme:EASTING>
<fme:NORTHING>823678</fme:NORTHING>
<fme:ENGLISHNAME>23</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653746</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823678.00000 828672.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1b9f7eed-9e35-470b-84a9-0a2ba53a6586">
<fme:FEATURE_ID>1210068963</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828406</fme:EASTING>
<fme:NORTHING>823679</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653908</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823679.00000 828406.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id864be2de-7299-4590-baff-2308b9c22b9d">
<fme:FEATURE_ID>1210067320</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000585</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828666</fme:EASTING>
<fme:NORTHING>823680</fme:NORTHING>
<fme:ENGLISHNAME>24</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653745</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823680.00000 828666.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idff8d52f0-5d6a-4b8d-ae53-fe6d6170ea31">
<fme:FEATURE_ID>1210067308</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000584</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828714</fme:EASTING>
<fme:NORTHING>823680</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653762</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823680.00000 828714.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1379bff2-1e80-46c0-8b47-0e52d794f86a">
<fme:FEATURE_ID>1210067848</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000584</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828707</fme:EASTING>
<fme:NORTHING>823682</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653759</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823682.00000 828707.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb308a8fa-c1fe-4201-b82b-ca42543fdf86">
<fme:FEATURE_ID>1210067274</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000583</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828739</fme:EASTING>
<fme:NORTHING>823682</fme:NORTHING>
<fme:ENGLISHNAME>7</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653772</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823682.00000 828739.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2f4ee645-a6fa-4d21-841f-006897be9754">
<fme:FEATURE_ID>1210067312</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000583</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828745</fme:EASTING>
<fme:NORTHING>823682</fme:NORTHING>
<fme:ENGLISHNAME>6</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653773</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823682.00000 828745.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idba3507ac-f992-4b74-94d0-0812f4f75da1">
<fme:FEATURE_ID>1210069539</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828403</fme:EASTING>
<fme:NORTHING>823683</fme:NORTHING>
<fme:ENGLISHNAME>19</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653899</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823683.00000 828403.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idee93e84a-2a6d-4c4b-9030-fb88579700b5">
<fme:FEATURE_ID>1210069004</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000570</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828425</fme:EASTING>
<fme:NORTHING>823683</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653971</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823683.00000 828425.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd5cb14e5-988e-4e11-9c45-f9538c6b4034">
<fme:FEATURE_ID>1210066766</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000580</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828657</fme:EASTING>
<fme:NORTHING>823683</fme:NORTHING>
<fme:ENGLISHNAME>25</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653741</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823683.00000 828657.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide20ccff3-f851-4a70-97f6-bf33dac34047">
<fme:FEATURE_ID>1210067272</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000582</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828754</fme:EASTING>
<fme:NORTHING>823683</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653775</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823683.00000 828754.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd94de9ed-05df-40e2-8db8-cc21176b6897">
<fme:FEATURE_ID>1210067854</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000582</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828760</fme:EASTING>
<fme:NORTHING>823683</fme:NORTHING>
<fme:ENGLISHNAME>4</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653778</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823683.00000 828760.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide3122295-a8c8-4490-a1af-d9ceef74f999">
<fme:FEATURE_ID>1210067857</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000581</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828769</fme:EASTING>
<fme:NORTHING>823683</fme:NORTHING>
<fme:ENGLISHNAME>3</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653780</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823683.00000 828769.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id57d36250-87bb-4551-8ff7-3b2d2879d7c7">
<fme:FEATURE_ID>1210067851</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000580</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828651</fme:EASTING>
<fme:NORTHING>823684</fme:NORTHING>
<fme:ENGLISHNAME>26</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653738</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823684.00000 828651.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1392ed6c-ce5d-41e3-8c25-823fa4a832bf">
<fme:FEATURE_ID>1210067283</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000581</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828775</fme:EASTING>
<fme:NORTHING>823684</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653784</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823684.00000 828775.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id48141716-fc7e-4c44-8360-a0ae7b0ca33e">
<fme:FEATURE_ID>1210067864</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000579</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828784</fme:EASTING>
<fme:NORTHING>823684</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653789</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823684.00000 828784.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id805303db-39a9-47e1-99da-8b2092b9d690">
<fme:FEATURE_ID>1210066746</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000563</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828332</fme:EASTING>
<fme:NORTHING>823685</fme:NORTHING>
<fme:ENGLISHNAME>35</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653687</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823685.00000 828332.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5b1e4541-1e84-4d32-81a8-b41eb0212cbd">
<fme:FEATURE_ID>1210067860</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000576</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828697</fme:EASTING>
<fme:NORTHING>823685</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653757</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823685.00000 828697.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id40235cf7-2403-4ff6-80c0-90163ec4fafd">
<fme:FEATURE_ID>1210067853</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000577</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828642</fme:EASTING>
<fme:NORTHING>823687</fme:NORTHING>
<fme:ENGLISHNAME>27</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653735</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823687.00000 828642.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5b6acae4-afa2-4178-82b5-fe130368fee2">
<fme:FEATURE_ID>1210067861</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000576</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828690</fme:EASTING>
<fme:NORTHING>823687</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653754</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823687.00000 828690.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide929179a-de23-42af-a9f8-9e0aa8c00e53">
<fme:FEATURE_ID>1210068974</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000570</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828421</fme:EASTING>
<fme:NORTHING>823688</fme:NORTHING>
<fme:ENGLISHNAME>6</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653957</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823688.00000 828421.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id886a9726-a07b-447f-88d3-29889fac69b2">
<fme:FEATURE_ID>1210067894</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000578</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828399</fme:EASTING>
<fme:NORTHING>823689</fme:NORTHING>
<fme:ENGLISHNAME>20</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653885</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823689.00000 828399.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4c1a4eb5-2afc-40aa-a201-c349b5a6465c">
<fme:FEATURE_ID>1210067293</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000572</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828628</fme:EASTING>
<fme:NORTHING>823690</fme:NORTHING>
<fme:ENGLISHNAME>28</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653732</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823690.00000 828628.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide85fddca-4415-4354-959c-1be3dacc5ca8">
<fme:FEATURE_ID>1210067286</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000574</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828679</fme:EASTING>
<fme:NORTHING>823690</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653751</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823690.00000 828679.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddae3374d-dc68-41ce-bdb4-523338bbec87">
<fme:FEATURE_ID>1210001029</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000567</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829361</fme:EASTING>
<fme:NORTHING>823690</fme:NORTHING>
<fme:ENGLISHNAME>Grand Horizon Block 6</fme:ENGLISHNAME>
<fme:CHINESENAME>海欣花園第六座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823690.00000 829361.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4f67a332-e3e7-4728-8711-72b454c47209">
<fme:FEATURE_ID>1210066210</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000563</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828333</fme:EASTING>
<fme:NORTHING>823691</fme:NORTHING>
<fme:ENGLISHNAME>36</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653688</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823691.00000 828333.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1a200f45-abb6-4bc9-8bde-b2f4b77a3158">
<fme:FEATURE_ID>1210067279</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000572</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828622</fme:EASTING>
<fme:NORTHING>823692</fme:NORTHING>
<fme:ENGLISHNAME>29</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653731</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823692.00000 828622.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ided315293-44d2-4071-9fd2-1ab4847d1bca">
<fme:FEATURE_ID>1210067863</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000574</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828672</fme:EASTING>
<fme:NORTHING>823692</fme:NORTHING>
<fme:ENGLISHNAME>13</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653747</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823692.00000 828672.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb6cb9d23-4e06-4f96-9543-fbd779bf912e">
<fme:FEATURE_ID>1210001023</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000575</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828818</fme:EASTING>
<fme:NORTHING>823692</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Fai Village Refuse Collection Point</fme:ENGLISHNAME>
<fme:CHINESENAME>青輝村垃圾收集站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823692.00000 828818.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0121aefb-1a75-4437-94d1-187fcfd4ee83">
<fme:FEATURE_ID>1210000581</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000562</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829156</fme:EASTING>
<fme:NORTHING>823692</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 5</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第五座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823692.00000 829156.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id71b87e88-4549-4d3f-b8ca-e0dc0d97c622">
<fme:FEATURE_ID>1210068982</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000570</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828417</fme:EASTING>
<fme:NORTHING>823693</fme:NORTHING>
<fme:ENGLISHNAME>7</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653944</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823693.00000 828417.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1291fbc0-f0e2-4a6a-b029-8a82cb81330d">
<fme:FEATURE_ID>1210067295</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000569</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828662</fme:EASTING>
<fme:NORTHING>823695</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653743</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823695.00000 828662.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id63a7d1db-cf92-41a1-96a5-5ce9ce588261">
<fme:FEATURE_ID>1210071213</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828972</fme:EASTING>
<fme:NORTHING>823695</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654270</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10582</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823695.00000 828972.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id62d070aa-55ff-4ef4-9102-b872269074e1">
<fme:FEATURE_ID>1210001030</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000571</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828972</fme:EASTING>
<fme:NORTHING>823695</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Rural Committee</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣鄉事委員會</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823695.00000 828972.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id85218616-f41f-4d54-a87b-f4075cfaa900">
<fme:FEATURE_ID>1310207141</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310100387</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829798</fme:EASTING>
<fme:NORTHING>823695</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1910088507</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13992</fme:ST_CODE>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823695.00000 829798.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1db552a3-0700-4084-a052-9e6b9e5a59a6">
<fme:FEATURE_ID>1210067319</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000568</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828613</fme:EASTING>
<fme:NORTHING>823696</fme:NORTHING>
<fme:ENGLISHNAME>30</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653730</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823696.00000 828613.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2cfa252a-de57-45f0-a5b3-45bfd3e021ea">
<fme:FEATURE_ID>1210066189</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000563</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828334</fme:EASTING>
<fme:NORTHING>823697</fme:NORTHING>
<fme:ENGLISHNAME>37</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653689</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823697.00000 828334.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide7e16e85-a024-4c53-b152-a6f8909fd362">
<fme:FEATURE_ID>1210066724</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000566</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828350</fme:EASTING>
<fme:NORTHING>823697</fme:NORTHING>
<fme:ENGLISHNAME>25</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653695</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823697.00000 828350.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9314c63f-c864-4f23-bf0b-a6dd8c7f570d">
<fme:FEATURE_ID>1210067311</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000569</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828654</fme:EASTING>
<fme:NORTHING>823697</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653740</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823697.00000 828654.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc889f38c-b882-4793-82eb-05c50b8d82b1">
<fme:FEATURE_ID>1210069557</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000570</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828414</fme:EASTING>
<fme:NORTHING>823698</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653931</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64053</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823698.00000 828414.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2a3cd770-3459-4189-b259-b2821b27fc3d">
<fme:FEATURE_ID>1210067280</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000568</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828606</fme:EASTING>
<fme:NORTHING>823698</fme:NORTHING>
<fme:ENGLISHNAME>31</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653727</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823698.00000 828606.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id08a376bd-8953-460b-a348-3184477b28c9">
<fme:FEATURE_ID>1210067862</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000565</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828644</fme:EASTING>
<fme:NORTHING>823700</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653736</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823700.00000 828644.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb6069ee9-8cc7-4691-b1d5-8e6f169f6457">
<fme:FEATURE_ID>1210066767</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000565</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828637</fme:EASTING>
<fme:NORTHING>823702</fme:NORTHING>
<fme:ENGLISHNAME>17</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653734</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823702.00000 828637.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id15b76437-96f1-4e11-a561-ee4e955b0956">
<fme:FEATURE_ID>1210191804</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000566</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828349</fme:EASTING>
<fme:NORTHING>823703</fme:NORTHING>
<fme:ENGLISHNAME>26</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810064225</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823703.00000 828349.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ideec463d8-b4aa-4118-a400-d335c0df7077">
<fme:FEATURE_ID>1210071193</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000561</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828584</fme:EASTING>
<fme:NORTHING>823703</fme:NORTHING>
<fme:ENGLISHNAME>43</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654155</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823703.00000 828584.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1dd04c4b-d52e-41ac-bca2-276a4cd8ee72">
<fme:FEATURE_ID>1210066757</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000563</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828335</fme:EASTING>
<fme:NORTHING>823704</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653690</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823704.00000 828335.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id95964a24-e07d-4493-82bc-ea8fdd5b1164">
<fme:FEATURE_ID>1210168661</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000564</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828426</fme:EASTING>
<fme:NORTHING>823705</fme:NORTHING>
<fme:ENGLISHNAME>Tigerhead Resite Vill Ph1 Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>老虎頭村一期變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823705.00000 828426.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1a9dc5f4-9304-452f-b992-896afcc59d29">
<fme:FEATURE_ID>1210071183</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000558</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828597</fme:EASTING>
<fme:NORTHING>823708</fme:NORTHING>
<fme:ENGLISHNAME>39</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654162</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823708.00000 828597.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddce2eb74-b233-43f6-995f-f076fd33ec78">
<fme:FEATURE_ID>1210040665</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000561</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828581</fme:EASTING>
<fme:NORTHING>823709</fme:NORTHING>
<fme:ENGLISHNAME>43A</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654154</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823709.00000 828581.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id28cc8db8-ad35-4b10-bb3d-0fde961a514e">
<fme:FEATURE_ID>1210066759</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000550</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828355</fme:EASTING>
<fme:NORTHING>823711</fme:NORTHING>
<fme:ENGLISHNAME>27</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653696</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823711.00000 828355.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbd82e579-ad96-4007-a87d-f9513fec28dd">
<fme:FEATURE_ID>1210066719</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828337</fme:EASTING>
<fme:NORTHING>823714</fme:NORTHING>
<fme:ENGLISHNAME>39</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653691</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823714.00000 828337.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id901a6f74-81ed-4e92-9246-0f6fdaa81d1e">
<fme:FEATURE_ID>1210071204</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000558</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828595</fme:EASTING>
<fme:NORTHING>823714</fme:NORTHING>
<fme:ENGLISHNAME>40</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654160</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823714.00000 828595.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0ca8daa4-4bfa-4964-8477-684f646b7e61">
<fme:FEATURE_ID>1210067322</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000556</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828611</fme:EASTING>
<fme:NORTHING>823714</fme:NORTHING>
<fme:ENGLISHNAME>32</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653729</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823714.00000 828611.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0986fa1b-a9e1-403f-8df6-d6ccbec0e354">
<fme:FEATURE_ID>1210066206</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000550</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828356</fme:EASTING>
<fme:NORTHING>823717</fme:NORTHING>
<fme:ENGLISHNAME>28</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653697</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823717.00000 828356.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idce74fb0a-53b2-4a32-8401-fdcf3ca57f42">
<fme:FEATURE_ID>1210067898</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000554</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828391</fme:EASTING>
<fme:NORTHING>823717</fme:NORTHING>
<fme:ENGLISHNAME>7</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653870</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823717.00000 828391.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id57531ff9-dbc6-455a-9bec-c7cb4e458e7b">
<fme:FEATURE_ID>1210070647</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000555</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828578</fme:EASTING>
<fme:NORTHING>823717</fme:NORTHING>
<fme:ENGLISHNAME>45</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654152</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823717.00000 828578.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd60c2cc4-bff3-4760-b92e-d2cfad070b2f">
<fme:FEATURE_ID>1210000950</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000551</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829352</fme:EASTING>
<fme:NORTHING>823717</fme:NORTHING>
<fme:ENGLISHNAME>Grand Horizon Block 5</fme:ENGLISHNAME>
<fme:CHINESENAME>海欣花園第五座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823717.00000 829352.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddfc18363-acc6-4ad5-b5a8-c20526947dcc">
<fme:FEATURE_ID>1210066188</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828338</fme:EASTING>
<fme:NORTHING>823719</fme:NORTHING>
<fme:ENGLISHNAME>40</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653692</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823719.00000 828338.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2e023829-3a22-495a-9d55-cad38b28c546">
<fme:FEATURE_ID>1210067267</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000556</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828609</fme:EASTING>
<fme:NORTHING>823719</fme:NORTHING>
<fme:ENGLISHNAME>33</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653728</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823719.00000 828609.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ideca638dc-4924-4437-90bd-757256206845">
<fme:FEATURE_ID>1210001041</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000546</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829168</fme:EASTING>
<fme:NORTHING>823719</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 6</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第六座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823719.00000 829168.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id12031d61-1075-4e9d-a11a-b49a10ce0d4c">
<fme:FEATURE_ID>1210067303</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000553</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828374</fme:EASTING>
<fme:NORTHING>823720</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653711</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823720.00000 828374.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0b666214-2103-435f-8078-11304c23fb89">
<fme:FEATURE_ID>1210001045</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000542</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829300</fme:EASTING>
<fme:NORTHING>823721</fme:NORTHING>
<fme:ENGLISHNAME>Grand Horizon Block 2</fme:ENGLISHNAME>
<fme:CHINESENAME>海欣花園第二座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823721.00000 829300.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4b8e3b47-6fa3-4e78-886a-7627b34bbfbb">
<fme:FEATURE_ID>1210066194</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000550</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828356</fme:EASTING>
<fme:NORTHING>823722</fme:NORTHING>
<fme:ENGLISHNAME>29</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653698</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823722.00000 828356.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id38a2e543-4cc5-4498-ab41-e1cdfd73963a">
<fme:FEATURE_ID>1210070693</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000555</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828576</fme:EASTING>
<fme:NORTHING>823722</fme:NORTHING>
<fme:ENGLISHNAME>46</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654151</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823722.00000 828576.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id832f55b9-7f85-4528-855c-3312cf19d9f6">
<fme:FEATURE_ID>1210071187</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000552</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828591</fme:EASTING>
<fme:NORTHING>823722</fme:NORTHING>
<fme:ENGLISHNAME>41</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654158</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823722.00000 828591.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idab1e4e54-fe5f-4d50-901b-9d9b427e2de8">
<fme:FEATURE_ID>1210067881</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000554</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828392</fme:EASTING>
<fme:NORTHING>823724</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653873</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823724.00000 828392.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb157321f-aa90-485d-b292-dbd6f8411e69">
<fme:FEATURE_ID>1210066178</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828339</fme:EASTING>
<fme:NORTHING>823725</fme:NORTHING>
<fme:ENGLISHNAME>41</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653693</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823725.00000 828339.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4c6e25f7-cb10-4c66-a29e-1529d42959f1">
<fme:FEATURE_ID>1210067289</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000553</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828375</fme:EASTING>
<fme:NORTHING>823726</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653712</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823726.00000 828375.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idacd9056b-ba04-443c-adad-f6ccf31e61ac">
<fme:FEATURE_ID>1210000698</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000537</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828516</fme:EASTING>
<fme:NORTHING>823726</fme:NORTHING>
<fme:ENGLISHNAME>Tung Wah Group of Hospitals S. C. Gaw Memorial College</fme:ENGLISHNAME>
<fme:CHINESENAME>東華三院吳祥川紀念中學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>73998</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823726.00000 828516.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id187fd3c6-e333-4d87-a0f0-802254f3250c">
<fme:FEATURE_ID>1210070673</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000537</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828516</fme:EASTING>
<fme:NORTHING>823726</fme:NORTHING>
<fme:ENGLISHNAME>7</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654119</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823726.00000 828516.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9ccb9f16-8997-411d-9c16-d2c39132ea03">
<fme:FEATURE_ID>1210070650</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000552</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828590</fme:EASTING>
<fme:NORTHING>823727</fme:NORTHING>
<fme:ENGLISHNAME>42</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654157</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823727.00000 828590.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide3cbf019-e6e8-4297-b01a-b8bf224b93c8">
<fme:FEATURE_ID>1210067868</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000547</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828605</fme:EASTING>
<fme:NORTHING>823727</fme:NORTHING>
<fme:ENGLISHNAME>34</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653725</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823727.00000 828605.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id64d07966-d704-4456-b1a6-37e700dd1c68">
<fme:FEATURE_ID>1210067867</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000550</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828358</fme:EASTING>
<fme:NORTHING>823728</fme:NORTHING>
<fme:ENGLISHNAME>30</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653699</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823728.00000 828358.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id40126af4-a9b7-4b40-a329-73bfb3092628">
<fme:FEATURE_ID>1210070664</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000545</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828573</fme:EASTING>
<fme:NORTHING>823730</fme:NORTHING>
<fme:ENGLISHNAME>47</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654150</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823730.00000 828573.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1e92975a-6c6c-4b7e-b90f-627af504096c">
<fme:FEATURE_ID>1210066716</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000549</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828340</fme:EASTING>
<fme:NORTHING>823731</fme:NORTHING>
<fme:ENGLISHNAME>42</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653694</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823731.00000 828340.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida93dfa67-2af4-49d6-bcc2-5e1b35de5097">
<fme:FEATURE_ID>1210178058</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210050863</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828828</fme:EASTING>
<fme:NORTHING>823731</fme:NORTHING>
<fme:ENGLISHNAME>Greenview Villa Tower 3</fme:ENGLISHNAME>
<fme:CHINESENAME>綠悠雅苑第三座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823731.00000 828828.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id54ba0559-a301-4236-9e48-4de41737536a">
<fme:FEATURE_ID>1210069010</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000538</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828415</fme:EASTING>
<fme:NORTHING>823732</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653936</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823732.00000 828415.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id37fb59f9-9653-4c7a-8ad1-ecadde4ef2f4">
<fme:FEATURE_ID>1210178057</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210050862</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828775</fme:EASTING>
<fme:NORTHING>823732</fme:NORTHING>
<fme:ENGLISHNAME>Greenview Villa Tower 2</fme:ENGLISHNAME>
<fme:CHINESENAME>綠悠雅苑第二座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823732.00000 828775.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6c8cdc6c-89c1-4de7-80eb-c198612fc780">
<fme:FEATURE_ID>1210067275</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000547</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828603</fme:EASTING>
<fme:NORTHING>823733</fme:NORTHING>
<fme:ENGLISHNAME>35</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653724</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823733.00000 828603.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc389bd40-f68b-4586-b3bc-ec110b5214d0">
<fme:FEATURE_ID>1210068419</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000536</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828398</fme:EASTING>
<fme:NORTHING>823734</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653883</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823734.00000 828398.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd932654a-a893-40f5-b0e3-781e5582496d">
<fme:FEATURE_ID>1210067318</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000530</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828380</fme:EASTING>
<fme:NORTHING>823736</fme:NORTHING>
<fme:ENGLISHNAME>17</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653720</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823736.00000 828380.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6e69391f-f338-4511-8dd3-ad0c775425c7">
<fme:FEATURE_ID>1210070689</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000545</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828570</fme:EASTING>
<fme:NORTHING>823736</fme:NORTHING>
<fme:ENGLISHNAME>48</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654149</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823736.00000 828570.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id68c311e8-94e5-4c56-a3fe-cbd9ee2086b6">
<fme:FEATURE_ID>1210068965</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000538</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828416</fme:EASTING>
<fme:NORTHING>823737</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653941</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823737.00000 828416.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ideb723131-895b-4f85-abfc-9cc440e5f83b">
<fme:FEATURE_ID>1210067883</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000536</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828399</fme:EASTING>
<fme:NORTHING>823739</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653886</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823739.00000 828399.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4822ab4e-d52e-479a-8c01-398bb043fcc4">
<fme:FEATURE_ID>1210000709</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000533</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829203</fme:EASTING>
<fme:NORTHING>823740</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 7</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第七座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823740.00000 829203.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id30ff8fa4-2ee6-477e-9b9f-0d11aa64ffd3">
<fme:FEATURE_ID>1210067302</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000540</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828600</fme:EASTING>
<fme:NORTHING>823741</fme:NORTHING>
<fme:ENGLISHNAME>36</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653723</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823741.00000 828600.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1fecb382-9a07-44fd-a474-10b3e9b2d5d2">
<fme:FEATURE_ID>1210067315</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000530</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828381</fme:EASTING>
<fme:NORTHING>823742</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653721</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823742.00000 828381.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id65bd4719-65fd-4dfd-8d0a-0dfc65bd9bbc">
<fme:FEATURE_ID>1210068976</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000538</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828417</fme:EASTING>
<fme:NORTHING>823743</fme:NORTHING>
<fme:ENGLISHNAME>3</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653945</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823743.00000 828417.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6624b132-28d5-433a-a100-6bc491d29cba">
<fme:FEATURE_ID>1210000653</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000529</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827995</fme:EASTING>
<fme:NORTHING>823744</fme:NORTHING>
<fme:ENGLISHNAME>Mount Haven Block 1</fme:ENGLISHNAME>
<fme:CHINESENAME>曉峰園第１座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823744.00000 827995.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6683ac65-fb86-49f2-8db4-82590f2062d0">
<fme:FEATURE_ID>1210000579</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000532</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829341</fme:EASTING>
<fme:NORTHING>823744</fme:NORTHING>
<fme:ENGLISHNAME>Grand Horizon Block 3</fme:ENGLISHNAME>
<fme:CHINESENAME>海欣花園第三座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76528</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823744.00000 829341.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4b0507a4-bf97-4178-a58f-184bd204ce8a">
<fme:FEATURE_ID>1210000813</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000515</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827876</fme:EASTING>
<fme:NORTHING>823745</fme:NORTHING>
<fme:ENGLISHNAME>Mount Haven Block 6</fme:ENGLISHNAME>
<fme:CHINESENAME>曉峰園第６座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823745.00000 827876.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd0ae5447-841a-41a5-9a1c-9cef629a26f3">
<fme:FEATURE_ID>1210000700</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000541</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828348</fme:EASTING>
<fme:NORTHING>823745</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823745.00000 828348.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7f78897e-07be-4465-bf12-343cd45ee252">
<fme:FEATURE_ID>1210070684</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000539</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828564</fme:EASTING>
<fme:NORTHING>823745</fme:NORTHING>
<fme:ENGLISHNAME>49</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654147</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823745.00000 828564.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id498073f9-3083-4283-9659-b0c75a04291a">
<fme:FEATURE_ID>1210071173</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000539</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828569</fme:EASTING>
<fme:NORTHING>823747</fme:NORTHING>
<fme:ENGLISHNAME>50</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654148</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823747.00000 828569.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id38c1d95a-296e-4009-966a-c59f8ced1b0b">
<fme:FEATURE_ID>1210070651</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000540</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828597</fme:EASTING>
<fme:NORTHING>823747</fme:NORTHING>
<fme:ENGLISHNAME>37</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654163</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823747.00000 828597.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id87c09697-72a5-4813-93da-b8c333ed9594">
<fme:FEATURE_ID>1210185598</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210050864</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828805</fme:EASTING>
<fme:NORTHING>823747</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810055270</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12429</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823747.00000 828805.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id04d1b656-69cc-484b-a650-f118c9b80f63">
<fme:FEATURE_ID>1210067866</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000530</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828382</fme:EASTING>
<fme:NORTHING>823748</fme:NORTHING>
<fme:ENGLISHNAME>19</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653722</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823748.00000 828382.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6b4e7df4-cd8a-43a1-ae20-7599c9a5d661">
<fme:FEATURE_ID>1210068468</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000536</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828399</fme:EASTING>
<fme:NORTHING>823748</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653887</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823748.00000 828399.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2f02178d-64d5-43a4-a0fe-4b90c02c8048">
<fme:FEATURE_ID>1210068968</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000538</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828418</fme:EASTING>
<fme:NORTHING>823749</fme:NORTHING>
<fme:ENGLISHNAME>4</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653946</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823749.00000 828418.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbf5edb44-b3aa-4f04-a1cd-34ac19ce6f35">
<fme:FEATURE_ID>1210067869</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000528</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828366</fme:EASTING>
<fme:NORTHING>823750</fme:NORTHING>
<fme:ENGLISHNAME>32</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653703</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823750.00000 828366.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida9cae94a-e05a-4931-b666-0c6805e8599c">
<fme:FEATURE_ID>1210070665</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000534</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828578</fme:EASTING>
<fme:NORTHING>823750</fme:NORTHING>
<fme:ENGLISHNAME>51</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654153</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823750.00000 828578.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc514704c-a1f2-49ec-82ae-0e1d8f2a0feb">
<fme:FEATURE_ID>1210068463</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000536</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828401</fme:EASTING>
<fme:NORTHING>823751</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653895</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823751.00000 828401.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id75037b2b-5d32-4b15-98a4-2bf92e56b711">
<fme:FEATURE_ID>1210178056</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210050803</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828722</fme:EASTING>
<fme:NORTHING>823751</fme:NORTHING>
<fme:ENGLISHNAME>Greenview Villa Tower 1</fme:ENGLISHNAME>
<fme:CHINESENAME>綠悠雅苑第一座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>82186</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823751.00000 828722.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3dca9954-c25e-43df-9934-f77c01a81788">
<fme:FEATURE_ID>1210071201</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000534</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828584</fme:EASTING>
<fme:NORTHING>823752</fme:NORTHING>
<fme:ENGLISHNAME>52</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654156</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823752.00000 828584.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id21213c18-9f8a-4b91-bdf1-d19a90d22aa5">
<fme:FEATURE_ID>1210019243</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000535</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829082</fme:EASTING>
<fme:NORTHING>823752</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Sewage P/Stn Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣污水處理站變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823752.00000 829082.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0f4e663f-13a3-44c3-a226-dc52cee20f9e">
<fme:FEATURE_ID>1210000920</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000526</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829229</fme:EASTING>
<fme:NORTHING>823752</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 8</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第八座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823752.00000 829229.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id92c36c13-9371-4904-8c4b-3d674fce886c">
<fme:FEATURE_ID>1210068438</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000530</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828383</fme:EASTING>
<fme:NORTHING>823754</fme:NORTHING>
<fme:ENGLISHNAME>20</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653851</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823754.00000 828383.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfbe654ef-9b78-4532-82d0-05eb6e0a934c">
<fme:FEATURE_ID>1210070680</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000531</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828594</fme:EASTING>
<fme:NORTHING>823755</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654159</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68319</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823755.00000 828594.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcb69a3e9-9cc5-46fa-9cb0-edd739c3793d">
<fme:FEATURE_ID>1210067314</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000528</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828367</fme:EASTING>
<fme:NORTHING>823756</fme:NORTHING>
<fme:ENGLISHNAME>33</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653705</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823756.00000 828367.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7c19f2d4-8c91-4b84-973a-4406c0b1af57">
<fme:FEATURE_ID>1310207140</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1310100386</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829811</fme:EASTING>
<fme:NORTHING>823756</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1910088506</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>13992</fme:ST_CODE>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823756.00000 829811.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd858df2e-4eb3-4490-ab90-8f745d9385c5">
<fme:FEATURE_ID>1210069006</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000525</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828420</fme:EASTING>
<fme:NORTHING>823759</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653954</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823759.00000 828420.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbfcfe8a7-ae1c-4fda-b25a-6e231745f8f6">
<fme:FEATURE_ID>1210019244</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000524</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829077</fme:EASTING>
<fme:NORTHING>823760</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Sewage Pumping Station</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣污水泵房</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823760.00000 829077.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc53246d4-c3f1-485b-ba21-a8d25423c9ee">
<fme:FEATURE_ID>1210067309</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000528</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828368</fme:EASTING>
<fme:NORTHING>823761</fme:NORTHING>
<fme:ENGLISHNAME>34</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653707</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823761.00000 828368.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf2158d6e-b676-46cb-960b-35d8568165a7">
<fme:FEATURE_ID>1210068446</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000522</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828399</fme:EASTING>
<fme:NORTHING>823763</fme:NORTHING>
<fme:ENGLISHNAME>13</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653888</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823763.00000 828399.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc9c2de2c-a545-457a-8b69-808fbc052d0a">
<fme:FEATURE_ID>1210068434</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000517</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828385</fme:EASTING>
<fme:NORTHING>823764</fme:NORTHING>
<fme:ENGLISHNAME>21</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653857</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823764.00000 828385.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id98beefb9-1d83-4bdf-88f4-1486b70ca4d6">
<fme:FEATURE_ID>1210068969</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000525</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828421</fme:EASTING>
<fme:NORTHING>823765</fme:NORTHING>
<fme:ENGLISHNAME>6</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653958</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823765.00000 828421.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5dacef84-4d3c-498b-9ea5-d717df99fc0a">
<fme:FEATURE_ID>1210000776</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000519</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829257</fme:EASTING>
<fme:NORTHING>823766</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 9</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第九座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823766.00000 829257.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3ec28c91-a41c-40d8-9107-3072ba49fef2">
<fme:FEATURE_ID>1210068462</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000517</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828386</fme:EASTING>
<fme:NORTHING>823769</fme:NORTHING>
<fme:ENGLISHNAME>22</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653858</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823769.00000 828386.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0051ad22-93a4-4bde-908f-b58c1be6cd33">
<fme:FEATURE_ID>1210068469</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000522</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828399</fme:EASTING>
<fme:NORTHING>823769</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653889</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823769.00000 828399.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide1228dd8-bcb1-438e-a6d1-311d69b7cf4c">
<fme:FEATURE_ID>1210168660</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000523</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828472</fme:EASTING>
<fme:NORTHING>823771</fme:NORTHING>
<fme:ENGLISHNAME>Tigerhead Resite Vill Ph2 Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>老虎頭村二期變電站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823771.00000 828472.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id43dd298c-92a6-4fcd-bea5-69c7dfab4272">
<fme:FEATURE_ID>1210180388</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000521</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828513</fme:EASTING>
<fme:NORTHING>823773</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>青衣四村村公所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823773.00000 828513.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide8974b74-81ef-4f59-836b-75f4a534fc19">
<fme:FEATURE_ID>1210067885</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000517</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828387</fme:EASTING>
<fme:NORTHING>823775</fme:NORTHING>
<fme:ENGLISHNAME>23</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653860</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823775.00000 828387.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0bb77e81-b195-41a7-9dff-a1532a15399c">
<fme:FEATURE_ID>1210040750</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000522</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828400</fme:EASTING>
<fme:NORTHING>823775</fme:NORTHING>
<fme:ENGLISHNAME>14A</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653893</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12439</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823775.00000 828400.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id96c17227-a63d-4fee-b0ef-588ef5994edf">
<fme:FEATURE_ID>1210000980</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000516</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829332</fme:EASTING>
<fme:NORTHING>823776</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 11</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第十一座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823776.00000 829332.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2c62cef3-750d-4f10-a89c-401b7644d15c">
<fme:FEATURE_ID>1210068989</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000514</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828421</fme:EASTING>
<fme:NORTHING>823778</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653959</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823778.00000 828421.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id72aec3c3-f91d-4b2a-9ad7-2a96c7a20778">
<fme:FEATURE_ID>1210068428</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000517</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828388</fme:EASTING>
<fme:NORTHING>823781</fme:NORTHING>
<fme:ENGLISHNAME>24</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653864</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64052</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823781.00000 828388.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id224a94a1-8aac-4cb1-a5b2-17c149abe6ab">
<fme:FEATURE_ID>1210069016</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000514</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828424</fme:EASTING>
<fme:NORTHING>823784</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653969</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823784.00000 828424.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id75e5b071-44f7-41e0-9660-3227840a34b6">
<fme:FEATURE_ID>1210069543</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000513</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828406</fme:EASTING>
<fme:NORTHING>823788</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653909</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823788.00000 828406.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc943d7f7-a820-464e-87dd-db38c818254a">
<fme:FEATURE_ID>1210069546</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000514</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828427</fme:EASTING>
<fme:NORTHING>823788</fme:NORTHING>
<fme:ENGLISHNAME>3</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653980</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823788.00000 828427.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddc81d0b7-0d77-467d-8053-8aa7f0c37866">
<fme:FEATURE_ID>1210000620</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000509</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828156</fme:EASTING>
<fme:NORTHING>823789</fme:NORTHING>
<fme:ENGLISHNAME>Hang Chui House</fme:ENGLISHNAME>
<fme:CHINESENAME>亨翠樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75567</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823789.00000 828156.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc2161e71-54eb-4b04-ae89-801968f0322e">
<fme:FEATURE_ID>1210071197</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000510</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828520</fme:EASTING>
<fme:NORTHING>823789</fme:NORTHING>
<fme:ENGLISHNAME>1</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654124</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823789.00000 828520.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7ee8eafc-9f8c-420b-be9d-aa0a361858c2">
<fme:FEATURE_ID>1210162284</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001066</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827960</fme:EASTING>
<fme:NORTHING>823792</fme:NORTHING>
<fme:ENGLISHNAME>3</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1810000334</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>11243</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823792.00000 827960.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb1d7a2b5-c67f-4271-97fa-f1ddd3eeaa93">
<fme:FEATURE_ID>1210069017</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000513</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828408</fme:EASTING>
<fme:NORTHING>823792</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653916</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823792.00000 828408.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1e43450c-950f-4c29-ab5a-b015b3300e2c">
<fme:FEATURE_ID>1210068972</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000514</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828430</fme:EASTING>
<fme:NORTHING>823794</fme:NORTHING>
<fme:ENGLISHNAME>4</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653989</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823794.00000 828430.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddc8e6570-0187-4d68-a1b7-83b25a905493">
<fme:FEATURE_ID>1210071174</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000510</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828522</fme:EASTING>
<fme:NORTHING>823794</fme:NORTHING>
<fme:ENGLISHNAME>2</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654127</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823794.00000 828522.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5b2a2b36-f750-440e-8446-f0fcfb87dbad">
<fme:FEATURE_ID>1210000878</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000512</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827975</fme:EASTING>
<fme:NORTHING>823795</fme:NORTHING>
<fme:ENGLISHNAME>Mount Haven Block 2</fme:ENGLISHNAME>
<fme:CHINESENAME>曉峰園第２座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823795.00000 827975.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4ff4aac8-7729-417b-a084-8c80562724d0">
<fme:FEATURE_ID>1210068990</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000513</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828412</fme:EASTING>
<fme:NORTHING>823797</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653927</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823797.00000 828412.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6111a830-05a1-4e05-ae35-795190e55492">
<fme:FEATURE_ID>1210071190</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000505</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828504</fme:EASTING>
<fme:NORTHING>823798</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654104</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823798.00000 828504.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id812b242d-af11-49c4-bac5-a71bf5c2d6cf">
<fme:FEATURE_ID>1210070688</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000510</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828525</fme:EASTING>
<fme:NORTHING>823800</fme:NORTHING>
<fme:ENGLISHNAME>3</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654131</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823800.00000 828525.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id946e285e-775b-464b-a92c-25ed6282858c">
<fme:FEATURE_ID>1210069567</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000502</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828435</fme:EASTING>
<fme:NORTHING>823802</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653999</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823802.00000 828435.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id58fc528a-80b6-449d-a558-daf875713739">
<fme:FEATURE_ID>1210000621</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000507</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829321</fme:EASTING>
<fme:NORTHING>823802</fme:NORTHING>
<fme:ENGLISHNAME>Greenfield Garden Block 10</fme:ENGLISHNAME>
<fme:CHINESENAME>翠怡花園第十座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75573</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823802.00000 829321.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id09349a9a-9692-477a-a20e-c71f90249606">
<fme:FEATURE_ID>1210068964</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000513</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828415</fme:EASTING>
<fme:NORTHING>823803</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653937</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823803.00000 828415.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0d6d6ff9-87e2-483e-8273-80f244b122f6">
<fme:FEATURE_ID>1210070661</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000505</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828507</fme:EASTING>
<fme:NORTHING>823803</fme:NORTHING>
<fme:ENGLISHNAME>6</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654108</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823803.00000 828507.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaff1d869-b6cb-4284-8768-2b69e0dee2cf">
<fme:FEATURE_ID>1210000731</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000506</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828853</fme:EASTING>
<fme:NORTHING>823804</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Garden Block 3</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡花園第三座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823804.00000 828853.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbbed1782-c759-403c-932a-2387790ec7ca">
<fme:FEATURE_ID>1210071182</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000510</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828528</fme:EASTING>
<fme:NORTHING>823805</fme:NORTHING>
<fme:ENGLISHNAME>4</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654137</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823805.00000 828528.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5395ff48-abde-4e08-b7bf-65a688b2bd7b">
<fme:FEATURE_ID>1210070111</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000500</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828488</fme:EASTING>
<fme:NORTHING>823806</fme:NORTHING>
<fme:ENGLISHNAME>13</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654083</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823806.00000 828488.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8a0ce4c1-661d-427e-a00d-56f4e65bcc5b">
<fme:FEATURE_ID>1210070129</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000502</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828438</fme:EASTING>
<fme:NORTHING>823807</fme:NORTHING>
<fme:ENGLISHNAME>6</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654009</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823807.00000 828438.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id772e6c88-aee1-4984-9f87-d2a74332d719">
<fme:FEATURE_ID>1210000880</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000511</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828389</fme:EASTING>
<fme:NORTHING>823808</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823808.00000 828389.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaef083fe-ffd7-43c1-b2a5-c0f87972792e">
<fme:FEATURE_ID>1210070683</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000505</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828510</fme:EASTING>
<fme:NORTHING>823808</fme:NORTHING>
<fme:ENGLISHNAME>7</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654113</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823808.00000 828510.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8cb5adba-286b-4d4a-b9b6-a28868d331af">
<fme:FEATURE_ID>1210000807</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000503</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828892</fme:EASTING>
<fme:NORTHING>823808</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Garden Block 4</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡花園第四座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823808.00000 828892.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5a6a9310-c9aa-4165-b689-95797d4fd266">
<fme:FEATURE_ID>1210069549</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000498</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828419</fme:EASTING>
<fme:NORTHING>823811</fme:NORTHING>
<fme:ENGLISHNAME>13</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653950</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823811.00000 828419.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddac3d870-3ba8-42dd-bdeb-8f47c6a5df7f">
<fme:FEATURE_ID>1210070100</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000500</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828491</fme:EASTING>
<fme:NORTHING>823811</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654087</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823811.00000 828491.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idaac840f1-b12b-4d0e-934f-2c26ff10c940">
<fme:FEATURE_ID>1210070137</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000502</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828441</fme:EASTING>
<fme:NORTHING>823812</fme:NORTHING>
<fme:ENGLISHNAME>7</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654015</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823812.00000 828441.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0066c1b3-01c7-489c-be77-b318939eb69e">
<fme:FEATURE_ID>1210000582</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000501</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827891</fme:EASTING>
<fme:NORTHING>823813</fme:NORTHING>
<fme:ENGLISHNAME>Mount Haven Block 5</fme:ENGLISHNAME>
<fme:CHINESENAME>曉峰園第５座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823813.00000 827891.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide2f49829-6c4b-48b0-b909-9da579a0365a">
<fme:FEATURE_ID>1210071199</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000505</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828513</fme:EASTING>
<fme:NORTHING>823813</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654117</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823813.00000 828513.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbfb2d5fb-46bf-4f55-82bf-a326bbb4da2b">
<fme:FEATURE_ID>1210070089</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000496</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828473</fme:EASTING>
<fme:NORTHING>823814</fme:NORTHING>
<fme:ENGLISHNAME>25</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654065</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823814.00000 828473.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd8f2b89c-fbc0-468e-957c-3ad34f6723fa">
<fme:FEATURE_ID>1210069015</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000498</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828422</fme:EASTING>
<fme:NORTHING>823816</fme:NORTHING>
<fme:ENGLISHNAME>14</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653962</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823816.00000 828422.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6aea93b9-4ded-407a-aeb5-78fffed73d97">
<fme:FEATURE_ID>1210070105</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000502</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828444</fme:EASTING>
<fme:NORTHING>823817</fme:NORTHING>
<fme:ENGLISHNAME>8</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654024</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823817.00000 828444.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id291920fe-f302-470b-af19-beda2cfe13b6">
<fme:FEATURE_ID>1210070101</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000500</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828495</fme:EASTING>
<fme:NORTHING>823817</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654093</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823817.00000 828495.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8e4904a1-3bbc-4a33-9159-f39dd5591c6b">
<fme:FEATURE_ID>1210000973</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000499</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827942</fme:EASTING>
<fme:NORTHING>823818</fme:NORTHING>
<fme:ENGLISHNAME>Mount Haven Block 3</fme:ENGLISHNAME>
<fme:CHINESENAME>曉峰園第３座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76433</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823818.00000 827942.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idefd4294e-5088-4f0b-92d0-87cb75f911dc">
<fme:FEATURE_ID>1210000958</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000497</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828824</fme:EASTING>
<fme:NORTHING>823819</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Garden Block 2</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡花園第二座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823819.00000 828824.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0acf6e2c-e661-4f6a-943d-8524d8366757">
<fme:FEATURE_ID>1210069527</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000493</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828404</fme:EASTING>
<fme:NORTHING>823820</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653904</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823820.00000 828404.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida4375fb5-3e4d-49a7-aae9-287b00619800">
<fme:FEATURE_ID>1210070141</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000496</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828476</fme:EASTING>
<fme:NORTHING>823820</fme:NORTHING>
<fme:ENGLISHNAME>26</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654069</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823820.00000 828476.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id160c31aa-3641-4ac0-8128-495fa87a796f">
<fme:FEATURE_ID>1210068958</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000498</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828425</fme:EASTING>
<fme:NORTHING>823821</fme:NORTHING>
<fme:ENGLISHNAME>15</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653972</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823821.00000 828425.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4d347714-a99e-4a3d-a942-13aa73a6285e">
<fme:FEATURE_ID>1210071192</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000492</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828518</fme:EASTING>
<fme:NORTHING>823822</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654121</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823822.00000 828518.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id61250951-53a3-4ecb-b8a9-55f154c0e54e">
<fme:FEATURE_ID>1210069574</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000489</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828457</fme:EASTING>
<fme:NORTHING>823823</fme:NORTHING>
<fme:ENGLISHNAME>37</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654044</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823823.00000 828457.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0eb5f28d-6f4d-435d-a0ac-d962b0d68323">
<fme:FEATURE_ID>1210000919</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000494</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828671</fme:EASTING>
<fme:NORTHING>823823</fme:NORTHING>
<fme:ENGLISHNAME>Yee Kui House</fme:ENGLISHNAME>
<fme:CHINESENAME>宜居樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75418</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823823.00000 828671.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idda136655-2653-467e-901b-2c4df443c0dc">
<fme:FEATURE_ID>1210069548</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000493</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828407</fme:EASTING>
<fme:NORTHING>823825</fme:NORTHING>
<fme:ENGLISHNAME>19</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653913</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823825.00000 828407.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id822f88ea-2f0a-46c9-8acf-86fef01812d1">
<fme:FEATURE_ID>1210070140</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000496</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828479</fme:EASTING>
<fme:NORTHING>823825</fme:NORTHING>
<fme:ENGLISHNAME>27</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654073</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823825.00000 828479.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5487f78b-6cd2-4c10-8c2c-f97a83115734">
<fme:FEATURE_ID>1210069584</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000500</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828500</fme:EASTING>
<fme:NORTHING>823825</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654097</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823825.00000 828500.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id69df42b2-4667-4b10-8a40-f6701919de7e">
<fme:FEATURE_ID>1210069020</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000498</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828428</fme:EASTING>
<fme:NORTHING>823826</fme:NORTHING>
<fme:ENGLISHNAME>16</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653983</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823826.00000 828428.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id93f1a491-9b0a-4450-9e05-58dde109389f">
<fme:FEATURE_ID>1210071198</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000492</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828520</fme:EASTING>
<fme:NORTHING>823826</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654125</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823826.00000 828520.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9468d2b3-adb7-4fa4-af22-8a1e88cfa021">
<fme:FEATURE_ID>1210069582</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000489</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828460</fme:EASTING>
<fme:NORTHING>823828</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654049</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823828.00000 828460.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd4b838a5-b1df-463f-af0f-5c7995a377cc">
<fme:FEATURE_ID>1210068980</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000493</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828410</fme:EASTING>
<fme:NORTHING>823829</fme:NORTHING>
<fme:ENGLISHNAME>20</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653921</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823829.00000 828410.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida6453810-9202-499a-bc2a-d326b62ab47d">
<fme:FEATURE_ID>1210071181</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000487</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828502</fme:EASTING>
<fme:NORTHING>823830</fme:NORTHING>
<fme:ENGLISHNAME>17</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654102</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823830.00000 828502.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id224e19ca-435e-47f9-b874-ea4963856edf">
<fme:FEATURE_ID>1210069569</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000496</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828482</fme:EASTING>
<fme:NORTHING>823831</fme:NORTHING>
<fme:ENGLISHNAME>28</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654077</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823831.00000 828482.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id932ca776-58f0-452b-8d77-36c9d58296ac">
<fme:FEATURE_ID>1210070641</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000486</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828442</fme:EASTING>
<fme:NORTHING>823832</fme:NORTHING>
<fme:ENGLISHNAME>49</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654021</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823832.00000 828442.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1640e442-415f-427e-b279-5b1a175a0eb5">
<fme:FEATURE_ID>1210070674</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000492</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828524</fme:EASTING>
<fme:NORTHING>823832</fme:NORTHING>
<fme:ENGLISHNAME>11</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654129</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823832.00000 828524.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf8aab434-7c35-4465-85c3-7ecb306d7954">
<fme:FEATURE_ID>1210001050</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000491</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829131</fme:EASTING>
<fme:NORTHING>823832</fme:NORTHING>
<fme:ENGLISHNAME>Serene Garden Block 1</fme:ENGLISHNAME>
<fme:CHINESENAME>海悅花園第一座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823832.00000 829131.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id773fd3eb-5078-4dbc-b788-0d2ef855fbbd">
<fme:FEATURE_ID>1210069580</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000489</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828463</fme:EASTING>
<fme:NORTHING>823834</fme:NORTHING>
<fme:ENGLISHNAME>39</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654052</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823834.00000 828463.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5da30217-c3e3-407e-8038-85bdc4725928">
<fme:FEATURE_ID>1210069013</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000493</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828413</fme:EASTING>
<fme:NORTHING>823835</fme:NORTHING>
<fme:ENGLISHNAME>21</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653929</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64051</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823835.00000 828413.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfcad5f99-951c-47eb-b198-20f3a9a06a22">
<fme:FEATURE_ID>1210070645</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000487</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828505</fme:EASTING>
<fme:NORTHING>823835</fme:NORTHING>
<fme:ENGLISHNAME>18</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654106</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823835.00000 828505.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6125c434-6092-46a3-ab9f-949deb42558c">
<fme:FEATURE_ID>1210000960</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000488</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829165</fme:EASTING>
<fme:NORTHING>823835</fme:NORTHING>
<fme:ENGLISHNAME>Serene Garden Block 2</fme:ENGLISHNAME>
<fme:CHINESENAME>海悅花園第二座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823835.00000 829165.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida605ae94-2c25-4fad-9354-b72f676344a4">
<fme:FEATURE_ID>1210069572</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000486</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828445</fme:EASTING>
<fme:NORTHING>823837</fme:NORTHING>
<fme:ENGLISHNAME>50</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654026</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823837.00000 828445.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf18a050a-5b74-43cf-aba1-6b82d1f9e3a2">
<fme:FEATURE_ID>1210071189</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000492</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828526</fme:EASTING>
<fme:NORTHING>823837</fme:NORTHING>
<fme:ENGLISHNAME>12</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654132</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823837.00000 828526.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8186eddc-1050-4231-a0a4-d8debf903a21">
<fme:FEATURE_ID>1210070086</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000489</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828467</fme:EASTING>
<fme:NORTHING>823839</fme:NORTHING>
<fme:ENGLISHNAME>40</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654057</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823839.00000 828467.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id67ae9583-0121-479a-b6f7-3d979a1946b6">
<fme:FEATURE_ID>1210180390</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000485</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829203</fme:EASTING>
<fme:NORTHING>823839</fme:NORTHING>
<fme:ENGLISHNAME>Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>海悅花園商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823839.00000 829203.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1a409d59-d63d-43f7-a0ad-b4c4a0b5b273">
<fme:FEATURE_ID>1210070654</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000487</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828508</fme:EASTING>
<fme:NORTHING>823841</fme:NORTHING>
<fme:ENGLISHNAME>19</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654111</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823841.00000 828508.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5dc143ed-f005-43fc-90c2-ec794238902b">
<fme:FEATURE_ID>1210070107</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000486</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828448</fme:EASTING>
<fme:NORTHING>823843</fme:NORTHING>
<fme:ENGLISHNAME>51</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654033</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823843.00000 828448.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0aa4a249-7ab1-4ea5-9259-10b0043b574c">
<fme:FEATURE_ID>1210068445</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000480</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828397</fme:EASTING>
<fme:NORTHING>823846</fme:NORTHING>
<fme:ENGLISHNAME>79</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653881</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823846.00000 828397.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2264f771-eb8e-4cad-aad3-1ecdf5bc5b57">
<fme:FEATURE_ID>1210071191</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000487</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828511</fme:EASTING>
<fme:NORTHING>823846</fme:NORTHING>
<fme:ENGLISHNAME>20</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654114</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823846.00000 828511.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1c04949a-7fbb-44df-8e30-07b692a5c2cd">
<fme:FEATURE_ID>1210070136</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000486</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828451</fme:EASTING>
<fme:NORTHING>823847</fme:NORTHING>
<fme:ENGLISHNAME>52</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654039</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823847.00000 828451.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3377c8c8-0ba6-4fa9-8988-f591422b8f68">
<fme:FEATURE_ID>1210070143</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000479</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828472</fme:EASTING>
<fme:NORTHING>823848</fme:NORTHING>
<fme:ENGLISHNAME>41</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654063</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823848.00000 828472.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb33329cf-3249-42ac-9ef9-b507e0536d1a">
<fme:FEATURE_ID>1210069562</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000478</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828492</fme:EASTING>
<fme:NORTHING>823848</fme:NORTHING>
<fme:ENGLISHNAME>29</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654088</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823848.00000 828492.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9eb3f222-bf9a-4fee-b1a6-a260ec147366">
<fme:FEATURE_ID>1210002380</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000484</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828941</fme:EASTING>
<fme:NORTHING>823849</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Garden Block 5</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡花園第五座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823849.00000 828941.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8ee6ad6e-e1e0-4aae-8e6f-a97bbec94a84">
<fme:FEATURE_ID>1210068444</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000480</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828399</fme:EASTING>
<fme:NORTHING>823850</fme:NORTHING>
<fme:ENGLISHNAME>80</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653890</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823850.00000 828399.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id2abfdc58-c895-48ca-9f76-8695af847fdb">
<fme:FEATURE_ID>1210068997</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000483</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828433</fme:EASTING>
<fme:NORTHING>823851</fme:NORTHING>
<fme:ENGLISHNAME>61</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653993</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823851.00000 828433.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6a2737b7-3335-409c-a125-d20eab094419">
<fme:FEATURE_ID>1210069563</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000479</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828474</fme:EASTING>
<fme:NORTHING>823852</fme:NORTHING>
<fme:ENGLISHNAME>42</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654068</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823852.00000 828474.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id1e58fb9a-1c3f-4862-bd71-6f9db0c9b3e5">
<fme:FEATURE_ID>1210002602</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000481</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828804</fme:EASTING>
<fme:NORTHING>823852</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Garden Block 1</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡花園第一座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823852.00000 828804.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcf26e471-6fd4-4ab7-bb1e-1ffd1f635870">
<fme:FEATURE_ID>1210070130</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000478</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828495</fme:EASTING>
<fme:NORTHING>823854</fme:NORTHING>
<fme:ENGLISHNAME>30</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654094</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823854.00000 828495.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbc1b118b-126c-4e71-8fed-4620d72626ef">
<fme:FEATURE_ID>1210068983</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000480</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828403</fme:EASTING>
<fme:NORTHING>823856</fme:NORTHING>
<fme:ENGLISHNAME>81</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653900</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823856.00000 828403.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id84590218-0364-4510-9d28-4e8f67dd3524">
<fme:FEATURE_ID>1210070099</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000483</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828436</fme:EASTING>
<fme:NORTHING>823856</fme:NORTHING>
<fme:ENGLISHNAME>62</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654000</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823856.00000 828436.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id078b32f5-14b7-483c-b2fe-23fe379f26a5">
<fme:FEATURE_ID>1210071177</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000476</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828518</fme:EASTING>
<fme:NORTHING>823858</fme:NORTHING>
<fme:ENGLISHNAME>21</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654122</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823858.00000 828518.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd40b98b9-cf82-4217-88f2-d61875aa322b">
<fme:FEATURE_ID>1210069575</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000479</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828477</fme:EASTING>
<fme:NORTHING>823859</fme:NORTHING>
<fme:ENGLISHNAME>43</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654072</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823859.00000 828477.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id14609718-4a95-4f32-a94b-0c2c70e7d810">
<fme:FEATURE_ID>1210069558</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000480</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828406</fme:EASTING>
<fme:NORTHING>823861</fme:NORTHING>
<fme:ENGLISHNAME>82</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653910</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823861.00000 828406.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id55ab26d0-3917-4a7e-bb2a-a03bfeb7b3be">
<fme:FEATURE_ID>1210070138</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000478</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828501</fme:EASTING>
<fme:NORTHING>823862</fme:NORTHING>
<fme:ENGLISHNAME>31</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654098</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823862.00000 828501.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida2a59e94-07ed-48ff-a82a-b742b5fd1eeb">
<fme:FEATURE_ID>1210070094</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000471</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828459</fme:EASTING>
<fme:NORTHING>823863</fme:NORTHING>
<fme:ENGLISHNAME>53</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654047</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823863.00000 828459.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb8ce4fcd-4181-48c3-803b-6e1d0d6980f0">
<fme:FEATURE_ID>1210070090</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000479</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828480</fme:EASTING>
<fme:NORTHING>823863</fme:NORTHING>
<fme:ENGLISHNAME>44</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654075</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823863.00000 828480.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6ecbc093-c007-48e4-bc26-64d2f8ffd610">
<fme:FEATURE_ID>1210071203</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000476</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828521</fme:EASTING>
<fme:NORTHING>823863</fme:NORTHING>
<fme:ENGLISHNAME>22</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654126</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823863.00000 828521.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id87454f89-de78-4e3d-add5-b75407640206">
<fme:FEATURE_ID>1210002384</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000482</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828378</fme:EASTING>
<fme:NORTHING>823864</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>鄧氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823864.00000 828378.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfeb4aa00-2131-47d3-b0c0-b402ed97393e">
<fme:FEATURE_ID>1210070144</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000470</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828440</fme:EASTING>
<fme:NORTHING>823864</fme:NORTHING>
<fme:ENGLISHNAME>63</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654012</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823864.00000 828440.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8271cc5f-1933-49cf-b7fb-d3abbd850428">
<fme:FEATURE_ID>1210068961</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000469</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828420</fme:EASTING>
<fme:NORTHING>823865</fme:NORTHING>
<fme:ENGLISHNAME>71</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653955</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823865.00000 828420.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id467144d5-9a2e-4e5c-9e98-7e6fb8d9ef71">
<fme:FEATURE_ID>1210070669</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000478</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828501</fme:EASTING>
<fme:NORTHING>823865</fme:NORTHING>
<fme:ENGLISHNAME>32</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654099</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823865.00000 828501.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7a5dd51c-6ca3-43ca-920e-366e09a35eae">
<fme:FEATURE_ID>1210001019</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000467</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828628</fme:EASTING>
<fme:NORTHING>823867</fme:NORTHING>
<fme:ENGLISHNAME>Tsuen Wan Trade Association Primary School</fme:ENGLISHNAME>
<fme:CHINESENAME>荃灣商會學校</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75418</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823867.00000 828628.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8723c610-1c7d-4648-b27d-89c9090d787b">
<fme:FEATURE_ID>1210070642</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000471</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828462</fme:EASTING>
<fme:NORTHING>823868</fme:NORTHING>
<fme:ENGLISHNAME>54</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654051</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823868.00000 828462.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf94600e9-0f0c-4e3e-88b1-5d403c77d02e">
<fme:FEATURE_ID>1210070660</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000476</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828524</fme:EASTING>
<fme:NORTHING>823869</fme:NORTHING>
<fme:ENGLISHNAME>23</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654130</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823869.00000 828524.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf0f3e7c0-d98e-46ae-a6b4-0d75a6a462a8">
<fme:FEATURE_ID>1210070133</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000470</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828443</fme:EASTING>
<fme:NORTHING>823870</fme:NORTHING>
<fme:ENGLISHNAME>64</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654023</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823870.00000 828443.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5625edbd-a5b6-49ae-933c-ccfdc649eb7a">
<fme:FEATURE_ID>1210068996</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000469</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828423</fme:EASTING>
<fme:NORTHING>823871</fme:NORTHING>
<fme:ENGLISHNAME>72</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653966</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823871.00000 828423.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idace795d5-b542-47c7-9e44-51b249e9ecf1">
<fme:FEATURE_ID>1210000971</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000472</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828891</fme:EASTING>
<fme:NORTHING>823871</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Garden Block 7</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡花園第七座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823871.00000 828891.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7064e3b4-8f2a-40f1-bf56-0931ba536a24">
<fme:FEATURE_ID>1210002360</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000477</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828381</fme:EASTING>
<fme:NORTHING>823872</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>陳氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823872.00000 828381.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4c918119-a2a6-48ac-a96d-1aa0c5637646">
<fme:FEATURE_ID>1210070679</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000463</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828505</fme:EASTING>
<fme:NORTHING>823873</fme:NORTHING>
<fme:ENGLISHNAME>33</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654107</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823873.00000 828505.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7cbc738a-4bf9-428a-9e0e-8638436fa605">
<fme:FEATURE_ID>1210068959</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000475</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828405</fme:EASTING>
<fme:NORTHING>823874</fme:NORTHING>
<fme:ENGLISHNAME>83</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653906</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823874.00000 828405.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id54d47965-f65f-46d3-8052-5efc2ffff209">
<fme:FEATURE_ID>1210070113</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000471</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828466</fme:EASTING>
<fme:NORTHING>823874</fme:NORTHING>
<fme:ENGLISHNAME>55</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654055</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823874.00000 828466.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc93dfd1a-b6c3-4b4f-b46a-126a62e96680">
<fme:FEATURE_ID>1210070671</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000476</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828527</fme:EASTING>
<fme:NORTHING>823874</fme:NORTHING>
<fme:ENGLISHNAME>24</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654134</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823874.00000 828527.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6b12197d-5c87-4121-9fc3-0f54eecb8310">
<fme:FEATURE_ID>1210070119</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000470</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828446</fme:EASTING>
<fme:NORTHING>823875</fme:NORTHING>
<fme:ENGLISHNAME>65</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654031</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823875.00000 828446.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id858bccd5-2cfb-4f02-a11f-a440afaee679">
<fme:FEATURE_ID>1210198180</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000468</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828694</fme:EASTING>
<fme:NORTHING>823875</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Carpark</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣停車場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823875.00000 828694.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idcc3a6f9f-372a-4dfa-91cc-1066ba0acee7">
<fme:FEATURE_ID>1210000915</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000460</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829197</fme:EASTING>
<fme:NORTHING>823875</fme:NORTHING>
<fme:ENGLISHNAME>Serene Garden Block 3</fme:ENGLISHNAME>
<fme:CHINESENAME>海悅花園第三座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75571</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823875.00000 829197.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id73c9af39-db51-4192-8185-b76b767a337d">
<fme:FEATURE_ID>1210068994</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000469</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828426</fme:EASTING>
<fme:NORTHING>823876</fme:NORTHING>
<fme:ENGLISHNAME>73</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653975</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823876.00000 828426.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id50057b20-1f9c-4db4-af6f-6eb0784831a1">
<fme:FEATURE_ID>1210000886</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000466</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828925</fme:EASTING>
<fme:NORTHING>823877</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Garden Block 6</fme:ENGLISHNAME>
<fme:CHINESENAME>青怡花園第六座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75570</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823877.00000 828925.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id86c9a5b0-c494-48b8-be86-8dc9f7865d1b">
<fme:FEATURE_ID>1210071185</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000463</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828508</fme:EASTING>
<fme:NORTHING>823878</fme:NORTHING>
<fme:ENGLISHNAME>34</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654112</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823878.00000 828508.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc69592dd-b7a0-41be-9187-82b8e366c586">
<fme:FEATURE_ID>1210070131</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000471</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828469</fme:EASTING>
<fme:NORTHING>823879</fme:NORTHING>
<fme:ENGLISHNAME>56</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654060</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823879.00000 828469.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbf7cdbe1-cfc6-4594-a4b1-d35bf13dc190">
<fme:FEATURE_ID>1210162854</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000001063</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828673</fme:EASTING>
<fme:NORTHING>823879</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653749</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>10582</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823879.00000 828673.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id83fbd7e8-bc83-487a-bf26-9328b94988e0">
<fme:FEATURE_ID>1210009172</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000474</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829272</fme:EASTING>
<fme:NORTHING>823880</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi New Ferry Terminus Public Toilet</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣新碼頭公廁</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823880.00000 829272.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf6c90546-2171-46a3-9082-d11538895b8b">
<fme:FEATURE_ID>1210069005</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000469</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828429</fme:EASTING>
<fme:NORTHING>823881</fme:NORTHING>
<fme:ENGLISHNAME>74</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653985</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823881.00000 828429.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id20db5d15-b027-4ff1-83bc-d0ab77e4da49">
<fme:FEATURE_ID>1210070085</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000470</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828450</fme:EASTING>
<fme:NORTHING>823881</fme:NORTHING>
<fme:ENGLISHNAME>66</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654037</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823881.00000 828450.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb723e087-7841-4a84-9d3e-03354bc3fe6f">
<fme:FEATURE_ID>1210070102</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000456</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828490</fme:EASTING>
<fme:NORTHING>823881</fme:NORTHING>
<fme:ENGLISHNAME>45</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654084</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823881.00000 828490.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id62760c45-db4c-4007-bc67-df6579621869">
<fme:FEATURE_ID>1210000959</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000473</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828385</fme:EASTING>
<fme:NORTHING>823883</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>鄧氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823883.00000 828385.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id51837a05-8a96-4635-af8d-c1f5a39f57e1">
<fme:FEATURE_ID>1210071176</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000463</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828512</fme:EASTING>
<fme:NORTHING>823883</fme:NORTHING>
<fme:ENGLISHNAME>35</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654116</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823883.00000 828512.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb8e50ac6-c5c3-441c-beec-d3fcde5a1647">
<fme:FEATURE_ID>1210068995</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000462</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828411</fme:EASTING>
<fme:NORTHING>823885</fme:NORTHING>
<fme:ENGLISHNAME>85</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653924</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823885.00000 828411.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida92f2d70-1c8b-465a-91ee-75623d487d31">
<fme:FEATURE_ID>1210070122</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000456</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828493</fme:EASTING>
<fme:NORTHING>823886</fme:NORTHING>
<fme:ENGLISHNAME>46</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654089</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823886.00000 828493.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idad7ed687-068e-4eff-ae7a-9f6876a72213">
<fme:FEATURE_ID>1210070104</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000455</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828473</fme:EASTING>
<fme:NORTHING>823887</fme:NORTHING>
<fme:ENGLISHNAME>57</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654066</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823887.00000 828473.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id09104c74-a41f-4c3f-9d71-b8aca4ea79ab">
<fme:FEATURE_ID>1210001086</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000447</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829015</fme:EASTING>
<fme:NORTHING>823888</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Municipal Services Building</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣市政大廈</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823888.00000 829015.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8b3bf6e1-b855-445d-95a0-5d4e2a7d763f">
<fme:FEATURE_ID>1210063999</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000447</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829015</fme:EASTING>
<fme:NORTHING>823888</fme:NORTHING>
<fme:ENGLISHNAME>38</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654316</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12429</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823888.00000 829015.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7e448e1b-92df-4321-a107-27dc3f83353f">
<fme:FEATURE_ID>1210068973</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000459</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828434</fme:EASTING>
<fme:NORTHING>823889</fme:NORTHING>
<fme:ENGLISHNAME>75</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653996</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823889.00000 828434.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6d67c71b-0fb9-4057-abb0-a355bc759ff7">
<fme:FEATURE_ID>1210070103</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000454</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828454</fme:EASTING>
<fme:NORTHING>823889</fme:NORTHING>
<fme:ENGLISHNAME>67</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654042</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823889.00000 828454.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="iddaf75638-7a0b-479d-b7eb-cba5362dff96">
<fme:FEATURE_ID>1210071208</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000463</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828515</fme:EASTING>
<fme:NORTHING>823889</fme:NORTHING>
<fme:ENGLISHNAME>36</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654118</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823889.00000 828515.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3fcecce3-dc38-4755-aa87-6d3f8095550a">
<fme:FEATURE_ID>1210068967</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000462</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828414</fme:EASTING>
<fme:NORTHING>823890</fme:NORTHING>
<fme:ENGLISHNAME>86</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653932</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823890.00000 828414.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3b5317bc-6753-4b20-9059-d8e55b6e3be7">
<fme:FEATURE_ID>1210070128</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000456</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828496</fme:EASTING>
<fme:NORTHING>823891</fme:NORTHING>
<fme:ENGLISHNAME>47</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654095</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823891.00000 828496.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd97a65aa-396e-4d19-899a-83c74be47630">
<fme:FEATURE_ID>1210000998</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000449</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828194</fme:EASTING>
<fme:NORTHING>823892</fme:NORTHING>
<fme:ENGLISHNAME>Hang Lai House</fme:ENGLISHNAME>
<fme:CHINESENAME>亨麗樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75567</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823892.00000 828194.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id57f1103f-7661-454d-bf62-566db202198f">
<fme:FEATURE_ID>1210001022</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000464</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828389</fme:EASTING>
<fme:NORTHING>823892</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>張氏家祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823892.00000 828389.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id27252c54-3812-4f6f-af8e-34422ae2a294">
<fme:FEATURE_ID>1210069573</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000455</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828476</fme:EASTING>
<fme:NORTHING>823893</fme:NORTHING>
<fme:ENGLISHNAME>58</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654070</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823893.00000 828476.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id17e657ca-3284-411d-a6cd-b8766f4110de">
<fme:FEATURE_ID>1210070088</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000459</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828437</fme:EASTING>
<fme:NORTHING>823894</fme:NORTHING>
<fme:ENGLISHNAME>76</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654004</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823894.00000 828437.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ide298e556-3f0f-4fd8-9dd5-c6d644ea2019">
<fme:FEATURE_ID>1210070132</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000454</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828457</fme:EASTING>
<fme:NORTHING>823894</fme:NORTHING>
<fme:ENGLISHNAME>68</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654045</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823894.00000 828457.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id13877450-37e1-4e75-8b9d-60cf16ed9cc2">
<fme:FEATURE_ID>1210070134</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000455</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828479</fme:EASTING>
<fme:NORTHING>823898</fme:NORTHING>
<fme:ENGLISHNAME>59</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654074</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823898.00000 828479.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id653073c1-8ec9-4331-b304-4307842b6286">
<fme:FEATURE_ID>1210069002</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000450</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828418</fme:EASTING>
<fme:NORTHING>823899</fme:NORTHING>
<fme:ENGLISHNAME>87</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653947</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823899.00000 828418.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id560873a8-da83-495b-902a-06d5d5390855">
<fme:FEATURE_ID>1210071178</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000456</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828501</fme:EASTING>
<fme:NORTHING>823899</fme:NORTHING>
<fme:ENGLISHNAME>48</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654100</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823899.00000 828501.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb0db441f-19c0-43fe-87c7-9e8a883bf0cb">
<fme:FEATURE_ID>1210070145</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000454</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828460</fme:EASTING>
<fme:NORTHING>823900</fme:NORTHING>
<fme:ENGLISHNAME>69</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654050</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823900.00000 828460.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida680fcbf-6a27-4146-8231-536ce3b4e034">
<fme:FEATURE_ID>1210000887</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000457</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828393</fme:EASTING>
<fme:NORTHING>823902</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>鄧氏宗祠</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823902.00000 828393.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idce35f36e-8e89-4bdb-a880-f755426e78e1">
<fme:FEATURE_ID>1210070087</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000453</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828441</fme:EASTING>
<fme:NORTHING>823902</fme:NORTHING>
<fme:ENGLISHNAME>77</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654016</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823902.00000 828441.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb6722816-2ed4-4e61-b0f0-08b321287f47">
<fme:FEATURE_ID>1210069532</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000450</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828421</fme:EASTING>
<fme:NORTHING>823903</fme:NORTHING>
<fme:ENGLISHNAME>88</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653960</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823903.00000 828421.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0239b2f8-b888-453f-888e-83efa46281b8">
<fme:FEATURE_ID>1210070121</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000455</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828483</fme:EASTING>
<fme:NORTHING>823903</fme:NORTHING>
<fme:ENGLISHNAME>60</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654078</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823903.00000 828483.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id59c1013a-e41e-49d1-8658-2abdc242412c">
<fme:FEATURE_ID>1210070092</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000454</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828463</fme:EASTING>
<fme:NORTHING>823905</fme:NORTHING>
<fme:ENGLISHNAME>70</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654053</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823905.00000 828463.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id5cbeafb5-904e-443a-8bc4-0e6f2d23e969">
<fme:FEATURE_ID>1210069579</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000453</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828444</fme:EASTING>
<fme:NORTHING>823906</fme:NORTHING>
<fme:ENGLISHNAME>78</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654025</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823906.00000 828444.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id4e890433-79aa-4591-86a5-191d77d48b08">
<fme:FEATURE_ID>1210069003</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000446</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828403</fme:EASTING>
<fme:NORTHING>823907</fme:NORTHING>
<fme:ENGLISHNAME>96</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653901</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823907.00000 828403.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id69732310-d47d-4dc2-b7c3-0c5fd759cd8a">
<fme:FEATURE_ID>1210069541</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000450</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828424</fme:EASTING>
<fme:NORTHING>823908</fme:NORTHING>
<fme:ENGLISHNAME>89</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653970</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823908.00000 828424.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7e3f8f46-6cb1-4a29-967f-26d1fc096c71">
<fme:FEATURE_ID>1210069537</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000446</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828406</fme:EASTING>
<fme:NORTHING>823912</fme:NORTHING>
<fme:ENGLISHNAME>97</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653911</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823912.00000 828406.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id824d65f1-b1d9-409b-b229-f624ad19e3d6">
<fme:FEATURE_ID>1210069018</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000450</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828427</fme:EASTING>
<fme:NORTHING>823914</fme:NORTHING>
<fme:ENGLISHNAME>90</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653981</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823914.00000 828427.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc544836e-5009-4b13-ad50-2d3add1b6446">
<fme:FEATURE_ID>1210069554</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000446</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828409</fme:EASTING>
<fme:NORTHING>823917</fme:NORTHING>
<fme:ENGLISHNAME>98</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653918</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823917.00000 828409.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idfed38a73-343e-4483-94bd-103c7fe05d8e">
<fme:FEATURE_ID>1210068998</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000446</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828412</fme:EASTING>
<fme:NORTHING>823923</fme:NORTHING>
<fme:ENGLISHNAME>99</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653928</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64049</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823923.00000 828412.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf1b05e4c-e1d7-45f3-806b-f3e0cfdc3600">
<fme:FEATURE_ID>1210062927</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000438</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828960</fme:EASTING>
<fme:NORTHING>823928</fme:NORTHING>
<fme:ENGLISHNAME>21</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654258</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12429</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823928.00000 828960.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id7d9ab8b6-4666-4515-9d6e-fc60c360680c">
<fme:FEATURE_ID>1420002292</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000438</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828960</fme:EASTING>
<fme:NORTHING>823928</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Town Family Medicine Clinic</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣市區家庭醫學診所</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20251015</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823928.00000 828960.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id6ec562e0-0c47-49c7-9648-238838c39f26">
<fme:FEATURE_ID>1210000594</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000444</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829197</fme:EASTING>
<fme:NORTHING>823931</fme:NORTHING>
<fme:ENGLISHNAME>Tivoli Garden Block 4</fme:ENGLISHNAME>
<fme:CHINESENAME>宏福花園第四座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823931.00000 829197.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id9aadf513-ea42-4837-b684-885d965d74d8">
<fme:FEATURE_ID>1210198181</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000439</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828685</fme:EASTING>
<fme:NORTHING>823932</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Shopping Centre</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣商場</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75418</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823932.00000 828685.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb7b7232e-f99e-437d-a6db-d94e7fb3d002">
<fme:FEATURE_ID>1210000780</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000422</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828629</fme:EASTING>
<fme:NORTHING>823940</fme:NORTHING>
<fme:ENGLISHNAME>Yee Yip House</fme:ENGLISHNAME>
<fme:CHINESENAME>宜業樓</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>75418</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823940.00000 828629.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0ac2f410-d79e-45ba-ba00-1a1f1d95be5f">
<fme:FEATURE_ID>1210067850</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000436</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828785</fme:EASTING>
<fme:NORTHING>823943</fme:NORTHING>
<fme:ENGLISHNAME>5</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653792</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12429</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823943.00000 828785.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id26054a26-e7c1-4756-b89c-b1300ec5afd1">
<fme:FEATURE_ID>1210000618</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000436</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828785</fme:EASTING>
<fme:NORTHING>823943</fme:NORTHING>
<fme:ENGLISHNAME>St. Thomas The Apostle Catholic Church</fme:ENGLISHNAME>
<fme:CHINESENAME>天主教聖多默宗徒堂</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823943.00000 828785.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idb7d824aa-3e79-4efa-b5ff-31fb5bed8310">
<fme:FEATURE_ID>1210000744</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000426</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829182</fme:EASTING>
<fme:NORTHING>823960</fme:NORTHING>
<fme:ENGLISHNAME>Tivoli Garden Block 3</fme:ENGLISHNAME>
<fme:CHINESENAME>宏福花園第三座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823960.00000 829182.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd8c1a55a-aa06-4fbb-ba88-efa88f43fa49">
<fme:FEATURE_ID>1210000623</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000428</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828040</fme:EASTING>
<fme:NORTHING>823963</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi North High Level Fresh Water &amp; Salt Water Pumping Station</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣北上食水及海水抽水站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823963.00000 828040.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc31d0a1f-048f-4310-95b1-73797b9f01d6">
<fme:FEATURE_ID>1210168659</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000430</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828065</fme:EASTING>
<fme:NORTHING>823968</fme:NORTHING>
<fme:ENGLISHNAME>TYN HI-LEVEL P/P STN</fme:ENGLISHNAME>
<fme:CHINESENAME>水務局青衣北泵房Ａ</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823968.00000 828065.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idbd6ab65d-2c04-4ca1-a29d-aa27ac797d12">
<fme:FEATURE_ID>1210069009</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154397</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828408</fme:EASTING>
<fme:NORTHING>823978</fme:NORTHING>
<fme:ENGLISHNAME>62</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653917</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64192</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823978.00000 828408.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idd1921fd8-fe43-455c-807f-9410f322e3a7">
<fme:FEATURE_ID>1210002348</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154414</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829029</fme:EASTING>
<fme:NORTHING>823981</fme:NORTHING>
<fme:ENGLISHNAME>Po Leung Kuk Castar Primary School</fme:ENGLISHNAME>
<fme:CHINESENAME>保良局世德小學</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823981.00000 829029.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idf4370f6d-0609-4314-9722-3510e8fb5445">
<fme:FEATURE_ID>1210063450</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154414</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829029</fme:EASTING>
<fme:NORTHING>823981</fme:NORTHING>
<fme:ENGLISHNAME>23</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654327</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>12429</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823981.00000 829029.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id334f4c1a-97f8-411c-ae16-4898dc4fe1f4">
<fme:FEATURE_ID>1210069535</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154397</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828411</fme:EASTING>
<fme:NORTHING>823982</fme:NORTHING>
<fme:ENGLISHNAME>61</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653925</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64192</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823982.00000 828411.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="ida850eb58-287a-441c-8ab2-aba6d0d71007">
<fme:FEATURE_ID>1210000699</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000418</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BDN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829152</fme:EASTING>
<fme:NORTHING>823984</fme:NORTHING>
<fme:ENGLISHNAME>Tivoli Garden Block 2</fme:ENGLISHNAME>
<fme:CHINESENAME>宏福花園第二座</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID/>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>76147</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823984.00000 829152.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id0df88468-89a2-4a5a-b3dd-60eec979d6c2">
<fme:FEATURE_ID>1210069534</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154397</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828415</fme:EASTING>
<fme:NORTHING>823987</fme:NORTHING>
<fme:ENGLISHNAME>60</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653938</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64192</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823987.00000 828415.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id8ecbe50a-dafa-4e44-acc0-1713950f404b">
<fme:FEATURE_ID>1210070125</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000419</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828436</fme:EASTING>
<fme:NORTHING>823989</fme:NORTHING>
<fme:ENGLISHNAME>25</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654001</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68253</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823989.00000 828436.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="idc8b47247-295c-4cf0-b669-b189074939b8">
<fme:FEATURE_ID>1210069547</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154397</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828419</fme:EASTING>
<fme:NORTHING>823991</fme:NORTHING>
<fme:ENGLISHNAME>59</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653951</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64192</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823991.00000 828419.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id548540fc-7bb5-4903-8cbb-3743e2e6db03">
<fme:FEATURE_ID>1210069587</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000000419</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828440</fme:EASTING>
<fme:NORTHING>823993</fme:NORTHING>
<fme:ENGLISHNAME>26</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654013</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68253</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823993.00000 828440.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id657ca0b5-0229-4e90-9f57-87c198cf9654">
<fme:FEATURE_ID>1210069011</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154397</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828423</fme:EASTING>
<fme:NORTHING>823996</fme:NORTHING>
<fme:ENGLISHNAME>58</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108653967</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>64192</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823996.00000 828423.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id940b6d7c-49fe-4100-a872-f6f924bbfb13">
<fme:FEATURE_ID>1210070117</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154402</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828466</fme:EASTING>
<fme:NORTHING>823996</fme:NORTHING>
<fme:ENGLISHNAME>9</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654056</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68253</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823996.00000 828466.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingsPoint gml:id="id3cf2bb95-666e-435b-b6e3-3419991491c1">
<fme:FEATURE_ID>1210070640</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000154402</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>ADR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828470</fme:EASTING>
<fme:NORTHING>823998</fme:NORTHING>
<fme:ENGLISHNAME>10</fme:ENGLISHNAME>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ADDR_ID>1108654061</fme:ADDR_ID>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ST_CODE>68253</fme:ST_CODE>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>823998.00000 828470.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingsPoint>
</gml:featureMember>
</gml:FeatureCollection>
