<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyLineAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820854.09003 827473.18911</gml:lowerCorner>
<gml:upperCorner>820943.42668 829729.90422</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id4678a9f6-e324-48fb-9e84-ef172c9c5507">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>7.86668928210847</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831876</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>828142.86062643</fme:EASTING>
<fme:NORTHING>820937.9642561</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820943.42668 828160.05585</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="id0c4aca20-238b-4958-a673-00f76ff0729f">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-64.1789941656726</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831875</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>827462.47049808</fme:EASTING>
<fme:NORTHING>820876.2417981</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820854.09003 827473.18911</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="ida806228b-d85c-4dba-aede-37be1d13d9a7">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Seawall</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.57631721468489</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000831874</fme:FEATURE_ID>
<fme:FEATURECODE>SEW</fme:FEATURECODE>
<fme:EASTING>829053.09098179</fme:EASTING>
<fme:NORTHING>820884.98972698</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820885.70430 829064.52416</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyLineAnno_E gml:id="idbb13b289-b37d-4cc5-aec2-4f5038c0b339">
<fme:AnnotationClassID>1</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>HWM</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>4.17102331458997</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1420000581</fme:FEATURE_ID>
<fme:FEATURECODE>HWM</fme:FEATURECODE>
<fme:EASTING>829729.904</fme:EASTING>
<fme:NORTHING>820924.256</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820924.25550 829729.90422</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyLineAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
