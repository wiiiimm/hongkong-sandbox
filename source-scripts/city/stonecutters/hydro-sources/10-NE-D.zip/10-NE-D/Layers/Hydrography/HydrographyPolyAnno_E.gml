<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydrographyPolyAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820970.60131 827850.51785</gml:lowerCorner>
<gml:upperCorner>820972.23232 827858.65205</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="idb17e07f6-f4ee-49ce-85fa-21415c6f4492">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>&lt;</fme:TextString>
<fme:FontName>HP5C</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-171.659188178892</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001274559</fme:FEATURE_ID>
<fme:FEATURECODE>DAD</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820970.60131 827850.51785</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:HydrographyPolyAnno_E gml:id="id2464ee6b-22a8-4cec-8883-e04ba247d10e">
<fme:AnnotationClassID>2</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Nullah</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>1</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-80.6969384623386</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000848222</fme:FEATURE_ID>
<fme:FEATURECODE>STO</fme:FEATURECODE>
<fme:EASTING>827853.29878992</fme:EASTING>
<fme:NORTHING>820985.99803572</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820972.23232 827858.65205</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:HydrographyPolyAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
