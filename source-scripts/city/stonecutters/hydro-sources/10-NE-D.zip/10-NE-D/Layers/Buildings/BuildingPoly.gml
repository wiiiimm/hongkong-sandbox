<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingPoly.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820797.73104 827448.71883 0.00000</gml:lowerCorner>
<gml:upperCorner>821000.00000 829186.92000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingPoly gml:id="id5d766a54-6a56-443f-8c0d-d99f8427538b">
<fme:FEATURE_ID>1000001143</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827777.48</fme:EASTING>
<fme:NORTHING>820804.68</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820811.97033 827791.00387 0.00000 820799.39672 827790.67824 0.00000 820799.37024 827763.49002 0.00000 820812.09076 827763.81946 0.00000 820811.93540 827769.81813 0.00000 820805.74609 827769.86856 0.00000 820805.40424 827783.06823 0.00000 820812.17131 827783.24348 0.00000 820811.97033 827791.00387 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id31f05977-6a17-4ee0-9337-0bdc1caee58e">
<fme:FEATURE_ID>1000001141</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829164.22</fme:EASTING>
<fme:NORTHING>820887.84</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820874.92000 829173.05000 0.00000 820873.91773 829157.25535 0.00000 820900.69000 829155.32000 0.00000 820901.75000 829171.26000 0.00000 820874.92000 829173.05000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id518707ab-4008-44d7-9f73-0aa6f4e51cb0">
<fme:FEATURE_ID>1000001138</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829149.4</fme:EASTING>
<fme:NORTHING>820936.79</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820925.83000 829155.87000 0.00000 820925.05000 829144.44000 0.00000 820947.74000 829142.92000 0.00000 820948.52829 829154.37914 0.00000 820925.83000 829155.87000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id22234bf7-23ea-49a4-a60b-f57a4a8ca1ca">
<fme:FEATURE_ID>1000001139</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829176.03</fme:EASTING>
<fme:NORTHING>820938.13</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820929.29000 829186.92000 0.00000 820928.05000 829166.28000 0.00000 820946.96589 829165.14358 0.00000 820948.20589 829185.78358 0.00000 820929.29000 829186.92000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id13a5f858-dc34-4c9c-8b3c-54d46ef33e5a">
<fme:FEATURE_ID>1000001145</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827465.95</fme:EASTING>
<fme:NORTHING>820975.21</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820969.35165 827476.16009 0.00000 820974.03395 827473.95146 0.00000 820964.09711 827453.24736 0.00000 820973.46362 827448.71883 0.00000 820986.91572 827475.61581 0.00000 820972.32881 827482.46293 0.00000 820969.35165 827476.16009 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id38938767-017a-42a7-82bf-7c285ccb1698">
<fme:FEATURE_ID>1000001137</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828382.31</fme:EASTING>
<fme:NORTHING>820984.76</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820983.51400 828389.31200 0.00000 820981.64800 828375.79600 0.00000 820985.96700 828375.28400 0.00000 820987.91000 828388.74900 0.00000 820983.51400 828389.31200 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id80fa5f33-9de4-49ef-ad9a-c9528ac74f0c">
<fme:FEATURE_ID>1000154394</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828319.22</fme:EASTING>
<fme:NORTHING>821002.75</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820998.35500 828322.49300 0.00000 820997.45500 828317.74200 0.00000 821000.00000 828317.27000 0.00000 821000.00000 828322.20000 0.00000 820998.35500 828322.49300 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id13b837ee-5a79-4049-a917-63b106334c2e">
<fme:FEATURE_ID>1000157987</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827643.29</fme:EASTING>
<fme:NORTHING>820930.75</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820956.12800 827667.08500 0.00000 820905.57500 827667.74000 0.00000 820905.65400 827619.07700 0.00000 820955.90500 827619.15200 0.00000 820956.12800 827667.08500 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="iddd71b5e5-2274-4216-9571-fd5a3b3ded4f">
<fme:FEATURE_ID>1000001135</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828352.13</fme:EASTING>
<fme:NORTHING>820991.23</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820989.54300 828356.28700 0.00000 820988.50600 828348.58500 0.00000 820992.83600 828347.98200 0.00000 820994.04400 828355.55100 0.00000 820989.54300 828356.28700 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb217a388-e499-4512-b742-c5bf4f90402b">
<fme:FEATURE_ID>1210075227</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827860.61</fme:EASTING>
<fme:NORTHING>821030.37</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241122</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820967.22290 827854.47023 0.00000 820967.03321 827853.24794 0.00000 821000.00000 827848.76900 0.00000 821000.00000 827883.51921 0.00000 820972.34061 827887.44679 0.00000 820967.22290 827854.47023 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id764739bf-9827-4424-825b-28d4f8150e0b">
<fme:FEATURE_ID>1000001144</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827694.86</fme:EASTING>
<fme:NORTHING>820803.05</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820797.77865 827704.86370 0.00000 820797.73104 827684.91200 0.00000 820808.24129 827684.81009 0.00000 820808.46707 827704.76061 0.00000 820797.77865 827704.86370 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idb2d1fda6-5750-4d51-8e42-d8bcf17c476f">
<fme:FEATURE_ID>1000001142</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828559.97</fme:EASTING>
<fme:NORTHING>820885.19</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820882.59076 828562.89087 0.00000 820881.83688 828557.96701 0.00000 820887.78676 828557.05593 0.00000 820888.54064 828561.97980 0.00000 820882.59076 828562.89087 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idefb53718-e4f5-495f-93da-d5c368638d77">
<fme:FEATURE_ID>1000001146</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827566.65</fme:EASTING>
<fme:NORTHING>820964.09</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820938.15542 827558.58465 0.00000 820981.51798 827537.34584 0.00000 820991.69491 827557.92093 0.00000 820963.01408 827572.59379 0.00000 820975.07993 827596.43218 0.00000 820960.70446 827603.68217 0.00000 820938.15542 827558.58465 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id679d334d-64e9-4510-a3c9-2e4b5cde6f27">
<fme:FEATURE_ID>1000001136</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828428.34</fme:EASTING>
<fme:NORTHING>820990.76</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820989.75500 828434.81500 0.00000 820988.14900 828422.26400 0.00000 820991.75988 828421.88188 0.00000 820993.36860 828434.40689 0.00000 820989.75500 828434.81500 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id79fadea1-0888-48e5-b75d-fa636e7fa970">
<fme:FEATURE_ID>1000157993</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827653.54</fme:EASTING>
<fme:NORTHING>820841.85</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820875.17371 827672.79377 0.00000 820808.34250 827672.66574 0.00000 820808.72659 827634.12898 0.00000 820875.30174 827634.51306 0.00000 820875.17371 827672.79377 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf9b379e5-b2a1-4598-b1a0-97e50174de25">
<fme:FEATURE_ID>1210075226</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827904.06</fme:EASTING>
<fme:NORTHING>820934.44</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820967.83128 827940.89543 0.00000 820954.27007 827942.25155 0.00000 820955.41392 827951.22440 0.00000 820943.91879 827952.68979 0.00000 820940.04313 827922.28743 0.00000 820918.97598 827925.13120 0.00000 820910.05600 827860.98900 0.00000 820932.31271 827857.96515 0.00000 820936.80121 827891.00223 0.00000 820946.82151 827889.71877 0.00000 820952.48838 827928.27518 0.00000 820966.53622 827927.01970 0.00000 820967.83128 827940.89543 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id1162aa96-f159-4c3e-a860-193b7ba3f91e">
<fme:FEATURE_ID>1000157979</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSS</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827612.6</fme:EASTING>
<fme:NORTHING>821007.98</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>821000.00000 827615.77700 0.00000 820991.38300 827598.32800 0.00000 821000.00000 827594.08300 0.00000 821000.00000 827615.77700 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id3dd9cdb5-611d-49f7-ba87-fbc79e9f3a84">
<fme:FEATURE_ID>1000155597</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>3</fme:FEATURESUBTYPE>
<fme:FEATURECODE>CGA</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827561.88</fme:EASTING>
<fme:NORTHING>821014.08</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820995.38063 827556.04972 0.00000 821000.00000 827553.70450 0.00000 821000.00000 827565.20754 0.00000 820995.38063 827556.04972 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="idf4fffc2f-7c17-4cb3-9c77-f5661c6b3621">
<fme:FEATURE_ID>1000154388</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827512.39</fme:EASTING>
<fme:NORTHING>820961.13</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820995.38063 827556.04972 0.00000 820991.69491 827557.92093 0.00000 820981.51798 827537.34584 0.00000 820938.15542 827558.58465 0.00000 820929.95829 827542.13391 0.00000 820925.34135 827532.75914 0.00000 820918.67712 827519.22733 0.00000 820913.93246 827509.59323 0.00000 820904.15194 827489.73375 0.00000 820962.14725 827460.90788 0.00000 820969.35165 827476.16009 0.00000 820972.32881 827482.46293 0.00000 820986.91572 827475.61581 0.00000 821000.00000 827502.26163 0.00000 821000.00000 827553.70450 0.00000 820995.38063 827556.04972 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPoly gml:id="id59528032-1789-4145-a9bd-7561cd6b4fd6">
<fme:FEATURE_ID>1000001140</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827587.28</fme:EASTING>
<fme:NORTHING>820933.36</fme:NORTHING>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820930.04211 827593.44894 0.00000 820926.44525 827586.30684 0.00000 820936.78177 827581.06882 0.00000 820940.18541 827588.33381 0.00000 820930.04211 827593.44894 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:BuildingPoly>
</gml:featureMember>
</gml:FeatureCollection>
