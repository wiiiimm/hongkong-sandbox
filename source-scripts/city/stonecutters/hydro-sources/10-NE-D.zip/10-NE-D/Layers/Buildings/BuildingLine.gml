<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingLine.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820802.80454 827427.04488 0.00000</gml:lowerCorner>
<gml:upperCorner>821000.00000 829837.83426 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingLine gml:id="id32dc70d8-4c65-4142-9a23-ba27386044ef">
<fme:FEATURE_ID>1210031600</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820985.69611 828182.02278 0.00000 820989.17411 828207.03244 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id68f159dd-c7bd-401b-b731-f1bce0078fdb">
<fme:FEATURE_ID>1000187748</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260729</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 829019.40000 0.00000 820925.52752 829024.35486 0.00000 820924.79000 829010.27000 0.00000 820923.23308 828989.52370 0.00000 820922.84000 828982.93000 0.00000 820922.52000 828978.64000 0.00000 820944.70000 828945.93000 0.00000 821000.00000 828942.19000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id5c1ccb03-b5a8-4006-9ba2-9c52adcd670c">
<fme:FEATURE_ID>1000159091</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820973.13448 827427.04488 0.00000 820975.94424 827432.73113 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="idcbf2d6b6-3382-467f-9047-f0a0240dd000">
<fme:FEATURE_ID>1210059495</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 828855.62607 0.00000 820979.56801 828886.78167 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id0ee4d775-82f7-4968-b621-38acf951090a">
<fme:FEATURE_ID>1000187375</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 829256.68582 0.00000 820908.44000 829262.90000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="idba315ee9-c6cb-4ed9-be26-22ca384077a6">
<fme:FEATURE_ID>1000187750</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 829248.88000 0.00000 820940.78000 829252.84000 0.00000 820937.54572 829202.15369 0.00000 820934.31235 829202.32649 0.00000 820933.76339 829193.96298 0.00000 820936.81000 829193.76000 0.00000 820936.58882 829189.24272 0.00000 820954.24274 829188.05105 0.00000 820951.47970 829142.05992 0.00000 821000.00000 829138.72000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id5cffd445-0807-4085-8617-76531e752cfc">
<fme:FEATURE_ID>1000198328</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000157987</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820905.57500 827667.74000 0.00000 820931.01350 827643.84261 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id5f55945b-65e1-4280-a7eb-32628e14f14d">
<fme:FEATURE_ID>1210054555</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210075226</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820946.82151 827889.71877 0.00000 820918.97598 827925.13120 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id3f4dae46-d8bf-4eca-94bb-67b8926fa3e1">
<fme:FEATURE_ID>1000187336</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820975.94424 827432.73113 0.00000 821000.00000 827481.41380 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id00f59094-715b-4947-8165-a4c82ad8b9b9">
<fme:FEATURE_ID>1210054561</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210075227</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 827874.99097 0.00000 820972.34061 827887.44679 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id5916bf46-cf59-47d9-a4a9-a8257d766fc9">
<fme:FEATURE_ID>1000159092</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820979.62539 828208.44831 0.00000 820979.33700 828211.92700 0.00000 820978.41700 828215.17200 0.00000 820976.43700 828219.37100 0.00000 820973.90900 828222.55500 0.00000 820970.33100 828225.24000 0.00000 820966.40300 828227.35900 0.00000 820961.12600 828228.77600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id436c7489-cc8f-48dd-a98f-2adddef97fdc">
<fme:FEATURE_ID>1000187326</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820940.37653 827852.46525 0.00000 820941.71660 827851.02467 0.00000 820941.41276 827849.09274 0.00000 821000.00000 827838.82000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="idcf7f443e-11d4-426e-b258-c3d53a2ab734">
<fme:FEATURE_ID>1000187372</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250827</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 829376.85300 0.00000 820917.58918 829382.38970 0.00000 820919.69144 829412.23964 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id5e699f09-cd13-4510-bd32-8106aa9fb374">
<fme:FEATURE_ID>1210054558</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241122</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820995.39211 827991.94909 0.00000 820936.78695 827999.36359 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id07f9873c-07e9-4c1a-a61c-767d57560624">
<fme:FEATURE_ID>1000187749</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 829033.55000 0.00000 820975.93000 829035.28000 0.00000 820920.30000 829038.75000 0.00000 820921.34000 829053.75000 0.00000 820927.31000 829053.36000 0.00000 820929.63000 829087.93000 0.00000 820926.77666 829088.18654 0.00000 820927.14542 829092.77925 0.00000 820930.02849 829092.56599 0.00000 820932.89000 829135.17000 0.00000 821000.00000 829130.66000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id1de0ba6c-effc-4db8-b2a0-30c53c13a605">
<fme:FEATURE_ID>1000187369</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250814</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 829714.63844 0.00000 820976.95543 829716.22625 0.00000 820940.28201 829718.71803 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id30e55df6-c50b-4867-a2da-dd7c976ff682">
<fme:FEATURE_ID>1000198363</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000157993</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820875.17371 827672.79377 0.00000 820808.72659 827634.12898 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id6ee25699-99d6-4cc4-9fae-1d1003a893d9">
<fme:FEATURE_ID>1000159095</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820929.97877 827593.43834 0.00000 820929.30875 827594.67231 0.00000 820929.29849 827601.00908 0.00000 820908.91015 827611.16325 0.00000 820892.50899 827611.15340 0.00000 820887.67871 827608.46792 0.00000 820843.82270 827519.32892 0.00000 820846.21761 827512.19728 0.00000 820887.73043 827491.83619 0.00000 820894.41340 827494.23710 0.00000 820936.76071 827581.04564 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id80fde7b8-74e6-4646-a886-aa1748a994f7">
<fme:FEATURE_ID>1000159098</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820946.80920 827839.94339 0.00000 820946.90988 827790.09767 0.00000 820885.86968 827790.10455 0.00000 820885.86968 827751.84959 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id9f691cdd-b881-476b-8097-9e91d2916bde">
<fme:FEATURE_ID>1210054562</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210075227</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820967.03321 827853.24794 0.00000 821000.00000 827858.97426 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id09a9fee3-cedb-434e-816c-4e17ddf9cc2c">
<fme:FEATURE_ID>1210059782</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250814</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820940.28201 829718.71803 0.00000 820940.95894 829728.36790 0.00000 820943.06988 829758.46030 0.00000 820946.09750 829792.18400 0.00000 820962.08073 829805.77925 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="idd48e80d0-1fe3-4200-a19c-c3cf72aa2640">
<fme:FEATURE_ID>1210001542</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250814</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820962.08073 829805.77925 0.00000 820999.91016 829837.83426 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id5d6b04c4-75bd-4659-9585-ef9c31a5fbc2">
<fme:FEATURE_ID>1000187743</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260729</fme:LASTUPDATEDATE>
<gml:multiCurveProperty>
<gml:MultiCurve srsName="EPSG:2326" srsDimension="3">
<gml:curveMember>
<gml:LineString>
<gml:posList>821000.00000 827830.73000 0.00000 820946.80920 827839.94339 0.00000 820911.72503 827849.04339 0.00000 820905.22212 827849.21663 0.00000 820818.65960 827836.29250 0.00000 820805.20261 827824.28525 0.00000 820805.23530 827809.44084 0.00000 820823.68338 827796.26189 0.00000 820823.57783 827752.56753 0.00000 820885.86968 827751.84959 0.00000</gml:posList>
</gml:LineString>
</gml:curveMember>
<gml:curveMember>
<gml:LineString>
<gml:posList>820885.86968 827751.84959 0.00000 820885.75885 827746.48634 0.00000 820885.83935 827731.36451 0.00000 821000.00000 827729.96037 0.00000</gml:posList>
</gml:LineString>
</gml:curveMember>
</gml:MultiCurve>
</gml:multiCurveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id38b47f8e-c1ca-4420-96be-d762542f5a93">
<fme:FEATURE_ID>1000159099</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260729</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820869.59127 827625.28390 0.00000 820849.35430 827625.28364 0.00000 820849.35430 827611.28153 0.00000 820824.59931 827621.58726 0.00000 820824.51625 827625.28333 0.00000 820808.88673 827625.28313 0.00000 820803.97592 827620.76554 0.00000 820803.61738 827598.19340 0.00000 820806.60577 827595.05573 0.00000 820806.51242 827577.21639 0.00000 820803.30574 827573.99242 0.00000 820802.80454 827534.19184 0.00000 820826.92087 827522.29782 0.00000 820869.57833 827609.22578 0.00000 820869.59127 827625.28390 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id35b7ef12-63de-4154-aea9-b365de4cc11b">
<fme:FEATURE_ID>1210054554</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210075226</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820940.04313 827922.28743 0.00000 820955.41392 827951.22440 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id7edf2d4c-da7c-4155-a7cc-7ae6f4163df9">
<fme:FEATURE_ID>1000187747</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>WLL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820962.05863 828921.22051 0.00000 820962.47581 828936.29930 0.00000 821000.00000 828933.75935 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="ide605fe34-9c7b-43b0-89cb-ba30363eff33">
<fme:FEATURE_ID>1310077700</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241122</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820948.24213 827900.00787 0.00000 821000.00000 827892.82025 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="idc982b2e9-c957-415b-b52b-9e323aecb1b6">
<fme:FEATURE_ID>1000198319</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000157987</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820931.01350 827643.84261 0.00000 820955.90500 827619.15200 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id0c73c59e-909c-43c3-bca0-33961a9a0ec8">
<fme:FEATURE_ID>1000198318</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000157987</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820956.12800 827667.08500 0.00000 820931.01350 827643.84261 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id710b2053-b9a6-4aeb-ae81-5ca11e89b30d">
<fme:FEATURE_ID>1310077701</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820955.41392 827951.22440 0.00000 821000.00000 827945.09616 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="idaacaf3cf-e962-4d8f-bc71-5f30b449cc51">
<fme:FEATURE_ID>1210054557</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210075226</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820910.05600 827860.98900 0.00000 820936.80121 827891.00223 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="idcc43c003-b713-4dcc-8c61-8387cc11df22">
<fme:FEATURE_ID>1000187374</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:multiCurveProperty>
<gml:MultiCurve srsName="EPSG:2326" srsDimension="3">
<gml:curveMember>
<gml:LineString>
<gml:posList>821000.00000 828313.98900 0.00000 820973.57800 828317.76600 0.00000</gml:posList>
</gml:LineString>
</gml:curveMember>
<gml:curveMember>
<gml:LineString>
<gml:posList>821000.00000 828148.33154 0.00000 820991.83100 828149.86700 0.00000 820988.30300 828151.09000 0.00000 820985.48000 828152.88500 0.00000 820983.33900 828154.64800 0.00000 820980.73700 828157.18900 0.00000 820978.70200 828159.82500 0.00000 820976.32500 828165.46700 0.00000 820975.38000 828168.63000 0.00000 820975.13500 828171.18300 0.00000 820975.70000 828181.09300 0.00000 820978.45800 828197.99000 0.00000 820979.68300 828206.54500 0.00000 820979.62539 828208.44831 0.00000 820989.17411 828207.03244 0.00000 821000.00000 828284.87938 0.00000</gml:posList>
</gml:LineString>
</gml:curveMember>
</gml:MultiCurve>
</gml:multiCurveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id47d51992-d0e6-4cc2-9bf1-32f98813951a">
<fme:FEATURE_ID>1000159093</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FEN</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820948.47426 827446.45150 0.00000 820975.94424 827432.73113 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id3002fb93-8c59-4b6a-9f7d-1d0dd8e73089">
<fme:FEATURE_ID>1000198293</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000157979</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 827605.78354 0.00000 820991.38300 827598.32800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="idb36072f0-03a7-4d61-8184-43bd399ad0b2">
<fme:FEATURE_ID>1210054556</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1210075226</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820932.31271 827857.96515 0.00000 820914.39509 827892.19071 0.00000 820951.45883 827921.27032 0.00000 820943.91879 827952.68979 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id231c79ab-08bf-43d7-b85c-0af5ca99308d">
<fme:FEATURE_ID>1000198364</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000157993</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820875.30174 827634.51306 0.00000 820808.34250 827672.66574 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingLine gml:id="id80eb043a-122f-4302-bfb3-e0de151f49b9">
<fme:FEATURE_ID>1000198327</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1000157987</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>2</fme:FEATURESUBTYPE>
<fme:FEATURECODE>OSL</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241118</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820931.01350 827643.84261 0.00000 820905.65400 827619.07700 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:BuildingLine>
</gml:featureMember>
</gml:FeatureCollection>
