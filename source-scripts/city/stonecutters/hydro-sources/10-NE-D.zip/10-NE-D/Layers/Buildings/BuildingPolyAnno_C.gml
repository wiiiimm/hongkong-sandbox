<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme BuildingPolyAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820801.25765 827664.42042</gml:lowerCorner>
<gml:upperCorner>820974.23765 829136.17531</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="idf5e01ede-3e46-4d2d-b978-d6cabb7c4af7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743261</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>829122.15207532</fme:EASTING>
<fme:NORTHING>820880.64880421</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820883.51518 829136.17531</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id60a1274d-32aa-4fb8-9d08-34fb63329095">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743263</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>827650.39718924</fme:EASTING>
<fme:NORTHING>820798.39126729</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820801.25765 827664.42042</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:BuildingPolyAnno_C gml:id="id0ba0d6a7-09fe-4133-ae56-f41f8a052e3d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>抽水房</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>0</fme:FontLeading>
<fme:WordSpacing>100</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000743262</fme:FEATURE_ID>
<fme:FEATURECODE>BLD</fme:FEATURECODE>
<fme:EASTING>828366.13147525</fme:EASTING>
<fme:NORTHING>820971.37127353</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820974.23765 828380.15471</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:BuildingPolyAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
