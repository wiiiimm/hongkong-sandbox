<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityLineAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820724.98135 827486.57788</gml:lowerCorner>
<gml:upperCorner>820932.84019 829201.33156</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="id457b26ec-c62d-4166-a5e9-e26a2351bc59">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-88.2710719231602</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162665</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827732.92454544</fme:EASTING>
<fme:NORTHING>820743.29908574</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820724.98135 827736.53639</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="id95999b2e-0940-4366-8578-cc7938f4d17f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>44.8096903070178</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162668</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>828623.53182096</fme:EASTING>
<fme:NORTHING>820896.11867414</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820911.26827 828634.44396</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="id003ae1f1-2174-4abd-8448-2fb5e5ca53dc">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-86.0240601451443</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162667</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>829197.00430628</fme:EASTING>
<fme:NORTHING>820809.04630388</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820790.88425 829201.33156</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="id4fcd6530-7ea8-4569-9223-3beace4216b2">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.79456518706095</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000162</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>829052.512</fme:EASTING>
<fme:NORTHING>820917.915</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820917.91489 829052.51249</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="idd71433f4-1806-4ee5-b3e7-29311dd0fe1d">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-62.8722650521476</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162664</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827486.578</fme:EASTING>
<fme:NORTHING>820890.775</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820890.77472 827486.57788</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_E gml:id="id70e9467a-57ad-49a3-91f0-5f71fcaaa43e">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Pipeline</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-80.9724095133368</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162666</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>828547.97418533</fme:EASTING>
<fme:NORTHING>820950.55065536</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820932.84019 828553.88387</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
