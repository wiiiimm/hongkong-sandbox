<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityPolyAnno_E.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820869.58785 827536.38804</gml:lowerCorner>
<gml:upperCorner>820965.37845 829197.11729</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id3e9b6299-c78f-449c-bb1c-bcab7122b2b3">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173875</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>827536.388</fme:EASTING>
<fme:NORTHING>820869.588</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820869.58785 827536.38804</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="id5075f3c9-2827-48a9-b310-f9ea46c3bd94">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173873</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>828981.661</fme:EASTING>
<fme:NORTHING>820956.685</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820956.68540 828981.66117</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="idbde78715-bfc1-493e-964e-0454dcd7c970">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173874</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>827800.69</fme:EASTING>
<fme:NORTHING>820937.444</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820937.44437 827800.68963</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityPolyAnno_E gml:id="idf7477916-d005-46fc-8d02-7f93d7543400">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>Fuel Tank</fme:TextString>
<fme:FontName>Arial</fme:FontName>
<fme:FontSize>5</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>-0.5</fme:FontLeading>
<fme:WordSpacing>150</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001173876</fme:FEATURE_ID>
<fme:FEATURECODE>WTK</fme:FEATURECODE>
<fme:EASTING>829197.117</fme:EASTING>
<fme:NORTHING>820965.378</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820965.37845 829197.11729</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityPolyAnno_E>
</gml:featureMember>
</gml:FeatureCollection>
