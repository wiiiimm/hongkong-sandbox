<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme UtilityLineAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820766.82301 827474.20066</gml:lowerCorner>
<gml:upperCorner>820957.64496 829194.48059</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id48141379-16f8-4b68-8e23-f120f6d1f669">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-88.9769690184314</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162361</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827735.04797424</fme:EASTING>
<fme:NORTHING>820786.1819137</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820766.82301 827735.39367</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id42ad52c2-05e8-4f66-893f-eac125beccf8">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-25.2777292210101</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162366</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>828498.38950819</fme:EASTING>
<fme:NORTHING>820895.62555181</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820894.40247 828507.69230</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="idf4c7f7cd-9707-46b7-841b-bda495b9581f">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-86.8778825603218</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162362</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>829193.84969676</fme:EASTING>
<fme:NORTHING>820893.97959405</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820882.41323 829194.48059</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id82eee399-da70-49f4-b63b-b46aa11923bf">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-35.6149256304968</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000222</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>828907.942</fme:EASTING>
<fme:NORTHING>820957.645</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820957.64496 828907.94221</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="idd67203ef-0bf8-4ee3-ab75-8998953817d9">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-62.6280479862961</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162364</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827462.11318617</fme:EASTING>
<fme:NORTHING>820941.61306525</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820918.26602 827474.20066</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="id0b4f83a9-280d-4dda-a754-2c1ac7e2bbc7">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>26.2814089165561</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162363</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>827578.79756567</fme:EASTING>
<fme:NORTHING>820860.37303906</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820866.37760 827590.95679</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:UtilityLineAnno_C gml:id="idca5906c4-e906-4c7a-aa46-c7f7299a1a0b">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>導管</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>-81.8699034834873</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1001162367</fme:FEATURE_ID>
<fme:FEATURECODE>PIP</fme:FEATURECODE>
<fme:EASTING>828581.09479048</fme:EASTING>
<fme:NORTHING>820951.07555097</fme:NORTHING>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820930.46638 828584.03896</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:UtilityLineAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
