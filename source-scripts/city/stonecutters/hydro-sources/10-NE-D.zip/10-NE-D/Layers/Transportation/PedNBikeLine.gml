<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PedNBikeLine.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820676.56851 827528.66233 0.00000</gml:lowerCorner>
<gml:upperCorner>821000.00000 829539.76483 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id809909fc-9594-409b-8c23-7420be86e32c">
<fme:FEATURE_ID>1000992317</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137424</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820690.47200 827857.35359 0.00000 820689.57467 827866.69432 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id6ef84351-96f4-4995-82a4-4d194697cc59">
<fme:FEATURE_ID>1000992344</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137409</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820743.82811 829209.21661 0.00000 820752.85990 829235.82565 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="ida460e1ff-c60b-4b9e-b053-cd6c755b0de5">
<fme:FEATURE_ID>1000992305</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137428</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820862.57000 829187.99000 0.00000 820902.90000 829185.20000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idd56750ea-9e04-4cdb-bf71-041e8d76af43">
<fme:FEATURE_ID>1000992313</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137423</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820680.71051 827769.88402 0.00000 820687.02427 827794.38700 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id0dc9d0c2-29e9-4b7c-993c-076b5269c48a">
<fme:FEATURE_ID>1000992371</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820878.95628 827681.98498 0.00000 820828.22853 827682.00676 0.00000 820827.23523 827682.14368 0.00000 820825.84842 827682.70553 0.00000 820824.86231 827683.38600 0.00000 820824.02654 827684.24445 0.00000 820823.37270 827685.24842 0.00000 820822.84818 827686.64977 0.00000 820822.74866 827712.25818 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id100f240a-bc05-42d0-be7e-9cea18a4834a">
<fme:FEATURE_ID>1000992341</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137414</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820745.40653 829075.73888 0.00000 820750.17289 829090.99281 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id5a73e3a3-c3de-4a07-b5a8-ecd006d3de2e">
<fme:FEATURE_ID>1000992342</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137418</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820732.82715 829156.67294 0.00000 820734.07952 829173.94009 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id64d92a79-bf46-4ebf-8ec3-40bf59b7c200">
<fme:FEATURE_ID>1210025848</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820902.06908 829175.73852 0.00000 820862.02251 829178.67431 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id4525c747-ab31-48cb-ac46-da537da31b46">
<fme:FEATURE_ID>1210025850</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820818.07621 829181.48391 0.00000 820750.53169 829185.74958 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idcf429a0e-cfa8-4e37-93d7-05bd02d3ac69">
<fme:FEATURE_ID>1000992308</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137425</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820691.17748 827689.46234 0.00000 820687.24610 827719.74789 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="iddb415fc7-c2e2-4718-b0b0-7e8a746dab5c">
<fme:FEATURE_ID>1000992362</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137405</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820886.75897 828594.38981 0.00000 820889.72663 828615.55224 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id78a672e1-9834-4325-acaa-788a5594df89">
<fme:FEATURE_ID>1210012141</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820967.24400 828568.81900 0.00000 820967.56537 828571.26130 0.00000 820975.74879 828570.02607 0.00000 820975.64585 828569.20258 0.00000 820976.93255 828569.09965 0.00000 820977.29283 828572.29066 0.00000 820975.95466 828572.29066 0.00000 820975.90319 828571.05543 0.00000 820967.61684 828572.34213 0.00000 820967.66831 828573.42296 0.00000 820958.50700 828574.96700 0.00000 820958.35259 828573.47443 0.00000 820950.06624 828574.86407 0.00000 820950.22065 828576.09930 0.00000 820948.62514 828576.20223 0.00000 820948.57367 828573.01122 0.00000 820949.96331 828573.01122 0.00000 820950.01478 828573.62883 0.00000 820958.19819 828572.54800 0.00000 820957.99232 828570.23194 0.00000 820964.88903 828569.25405 0.00000 820964.83300 828569.18400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id93401d98-18a5-404a-a662-6f35e3e853e1">
<fme:FEATURE_ID>1000992363</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137402</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820890.77060 828623.31587 0.00000 820924.21046 828657.66998 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id65131d01-ba83-491f-94e1-2e01b77d3aca">
<fme:FEATURE_ID>1000992335</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137417</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240926</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820735.33439 829209.95698 0.00000 820736.52000 829226.36000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id16d7100b-827c-48c2-9221-c6339dfd69bb">
<fme:FEATURE_ID>1000992330</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137412</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820751.08465 829143.75225 0.00000 820747.96991 829172.83734 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id4bbf60ad-e48d-413f-a832-9f1ac2c68a08">
<fme:FEATURE_ID>1000992333</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137417</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240926</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820736.87125 829209.83631 0.00000 820737.86000 829226.23000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id1373f24c-70a2-4c28-b860-159ce52b556e">
<fme:FEATURE_ID>1000992350</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137407</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820757.99687 829251.27092 0.00000 820754.79961 829241.70880 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id6bcd8277-83b0-42ca-b22c-9f2b9564c196">
<fme:FEATURE_ID>1000992311</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137419</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820700.12609 827661.63800 0.00000 820686.70446 827683.65874 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idf699023e-0859-4e75-b69c-4ce8a9f5f534">
<fme:FEATURE_ID>1000992332</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137413</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820750.52000 829236.54000 0.00000 820739.69000 829233.56000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id778d31b0-f81f-4831-b205-8b462b833fdc">
<fme:FEATURE_ID>1000992343</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137412</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820744.09449 829143.08523 0.00000 820740.18449 829173.46825 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idf63983fc-f609-4040-97f7-7c7e94d7ba53">
<fme:FEATURE_ID>1000992355</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137406</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820880.64799 828555.19664 0.00000 820877.64757 828534.12556 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id7dd81f64-e33e-4f9c-acb2-f844d7aa57ae">
<fme:FEATURE_ID>1000992348</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137410</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820756.23908 829314.33481 0.00000 820758.81095 829299.07721 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id28e2fa07-5354-42fe-aa99-9a667b55dd03">
<fme:FEATURE_ID>1000992318</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137420</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820691.76410 827619.06686 0.00000 820698.45441 827638.79236 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id44763e15-4665-42b2-8321-d774b7865b71">
<fme:FEATURE_ID>1000992315</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137421</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820695.52994 827800.43991 0.00000 820699.54101 827805.80403 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id18e3013c-782d-4d45-b769-e8b4959c2cf0">
<fme:FEATURE_ID>1210026808</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820792.38882 827528.66233 0.00000 820794.49617 827718.38415 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id6bbfdb84-a039-4608-aff1-015173618294">
<fme:FEATURE_ID>1210025851</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820818.52000 829188.83000 0.00000 820751.23921 829193.11949 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id960ae2c1-73ee-4787-8b64-9f6eb222dc4b">
<fme:FEATURE_ID>1000992340</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137414</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820744.09222 829076.15439 0.00000 820749.02206 829092.35535 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id4861ed5a-9e3e-4a32-9e83-081a1b23ba3b">
<fme:FEATURE_ID>1000992312</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137423</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820686.45179 827769.78745 0.00000 820692.40862 827794.37316 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idc0d80880-3286-41d4-85d0-adef020629a8">
<fme:FEATURE_ID>1210025846</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820687.24610 827719.74789 0.00000 820789.97039 827718.46021 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id77e85feb-09af-461c-a628-9a774cbe537b">
<fme:FEATURE_ID>1000992347</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137408</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820760.19618 829291.19707 0.00000 820764.62438 829273.15543 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id0a25e5a1-58e0-4a0b-9c4f-54f8f544c02a">
<fme:FEATURE_ID>1000992346</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137410</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820754.82000 829314.36000 0.00000 820757.38359 829298.88507 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id0a4fc6ed-1d6c-40eb-96a4-6a6679be93f3">
<fme:FEATURE_ID>1000992354</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137403</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820896.95186 828484.14309 0.00000 820889.84658 828500.35725 0.00000 820877.03751 828526.01503 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id685cc6b8-4732-43fa-b63b-9078b2f53270">
<fme:FEATURE_ID>1000992353</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137403</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820894.91400 828484.45779 0.00000 820875.15248 828525.27768 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id9ef6e355-7124-4b23-bdb0-3c5afbc5de03">
<fme:FEATURE_ID>1000992314</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137426</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820678.17021 827769.92675 0.00000 820678.29497 827774.44973 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="ida185934b-2a42-4de9-89c7-2ac6485a4730">
<fme:FEATURE_ID>1000992365</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137398</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820964.27394 828445.84104 0.00000 820965.78597 828456.49676 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id19afee92-6ea0-404b-9071-3f3ab87c7b92">
<fme:FEATURE_ID>1210026806</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820794.64373 827727.39314 0.00000 820796.20800 827821.53500 0.00000 820796.68600 827824.94700 0.00000 820798.09900 827829.46600 0.00000 820799.65000 827832.54300 0.00000 820802.15900 827836.04100 0.00000 820803.94100 827837.91500 0.00000 820807.30800 827840.59700 0.00000 820809.53300 827841.91400 0.00000 820811.48300 827842.83100 0.00000 820815.58200 827844.14500 0.00000 820896.08384 827855.86816 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idae29c55e-8e25-4708-81b8-2fabee357ff8">
<fme:FEATURE_ID>1000992327</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137411</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820751.97000 829137.43000 0.00000 820753.77000 829120.85000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id1c773755-f33a-449a-a3c0-09f01d6abaab">
<fme:FEATURE_ID>1000992310</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137419</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820705.82080 827661.60865 0.00000 820692.33809 827683.52939 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id722d1143-8510-440e-9b69-2c98e19942a1">
<fme:FEATURE_ID>1001086434</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001142514</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>FBR_touchBoundary</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820967.24400 828568.81900 0.00000 820966.65400 828564.76000 0.00000 821000.00000 828560.03800 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id0942164d-6abd-4511-ac00-7219aa179656">
<fme:FEATURE_ID>1000992316</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137421</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820688.21799 827800.34460 0.00000 820698.58678 827813.60900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id97fc21f8-83fb-43e7-89bd-15a2d3e24c9b">
<fme:FEATURE_ID>1000992325</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001142514</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820891.04664 828575.46580 0.00000 820964.23900 828565.10200 0.00000 820964.83300 828569.18400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id70e36df8-9201-4afb-a7e3-dea3a6f277d7">
<fme:FEATURE_ID>1000992361</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137405</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820885.96332 828615.87599 0.00000 820882.99925 828594.79887 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id55bf71b0-d607-4f19-92dc-3cf06380f6c9">
<fme:FEATURE_ID>1000992367</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137399</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820962.04669 828430.30496 0.00000 820963.52624 828441.08578 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id05cf4b5b-7bba-47d5-9c90-a9208e994602">
<fme:FEATURE_ID>1000992309</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137425</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820685.34050 827689.22599 0.00000 820680.21489 827719.88081 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id6eaacd5a-081a-42c1-9b37-c5023ec7e474">
<fme:FEATURE_ID>1000992368</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137399</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820960.76612 828430.48790 0.00000 820962.30838 828441.25817 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="ided2f85d0-41f0-4696-b13a-566c2fafd73f">
<fme:FEATURE_ID>1000992351</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137404</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820879.91033 828424.99050 0.00000 820894.93708 828477.33703 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idf1273866-18ba-42e9-ac2c-9c224ff527bc">
<fme:FEATURE_ID>1000992345</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137408</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820758.77000 829290.99000 0.00000 820763.26000 829273.25000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id87965979-54ce-42bb-bb61-cb84dff85df9">
<fme:FEATURE_ID>1000992374</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820909.16876 829273.04434 0.00000 820917.58918 829382.38970 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id1ef97572-ec80-4d2f-8eb1-341dbb851c9f">
<fme:FEATURE_ID>1000992349</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137407</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820761.14000 829239.56000 0.00000 820764.88669 829250.92995 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idbd9e4995-dab9-4689-9248-25a6383591fa">
<fme:FEATURE_ID>1000992352</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137404</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820893.50167 828477.58310 0.00000 820878.49584 828425.17025 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idfc490a2d-1d1a-428b-8b0e-4d435c9823fd">
<fme:FEATURE_ID>1000992319</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137427</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820676.73732 827719.93381 0.00000 820676.56851 827715.02255 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idf7654a95-9854-40fb-8d14-3aa88e0fcdaf">
<fme:FEATURE_ID>1000992334</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137416</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820742.56000 829142.96000 0.00000 820734.05000 829147.67000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id8668d34d-8e66-4047-8513-dc9658d703d4">
<fme:FEATURE_ID>1000992356</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137406</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820875.45041 828534.43371 0.00000 820878.44832 828555.50129 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id7c4a69ba-fa8a-45fb-b453-c4b96c6688ff">
<fme:FEATURE_ID>1000992307</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137427</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820677.72859 827719.91870 0.00000 820677.56055 827714.97985 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id05eb9b54-4898-4607-a6ba-8809c3bc66b6">
<fme:FEATURE_ID>1000992322</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137422</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820698.78972 827845.66209 0.00000 820693.48136 827851.55440 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="ida854082a-4d26-4019-b997-be3fdd4702c8">
<fme:FEATURE_ID>1000992375</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260729</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820918.44372 829394.52335 0.00000 820884.38685 829396.83212 0.00000 820880.22552 829397.16502 0.00000 820878.15939 829397.43688 0.00000 820876.43771 829397.80069 0.00000 820875.14153 829398.16100 0.00000 820873.85281 829398.58044 0.00000 820872.58355 829399.05555 0.00000 820871.33690 829399.58512 0.00000 820870.02378 829400.21421 0.00000 820869.08561 829400.71123 0.00000 820868.16152 829401.24201 0.00000 820867.33959 829401.75049 0.00000 820866.45210 829402.34043 0.00000 820865.58594 829402.95990 0.00000 820864.74146 829403.60862 0.00000 820863.91965 829404.28584 0.00000 820863.12088 829404.99128 0.00000 820862.41773 829405.65436 0.00000 820861.66668 829406.41040 0.00000 820860.94246 829407.19110 0.00000 820860.24535 829407.99609 0.00000 820859.57619 829408.82442 0.00000 820858.93561 829409.67547 0.00000 820858.38115 829410.46589 0.00000 820857.79907 829411.35820 0.00000 820857.29918 829412.18408 0.00000 820856.77894 829413.11286 0.00000 820856.29220 829414.05870 0.00000 820855.83881 829415.02187 0.00000 820855.45732 829415.90869 0.00000 820855.06985 829416.90023 0.00000 820854.71790 829417.90405 0.00000 820854.40137 829418.92046 0.00000 820854.14555 829419.85134 0.00000 820853.89821 829420.88676 0.00000 820853.68775 829421.92946 0.00000 820853.51410 829422.97976 0.00000 820853.38882 829423.93699 0.00000 820853.28624 829424.99742 0.00000 820853.22573 829425.96091 0.00000 820853.19478 829427.02748 0.00000 820853.19591 829427.78537 0.00000 820853.30337 829429.80783 0.00000 820860.72839 829539.54538 0.00000 820857.18167 829539.76483 0.00000 820849.75697 829430.03829 0.00000 820849.67037 829428.70514 0.00000 820849.64265 829427.95389 0.00000 820849.64755 829426.49510 0.00000 820849.69269 829425.32626 0.00000 820849.81067 829424.06912 0.00000 820849.98679 829422.63211 0.00000 820850.17835 829421.39256 0.00000 820850.39789 829420.25575 0.00000 820850.66156 829419.12971 0.00000 820850.99212 829417.91593 0.00000 820851.36792 829416.71407 0.00000 820851.78709 829415.53061 0.00000 820852.21209 829414.45652 0.00000 820852.71649 829413.30428 0.00000 820853.26267 829412.17146 0.00000 820853.84849 829411.06130 0.00000 820854.47703 829409.97183 0.00000 820855.09158 829408.99123 0.00000 820855.73936 829408.03416 0.00000 820856.42115 829407.10144 0.00000 820857.20030 829406.11702 0.00000 820858.00909 829405.16283 0.00000 820859.11653 829403.93339 0.00000 820859.78980 829403.24442 0.00000 820860.63248 829402.45349 0.00000 820861.78686 829401.42965 0.00000 820862.43882 829400.88189 0.00000 820863.12748 829400.34827 0.00000 820864.24359 829399.57408 0.00000 820865.52883 829398.72817 0.00000 820866.75342 829397.96483 0.00000 820867.85050 829397.32697 0.00000 820869.08668 829396.70558 0.00000 820870.70198 829395.98648 0.00000 820872.06377 829395.44718 0.00000 820873.53867 829394.93302 0.00000 820874.75518 829394.56173 0.00000 820875.99793 829394.25344 0.00000 820877.76021 829393.91457 0.00000 820879.80482 829393.62249 0.00000 820883.24698 829393.34601 0.00000 820891.23541 829392.77101 0.00000 820918.19408 829390.97877 0.00000 820918.44372 829394.52335 0.00000 820918.19408 829390.97877 0.00000 820917.58918 829382.38970 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idd5dac12c-3457-484d-9667-e9467bdc3582">
<fme:FEATURE_ID>1000992324</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137424</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820692.11032 827857.31768 0.00000 820691.02502 827867.34053 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id16babdfe-59de-48b8-bbca-c2b019cecfac">
<fme:FEATURE_ID>1000992306</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137429</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820818.96000 829190.98000 0.00000 820751.39000 829195.32000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id3ba689c3-d33a-454c-acb8-08c9b570ed9c">
<fme:FEATURE_ID>1000992323</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137422</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820698.78623 827843.24752 0.00000 820691.48829 827851.55240 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idcf9ab356-a16c-411b-b314-4182832312ae">
<fme:FEATURE_ID>1000992373</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820823.05107 827718.58808 0.00000 820823.65900 827719.77188 0.00000 820824.42725 827720.69088 0.00000 820825.62731 827721.58370 0.00000 820826.61272 827721.93181 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idc800298b-7546-46f3-9955-343ac00df4d3">
<fme:FEATURE_ID>1001086435</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001142514</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME>FBR_touchBoundary</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>821000.00000 828556.62800 0.00000 820890.60271 828572.39230 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idfcfae10f-e92d-4cb8-91bc-3e75e6505fc6">
<fme:FEATURE_ID>1000992328</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137409</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820750.80000 829208.74000 0.00000 820759.01000 829233.48000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idfc87c164-89cc-4cfa-bd03-d9f1e75d200d">
<fme:FEATURE_ID>1000992338</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137415</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820736.93000 829053.00000 0.00000 820741.82701 829068.94513 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="ida45fa156-6036-411b-864d-d258486535ce">
<fme:FEATURE_ID>1000992359</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137400</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820928.08572 828685.52521 0.00000 820925.28247 828665.18380 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="ida4634a36-970e-4f1b-a165-664c3455e6df">
<fme:FEATURE_ID>1000992321</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137426</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820677.20523 827769.94298 0.00000 820677.25375 827774.44478 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id19915cf0-87ac-47c5-ae04-394293c88140">
<fme:FEATURE_ID>1000992366</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137398</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820962.97571 828446.03337 0.00000 820964.53024 828456.68583 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id1e06c74d-34c0-4fb4-bdea-ef37b3f49441">
<fme:FEATURE_ID>1210025849</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820902.74582 829183.03858 0.00000 820862.30828 829186.00285 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id7865d6cc-91a4-4185-b210-bee6145319a6">
<fme:FEATURE_ID>1000992336</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137416</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820742.18000 829141.69000 0.00000 820733.72000 829146.56000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id130ab526-b068-42a4-90a5-d3654fd51be8">
<fme:FEATURE_ID>1000992358</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137401</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820921.82305 828719.78725 0.00000 820927.42788 828691.78115 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="ide93095fd-f5f7-44da-82a4-2add6a0ba403">
<fme:FEATURE_ID>1000992364</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137402</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820887.66852 828625.07814 0.00000 820920.16648 828658.22403 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id135f7184-ac51-414b-af88-67fe1b600007">
<fme:FEATURE_ID>1210025847</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820687.37847 827729.17883 0.00000 820789.78377 827727.52100 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id1ac06671-ff9d-44f1-b476-99341a48609e">
<fme:FEATURE_ID>1000992357</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137401</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820925.89964 828692.00421 0.00000 820920.34558 828720.00564 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id064940ec-cf83-45b9-a846-2c209c218301">
<fme:FEATURE_ID>1000992369</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137397</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820990.31885 828438.80148 0.00000 820965.33830 828442.32515 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idd3685293-3299-47f6-9481-9acb5bc1b00b">
<fme:FEATURE_ID>1000992331</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137413</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820751.07000 829237.81000 0.00000 820739.96000 829235.02000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id105fdd05-5cfb-42f4-9fed-ddff5194e56c">
<fme:FEATURE_ID>1210032851</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820992.37787 828453.36455 0.00000 820967.35425 828456.94762 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="ida527785c-6eee-4d3b-8b94-854c7b45b9a0">
<fme:FEATURE_ID>1000992360</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137400</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820922.96407 828665.49957 0.00000 820925.79545 828685.84934 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id4b1a8c8a-10fe-4485-b0b3-5b26c9afdbe3">
<fme:FEATURE_ID>1000992339</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137415</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820738.45587 829052.98351 0.00000 820743.17914 829068.52593 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idc5e60b17-1282-4f38-8fd3-ae354e04cc77">
<fme:FEATURE_ID>1000992320</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137422</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820698.78622 827843.24722 0.00000 820691.49143 827851.55240 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id6ded1705-928e-4622-abee-e88b814505d6">
<fme:FEATURE_ID>1000992326</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137420</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820693.27534 827619.10715 0.00000 820699.81220 827638.78916 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id413cd347-c700-4936-9f49-913d37a7583f">
<fme:FEATURE_ID>1000992370</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137397</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820990.56578 828440.55285 0.00000 820965.59894 828444.03094 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idfa2bb77b-8204-4da7-a200-d5b56bdaf30c">
<fme:FEATURE_ID>1000992372</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>PAE</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250814</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820832.07620 827721.94507 0.00000 820845.21909 827721.46481 0.00000 820880.76127 827720.58695 0.00000 820880.48600 827689.43900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idc863d6f5-f17b-4984-a72d-2516be311cb8">
<fme:FEATURE_ID>1000992329</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137411</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820744.86545 829136.64248 0.00000 820747.64880 829115.20074 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="id52531158-ff7a-4851-ad4e-e97c20b9b637">
<fme:FEATURE_ID>1000992337</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID>1001137418</fme:FEATUREPOLY_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820731.52691 829156.71581 0.00000 820732.86459 829174.02270 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikeLine gml:id="idb5bdbff3-7ed0-496a-8f7a-b6cd2d3d0ff1">
<fme:FEATURE_ID>1210032852</fme:FEATURE_ID>
<fme:FEATUREPOLY_ID/>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY/>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>820992.67485 828455.46487 0.00000 820967.64255 828458.98522 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:PedNBikeLine>
</gml:featureMember>
</gml:FeatureCollection>
