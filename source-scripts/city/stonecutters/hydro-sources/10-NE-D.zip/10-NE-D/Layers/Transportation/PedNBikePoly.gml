<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PedNBikePoly.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820676.56851 827619.06686 0.00000</gml:lowerCorner>
<gml:upperCorner>821000.00000 829314.36000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id74d56ab8-ef18-4a40-8f82-8c839d045e05">
<fme:FEATURE_ID>1001137412</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829158.51</fme:EASTING>
<fme:NORTHING>820745.78</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820746.04423 829173.01463 0.00000 820740.18449 829173.46825 0.00000 820744.09449 829143.08523 0.00000 820749.56000 829143.64000 0.00000 820751.08465 829143.75225 0.00000 820747.96991 829172.83734 0.00000 820746.04423 829173.01463 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id83c62675-f0df-4990-8472-d5aa5cecbbfb">
<fme:FEATURE_ID>1001137407</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829245.86</fme:EASTING>
<fme:NORTHING>820759.8</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820757.99687 829251.27092 0.00000 820754.79961 829241.70880 0.00000 820759.70999 829240.10703 0.00000 820761.14000 829239.56000 0.00000 820764.88669 829250.92995 0.00000 820763.17204 829251.03987 0.00000 820757.99687 829251.27092 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idd0bae2f6-c7d5-4794-b2e8-8c682a2b544f">
<fme:FEATURE_ID>1001137429</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829192.07</fme:EASTING>
<fme:NORTHING>820784.9</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820751.23921 829193.11949 0.00000 820818.52000 829188.83000 0.00000 820818.78356 829190.99133 0.00000 820751.39000 829195.32000 0.00000 820751.23921 829193.11949 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idf3b9b287-b852-4812-9d38-05207ae6e48a">
<fme:FEATURE_ID>1001137406</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828544.82</fme:EASTING>
<fme:NORTHING>820878.05</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820878.44832 828555.50129 0.00000 820875.45041 828534.43371 0.00000 820877.64757 828534.12556 0.00000 820880.64799 828555.19664 0.00000 820878.44832 828555.50129 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id54f2b32c-1d69-4c1c-b0ef-2adfeeea4646">
<fme:FEATURE_ID>1001137398</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828451.24</fme:EASTING>
<fme:NORTHING>820964.39</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820964.53024 828456.68583 0.00000 820962.97571 828446.03337 0.00000 820964.27394 828445.84104 0.00000 820965.78597 828456.49676 0.00000 820964.53024 828456.68583 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id8074c6f2-59d6-4e8c-a60f-a2698233e407">
<fme:FEATURE_ID>1001142514</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828565.87</fme:EASTING>
<fme:NORTHING>820949.17</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820890.60271 828572.39230 0.00000 820889.89878 828567.97457 0.00000 821000.00000 828552.27632 0.00000 821000.00000 828565.06852 0.00000 820967.35168 828569.73697 0.00000 820958.05210 828570.90449 0.00000 820891.74546 828580.32330 0.00000 820891.04664 828575.46580 0.00000 820890.60271 828572.39230 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="iddf01a9a1-276e-4db9-b719-d4b1f8cc291b">
<fme:FEATURE_ID>1001137417</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829218.15</fme:EASTING>
<fme:NORTHING>820735.93</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240926</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820736.52000 829226.36000 0.00000 820735.33439 829209.95698 0.00000 820736.87125 829209.83631 0.00000 820737.86000 829226.23000 0.00000 820736.52000 829226.36000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idc67da289-04bf-4e17-9eb1-e5fa59d19a87">
<fme:FEATURE_ID>1001137426</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827772.22</fme:EASTING>
<fme:NORTHING>820677.73</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820677.25375 827774.44478 0.00000 820677.20523 827769.94298 0.00000 820678.17021 827769.92675 0.00000 820678.29497 827774.44973 0.00000 820677.25375 827774.44478 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id397db35c-b065-4ef2-b9c8-661910c27669">
<fme:FEATURE_ID>1001137404</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828451.39</fme:EASTING>
<fme:NORTHING>820886.74</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820893.50167 828477.58310 0.00000 820878.49584 828425.17025 0.00000 820879.91033 828424.99050 0.00000 820894.93708 828477.33703 0.00000 820893.50167 828477.58310 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id3755e93c-3c0a-47c7-b97d-847f5db20a88">
<fme:FEATURE_ID>1001137413</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829235.69</fme:EASTING>
<fme:NORTHING>820745.12</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820739.96000 829235.02000 0.00000 820739.69000 829233.56000 0.00000 820750.52000 829236.54000 0.00000 820751.07000 829237.81000 0.00000 820739.96000 829235.02000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id91a5189f-bc94-439a-8fbb-fa05e072a8c3">
<fme:FEATURE_ID>1001137411</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829127.56</fme:EASTING>
<fme:NORTHING>820749.41</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820750.10000 829137.25000 0.00000 820744.86545 829136.64248 0.00000 820747.64880 829115.20074 0.00000 820752.37795 829119.56528 0.00000 820753.77000 829120.85000 0.00000 820751.97000 829137.43000 0.00000 820750.10000 829137.25000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id9086a963-c10c-42a9-8202-654902aa4b64">
<fme:FEATURE_ID>1210009618</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829187.3</fme:EASTING>
<fme:NORTHING>820784.56</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>X</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820751.23921 829193.11949 0.00000 820750.53169 829185.74958 0.00000 820818.07621 829181.48391 0.00000 820818.52000 829188.83000 0.00000 820751.23921 829193.11949 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id46cf6c19-f713-4f24-8cec-7fd334696d81">
<fme:FEATURE_ID>1001137428</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829185.54</fme:EASTING>
<fme:NORTHING>820882.9</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820862.30828 829186.00285 0.00000 820902.74582 829183.03858 0.00000 820902.90145 829185.19990 0.00000 820862.57000 829187.99000 0.00000 820862.30828 829186.00285 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id5a056e3a-99ff-46b0-8a88-d2598926bca4">
<fme:FEATURE_ID>1001137402</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828640.93</fme:EASTING>
<fme:NORTHING>820905.57</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820920.16648 828658.22403 0.00000 820887.66852 828625.07814 0.00000 820890.77060 828623.31587 0.00000 820924.21046 828657.66998 0.00000 820920.16648 828658.22403 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idc2ae10fa-343e-48c9-9816-50f465242c5d">
<fme:FEATURE_ID>1210012480</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828456.18</fme:EASTING>
<fme:NORTHING>820980.08</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820967.64255 828458.98522 0.00000 820967.35425 828456.94762 0.00000 820992.37787 828453.36455 0.00000 820992.67485 828455.46487 0.00000 820967.64255 828458.98522 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idf6b7c016-a063-4dc6-8ab6-c98b9b92dee5">
<fme:FEATURE_ID>1001137399</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828435.74</fme:EASTING>
<fme:NORTHING>820962.16</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820962.30838 828441.25817 0.00000 820960.76612 828430.48790 0.00000 820962.04669 828430.30496 0.00000 820963.52624 828441.08578 0.00000 820962.30838 828441.25817 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id878e162a-e49f-4781-8d1f-86990fb5a478">
<fme:FEATURE_ID>1001137421</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827805.3</fme:EASTING>
<fme:NORTHING>820695.15</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820698.58678 827813.60900 0.00000 820688.21799 827800.34460 0.00000 820695.52994 827800.43991 0.00000 820699.54101 827805.80403 0.00000 820698.58678 827813.60900 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id59971264-26cc-4e8e-a0fa-1df2bac42cfe">
<fme:FEATURE_ID>1001137403</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828505.3</fme:EASTING>
<fme:NORTHING>820886.02</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820877.03751 828526.01503 0.00000 820875.15248 828525.27768 0.00000 820894.91400 828484.45779 0.00000 820896.95186 828484.14309 0.00000 820889.84658 828500.35725 0.00000 820877.03751 828526.01503 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id0094d793-fcf2-4d35-91ed-b49796e62cf6">
<fme:FEATURE_ID>1001137400</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828675.5</fme:EASTING>
<fme:NORTHING>820925.53</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820925.79545 828685.84934 0.00000 820922.96407 828665.49957 0.00000 820925.28247 828665.18380 0.00000 820928.08572 828685.52521 0.00000 820925.79545 828685.84934 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idc99d21a3-74c5-45be-86af-344a7d79a7fd">
<fme:FEATURE_ID>1001137401</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828705.81</fme:EASTING>
<fme:NORTHING>820923.89</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820921.82305 828719.78725 0.00000 820920.34558 828720.00564 0.00000 820925.89964 828692.00421 0.00000 820927.42788 828691.78115 0.00000 820921.82305 828719.78725 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id344c43a7-20e7-446b-a42f-87d8a30be825">
<fme:FEATURE_ID>1001137420</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827628.78</fme:EASTING>
<fme:NORTHING>820695.77</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820698.45441 827638.79236 0.00000 820691.76410 827619.06686 0.00000 820693.27534 827619.10715 0.00000 820699.81220 827638.78916 0.00000 820698.45441 827638.79236 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="ideb00f212-0ac5-4f12-b708-9b3257a445ef">
<fme:FEATURE_ID>1001137409</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829221.77</fme:EASTING>
<fme:NORTHING>820751.57</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820752.85990 829235.82565 0.00000 820743.82811 829209.21661 0.00000 820748.91784 829208.84456 0.00000 820750.80000 829208.74000 0.00000 820759.01000 829233.48000 0.00000 820757.28731 829234.19734 0.00000 820752.85990 829235.82565 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id25d0c939-8f32-457f-af1d-a79557c4ec72">
<fme:FEATURE_ID>1001137408</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829282.29</fme:EASTING>
<fme:NORTHING>820761.68</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820760.19618 829291.19707 0.00000 820758.77000 829290.99000 0.00000 820763.26000 829273.25000 0.00000 820764.62438 829273.15543 0.00000 820760.19618 829291.19707 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id4a06e8ea-54df-48d8-9edb-81496d35be1f">
<fme:FEATURE_ID>1001137416</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829144.67</fme:EASTING>
<fme:NORTHING>820738.22</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820734.05000 829147.67000 0.00000 820733.72000 829146.56000 0.00000 820742.18000 829141.69000 0.00000 820742.56000 829142.96000 0.00000 820734.05000 829147.67000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id5b62eab0-f928-4d02-acec-1a3b6086e781">
<fme:FEATURE_ID>1001137397</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828441.42</fme:EASTING>
<fme:NORTHING>820978.01</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820965.59894 828444.03094 0.00000 820965.33830 828442.32515 0.00000 820990.31885 828438.80148 0.00000 820990.56578 828440.55285 0.00000 820965.59894 828444.03094 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idd0b3dbf2-cb10-416a-9f4b-4e7616f36bee">
<fme:FEATURE_ID>1420004261</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828573.98</fme:EASTING>
<fme:NORTHING>820952.45</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820958.35047 828573.52697 0.00000 820950.06624 828574.86407 0.00000 820950.22065 828576.09930 0.00000 820948.62514 828576.20223 0.00000 820948.57367 828573.01122 0.00000 820949.96331 828573.01122 0.00000 820950.01478 828573.62883 0.00000 820958.19819 828572.54800 0.00000 820958.35047 828573.52697 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id765a0323-c6b9-4eff-984f-a1f557b541bd">
<fme:FEATURE_ID>1001137405</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828605.15</fme:EASTING>
<fme:NORTHING>820886.36</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820885.96332 828615.87599 0.00000 820882.99925 828594.79887 0.00000 820886.75897 828594.38981 0.00000 820889.72663 828615.55224 0.00000 820885.96332 828615.87599 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id4cd1a9d6-d623-415e-b3dc-79ac287e7e01">
<fme:FEATURE_ID>1420004262</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>828571.03</fme:EASTING>
<fme:NORTHING>820973.19</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820975.90319 828571.05543 0.00000 820967.61684 828572.34213 0.00000 820967.56537 828571.26130 0.00000 820975.74879 828570.02607 0.00000 820975.64585 828569.20258 0.00000 820976.93255 828569.09965 0.00000 820977.29283 828572.29066 0.00000 820975.95466 828572.29066 0.00000 820975.90319 828571.05543 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id9a0bc4e7-d365-4b69-a030-85c29fe89c9d">
<fme:FEATURE_ID>1210009617</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829180.87</fme:EASTING>
<fme:NORTHING>820882.29</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>X</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820862.30828 829186.00285 0.00000 820862.02251 829178.67431 0.00000 820902.06908 829175.73852 0.00000 820902.74582 829183.03858 0.00000 820862.30828 829186.00285 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id656a6085-ff18-4711-9475-a51d2efce21d">
<fme:FEATURE_ID>1210009616</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827723.73</fme:EASTING>
<fme:NORTHING>820738.25</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820687.24610 827719.74789 0.00000 820789.97039 827718.46021 0.00000 820789.78377 827727.52100 0.00000 820687.37847 827729.17883 0.00000 820687.24610 827719.74789 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id5fead0ec-2589-4360-8448-f4b7e420649e">
<fme:FEATURE_ID>1001137422</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827847.93</fme:EASTING>
<fme:NORTHING>820695.65</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820693.48136 827851.55440 0.00000 820691.49143 827851.55240 0.00000 820698.78622 827843.24722 0.00000 820698.78972 827845.66209 0.00000 820693.48136 827851.55440 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idfa396512-7210-4dee-a757-bab89b4aacee">
<fme:FEATURE_ID>1001137414</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829083.93</fme:EASTING>
<fme:NORTHING>820747.2</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820749.02206 829092.35535 0.00000 820744.09222 829076.15439 0.00000 820745.40653 829075.73888 0.00000 820750.17289 829090.99281 0.00000 820749.02206 829092.35535 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id4b883367-ae1c-472c-bdeb-9a7958ac5f20">
<fme:FEATURE_ID>1001137424</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827862.12</fme:EASTING>
<fme:NORTHING>820690.81</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820691.02502 827867.34053 0.00000 820689.57467 827866.69432 0.00000 820690.47200 827857.35359 0.00000 820692.11032 827857.31768 0.00000 820691.02502 827867.34053 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id658a0cf8-fe32-4682-8135-4db4c91e15a4">
<fme:FEATURE_ID>1001137410</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829306.62</fme:EASTING>
<fme:NORTHING>820756.82</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820756.23908 829314.33481 0.00000 820754.82000 829314.36000 0.00000 820757.38359 829298.88507 0.00000 820758.81095 829299.07721 0.00000 820756.23908 829314.33481 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idb542ec0e-ad93-4b71-869e-ba9fad90043b">
<fme:FEATURE_ID>1001137427</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827717.46</fme:EASTING>
<fme:NORTHING>820677.15</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820676.73732 827719.93381 0.00000 820676.56851 827715.02255 0.00000 820677.56055 827714.97985 0.00000 820677.72859 827719.91870 0.00000 820676.73732 827719.93381 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idcb5aac36-ca50-4324-b866-6f70da4d2665">
<fme:FEATURE_ID>1001137418</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829165.24</fme:EASTING>
<fme:NORTHING>820732.82</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820732.86459 829174.02270 0.00000 820731.52691 829156.71581 0.00000 820732.82715 829156.67294 0.00000 820734.07952 829173.94009 0.00000 820732.86459 829174.02270 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id701112d4-2b0e-4d33-ae2b-5833613474d6">
<fme:FEATURE_ID>1001137419</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827672.57</fme:EASTING>
<fme:NORTHING>820696.27</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820692.33809 827683.52939 0.00000 820686.70446 827683.65874 0.00000 820700.12609 827661.63800 0.00000 820705.82080 827661.60865 0.00000 820692.33809 827683.52939 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idf9943d0f-2ab5-43b2-a2a4-45c63098fe0b">
<fme:FEATURE_ID>1001137415</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>829060.82</fme:EASTING>
<fme:NORTHING>820740.08</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820741.82701 829068.94513 0.00000 820736.93000 829053.00000 0.00000 820738.45587 829052.98351 0.00000 820743.17914 829068.52593 0.00000 820741.82701 829068.94513 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id6f2c1652-857c-441e-9430-bd7529771830">
<fme:FEATURE_ID>1001137423</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827781.97</fme:EASTING>
<fme:NORTHING>820686.62</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820687.02427 827794.38700 0.00000 820680.71051 827769.88402 0.00000 820686.45179 827769.78745 0.00000 820692.40862 827794.37316 0.00000 820687.02427 827794.38700 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id2fd5905c-b846-4eea-adce-9e360fac2961">
<fme:FEATURE_ID>1001137425</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>827705.03</fme:EASTING>
<fme:NORTHING>820685.92</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>820687.24610 827719.74789 0.00000 820680.21489 827719.88081 0.00000 820685.34050 827689.22599 0.00000 820691.17748 827689.46234 0.00000 820687.24610 827719.74789 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
</gml:FeatureCollection>
