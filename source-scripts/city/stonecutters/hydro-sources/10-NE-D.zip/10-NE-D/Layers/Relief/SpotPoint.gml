<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme SpotPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820672.39400 827465.29551 0.00000</gml:lowerCorner>
<gml:upperCorner>820937.63218 829256.79951 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:SpotPoint gml:id="id6b2d251d-3223-4d07-88e4-d95a35276a29">
<fme:FEATURE_ID>1001110463</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827751.45</fme:EASTING>
<fme:NORTHING>820672.39</fme:NORTHING>
<fme:SPOTHEIGHT>7.4</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820672.39400 827751.45200 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idfb83fe1c-4dcf-43da-9403-4644a0667d09">
<fme:FEATURE_ID>1001110466</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827726.57</fme:EASTING>
<fme:NORTHING>820820.25</fme:NORTHING>
<fme:SPOTHEIGHT>5.8</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>9</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820820.24872 827726.56615 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="id2e5e1a1e-3030-4652-87a0-d66af2d85cc3">
<fme:FEATURE_ID>1001110465</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829256.8</fme:EASTING>
<fme:NORTHING>820922.11</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>3</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820922.10881 829256.79951 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="ide8d35c65-c5f3-4639-9e44-e700ae535cc2">
<fme:FEATURE_ID>1001110464</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828944.67</fme:EASTING>
<fme:NORTHING>820936.86</fme:NORTHING>
<fme:SPOTHEIGHT>4.7</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820936.86446 828944.67123 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
<gml:featureMember>
<fme:SpotPoint gml:id="idbc2d8d20-e58c-4968-b44e-5128542b0ee3">
<fme:FEATURE_ID>1001110467</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SPT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827465.3</fme:EASTING>
<fme:NORTHING>820937.63</fme:NORTHING>
<fme:SPOTHEIGHT>5.6</fme:SPOTHEIGHT>
<fme:HEIGHTVALUEPOSITION>1</fme:HEIGHTVALUEPOSITION>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820937.63218 827465.29551 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:SpotPoint>
</gml:featureMember>
</gml:FeatureCollection>
