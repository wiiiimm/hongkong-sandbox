<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820870.74179 827738.19703</gml:lowerCorner>
<gml:upperCorner>820990.18750 829442.85804</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id0a96c86d-750a-4f14-944e-5c4f2d1cd6a7">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>中石化香港油庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959327</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>829081.408</fme:EASTING>
<fme:NORTHING>820977.685</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70071</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283329</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820977.94113 829081.71489</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="idc5f721c9-9cee-4cee-b7d8-892836381444">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>油庫</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959325</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>828331.375</fme:EASTING>
<fme:NORTHING>820990.1875</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70069</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001284052</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820990.18750 828331.37500</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id405bd6af-dceb-443c-bc79-98ee1aa73d40">
<fme:AnnotationClassID>3</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>埃克森美孚青衣油庫(西)</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>6.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1000959326</fme:FEATURE_ID>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:EASTING>827738.197</fme:EASTING>
<fme:NORTHING>820914.345</fme:NORTHING>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE>70072</fme:ST_CODE>
<fme:LINKFEATURE_ID>1001283322</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820914.34503 827738.19703</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:PlacePointAnno_C gml:id="id112ed576-94aa-45a6-a520-8ee7e3731954">
<fme:AnnotationClassID>0</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>防波堤</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>3.0906256737026</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210000007</fme:FEATURE_ID>
<fme:FEATURECODE>TYP</fme:FEATURECODE>
<fme:EASTING/>
<fme:NORTHING/>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:ST_CODE/>
<fme:LINKFEATURE_ID/>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820870.74179 829442.85804</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
