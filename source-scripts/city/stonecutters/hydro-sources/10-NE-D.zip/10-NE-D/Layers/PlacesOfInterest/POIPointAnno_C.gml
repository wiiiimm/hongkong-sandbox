<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPointAnno_C.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="2">
<gml:lowerCorner>820654.70079 827651.91260</gml:lowerCorner>
<gml:upperCorner>820861.94770 829264.14947</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idc7377895-2459-4756-82c1-3fd30a154c3c">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001164</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827651.91209619</fme:EASTING>
<fme:NORTHING>820684.94364529</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007838</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820684.94365 827651.91260</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id7d2b23ee-a7cc-4c1f-a6eb-dc6a016dd835">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001170</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>829097.20654409</fme:EASTING>
<fme:NORTHING>820783.21941088</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007790</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820786.08579 829106.47157</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id6112a92e-1330-4cec-abca-40924e90b696">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001203</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>829254.88443649</fme:EASTING>
<fme:NORTHING>820740.16176098</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007790</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820743.02814 829264.14947</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id268b861f-9adc-48a4-9e2b-a61e355d1c98">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001235</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827828.10965871</fme:EASTING>
<fme:NORTHING>820683.2530661</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007838</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820683.25307 827828.11016</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id0492e017-4478-4cbf-a325-3e2013512553">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001269</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>829183.30935351</fme:EASTING>
<fme:NORTHING>820708.18760986</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007790</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820711.05399 829192.57438</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="ide3a4b7e7-4a37-4d71-987a-4500fda167f8">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001274</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>827746.7732671</fme:EASTING>
<fme:NORTHING>820654.7007899</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007838</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820654.70079 827746.77377</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="idf9ff7f1d-0fbc-4fc2-b0f6-02714142ae71">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001314</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>828568.37731635</fme:EASTING>
<fme:NORTHING>820859.08132131</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007898</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820861.94770 828577.64235</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
<gml:featureMember>
<fme:POIPointAnno_C gml:id="id06fe1b1a-14de-4b11-9b72-60038e732ed4">
<fme:AnnotationClassID>9</fme:AnnotationClassID>
<fme:Status>0</fme:Status>
<fme:TextString>碼頭</fme:TextString>
<fme:FontName>SMO Chiron Sans HK TT Light</fme:FontName>
<fme:FontSize>5.0001</fme:FontSize>
<fme:Bold>0</fme:Bold>
<fme:Italic>0</fme:Italic>
<fme:Underline>0</fme:Underline>
<fme:Angle>0</fme:Angle>
<fme:FontLeading>1</fme:FontLeading>
<fme:WordSpacing>200</fme:WordSpacing>
<fme:CharacterWidth>100</fme:CharacterWidth>
<fme:CharacterSpacing>20</fme:CharacterSpacing>
<fme:FlipAngle>180</fme:FlipAngle>
<fme:FEATURE_ID>1210001413</fme:FEATURE_ID>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:EASTING>829146.53282581</fme:EASTING>
<fme:NORTHING>820836.37720658</fme:NORTHING>
<fme:LINKFEATURE_ID>1210007790</fme:LINKFEATURE_ID>
<fme:LASTUPDATEDATE>20230906</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="2">
<gml:pos>820839.24359 829155.79786</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPointAnno_C>
</gml:featureMember>
</gml:FeatureCollection>
