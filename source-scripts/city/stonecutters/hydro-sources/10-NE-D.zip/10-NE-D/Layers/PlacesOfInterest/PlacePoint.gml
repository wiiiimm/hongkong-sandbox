<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PlacePoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820940.00141 827644.99861 0.00000</gml:lowerCorner>
<gml:upperCorner>820940.00141 827644.99861 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PlacePoint gml:id="id5f4263bd-6f48-4dc4-ae47-14842185804d">
<fme:FEATURE_ID>1001283322</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>4</fme:FEATURESUBTYPE>
<fme:FEATURECODE>SIT</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827645</fme:EASTING>
<fme:NORTHING>820940</fme:NORTHING>
<fme:ST_CODE>70072</fme:ST_CODE>
<fme:ENGLISHNAME>ExxonMobil Hong Kong Limited Tsing Yi Terminal (West)</fme:ENGLISHNAME>
<fme:CHINESENAME>埃克森美孚香港有限公司青衣油庫(西)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:ALIAS_CHINESENAME/>
<fme:ALIAS_ENGLISHNAME/>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820940.00141 827644.99861 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:PlacePoint>
</gml:featureMember>
</gml:FeatureCollection>
