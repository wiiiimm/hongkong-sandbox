<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme POIPoint.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>820678.00000 827745.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>820989.58851 829654.81300 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:POIPoint gml:id="idba6157bd-c04b-47d7-b901-f81c5db3eb78">
<fme:FEATURE_ID>1210007838</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827745</fme:EASTING>
<fme:NORTHING>820678</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Esso Pier No.1</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣埃索1號碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820678.00000 827745.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id47ba765c-b221-4c4f-afc2-1ee8a9ca3987">
<fme:FEATURE_ID>1210007790</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829192</fme:EASTING>
<fme:NORTHING>820739</fme:NORTHING>
<fme:ENGLISHNAME>Sinopec Hong Kong Oil Terminal Pier</fme:ENGLISHNAME>
<fme:CHINESENAME>中石化香港油庫碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820739.00000 829192.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idea5004ae-733f-4fa5-a34b-ac3b01e0f0ca">
<fme:FEATURE_ID>1000973838</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>827791.86</fme:EASTING>
<fme:NORTHING>820813.47</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820813.46655 827791.85885 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id832e904f-35cf-4bb8-8882-b60e82e3ca11">
<fme:FEATURE_ID>1210035139</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829541.46</fme:EASTING>
<fme:NORTHING>820859.34</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820859.34400 829541.46400 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="idf5508994-b6b8-482f-9043-1cc602bb3fdd">
<fme:FEATURE_ID>1210007898</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FER</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828574</fme:EASTING>
<fme:NORTHING>820883</fme:NORTHING>
<fme:ENGLISHNAME>Tsing Yi Esso Pier No.2</fme:ENGLISHNAME>
<fme:CHINESENAME>青衣埃索2號碼頭</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820883.00000 828574.00000 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id423e76b5-c9e5-4d9a-b542-9e4a6855e6b6">
<fme:FEATURE_ID>1210035138</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>NAU</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>829654.81</fme:EASTING>
<fme:NORTHING>820936.81</fme:NORTHING>
<fme:ENGLISHNAME>Nautical Navigation Beacon</fme:ENGLISHNAME>
<fme:CHINESENAME>航標(航海)</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820936.80900 829654.81300 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id3132fd32-6f0d-47c1-9995-63a735ffda9e">
<fme:FEATURE_ID>1420003624</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>11</fme:FEATURESUBTYPE>
<fme:FEATURECODE>HLP</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>1</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828243.69</fme:EASTING>
<fme:NORTHING>820977.77</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20260127</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820977.76593 828243.68658 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
<gml:featureMember>
<fme:POIPoint gml:id="id949e3597-ce5b-48c4-b8e4-950773107e53">
<fme:FEATURE_ID>1000973837</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>10</fme:FEATURESUBTYPE>
<fme:FEATURECODE>EES</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>19</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:FEATUREANGLE>0</fme:FEATUREANGLE>
<fme:DISPLAY>0</fme:DISPLAY>
<fme:EASTING>828361.08</fme:EASTING>
<fme:NORTHING>820989.59</fme:NORTHING>
<fme:ENGLISHNAME>Electricity Substation</fme:ENGLISHNAME>
<fme:CHINESENAME>電力變壓站</fme:CHINESENAME>
<fme:DISTRICT>S</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:pointProperty>
<gml:Point srsName="EPSG:2326" srsDimension="3">
<gml:pos>820989.58851 828361.08063 0.00000</gml:pos>
</gml:Point>
</gml:pointProperty>
</fme:POIPoint>
</gml:featureMember>
</gml:FeatureCollection>
