<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme PedNBikePoly.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>815014.60590 815000.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>817594.54145 818680.40694 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id86206907-9681-4d3c-bdb3-c6b8fd47a5fc">
<fme:FEATURE_ID>1001138316</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817796.46</fme:EASTING>
<fme:NORTHING>815487.54</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815489.41309 817800.19001 0.00000 815485.41535 817800.05547 0.00000 815485.66158 817792.73914 0.00000 815489.65931 817792.87368 0.00000 815489.41309 817800.19001 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="ida5d619ca-50a9-4c52-be94-2bd0ee44570e">
<fme:FEATURE_ID>1001138311</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815864.75</fme:EASTING>
<fme:NORTHING>817122.83</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>817118.92645 815872.19495 0.00000 817116.07446 815869.37953 0.00000 817126.45237 815857.56421 0.00000 817129.81159 815859.80368 0.00000 817118.92645 815872.19495 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id1932fde7-1f95-465a-82c6-2dece3fcbee3">
<fme:FEATURE_ID>1310039445</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818521.59</fme:EASTING>
<fme:NORTHING>816707.64</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816730.84900 818539.53500 0.00000 816727.99800 818538.58200 0.00000 816728.14700 818537.85500 0.00000 816713.93000 818533.36900 0.00000 816704.11176 818530.27531 0.00000 816701.28144 818527.97573 0.00000 816704.18832 818523.91003 0.00000 816718.93700 818503.64800 0.00000 816721.23100 818505.29800 0.00000 816706.67781 818525.32979 0.00000 816704.89700 818527.78100 0.00000 816728.95000 818535.40100 0.00000 816729.10000 818534.89200 0.00000 816732.12800 818535.79300 0.00000 816730.84900 818539.53500 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id874eef53-f915-457a-9356-b00035d2e2b4">
<fme:FEATURE_ID>1001138312</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815805.72</fme:EASTING>
<fme:NORTHING>817067.41</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>817061.99214 815813.27648 0.00000 817059.41836 815810.35275 0.00000 817072.70174 815798.20450 0.00000 817075.39949 815801.15782 0.00000 817061.99214 815813.27648 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id454b840d-59d0-478e-b882-3ed8182721c7">
<fme:FEATURE_ID>1001138317</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817586.99</fme:EASTING>
<fme:NORTHING>815347.32</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815344.86853 817589.21754 0.00000 815342.09757 817585.44903 0.00000 815349.77198 817584.76382 0.00000 815352.54294 817588.53233 0.00000 815344.86853 817589.21754 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="ide9a1a737-1521-49cf-b3dd-27b39236ea34">
<fme:FEATURE_ID>1310039457</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817177.34</fme:EASTING>
<fme:NORTHING>815256.53</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815254.56347 817179.50743 0.00000 815254.24607 817175.52005 0.00000 815258.50058 817175.18138 0.00000 815258.81798 817179.16876 0.00000 815254.56347 817179.50743 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id262bbf25-18cb-448b-8d50-c54eacb1ece0">
<fme:FEATURE_ID>1210024151</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818607.87</fme:EASTING>
<fme:NORTHING>815356.48</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815356.70500 818612.47900 0.00000 815352.14508 818606.00515 0.00000 815355.63256 818603.12419 0.00000 815361.09122 818609.64426 0.00000 815356.70500 818612.47900 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id84432ff0-097b-497f-bac4-a7e58509dd04">
<fme:FEATURE_ID>1310039458</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818630.57</fme:EASTING>
<fme:NORTHING>815319.28</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815313.79211 818633.84395 0.00000 815312.92071 818629.94003 0.00000 815324.77407 818627.29420 0.00000 815325.64547 818631.19812 0.00000 815313.79211 818633.84395 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="ideddbd24c-4ca6-429d-ac1d-83396862a54a">
<fme:FEATURE_ID>1310039454</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818677.95</fme:EASTING>
<fme:NORTHING>816395.04</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816391.08500 818680.40694 0.00000 816390.64504 818676.43120 0.00000 816398.99406 818675.50728 0.00000 816399.37681 818678.88225 0.00000 816399.62572 818679.42337 0.00000 816391.08500 818680.40694 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idc33f4313-e696-494c-bc20-4efd831816e0">
<fme:FEATURE_ID>1310039447</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815784.27</fme:EASTING>
<fme:NORTHING>817048.46</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>817045.57304 815786.78324 0.00000 817044.90638 815782.83918 0.00000 817051.34196 815781.75139 0.00000 817052.00862 815785.69545 0.00000 817045.57304 815786.78324 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idecb56c5c-0404-422d-87dc-1af14e4a23b8">
<fme:FEATURE_ID>1001138313</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815735.36</fme:EASTING>
<fme:NORTHING>817002.59</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>817001.05912 815739.40355 0.00000 816998.43098 815736.38780 0.00000 817004.14727 815731.29673 0.00000 817006.72161 815734.36040 0.00000 817001.05912 815739.40355 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idac9c89cc-15a3-4ac2-93aa-235809ffca5a">
<fme:FEATURE_ID>1310035884</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>FBR</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815894.43</fme:EASTING>
<fme:NORTHING>816659.03</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20240926</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816642.40371 815907.62853 0.00000 816642.29847 815903.62991 0.00000 816650.25787 815903.42042 0.00000 816652.21193 815902.43164 0.00000 816653.74297 815901.65692 0.00000 816669.77957 815875.48172 0.00000 816673.19034 815877.57137 0.00000 816656.56113 815904.71384 0.00000 816651.26176 815907.39538 0.00000 816642.40371 815907.62853 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id765987ea-e971-41ad-8b2a-df9c876e72a6">
<fme:FEATURE_ID>1310039459</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817088.48</fme:EASTING>
<fme:NORTHING>815288.37</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815287.33972 817091.16565 0.00000 815285.71253 817087.35564 0.00000 815289.39109 817085.78460 0.00000 815291.01828 817089.59461 0.00000 815287.33972 817091.16565 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id3f94de41-dfe7-4f8e-b541-a9264d01af07">
<fme:FEATURE_ID>1001138324</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>816996.26</fme:EASTING>
<fme:NORTHING>815025.01</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815024.77673 817001.34819 0.00000 815020.75851 817000.46506 0.00000 815025.25022 816991.17393 0.00000 815029.26751 816992.04950 0.00000 815024.77673 817001.34819 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id51587aeb-095a-4727-82a4-86d798262274">
<fme:FEATURE_ID>1310039451</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817684.98</fme:EASTING>
<fme:NORTHING>815484.21</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815484.70749 817687.78400 0.00000 815481.39623 817685.42391 0.00000 815483.71787 817682.16661 0.00000 815487.02913 817684.52670 0.00000 815484.70749 817687.78400 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id76962421-dd53-4f17-af12-ccf99a1a67c6">
<fme:FEATURE_ID>1001138323</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818446.91</fme:EASTING>
<fme:NORTHING>815030.79</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815029.62816 818450.46494 0.00000 815026.84552 818447.57209 0.00000 815031.98416 818443.34652 0.00000 815034.71577 818446.27731 0.00000 815029.62816 818450.46494 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="ide0ce46e1-56b2-4453-8084-cbaa40c83fc5">
<fme:FEATURE_ID>1310039460</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>816055.91</fme:EASTING>
<fme:NORTHING>817591.7</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>817592.15935 816058.74489 0.00000 817588.84854 816056.29055 0.00000 817591.23064 816053.07719 0.00000 817594.54145 816055.53153 0.00000 817592.15935 816058.74489 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="ida90fafcc-b53d-45dd-91a5-892c7c231e67">
<fme:FEATURE_ID>1310039449</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815870.61</fme:EASTING>
<fme:NORTHING>816715.64</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816714.17331 815873.10993 0.00000 816713.20846 815869.04063 0.00000 816717.10056 815868.11779 0.00000 816718.06541 815872.18709 0.00000 816714.17331 815873.10993 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="ide3dc0509-a31b-4c11-8938-bcba5e45f1cb">
<fme:FEATURE_ID>1310039456</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817636.27</fme:EASTING>
<fme:NORTHING>815052.12</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815052.90367 817639.03531 0.00000 815049.38137 817637.13967 0.00000 815051.33929 817633.50164 0.00000 815054.86159 817635.39728 0.00000 815052.90367 817639.03531 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id6581ea07-708e-4c9a-a3a7-6f9d22cfc433">
<fme:FEATURE_ID>1001142513</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815000.22</fme:EASTING>
<fme:NORTHING>817477.68</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>817476.10431 815004.94925 0.00000 817475.61340 815000.00000 0.00000 817479.62360 815000.00000 0.00000 817480.08884 815004.59243 0.00000 817476.10431 815004.94925 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="iddce31189-f7cc-4197-b206-346ab19ab163">
<fme:FEATURE_ID>1310039455</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817758.33</fme:EASTING>
<fme:NORTHING>815583.9</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815583.71914 817760.26266 0.00000 815581.03797 817760.18152 0.00000 815581.15896 817756.18335 0.00000 815584.10431 817756.27248 0.00000 815585.48740 817756.49882 0.00000 815587.12848 817756.90920 0.00000 815586.15809 817760.78971 0.00000 815584.67782 817760.41954 0.00000 815583.71914 817760.26266 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id26299024-1d88-4900-84f0-a59d9eab4774">
<fme:FEATURE_ID>1001138310</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815923</fme:EASTING>
<fme:NORTHING>817384.15</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20250815</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>817390.80120 815935.07991 0.00000 817384.26739 815934.57731 0.00000 817380.83295 815933.82341 0.00000 817381.41672 815931.17929 0.00000 817383.62000 815927.39700 0.00000 817383.38500 815920.20100 0.00000 817359.80719 815914.24261 0.00000 817360.27214 815910.92261 0.00000 817360.27225 815910.92183 0.00000 817360.27306 815910.91603 0.00000 817360.44814 815910.96977 0.00000 817360.45068 815910.97046 0.00000 817360.54522 815910.99943 0.00000 817386.57192 815917.51521 0.00000 817385.76646 815927.60260 0.00000 817385.69142 815928.37857 0.00000 817387.61806 815931.39418 0.00000 817393.30000 815931.80000 0.00000 817391.62225 815934.00221 0.00000 817390.80120 815935.07991 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idd215b8a6-4b11-41a1-ab56-f5d190339cb9">
<fme:FEATURE_ID>1001138322</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818484.66</fme:EASTING>
<fme:NORTHING>815038.45</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815042.86045 818486.98421 0.00000 815031.83488 818485.78031 0.00000 815036.44085 818482.25181 0.00000 815043.05914 818482.98204 0.00000 815042.86045 818486.98421 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idc9d63371-17b8-4da5-9750-a60adcbfdefc">
<fme:FEATURE_ID>1001138314</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815784.4</fme:EASTING>
<fme:NORTHING>816890.96</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816888.30292 815792.70264 0.00000 816884.27496 815790.38439 0.00000 816893.62367 815776.08635 0.00000 816897.64188 815778.41951 0.00000 816888.30292 815792.70264 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id8b52856e-e10c-4f34-9f04-32974db6543a">
<fme:FEATURE_ID>1310039446</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815530.36</fme:EASTING>
<fme:NORTHING>816981.59</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816983.32153 815532.73013 0.00000 816979.34947 815532.25821 0.00000 816979.85747 815527.98254 0.00000 816983.82953 815528.45446 0.00000 816983.32153 815532.73013 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id3a2abffb-1716-45b2-a7fc-88604c634c2f">
<fme:FEATURE_ID>1001138319</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818550.17</fme:EASTING>
<fme:NORTHING>815157.43</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815157.52103 818556.20292 0.00000 815153.51757 818545.40470 0.00000 815157.21577 818543.87312 0.00000 815161.41839 818555.20870 0.00000 815157.52103 818556.20292 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id396b4713-320f-4e7f-88aa-0db4dae37c14">
<fme:FEATURE_ID>1001138320</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818543.33</fme:EASTING>
<fme:NORTHING>815107.02</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815107.95155 818548.56319 0.00000 815104.02517 818547.79498 0.00000 815106.09346 818538.07883 0.00000 815110.01131 818538.88544 0.00000 815107.95155 818548.56319 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idebf7e201-26e3-4cfd-8522-b7cc6772334f">
<fme:FEATURE_ID>1001138326</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817120.74</fme:EASTING>
<fme:NORTHING>815019.61</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815022.87523 817124.54103 0.00000 815014.60590 817120.54894 0.00000 815016.34490 817116.94674 0.00000 815024.61422 817120.93882 0.00000 815022.87523 817124.54103 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id47949ad9-f556-4122-af64-e4f123757fb4">
<fme:FEATURE_ID>1310039448</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815916.99</fme:EASTING>
<fme:NORTHING>816860.24</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816858.79400 815919.74100 0.00000 816857.77900 815915.08600 0.00000 816861.68717 815914.23384 0.00000 816862.70217 815918.88884 0.00000 816858.79400 815919.74100 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id081470eb-0bb9-40ec-82ff-37f8d166296d">
<fme:FEATURE_ID>1001138318</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818564.76</fme:EASTING>
<fme:NORTHING>815182.05</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815187.41453 818566.94193 0.00000 815176.48546 818566.57586 0.00000 815176.61443 818562.57792 0.00000 815187.66946 818562.94802 0.00000 815187.41453 818566.94193 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="idfac1e784-78b3-4ab7-92a7-600ab91cc951">
<fme:FEATURE_ID>1310039443</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>815839.61</fme:EASTING>
<fme:NORTHING>816675.22</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816673.48041 815842.28007 0.00000 816672.23901 815838.47759 0.00000 816676.95289 815836.93864 0.00000 816678.19429 815840.74112 0.00000 816673.48041 815842.28007 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id0560d11e-019f-4f0f-b47a-8b11a71458d9">
<fme:FEATURE_ID>1001138325</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817550.66</fme:EASTING>
<fme:NORTHING>815023.07</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815019.58831 817554.79833 0.00000 815017.37813 817551.43885 0.00000 815026.63970 817546.49846 0.00000 815028.69496 817549.93366 0.00000 815019.58831 817554.79833 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id675ff724-7c0d-409d-8e68-aa1ad33a166a">
<fme:FEATURE_ID>1310039453</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>818629.25</fme:EASTING>
<fme:NORTHING>816372.77</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20241217</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>816370.28875 818633.39452 0.00000 816368.08350 818628.91368 0.00000 816369.12443 818628.60790 0.00000 816369.98880 818628.35179 0.00000 816370.87011 818627.97408 0.00000 816371.53321 818627.62674 0.00000 816372.27855 818627.17306 0.00000 816372.97308 818626.74311 0.00000 816373.70496 818626.29761 0.00000 816374.22110 818625.87256 0.00000 816374.80867 818625.28500 0.00000 816375.92540 818623.73978 0.00000 816376.20682 818629.11566 0.00000 816376.67625 818629.99863 0.00000 816370.28875 818633.39452 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
<gml:featureMember>
<fme:PedNBikePoly gml:id="id2a091fe8-072d-4c9a-8703-f0185d97a828">
<fme:FEATURE_ID>1001138321</fme:FEATURE_ID>
<fme:FEATURESUBTYPE>1</fme:FEATURESUBTYPE>
<fme:FEATURECODE>BRI</fme:FEATURECODE>
<fme:DATASTATUS>E</fme:DATASTATUS>
<fme:DATASOURCE>2</fme:DATASOURCE>
<fme:DATALEVEL>OG</fme:DATALEVEL>
<fme:EASTING>817089.08</fme:EASTING>
<fme:NORTHING>815054.92</fme:NORTHING>
<fme:ENGLISHNAME/>
<fme:CHINESENAME/>
<fme:DISTRICT>T</fme:DISTRICT>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>815056.75164 817093.85966 0.00000 815050.20938 817087.07053 0.00000 815053.08969 817084.29495 0.00000 815059.63195 817091.08409 0.00000 815056.75164 817093.85966 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:PedNBikePoly>
</gml:featureMember>
</gml:FeatureCollection>
