<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydroPolygon.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>813956.16100 818000.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>814124.38400 818097.84800 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydroPolygon gml:id="id03d76ad6-ff38-4dcf-80cd-3bf8a9980981">
<fme:HYDROPOLYGONTYPE>PON</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1109203258</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>813989.02360 818000.47980 0.00000 813988.97895 818000.00000 0.00000 813992.90436 818000.00000 0.00000 813992.26290 818001.06740 0.00000 813991.10040 818001.67630 0.00000 813989.85750 818001.42750 0.00000 813989.02360 818000.47980 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id20deba4a-6a52-42ee-a873-0a383a568d87">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104404241</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>813958.12400 818035.87700 0.00000 813956.16100 818035.38900 0.00000 813957.03800 818031.69400 0.00000 813959.12800 818032.20700 0.00000 813958.12400 818035.87700 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id7b047a75-cd5f-4262-97e0-932a7e2d7411">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104404151</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>813957.73800 818065.92600 0.00000 813956.83700 818065.85900 0.00000 813956.90600 818065.12100 0.00000 813957.72789 818065.13798 0.00000 813957.73837 818065.92603 0.00000 813957.73800 818065.92600 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id02a6dc33-5cc5-4497-bb82-852cf93cd16f">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104403312</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>814031.33500 818074.57300 0.00000 814031.30100 818073.78600 0.00000 814032.26800 818073.90300 0.00000 814032.19900 818074.59000 0.00000 814031.33500 818074.57300 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id6a6487c6-069c-4190-8f74-9a259fcb413d">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104403311</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>814123.21693 818083.58695 0.00000 814122.67724 818082.16009 0.00000 814123.86773 818081.79213 0.00000 814124.38400 818083.15300 0.00000 814123.21693 818083.58695 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="idde7b2811-4bff-42ef-a515-32655e6cdd40">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104402106</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>813980.30600 818097.84800 0.00000 813979.85500 818096.04800 0.00000 813981.58100 818095.77600 0.00000 813982.00700 818097.57600 0.00000 813980.30600 818097.84800 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
</gml:FeatureCollection>
