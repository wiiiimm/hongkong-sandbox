<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydroLine.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>813814.17480 818000.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>813888.89372 818042.80628 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydroLine gml:id="id78fa056c-64bf-4c78-998b-9545a2fb084b">
<fme:HYDROLINETYPE>DRA</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1810025405</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813840.85914 818000.00000 0.00000 813846.58713 818018.13865 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
<gml:featureMember>
<fme:HydroLine gml:id="id1355ba09-b91e-444c-b37b-9a363113a0d5">
<fme:HYDROLINETYPE>DRA</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1810025407</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813888.89372 818008.97115 0.00000 813885.41276 818007.05409 0.00000 813883.58240 818006.04607 0.00000 813880.56410 818005.61548 0.00000 813877.31390 818005.66876 0.00000 813874.27683 818006.09502 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
<gml:featureMember>
<fme:HydroLine gml:id="id05e9d2ea-82fe-4801-bf93-0fc00d51fc75">
<fme:HYDROLINETYPE>DRA</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1810025406</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813877.52202 818000.00000 0.00000 813874.27683 818006.09502 0.00000 813872.57181 818006.14830 0.00000 813868.84207 818005.45563 0.00000 813862.02199 818006.89425 0.00000 813856.37410 818009.93132 0.00000 813846.58713 818018.13865 0.00000 813845.53446 818019.02142 0.00000 813834.36866 818024.58385 0.00000 813821.90068 818032.94912 0.00000 813816.35936 818037.37152 0.00000 813817.82514 818039.20816 0.00000 813814.17480 818042.80628 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
</gml:FeatureCollection>
