<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme Shoreline.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>814400.00000 817879.59943 0.00000</gml:lowerCorner>
<gml:upperCorner>814675.57566 818000.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:Shoreline gml:id="idd0f7d343-1231-4238-a3ac-f547a0993680">
<fme:SHORELINEID>1810001807</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>814452.61772 817903.27450 0.00000 814453.89039 817905.84077 0.00000 814460.19374 817908.63228 0.00000 814468.66042 817910.11395 0.00000 814475.22210 817911.17228 0.00000 814487.92213 817913.07728 0.00000 814506.54883 817916.88729 0.00000 814536.16600 817925.88100 0.00000 814570.76100 817938.09300 0.00000 814602.87700 817954.29000 0.00000 814623.52100 817965.46700 0.00000 814649.43000 817981.96300 0.00000 814675.57566 818000.00000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="idde7151e8-0365-47ce-84e1-bef9a0aea371">
<fme:SHORELINEID>1810001808</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>814400.00000 817879.59943 0.00000 814404.41400 817880.99700 0.00000 814419.80942 817887.14366 0.00000 814423.94355 817888.86345 0.00000 814427.51543 817889.52491 0.00000 814431.55033 817890.12022 0.00000 814438.56180 817890.88090 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
</gml:FeatureCollection>
