<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme Shoreline.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>813514.54300 818173.30200 0.00000</gml:lowerCorner>
<gml:upperCorner>813800.00000 818704.36900 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:Shoreline gml:id="idf6423e27-72f3-4c98-9658-7c1969e406a8">
<fme:SHORELINEID>1104371095</fme:SHORELINEID>
<fme:SHORELINETYPE>SWA</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813800.00000 818283.22100 0.00000 813797.40700 818283.72000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id5af3d8db-8f17-4610-a944-7e18602da864">
<fme:SHORELINEID>1104371096</fme:SHORELINEID>
<fme:SHORELINETYPE>SWA</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813732.11807 818408.24872 0.00000 813733.95282 818409.02740 0.00000 813734.10186 818409.15539 0.00000 813734.11547 818409.30366 0.00000 813729.01232 818420.82601 0.00000 813727.52998 818420.24808 0.00000 813720.46470 818436.09482 0.00000 813719.85500 818435.87400 0.00000 813714.30360 818448.15817 0.00000 813705.25800 818468.36200 0.00000 813689.32815 818504.40007 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id5c1cce33-f046-4f33-820d-caf7e9e94c31">
<fme:SHORELINEID>1104372206</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813597.30400 818673.23800 0.00000 813598.38900 818674.52200 0.00000 813598.70700 818675.71400 0.00000 813598.64100 818676.42200 0.00000 813598.15100 818677.56900 0.00000 813595.68500 818679.89700 0.00000 813593.95600 818681.83100 0.00000 813591.79600 818684.02200 0.00000 813589.59700 818686.23400 0.00000 813588.06900 818687.98400 0.00000 813585.35500 818690.75500 0.00000 813581.61200 818695.24600 0.00000 813581.43400 818695.56500 0.00000 813574.88300 818703.74300 0.00000 813573.39700 818704.36900 0.00000 813571.54800 818703.95400 0.00000 813569.17100 818702.95700 0.00000 813561.18700 818699.30500 0.00000 813546.67300 818692.44300 0.00000 813540.00000 818689.83600 0.00000 813529.68500 818684.37600 0.00000 813520.58200 818679.90000 0.00000 813517.68575 818678.69551 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="idd6ae322b-f4fd-49a9-9b47-23cb508601b5">
<fme:SHORELINEID>1104372209</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813514.54300 818678.34100 0.00000 813516.37892 818678.85356 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="ide8753ce9-876e-4463-8a0f-c02fb6597f24">
<fme:SHORELINEID>1104372207</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813517.68575 818678.69551 0.00000 813517.62200 818678.66900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id2d923c92-76e8-410d-b347-81141932fcf8">
<fme:SHORELINEID>1104372189</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813734.31400 818175.73900 0.00000 813735.60800 818178.15400 0.00000 813734.93400 818270.03000 0.00000 813734.35000 818379.84800 0.00000 813729.00900 818383.53000 0.00000 813731.01500 818385.81800 0.00000 813735.50100 818405.26400 0.00000 813734.56100 818405.31400 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="idae14505e-a4fd-440f-8291-c806dfac6878">
<fme:SHORELINEID>1104371098</fme:SHORELINEID>
<fme:SHORELINETYPE>SWA</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813516.37892 818678.85356 0.00000 813518.85700 818681.44100 0.00000 813520.23400 818682.38200 0.00000 813520.84600 818681.58200 0.00000 813519.25600 818680.52400 0.00000 813517.68575 818678.69551 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id10e311bb-1698-4412-935b-ff9254d16a25">
<fme:SHORELINEID>1104372188</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813732.80600 818405.74500 0.00000 813733.69600 818405.66900 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id2ea79048-4c34-448d-ba75-b50cc444dba8">
<fme:SHORELINEID>1104372187</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813738.89100 818173.30200 0.00000 813779.71500 818174.37200 0.00000 813780.80800 818174.42400 0.00000 813793.13600 818283.97100 0.00000 813793.31300 818286.05500 0.00000 813793.73100 818286.43200 0.00000 813794.25700 818286.76800 0.00000 813794.77500 818286.98800 0.00000 813795.32000 818287.12400 0.00000 813796.12900 818286.45500 0.00000 813796.76800 818285.62200 0.00000 813797.20400 818284.66700 0.00000 813797.40700 818283.72000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id27458f4f-4674-47cc-a06f-af88b7c07ecf">
<fme:SHORELINEID>1104371097</fme:SHORELINEID>
<fme:SHORELINETYPE>SWA</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813689.32815 818504.40007 0.00000 813676.46400 818533.06200 0.00000 813636.18045 818585.23996 0.00000 813634.71200 818587.14200 0.00000 813599.21900 818669.33600 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="idb99eb79d-2e7a-48e7-8c1e-89f17aa9361f">
<fme:SHORELINEID>1104372208</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>813516.37892 818678.85356 0.00000 813516.40200 818678.86000 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
</gml:FeatureCollection>
