<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydroPolygon.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>812727.02461 802924.43656 0.00000</gml:lowerCorner>
<gml:upperCorner>812771.87538 802993.35100 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydroPolygon gml:id="id029bc3a3-a5ea-46b5-b457-ce65b331f781">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1109203256</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>812751.24050 802993.35100 0.00000 812750.24420 802993.25870 0.00000 812750.34030 802992.52250 0.00000 812751.17880 802992.60380 0.00000 812751.24050 802993.35100 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id2432f777-e518-4e8b-8677-d3edf3a2e868">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1109203183</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>812765.76508 802992.60931 0.00000 812764.82928 802992.36108 0.00000 812765.13152 802991.42894 0.00000 812765.13849 802991.38593 0.00000 812766.06708 802991.67712 0.00000 812765.76508 802992.60931 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id18cb57ac-79ac-42f2-8091-a7940a7b7fbe">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104404087</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>812751.94085 802984.88666 0.00000 812750.83647 802984.59870 0.00000 812751.08726 802983.50899 0.00000 812752.23249 802983.77256 0.00000 812751.94085 802984.88666 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="ida1513960-eb56-431d-83ad-86219fdfba77">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104402869</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>812727.22790 802929.88270 0.00000 812727.02461 802929.03170 0.00000 812727.90820 802928.80940 0.00000 812728.10960 802929.65540 0.00000 812727.22790 802929.88270 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id6fa2683d-734c-423b-a216-a772e5a541db">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104402868</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>812733.33104 802984.42097 0.00000 812733.17650 802983.31350 0.00000 812734.34039 802983.15109 0.00000 812734.46547 802984.29591 0.00000 812733.33104 802984.42097 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="idb336b917-57a2-4abb-ac60-849b2bae0188">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104402867</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>812771.35387 802925.96403 0.00000 812770.33580 802925.44819 0.00000 812770.81221 802924.43656 0.00000 812771.87538 802924.93724 0.00000 812771.35387 802925.96403 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
</gml:FeatureCollection>
