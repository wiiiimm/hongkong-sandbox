<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme Shoreline.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>812018.47400 803750.00000 0.00000</gml:lowerCorner>
<gml:upperCorner>812084.78614 803790.29575 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:Shoreline gml:id="id2db1a1b2-3f13-47c9-a742-5d379bf1c8d7">
<fme:SHORELINEID>1104371189</fme:SHORELINEID>
<fme:SHORELINETYPE>SWA</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812075.96274 803750.00000 0.00000 812084.78614 803784.62091 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id20de63e0-a496-4739-828a-64d58d31331d">
<fme:SHORELINEID>1810010441</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20250818</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812032.07337 803753.36500 0.00000 812031.88300 803753.74200 0.00000 812032.12700 803757.01300 0.00000 812033.12000 803760.00900 0.00000 812034.31600 803762.26200 0.00000 812036.97800 803763.99300 0.00000 812037.82926 803766.14404 0.00000 812037.17838 803771.28755 0.00000 812038.81959 803775.04068 0.00000 812039.44288 803777.70979 0.00000 812040.33930 803780.79746 0.00000 812042.43095 803784.18394 0.00000 812046.36023 803787.70763 0.00000 812054.39697 803789.19591 0.00000 812058.35511 803789.62467 0.00000 812064.55040 803790.29575 0.00000 812072.80541 803788.94638 0.00000 812078.28230 803787.20012 0.00000 812083.36231 803785.05699 0.00000 812084.63231 803784.58074 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id8fe775e2-112e-4454-8576-06505d41412a">
<fme:SHORELINEID>1104372337</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812018.47400 803750.00000 0.00000 812019.79566 803751.11008 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
<gml:featureMember>
<fme:Shoreline gml:id="id0a1a9ca9-3343-4eb9-885d-2d453e9853c3">
<fme:SHORELINEID>1104372333</fme:SHORELINEID>
<fme:SHORELINETYPE>HWM</fme:SHORELINETYPE>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812019.79566 803751.11008 0.00000 812020.16600 803751.41400 0.00000 812023.36700 803751.82800 0.00000 812025.89700 803751.59900 0.00000 812027.81500 803750.87600 0.00000 812028.62200 803750.50500 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:Shoreline>
</gml:featureMember>
</gml:FeatureCollection>
