<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydroPolygon.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>812600.00000 803279.58700 0.00000</gml:lowerCorner>
<gml:upperCorner>813069.89100 803750.00000 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydroPolygon gml:id="id98ef6cd4-24a0-4e95-b421-b773d473a241">
<fme:HYDROPOLYGONTYPE>NUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104404902</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>813025.60034 803305.16374 0.00000 813024.16883 803304.59608 0.00000 813028.52700 803297.42100 0.00000 813035.07400 803280.59800 0.00000 813052.59500 803281.62800 0.00000 813069.66400 803279.58700 0.00000 813069.79236 803280.38767 0.00000 813069.89100 803281.00300 0.00000 813052.77000 803283.10300 0.00000 813036.08800 803282.10100 0.00000 813029.92506 803297.98127 0.00000 813025.60034 803305.16374 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="iddc6291bc-76f6-4879-936f-d3a647fcf9ee">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104404088</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>813034.69800 803483.87000 0.00000 813033.50500 803483.58200 0.00000 813033.79400 803482.18500 0.00000 813035.01400 803482.46500 0.00000 813034.69800 803483.87000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id7fc43b08-85a4-4199-9c3b-14b6c4c48be5">
<fme:HYDROPOLYGONTYPE>CUL</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104402871</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>813032.59600 803362.91700 0.00000 813031.87100 803362.41000 0.00000 813032.35600 803361.64800 0.00000 813033.14300 803362.13300 0.00000 813032.59600 803362.91700 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id032acc04-9dbe-4a48-a6cb-7df678cbc627">
<fme:HYDROPOLYGONTYPE>PON</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104401544</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>812600.00000 803750.00000 0.00000 812600.00000 803657.59247 0.00000 812620.52859 803654.15860 0.00000 812626.09200 803653.22800 0.00000 812636.83066 803672.58345 0.00000 812644.52900 803686.45900 0.00000 812648.88300 803684.27900 0.00000 812677.29300 803735.88100 0.00000 812685.01118 803750.00000 0.00000 812600.00000 803750.00000 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
<gml:featureMember>
<fme:HydroPolygon gml:id="id89f1e994-a3a1-4b16-b814-532e96586fb1">
<fme:HYDROPOLYGONTYPE>BRE</fme:HYDROPOLYGONTYPE>
<fme:STATUS>E</fme:STATUS>
<fme:HYDROPOLYGONID>1104401134</fme:HYDROPOLYGONID>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:surfaceProperty>
<gml:Surface srsName="EPSG:2326" srsDimension="3">
<gml:patches>
<gml:PolygonPatch>
<gml:exterior>
<gml:LinearRing>
<gml:posList>812600.00000 803368.84200 0.00000 812600.00000 803335.95000 0.00000 812600.26200 803335.85500 0.00000 812609.35000 803333.36300 0.00000 812617.71600 803331.59600 0.00000 812624.04200 803330.98100 0.00000 812629.98200 803331.91400 0.00000 812636.56100 803335.12600 0.00000 812640.10500 803339.57300 0.00000 812641.57500 803344.01100 0.00000 812642.75200 803349.44400 0.00000 812642.24400 803352.89400 0.00000 812641.92100 803354.47900 0.00000 812640.23200 803357.51600 0.00000 812636.80600 803360.42800 0.00000 812633.59000 803362.45700 0.00000 812629.50500 803364.32300 0.00000 812627.93500 803365.18500 0.00000 812625.73500 803366.18500 0.00000 812621.96800 803367.29200 0.00000 812616.65200 803367.99200 0.00000 812611.79700 803368.56000 0.00000 812605.62700 803369.00100 0.00000 812600.00000 803368.84200 0.00000</gml:posList>
</gml:LinearRing>
</gml:exterior>
</gml:PolygonPatch>
</gml:patches>
</gml:Surface>
</gml:surfaceProperty>
</fme:HydroPolygon>
</gml:featureMember>
</gml:FeatureCollection>
