<?xml version="1.0" encoding="UTF-8"?>
<gml:FeatureCollection xmlns:fme="http://www.safe.com/gml/fme" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:gml="http://www.opengis.net/gml" xsi:schemaLocation="http://www.safe.com/gml/fme HydroLine.xsd">
<gml:boundedBy>
<gml:Envelope srsName="EPSG:2326" srsDimension="3">
<gml:lowerCorner>812720.32048 802904.52840 0.00000</gml:lowerCorner>
<gml:upperCorner>812747.50979 802984.37739 0.00000</gml:upperCorner>
</gml:Envelope>
</gml:boundedBy>
<gml:featureMember>
<fme:HydroLine gml:id="id3070bd8f-be7c-464f-b4a3-c8710678c14c">
<fme:HYDROLINETYPE>STR</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1104339551</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812729.76920 802925.93040 0.00000 812729.61200 802927.44680 0.00000 812729.55150 802927.72230 0.00000 812729.04680 802928.69270 0.00000 812728.04825 802929.39809 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
<gml:featureMember>
<fme:HydroLine gml:id="idc97d9c4a-8f90-49f0-8db5-bdda2af32af0">
<fme:HYDROLINETYPE>STR</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1109082404</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812733.09810 802904.52840 0.00000 812731.87907 802904.93861 0.00000 812731.38305 802905.27507 0.00000 812731.21180 802905.48440 0.00000 812727.90553 802908.98921 0.00000 812725.66872 802911.22789 0.00000 812725.19781 802911.62161 0.00000 812722.62683 802912.69913 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
<gml:featureMember>
<fme:HydroLine gml:id="id035b0e35-d72c-4e87-a762-c91d5d3e6921">
<fme:HYDROLINETYPE>STR</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1109082563</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812727.76828 802914.97156 0.00000 812727.73922 802914.81546 0.00000 812727.25884 802914.20309 0.00000 812726.54959 802913.88257 0.00000 812722.62683 802912.69913 0.00000 812721.46214 802912.32858 0.00000 812720.32048 802912.12794 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
<gml:featureMember>
<fme:HydroLine gml:id="id263f6b5c-1142-4255-b0e4-6b20edf7a287">
<fme:HYDROLINETYPE>STR</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1104339550</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812747.50979 802984.37739 0.00000 812734.48133 802983.90064 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
<gml:featureMember>
<fme:HydroLine gml:id="id15ec2235-681e-4e6f-bf3d-c640e4d276ee">
<fme:HYDROLINETYPE>STR</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1104339553</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812727.17524 802929.66998 0.00000 812726.16150 802930.04810 0.00000 812724.31830 802930.57080 0.00000 812723.91010 802930.89320 0.00000 812723.90180 802931.34320 0.00000 812726.04500 802943.80440 0.00000 812725.52700 802943.86940 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
<gml:featureMember>
<fme:HydroLine gml:id="idf2930213-300c-47bf-b8b2-430b39678ecf">
<fme:HYDROLINETYPE>STR</fme:HYDROLINETYPE>
<fme:HYDROLINEID>1109082508</fme:HYDROLINEID>
<fme:STATUS>E</fme:STATUS>
<fme:LASTUPDATEDATE>20230903</fme:LASTUPDATEDATE>
<gml:curveProperty>
<gml:LineString srsName="EPSG:2326" srsDimension="3">
<gml:posList>812727.95540 802915.58070 0.00000 812727.77055 802914.98372 0.00000 812727.76828 802914.97156 0.00000</gml:posList>
</gml:LineString>
</gml:curveProperty>
</fme:HydroLine>
</gml:featureMember>
</gml:FeatureCollection>
